#!/bin/sh

#创建日志目录
mkdir -p /data/mini_drama/logs

basepath=$(pwd)
exportpath=$basepath"/lib"
confpath=$basepath"/conf"

export LD_LIBRARY_PATH=$exportpath

./mini-drama -c $confpath
