package raw

import (
	"context"
	rawEntity "goserver/app/common/repository/raw"
	"goserver/app/model/dao/raw"
	"time"
)

// ReferralService 端元生配置Service
type ReferralService struct {
	Ctx context.Context
}

type ReferralModel struct {
	HashId         string
	ReferralUrl    string
	BookName       string
	CopyrightOwner string
	CreatedTime    time.Time
}

func NewReferralService(ctx context.Context) *ReferralService {
	return &ReferralService{Ctx: ctx}
}

func (r *ReferralService) Import(res []rawEntity.ReferralEntity) error {
	referralDao := raw.NewReferralDao(r.Ctx)
	e := referralDao.InsertBatchSize(res, 500)
	if e != nil {
		return e
	}
	return nil
}

// 查询指定时间段的数据
func (r *ReferralService) QueryByCreatedTime(startTime, endTime string) ([]*ReferralModel, error) {
	referralDao := raw.NewReferralDao(r.Ctx)
	data, err := referralDao.QueryDataByTime(startTime, endTime)
	if err != nil {
		return nil, err
	}
	return r.ConvertToModel(data)

}

func (r *ReferralService) ConvertToModel(data []rawEntity.ReferralEntity) ([]*ReferralModel, error) {
	var modelData []*ReferralModel
	for _, val := range data {
		modelData = append(modelData, &ReferralModel{
			HashId:         val.HashId,
			ReferralUrl:    val.ReferralUrl,
			BookName:       val.BookName,
			CopyrightOwner: val.CopyrightOwner,
			CreatedTime:    val.CreatedTime,
		})
	}
	return modelData, nil
}
