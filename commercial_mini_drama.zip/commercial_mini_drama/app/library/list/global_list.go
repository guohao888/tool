package list

import (
	fanqie2 "goserver/app/common/dto/fanqie"
	"sync"
)

var (
	Glu  *GlobalUserList
	Glio *GlobalIAAOrderList
	Glpo *GlobalIAPOrderList
)

func Init() {
	Glu = NewGlobalUserList()
	Glio = NewGlobalIAAOrderList()
	Glpo = NewGlobalIAPOrderList()
}

func NewGlobalUserList() *GlobalUserList {
	return &GlobalUserList{list: make([]fanqie2.TomatoUserReq, 0, 10000)}
}

func NewGlobalIAAOrderList() *GlobalIAAOrderList {
	return &GlobalIAAOrderList{list: make([]fanqie2.TomatoIAAOrderReq, 0, 10000)}
}
func NewGlobalIAPOrderList() *GlobalIAPOrderList {
	return &GlobalIAPOrderList{list: make([]fanqie2.TomatoIAPOrderReq, 0, 10000)}
}

func GetGluList() *GlobalUserList {
	return Glu
}

func GetGlioList() *GlobalIAAOrderList {
	return Glio
}

func GetGlpoList() *GlobalIAPOrderList {
	return Glpo
}

type GlobalUserList struct {
	list  []fanqie2.TomatoUserReq
	mutex sync.Mutex
}

func (g *GlobalUserList) Add(item fanqie2.TomatoUserReq) {
	g.mutex.Lock()
	defer g.mutex.Unlock()
	g.list = append(g.list, item)
}

func (g *GlobalUserList) GetList() []fanqie2.TomatoUserReq {
	g.mutex.Lock()
	defer g.mutex.Unlock()
	data := append([]fanqie2.TomatoUserReq(nil), g.list...)
	g.list = g.list[:0]
	return data
}

func (g *GlobalUserList) Restore(data []fanqie2.TomatoUserReq) {
	g.mutex.Lock()
	defer g.mutex.Unlock()
	g.list = append(data, g.list...)
}

type GlobalIAAOrderList struct {
	list  []fanqie2.TomatoIAAOrderReq
	mutex sync.Mutex
}

func (g *GlobalIAAOrderList) Add(item fanqie2.TomatoIAAOrderReq) {
	g.mutex.Lock()
	defer g.mutex.Unlock()
	g.list = append(g.list, item)
}

func (g *GlobalIAAOrderList) GetList() []fanqie2.TomatoIAAOrderReq {
	g.mutex.Lock()
	defer g.mutex.Unlock()
	data := append([]fanqie2.TomatoIAAOrderReq(nil), g.list...)
	g.list = g.list[:0]
	return data
}

func (g *GlobalIAAOrderList) Restore(data []fanqie2.TomatoIAAOrderReq) {
	g.mutex.Lock()
	defer g.mutex.Unlock()
	g.list = append(data, g.list...)
}

type GlobalIAPOrderList struct {
	list  []fanqie2.TomatoIAPOrderReq
	mutex sync.Mutex
}

func (g *GlobalIAPOrderList) Add(item fanqie2.TomatoIAPOrderReq) {
	g.mutex.Lock()
	defer g.mutex.Unlock()
	g.list = append(g.list, item)
}

func (g *GlobalIAPOrderList) GetList() []fanqie2.TomatoIAPOrderReq {
	g.mutex.Lock()
	defer g.mutex.Unlock()
	data := append([]fanqie2.TomatoIAPOrderReq(nil), g.list...)
	g.list = g.list[:0]
	return data
}

func (g *GlobalIAPOrderList) Restore(data []fanqie2.TomatoIAPOrderReq) {
	g.mutex.Lock()
	defer g.mutex.Unlock()
	g.list = append(data, g.list...)
}
