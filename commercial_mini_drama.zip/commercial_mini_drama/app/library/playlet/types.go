package playlet

type AdvertiserInfo struct {
	AdvertiserId   string `json:"advertiser_id"`
	AdvertiserName string `json:"advertiser_name"`
}
