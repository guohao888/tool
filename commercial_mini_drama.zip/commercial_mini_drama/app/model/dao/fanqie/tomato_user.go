package fanqie

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	dto "goserver/app/common/dto/fanqie"
	repo "goserver/app/common/repository/fanqie"
	"goserver/app/library/driver/dorisdb"
	timeUtil "goserver/app/library/utils/time"
	"goserver/app/model/dao"
	"strconv"
	"strings"
	"time"
)

// TomatoUserDao 番茄用户DAO
type TomatoUserDao struct {
	Ctx context.Context
}

func NewTomatoUserDao(ctx context.Context) *TomatoUserDao {
	return &TomatoUserDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (t *TomatoUserDao) InsertBatchSize(data []*repo.UserEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 3000
	}
	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = t.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (t *TomatoUserDao) buildInsertSentence(tx *gorm.DB, data []*repo.UserEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.IAAUserTableName() + " (device_id, buying_timestamp, distributor_id, app_id, app_name, promotion_id, ad_id, ip, user_agent, buying_date, buying_hour, attributed, book_id, book_name, book_gender, book_category, action_id, project_id, ad_id_v2, mid, clue_token, union_id, mid_id) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.DeviceId,
			v.BuyingTimestamp,
			v.DistributorId,
			v.AppId,
			v.AppName,
			v.PromotionId,
			v.AdId,
			v.Ip,
			v.UserAgent,
			v.BuyingDate,
			v.BuyingHour,
			v.Attributed,
			v.BookId,
			v.BookName,
			v.BookGender,
			v.BookCategory,
			v.ActionId,
			v.ProjectId,
			v.AdIdV2,
			v.Mid,
			v.ClueToken,
			v.UnionId,
			v.MidId,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// Req2Entity 请求参数结构转化
func (t *TomatoUserDao) Req2Entity(data []dto.TomatoUserReq) error {
	var list []*repo.UserEntity
	for _, v := range data {
		// 媒体字段拆分
		mid := strings.Join(v.Mid, ",")
		var midId string
		if len(v.Mid) >= 2 && (v.Mid[0] == "" || v.Mid[0] == "0" || v.Mid[0] == "__MID1__") {
			midId = v.Mid[2]
		} else if len(v.Mid) >= 2 && (v.Mid[2] == "" || v.Mid[2] == "0" || v.Mid[2] == "__MID3__") {
			midId = v.Mid[0]
		}
		// 时间戳格式化
		butTime, _ := strconv.Atoi(v.BuyingTimestamp)
		buyDate := timeUtil.StringFromSecond(int64(butTime))
		buyDateTime, _ := time.ParseInLocation(time.DateTime, buyDate, time.Local)
		info := &repo.UserEntity{
			DeviceId:        v.DeviceId,
			BuyingTimestamp: v.BuyingTimestamp,
			DistributorId:   v.DistributorId,
			AppId:           v.AppId,
			AppName:         v.AppName,
			PromotionId:     v.PromotionId,
			AdId:            v.AdId,
			Ip:              v.Ip,
			UserAgent:       v.UserAgent,
			BuyingDate:      buyDateTime,
			BuyingHour:      buyDate[11:13],
			Attributed:      v.Attributed,
			BookId:          v.BookId,
			BookName:        v.BookName,
			BookGender:      v.BookGender,
			BookCategory:    v.BookCategory,
			ActionId:        v.ActionId,
			ProjectId:       v.ProjectId,
			AdIdV2:          v.AdIdV2,
			Mid:             mid,
			ClueToken:       v.ClueToken,
			UnionId:         v.UnionId,
			MidId:           midId,
		}
		list = append(list, info)
	}
	err := t.InsertBatchSize(list, 3000)
	return err
}
