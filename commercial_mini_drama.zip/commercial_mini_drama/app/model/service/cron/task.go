package cron

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"github.com/tidwall/sjson"
	"github.com/xxl-job/xxl-job-executor-go"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/model/service/accounts"
	"goserver/app/model/service/task"
	"sync"
)

type AppIdTaskRegister struct {
	exec   xxl.Executor
	media  string
	regMap map[string]struct{}
	mu     sync.RWMutex
}

func NewAppIdTaskRegister(media string, exec xxl.Executor) (*AppIdTaskRegister, error) {
	return &AppIdTaskRegister{
		exec:   exec,
		media:  media,
		regMap: make(map[string]struct{}),
	}, nil
}

func (r *AppIdTaskRegister) RegTask(pattern string, task xxl.TaskFunc) {
	r.mu.Lock()
	defer r.mu.Unlock()

	if _, ok := r.regMap[pattern]; !ok {
		r.exec.RegTask(pattern, task)
		r.regMap[pattern] = struct{}{}
	}
}

func (r *AppIdTaskRegister) GetToutiaoAppIds() ([]string, error) {
	oauthConfigService := accounts.NewOauthConfigService(context.Background())
	appIds, err := oauthConfigService.DistinctAppIds(r.media)
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return appIds, nil
}

// ToutiaoAppIdRegTask 任务注册
func (r *AppIdTaskRegister) ToutiaoAppIdRegTask(appIds []string) {

	for _, v := range appIds {
		appId := v // 应用Id

		// 同步头条广告主的推广链数据
		for _, vv := range accountrepo.AppTypes {
			appType := vv // 设置头条小程序类型

			for _, vvv := range accountrepo.Priorities {
				priority := vvv // 优先级

				r.RegTask(fmt.Sprintf("account_promotion_url_sync_toutiao_%s_%s_%s", appType, priority, appId), func(cxt context.Context, param *xxl.RunReq) string {
					if params := param.ExecutorParams; params != "" {
						params, _ = sjson.Set(params, "app_ids.-1", appId)  // 设置头条oauth授权的应用id
						params, _ = sjson.Set(params, "app_type", appType)  // 设置头条小程序类型
						params, _ = sjson.Set(params, "priority", priority) // 优先级
						param.ExecutorParams = params
					}
					return task.AccountPromotionUrlSyncToutiao(cxt, param) // 同步头条广告主的推广链数据
				})
			}
		}
	}

}

// ToutiaoAppIdJobInfoAdd 后台任务创建（没有才创建，有的话不处理）
func (r *AppIdTaskRegister) ToutiaoAppIdJobInfoAdd(appIds []string) {

	for i, appId := range appIds {
		// 同步头条广告主的推广链数据
		for _, appType := range accountrepo.AppTypes {
			for _, priority := range accountrepo.Priorities {
				err := task.AccountPromotionUrlSyncToutiaoJobInfoAdd(i, appId, appType, priority)
				if err != nil {
					log.Errorf("xxl-job admin后台新增任务错误, err: %s", err)
				}
			}
		}
	}

}

func AppIdTaskAutoRegister(ctx context.Context, param *xxl.RunReq) (msg string) {
	appIds, err := toutiaoAppIdTaskRegister.GetToutiaoAppIds()
	if err != nil {
		panic(err)
	}
	toutiaoAppIdTaskRegister.ToutiaoAppIdRegTask(appIds)
	toutiaoAppIdTaskRegister.ToutiaoAppIdJobInfoAdd(appIds)

	return "应用的定时任务自动注册和后台任务自动新增成功"
}
