package mediareport

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/dto/warningdto"
	"goserver/app/common/repository/accounts"
	repo "goserver/app/common/repository/mediareport"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// ReportMediaDao 素材DAO
type ReportMediaDao struct {
	Ctx context.Context
}

func NewReportMediaDao(ctx context.Context) *ReportMediaDao {
	return &ReportMediaDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (r *ReportMediaDao) InsertBatchSize(data []*repo.ReportMediaEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = r.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *ReportMediaDao) buildInsertSentence(tx *gorm.DB, data []*repo.ReportMediaEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.ReportMediaTableName() + " ( advertiser_id, material_id, project_id, promotion_id, create_time, create_hour, promotion_name, convert_cnt, click_cnt, show_cnt, stat_cost, active, active_pay ) VALUES "
	var vals []interface{}
	for _, row := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			row.AdvertiserId,
			row.MaterialId,
			row.ProjectId,
			row.PromotionId,
			row.CreateTime,
			row.CreateHour,
			row.PromotionName,
			row.ConvertCnt,
			row.ClickCnt,
			row.ShowCnt,
			row.StatCost,
			row.Active,
			row.ActivePay,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// GetMaterialIds 获取素材ID
func (r *ReportMediaDao) GetMaterialIds(materialId string) (data []warningdto.MaStruct, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(repo.ReportMediaTableName()).Select("material_id")
	if materialId != "" {
		q = q.Where("material_id = ?", materialId)
	}
	err = q.Group("material_id").Limit(100).Find(&data).Error
	if err != nil {
		return
	}
	return
}

// GetAdvertiserIds 获取账号ID
func (r *ReportMediaDao) GetAdvertiserIds(advertiserId string) (data []warningdto.Advertiser, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(repo.ReportMediaTableName()).Select("advertiser_id")
	if advertiserId != "" {
		q = q.Where("advertiser_id = ?", advertiserId)
	}
	err = q.Group("advertiser_id").Limit(100).Find(&data).Error
	if err != nil {
		return
	}
	return
}

// GetAlbumName 获取剧目名称
func (r *ReportMediaDao) GetAlbumName(albumName string) (data []warningdto.Album, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.AccountDistributorPromotionUrlTableName()).Select("book_name")
	if albumName != "" {
		q = q.Where("book_name like ?", "%"+albumName+"%")
	}
	err = q.Group("book_name").Limit(100).Find(&data).Error
	if err != nil {
		return
	}
	return
}

// GetOptimizer 获取剧目名称
func (r *ReportMediaDao) GetOptimizer(optimizer string) (data []warningdto.Optimizer, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.AccountDistributorPromotionUrlTableName()).Select("optimizer_name")
	if optimizer != "" {
		q = q.Where("optimizer_name like ?", "%"+optimizer+"%")
	}
	err = q.Group("optimizer_name").Limit(100).Find(&data).Error
	if err != nil {
		return
	}
	return
}

// GetMedia 获取媒体名称
func (r *ReportMediaDao) GetMedia(media string) (data []warningdto.MediaStruct, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.AccountDistributorPromotionUrlTableName()).Select("media")
	if media != "" {
		q = q.Where("media like ?", "%"+media+"%")
	}
	err = q.Group("media").Limit(100).Find(&data).Error
	if err != nil {
		return
	}
	return
}
