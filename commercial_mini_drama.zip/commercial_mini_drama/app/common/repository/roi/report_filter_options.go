package roi

import (
	"goserver/app/common/repository"
	"time"
)

const ReportFilterOptionsTable = "report_filter_options"
const FilterOptionAllDesc = "全部"

// ReportFilterOptions 筛选项表结构体
type ReportFilterOptions struct {
	FilterValue string    `gorm:"column:filter_value;type:varchar(256);not null;default:'';comment:筛选值" json:"filter_value"`
	ValueType   string    `gorm:"column:value_type;type:varchar(256);not null;default:'';comment:筛选类型（媒体：media；推广产品：delivery_product）" json:"value_type"`
	EnumValue   string    `gorm:"column:enum_value;type:varchar(256);not null;default:'';comment:枚举值" json:"enum_value"`
	CreatedAt   time.Time `gorm:"column:created_at;type:datetime;not null;default:CURRENT_TIMESTAMP;comment:创建时间" json:"created_at"`
	UpdatedAt   time.Time `gorm:"column:updated_at;type:datetime;not null;default:CURRENT_TIMESTAMP;comment:更新时间" json:"updated_at"`
}

func (*ReportFilterOptions) TableName() string {
	return ReportDataTableName()
}

func ReportFilterOptionsTableName() string {
	if repository.IsDebugTable(ReportFilterOptionsTable) {
		return ReportFilterOptionsTable
	} else {
		return ReportFilterOptionsTable
	}
}
