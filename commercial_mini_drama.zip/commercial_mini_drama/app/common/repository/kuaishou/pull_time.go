package kuaishou

import (
	"goserver/app/common/repository"
	"time"
)

const PullTimeInfo = "kuaishou_pull_time"

type PullTimeInfoEntity struct {
	PullTime time.Time `gorm:"column:pull_time"` // 拉取时间
	PullType int       `gorm:"column:pull_type"` // 拉取类型： 1 明细 2 总览
}

func (*PullTimeInfoEntity) TableName() string {
	return PullTimeInfo
}

func PullTimeInfoTableName() string {
	if repository.IsDebugTable(PullTimeInfo) {
		return PullTimeInfo // + "_dev"
	} else {
		return PullTimeInfo
	}
}
