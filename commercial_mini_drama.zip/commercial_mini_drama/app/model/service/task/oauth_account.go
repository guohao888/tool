package task

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	accountsvc "goserver/app/model/service/accounts"
)

func OauthAccountSyncToutiao(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.OauthAccountSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
		if params.MasterAppId == "" {
			panic(errors.New("主应用ID不能为空"))
		}
	}

	media := repository.MediaToutiao

	// 通过主应用获取其下所有管家的广告主
	oauthAccountService := accountsvc.NewOauthAccountService(ctx)
	err := oauthAccountService.OauthAccountSync(media, params)
	if err != nil {
		panic(fmt.Errorf("头条oauth广告主账户同步失败, %w", err))
	}

	// 将管家下的广告主均衡分配到应用
	oauthBalanceAccountService := accountsvc.NewOauthBalanceAccountService(ctx)
	err = oauthBalanceAccountService.OauthBalanceAccountSyncToutiao(media)
	if err != nil {
		panic(fmt.Errorf("均衡头条管家账号下的广告主到应用失败, %w", err))
	}

	return "头条oauth广告主账户同步刷新成功 && 均衡头条管家账号下的广告主到应用成功"
}
