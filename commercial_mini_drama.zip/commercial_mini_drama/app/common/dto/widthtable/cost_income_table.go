package widthtable

type SyncExecutorParams struct {
	IsHistory int `json:"is_history"` // 历史数据 1 当日数据 0
}
