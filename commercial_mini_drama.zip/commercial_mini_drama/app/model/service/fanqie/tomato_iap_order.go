package fanqie

import (
	"context"
	dto "goserver/app/common/dto/fanqie"
	"goserver/app/model/dao/fanqie"
)

// TomatoIAPOrderService 番茄IAP订单Service
type TomatoIAPOrderService struct {
	Ctx context.Context
}

// NewTomatoIAPOrderService 创建上下文IAP订单Service
func NewTomatoIAPOrderService(ctx context.Context) *TomatoIAPOrderService {
	return &TomatoIAPOrderService{Ctx: ctx}
}

// SaveIAPOrderInfos 保存IAP订单数据
func (t *TomatoIAPOrderService) SaveIAPOrderInfos(req []dto.TomatoIAPOrderReq) error {
	tomatoIAPOrderDao := fanqie.NewTomatoIAPOrderDao(t.Ctx)
	err := tomatoIAPOrderDao.Req2Entity(req)
	return err
}
