package accounts

import (
	"goserver/app/common"
	"goserver/app/common/dto/page"
	"goserver/app/library/myerror"
	"time"

	"github.com/gin-gonic/gin"
)

type ConfigListParams struct {
	page.Pagination          // 分页
	AuthType        string   `json:"auth_type"`
	Media           []string `json:"media"` // 媒体
}

type ConfigListReq struct {
	common.CommonParams
	Params *ConfigListParams `json:"params"`
}

type AppIDListReq struct {
	common.CommonParams
	ConfigListParams
}

type SingleAppIdReq struct {
	common.CommonParams
	AppId    string `json:"app_id"`
	Key      string `json:"key"`
	Media    string `json:"media"`
	AuthType string `json:"auth_type"`
}

func NewSingleAppIdReq(c *gin.Context) *SingleAppIdReq {
	var req SingleAppIdReq
	if err := c.ShouldBindJSON(&req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return &req
}

func NewConfigListReq(c *gin.Context) *ConfigListReq {
	var req ConfigListReq
	if err := c.ShouldBindJSON(&req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return &req
}

func NewAppIdListReq(c *gin.Context) *ConfigListReq {
	var req AppIDListReq
	if err := c.ShouldBindJSON(&req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)

	return &ConfigListReq{
		CommonParams: req.CommonParams,
		Params: &ConfigListParams{
			Pagination: req.Pagination,
			AuthType:   req.AuthType,
			Media:      req.Media,
		},
	}
}

type OauthConfigList struct {
	No        int64     `json:"no"`
	Media     string    `json:"media"`
	AppID     string    `json:"app_id"`
	AppSecret string    `json:"app_secret"`
	AuthType  string    `json:"auth_type"`
	CreatedAt time.Time `json:"created_at"`
	UpdatedAt time.Time `json:"updated_at"`
	OauthUrl  string    `json:"oauth_url"`
}
