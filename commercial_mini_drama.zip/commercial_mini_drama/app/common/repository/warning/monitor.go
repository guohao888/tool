package warning

import (
	"goserver/app/common/repository"
	"time"
)

const MonitorInfoEntityTable = "monitor_info"

type MonitorInfoEntity struct {
	TaskId           string    `gorm:"column:task_id"`            // 任务ID
	TaskType         int       `gorm:"column:task_type"`          // 任务类型 2：素材拒审监控: 3：投放异常预警
	TaskName         string    `gorm:"column:task_name"`          // 任务名称
	Media            int       `gorm:"column:media"`              // 媒体 2: 巨量广告
	MonitorObject    int       `gorm:"column:monitor_object"`     // 应用媒体 2: 巨量广告
	Metrics          int       `gorm:"column:metrics"`            // 指标 1:消耗 2：拒审 3：ROI
	DateCondition    int       `gorm:"column:date_condition"`     // 时间条件 1.过去24小时  2：当天 3：过去三天
	Condition        string    `gorm:"column:condition"`          // 条件 >, <,<=,>=,=
	Numerical        string    `gorm:"column:numerical"`          // 条件数值
	MetricsTwo       int       `gorm:"column:metrics_two"`        // 指标 1:消耗 2：拒审 3：ROI
	DateConditionTwo int       `gorm:"column:date_condition_two"` // 时间条件 1.过去24小时  2：当天 3：过去三天
	ConditionTwo     string    `gorm:"column:condition_two"`      // 条件 >, <,<=,>=,=
	NumericalTwo     string    `gorm:"column:numerical_two"`      // 条件数值
	IntervalType     int       `gorm:"column:interval_type"`      // 1: 间隔执行  2：定时
	IntervalValue    string    `gorm:"column:interval_value"`     // 小时 09:00
	EffectiveType    int       `gorm:"column:effective_type"`     // 1:长期  2：开始-结束时间
	EffectiveValue   string    `gorm:"column:effective_value"`    // ;号分割  2025-01-01；2025-03-01
	MsgTo            string    `gorm:"column:msg_to"`             // 发送对象
	ScopeType        int       `gorm:"column:scope_type"`         // 1:ALL 2: 指定账号
	ScopeValue       string    `gorm:"column:scope_value"`        // 账号: 逗号分割
	Status           int       `gorm:"column:status"`             // 状态  1 开启  2 关闭
	IsDelete         int       `gorm:"column:is_delete"`          // 0 正常  1 删除
	CreateUser       string    `gorm:"column:create_user"`        // 创建人
	CreatedAt        time.Time `gorm:"column:created_at"`         // 创建时间
	Operation        int       `gorm:"column:operation"`          // 操作类型 1 推推 2 拉空
}

func (*MonitorInfoEntity) TableName() string {
	return MonitorInfoEntityTable
}

func MonitorInfoEntityTableName() string {
	if repository.IsDebugTable(MonitorInfoEntityTable) {
		return MonitorInfoEntityTable + "_dev"
	} else {
		return MonitorInfoEntityTable
	}
}

type ExecSqlInfo struct {
	Start    []K2V
	End      []K2V
	MsgTo    string
	WhereSql string
}

type K2V struct {
	K int
	V string
}

type RejectInfo struct {
	AdvertiserId  string
	MaterialId    string
	FileName      string
	AccountName   string
	ProjectId     string
	ProjectName   string
	PromotionId   string
	PromotionName string
	RejectReason  string
	Suggestion    string
	RejectTime    int
	NickName      string
}

type ROIMonitor struct {
	AdvertiserId   string
	AdvertiserName string
	MediaCost      float64
	Income         float64
	ROI            float64
	NickName       string
}

type WeekSchedule struct {
	AdvertiserId   string  `gorm:"column:advertiser_id"`
	AdvertiserName string  `gorm:"column:advertiser_name"`
	ProjectId      string  `gorm:"column:project_id"`
	ProjectName    string  `gorm:"column:project_name"`
	Cost           float64 `gorm:"column:cost"`
	ROI            float64 `gorm:"column:roi"`
	Operation      string  `gorm:"column:operation"`
	Result         string  `gorm:"column:result"`
	ErrMsg         string  `gorm:"column:err_msg"`
	NickName       string  `gorm:"column:nick_name"`
}
