package mediareport

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	repo "goserver/app/common/repository/mediareport"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// VideoFileDao 视频素材DAO
type VideoFileDao struct {
	Ctx context.Context
}

func NewVideoFileDao(ctx context.Context) *VideoFileDao {
	return &VideoFileDao{Ctx: ctx}
}

func (v *VideoFileDao) GetAccountAndMaterialIds(searchDate string) ([]repo.AdvertiserIdsAndMaterialIdsNew, error) {
	var res []repo.AdvertiserIdsAndMaterialIdsNew
	db := dorisdb.DorisClient()
	sql := "SELECT advertiser_id, material_id FROM spi_material_modification_log WHERE date(created_at) = '" + searchDate + "' GROUP BY advertiser_id, material_id "
	err := db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return res, nil
}

func (v *VideoFileDao) GetAccountAndUser(searchDate string) ([]repo.AdvertiserIdsAndMaterialIdsNew, error) {
	var res []repo.AdvertiserIdsAndMaterialIdsNew
	db := dorisdb.DorisClient()
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT advertiser_id FROM spi_material_modification_log WHERE date(created_at) = '" + searchDate + "' GROUP BY advertiser_id ) has LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) ac ON has.advertiser_id = ac.advertiser_id"
	err := db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return res, nil
}

//func (v *VideoFileDao) GetMaterialIdsAndAdvertisersNoPull(isReplenish int, appid string) ([]repo.AdvertiserIdsAndMaterialIds, error) {
//	var res []repo.AdvertiserIdsAndMaterialIds
//	db := dorisdb.DorisClient()
//	var searchDate string
//	if isReplenish == 1 {
//		searchDate = " WHERE date(create_time) = CURRENT_DATE"
//	}
//	sql := "SELECT me.advertiser_id as advertiser_id, me.material_id as material_id, oa.oauth_id as oauth_id FROM ( SELECT advertiser_id, material_id FROM report_media " + searchDate + " GROUP BY advertiser_id, material_id ) me LEFT JOIN ( SELECT advertiser_id, oauth_id FROM oauth_account WHERE oauth_id IN (SELECT oauth_id FROM oauth WHERE app_id  = '" + appid + "' ) ) oa ON me.advertiser_id = oa.advertiser_id WHERE oa.oauth_id IS NOT NULL "
//	err := db.Raw(sql).Scan(&res).Error
//	if err != nil && !gorm.IsRecordNotFoundError(err) {
//		return nil, err
//	}
//	return res, nil
//}

// InsertBatchSize 插入更新数据
func (v *VideoFileDao) InsertBatchSize(data []*repo.VideoFileEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = v.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (v *VideoFileDao) buildInsertSentence(tx *gorm.DB, data []*repo.VideoFileEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.VideoFileTableName() + " ( advertiser_id, material_id, video_id, create_time, filename, width, size, duration, format, bit_rate, height, url, poster_url, signature, source, file_cutter ) VALUES "
	var vals []interface{}
	for _, row := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			row.AdvertiserId,
			row.MaterialId,
			row.VideoId,
			row.CreateTime,
			row.Filename,
			row.Width,
			row.Size,
			row.Duration,
			row.Format,
			row.BitRate,
			row.Height,
			row.Url,
			row.PosterUrl,
			row.Signature,
			row.Source,
			row.FileCutter,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
