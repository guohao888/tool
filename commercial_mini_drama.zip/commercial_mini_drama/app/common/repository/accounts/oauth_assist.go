package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const OauthAssistEntityTable = "oauth_assist"

// OauthAssistEntity 协管授权账号
type OauthAssistEntity struct {
	Media             string    `gorm:"column:media"`               // 授权媒体
	OauthId           string    `gorm:"column:oauth_id"`            // 授权唯一标识
	AccessToken       string    `gorm:"column:access_token"`        // access token
	RefreshToken      string    `gorm:"column:refresh_token"`       // refresh token
	ExpireAt          time.Time `gorm:"column:expire_at"`           // access token 到期时间
	RefreshExpireAt   time.Time `gorm:"column:refresh_expire_at"`   // refresh token 到期时间
	ExpireTime        int64     `gorm:"column:expire_time"`         // access token 有效时长
	RefreshExpireTime int64     `gorm:"column:refresh_expire_time"` // refresh token 有效时长
	AppId             string    `gorm:"column:app_id"`              // app id
	UserId            string    `gorm:"column:user_id"`             // 管家账户ID
	AppSecret         string    `gorm:"column:app_secret"`          // app secret
	Ext               string    `gorm:"column:ext"`                 // 扩展数据，根据平台存储所需数据
	CreatedAt         time.Time `gorm:"column:created_at"`          // 创建时间
	UpdatedAt         time.Time `gorm:"column:updated_at"`          // 更新时间
}

func (*OauthAssistEntity) TableName() string {
	return OauthAssistTableName()
}

func OauthAssistTableName() string {
	if repository.IsDebugTable(OauthAssistEntityTable) {
		return OauthAssistEntityTable + "_dev"
	} else {
		return OauthAssistEntityTable
	}
}
