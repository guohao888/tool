package calc

import "github.com/shopspring/decimal"

var (
	OneHundred  = decimal.NewFromInt(100)
	OneThousand = decimal.NewFromInt(1000)
)

func DecimalDiv(v1, v2 decimal.Decimal) decimal.Decimal {
	if v2.IsZero() {
		return decimal.Zero
	} else {
		return v1.Div(v2)
	}
}

func Int64Div(v1, v2 int64) decimal.Decimal {
	if v2 == 0 {
		return decimal.Zero
	}
	return decimal.NewFromInt(v1).Div(decimal.NewFromInt(v2))
}
