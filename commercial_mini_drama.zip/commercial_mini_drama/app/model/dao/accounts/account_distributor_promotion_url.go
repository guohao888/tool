package accounts

import (
	"context"
	"fmt"
	accountdto "goserver/app/common/dto/accounts"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"strings"
)

type AccountDistributorPromotionUrlDao struct {
	Ctx context.Context
}

func NewAccountDistributorPromotionUrlDao(ctx context.Context) *AccountDistributorPromotionUrlDao {
	return &AccountDistributorPromotionUrlDao{Ctx: ctx}
}

func (d *AccountDistributorPromotionUrlDao) Merge(params accountdto.PromotionUrlMergeExecutorParams) error {
	accountPromotionUrlDao := NewAccountPromotionUrlDao(d.Ctx)
	t1 := accountPromotionUrlDao.MergeQuery(params)

	distributorPromotionUrlDao := NewDistributorPromotionUrlDao(d.Ctx)
	t2 := distributorPromotionUrlDao.MergeQuery(params)

	optimizerInfoDao := NewOptimizerInfoDao(d.Ctx)
	t3 := optimizerInfoDao.MergeQuery(params)

	db := dorisdb.DorisClient()
	selectColumns := []string{
		"'短剧' AS module",
		"t1.media AS media",
		"t1.advertiser_id AS advertiser_id",
		"t2.distributor AS distributor",
		"t2.app_name AS app_name",
		"t2.book_id AS book_id",
		"t2.promotion_id AS promotion_id",
		"t2.book_name AS book_name",
		"COALESCE(t3.region, '') AS region",
		"t2.optimizer_id AS optimizer_id",
		"t2.optimizer_name AS optimizer_name",
		"t2.promotion_url AS promotion_url",
		"t2.promotion_name AS promotion_name",
		"t1.advertiser_name AS advertiser_name",
		"t1.create_time AS apu_create_time",
		"t2.create_time AS dpu_create_time",
	}

	insertColumns := []string{
		"module",
		"media",
		"advertiser_id",
		"distributor",
		"app_name",
		"book_id",
		"promotion_id",
		"book_name",
		"region",
		"optimizer_id",
		"optimizer_name",
		"promotion_url",
		"promotion_name",
		"advertiser_name",
		"apu_create_time",
		"dpu_create_time",
	}
	insertSql := fmt.Sprintf("INSERT INTO %s(%s) SELECT %s FROM (?) AS t1 LEFT JOIN (?) AS t2 ON t1.promotion_url = t2.promotion_url LEFT JOIN (?) AS t3 ON t2.optimizer_name = t3.nick_name WHERE t2.promotion_url IS NOT NULL",
		accountrepo.AccountDistributorPromotionUrlTableName(),
		strings.Join(insertColumns, ","),
		strings.Join(selectColumns, ","),
	)
	err := db.Exec(insertSql, t1, t2, t3).Error
	return err
}
