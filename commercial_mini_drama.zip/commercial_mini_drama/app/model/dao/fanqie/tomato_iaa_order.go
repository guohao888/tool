package fanqie

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	dto "goserver/app/common/dto/fanqie"
	repo "goserver/app/common/repository/fanqie"
	"goserver/app/library/driver/dorisdb"
	timeUtil "goserver/app/library/utils/time"
	"goserver/app/model/dao"
	"strconv"
	"strings"
	"time"
)

// TomatoIAAOrderDao 番茄IAA订单DAO
type TomatoIAAOrderDao struct {
	Ctx context.Context
}

func NewTomatoIAAOrderDao(ctx context.Context) *TomatoIAAOrderDao {
	return &TomatoIAAOrderDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (t *TomatoIAAOrderDao) InsertBatchSize(data []*repo.IAAOrderEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 3000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = t.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (t *TomatoIAAOrderDao) buildInsertSentence(tx *gorm.DB, data []*repo.IAAOrderEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.IAAOrderTableName() + " ( ecpm_no, device_id, event_time, distributor_id, app_id, app_name, promotion_id, ecpm_cost, event_date, event_hour, register_time, register_date, register_hour, book_id, book_name, book_gender, book_category ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.EcpmNo,
			v.DeviceId,
			v.EventTime,
			v.DistributorId,
			v.AppId,
			v.AppName,
			v.PromotionId,
			v.EcpmCost,
			v.EventDate,
			v.EventHour,
			v.RegisterTime,
			v.RegisterDate,
			v.RegisterHour,
			v.BookId,
			v.BookName,
			v.BookGender,
			v.BookCategory,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// Req2Entity 请求参数结构转化
func (t *TomatoIAAOrderDao) Req2Entity(data []dto.TomatoIAAOrderReq) error {
	var list []*repo.IAAOrderEntity
	for _, v := range data {
		// 时间戳格式化
		evenTime, _ := strconv.Atoi(v.EventTime)
		registerTime, _ := strconv.Atoi(v.RegisterTime)
		evenDate := timeUtil.StringFromSecond(int64(evenTime))
		evenDatetime, _ := time.ParseInLocation(time.DateTime, evenDate, time.Local)
		registerDate := timeUtil.StringFromSecond(int64(registerTime))
		registerDatetime, _ := time.ParseInLocation(time.DateTime, registerDate, time.Local)
		info := &repo.IAAOrderEntity{
			EcpmNo:        v.EcpmNo,
			DeviceId:      v.DeviceId,
			EventTime:     v.EventTime,
			DistributorId: v.DistributorId,
			AppId:         v.AppId,
			AppName:       v.AppName,
			PromotionId:   v.PromotionId,
			EcpmCost:      v.EcpmCost,
			EventDate:     evenDatetime,
			EventHour:     evenDate[11:13],
			RegisterTime:  v.RegisterTime,
			RegisterDate:  registerDatetime,
			RegisterHour:  registerDate[11:13],
			BookId:        v.BookId,
			BookName:      v.BookName,
			BookGender:    v.BookGender,
			BookCategory:  v.BookCategory,
		}
		list = append(list, info)
	}
	err := t.InsertBatchSize(list, 3000)
	return err
}
