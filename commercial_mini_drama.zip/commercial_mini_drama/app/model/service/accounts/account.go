package accounts

import (
	"context"
	"errors"
	"fmt"
	"github.com/tealeg/xlsx"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/dto/accounts"
	accountsDto "goserver/app/common/dto/accounts"
	"goserver/app/common/dto/page"
	accountsRepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/library/utils"
	timeUtil "goserver/app/library/utils/time"
	accountsDao "goserver/app/model/dao/accounts"
	dao "goserver/app/model/dao/roi"
	"io/ioutil"
	"os"
	"strconv"
	"strings"
	"time"
)

type AccountService struct {
	Ctx context.Context
}

var rowTitleMap map[string][]string
var tableNameMap map[string]string
var excelTitle string

func init() {
	rowTitleMap = map[string][]string{
		accountsDao.ExportTypePromotion: {"模块", "应用包名", "剧目ID", "剧目名称", "媒体名称", "分销商", "地区", "优化师ID", "优化师", "账户ID", "账户名称", "推广链ID", "推广链名称", "推广链URL", "创建时间", "更新时间"},
		accountsDao.ExportTypeAccount:   {"模块", "应用包名", "剧目ID", "剧目名称", "媒体名称", "分销商", "地区", "优化师ID", "优化师", "账户ID", "账户名称", "启用状态", "账户返点", "创建时间", "更新时间"},
	}
	tableNameMap = map[string]string{
		accountsDao.ExportTypePromotion: "账户推广链信息表",
		accountsDao.ExportTypeAccount:   "账户信息表",
	}
	excelTitle = "应用包名,剧目ID,剧目名称,媒体名称,分销商 优化师ID,优化师 账户ID,账户名称,日期"
}

func NewAccountService(ctx context.Context) *AccountService {
	return &AccountService{Ctx: ctx}
}

// GetFilterOptions 获取筛选项
func (s *AccountService) GetFilterOptions() (accounts.FilterOptionResp, error) {
	resp := accounts.FilterOptionResp{}
	accountDistributorDao := accountsDao.NewAccountDistributorDao(s.Ctx)
	eg := new(errgroup.Group)
	var err error
	eg.Go(func() error {
		resp.Media, err = accountDistributorDao.DistinctList(accountsDao.SelectColumnMedia)
		if err != nil {
			return err
		}
		return nil
	})
	eg.Go(func() error {
		resp.AppName, err = accountDistributorDao.DistinctList(accountsDao.SelectColumnAppName)
		if err != nil {
			return err
		}
		return nil
	})
	eg.Go(func() error {
		resp.NickName, err = accountDistributorDao.DistinctList(accountsDao.SelectColumnOptimizerName)
		if err != nil {
			return err
		}
		return nil
	})
	err = eg.Wait()
	if err != nil {
		log.Errorf("获取刷选项失败, err:%s", err)
		return resp, err
	}
	resp.AccountStatus = []accounts.GeneralOption{
		{Key: accountsDao.StatusAllName, Val: accountsDao.StatusAll},
		{Key: accountsDao.StatusOpenName, Val: accountsDao.StatusOpen},
		{Key: accountsDao.StatusCloseName, Val: accountsDao.StatusClose},
	}
	return resp, nil
}

// GetOptionSearch 模糊获取字段列表
func (s *AccountService) GetOptionSearch(req *accountsDto.OptionSearchParams) ([]string, error) {
	accountDistributorDao := accountsDao.NewAccountDistributorDao(s.Ctx)
	valueSlice, err := accountDistributorDao.DistinctLikeSearchList(req.SearchColumn, req.Keywords)
	if err != nil {
		return nil, err
	}
	return valueSlice, nil
}

func (s *AccountService) AddFilterList() (accounts.AddFilterOptions, error) {
	resp := accounts.AddFilterOptions{}
	accountDistributorDao := accountsDao.NewAccountDistributorDao(s.Ctx)
	eg := new(errgroup.Group)
	var err error
	eg.Go(func() error {
		resp.Media, err = accountDistributorDao.DistinctList(accountsDao.SelectColumnMedia)
		if err != nil {
			return err
		}
		return nil
	})
	eg.Go(func() error {
		resp.AppName, err = accountDistributorDao.DistinctList(accountsDao.SelectColumnAppName)
		if err != nil {
			return err
		}
		return nil
	})
	eg.Go(func() error {
		optimizerInfoDao := accountsDao.NewOptimizerInfoDao(s.Ctx)
		res, err := optimizerInfoDao.OptimizerInfoList()
		if err != nil {
			return err
		}
		optimizerList := make([]*accounts.OptimizerInfo, 0)
		for _, re := range res {
			optimizerList = append(optimizerList, &accounts.OptimizerInfo{
				NickName: re.NickName,
				Region:   re.Region,
			})
		}
		resp.OptimizerList = optimizerList
		return nil
	})
	err = eg.Wait()
	if err != nil {
		log.Errorf("获取刷选项失败, err:%s", err)
		return resp, err
	}
	return resp, nil
}

// AddAccount 添加账户信息
func (s *AccountService) AddAccount(req *accountsDto.AddParams) error {
	accountDistributorDao := accountsDao.NewAccountDistributorDao(s.Ctx)
	var accountDistributor []*accountsRepo.AccountDistributorEntity
	apuCreateTime, er := time.Parse(time.DateTime, req.ApuCreateTime)
	if er != nil {
		return er
	}
	accountDistributor = append(accountDistributor, &accountsRepo.AccountDistributorEntity{
		Module:         accountsRepo.DefaultModuleName,
		Media:          req.Media,
		Distributor:    req.Distributor,
		AdvertiserId:   req.AdvertiserId,
		OptimizerId:    req.OptimizerId,
		AppName:        req.AppName,
		BookId:         req.BookId,
		BookName:       req.BookName,
		Region:         req.Region,
		OptimizerName:  req.OptimizerName,
		AdvertiserName: req.AdvertiserName,
		ApuCreateTime:  apuCreateTime,
		DpuCreateTime:  apuCreateTime,
	})
	err := accountDistributorDao.Insert(accountDistributor)
	if err != nil {
		return err
	}
	return nil
}

// GetDataList 获取数据列表
func (s *AccountService) GetDataList(req *accountsDto.DataListParams) (*page.Paginator, error) {
	accountDistributorDao := accountsDao.NewAccountDistributorDao(s.Ctx)
	paginator, err := accountDistributorDao.GetDataList(req)
	var list []*accountsDto.DataInfoResp
	for _, info := range paginator.List.([]accountsRepo.AccountDistributorEntity) {
		list = append(list, &accountsDto.DataInfoResp{
			Module:         info.Module,
			AppName:        info.AppName,
			BookId:         info.BookId,
			BookName:       info.BookName,
			Media:          info.Media,
			Distributor:    info.Distributor,
			Region:         info.Region,
			OptimizerId:    info.OptimizerId,
			OptimizerName:  info.OptimizerName,
			AdvertiserId:   info.AdvertiserId,
			AdvertiserName: info.AdvertiserName,
			AdvertiserStatus: func(status int64) string {
				if status == accountsDao.StatusClose {
					return accountsDao.StatusCloseName
				} else {
					return accountsDao.StatusOpenName
				}
			}(info.Status),
			Status:          info.Status,
			AdvertiserPoint: fmt.Sprintf("%.0f%%", accountsRepo.AccountPoint*100),
			CreatedAt:       info.ApuCreateTime.Format(time.DateTime),
			UpdatedAt:       info.UpdatedAt.Format(time.DateTime),

			PromotionUrl:  info.PromotionUrl,
			PromotionId:   info.PromotionId,
			PromotionName: info.PromotionName,
		})
	}
	paginator.List = list
	return paginator, err
}

// InfraDataDownload 数据导出
func (s *AccountService) InfraDataDownload(listType string, res *page.Paginator) (*xlsx.File, error) {
	xlFile := xlsx.NewFile()
	if _, ok := tableNameMap[listType]; !ok {
		return nil, errors.New("表名称不存在")
	}
	sheet1, err := xlFile.AddSheet(tableNameMap[listType])
	if err != nil {
		return nil, err
	}
	if _, ok := rowTitleMap[listType]; !ok {
		return nil, errors.New("维度指标不存在")
	}
	titleRow := sheet1.AddRow()
	for _, rowName := range rowTitleMap[listType] {
		titleRow.AddCell().SetString(rowName)
	}
	for _, info := range res.List.([]*accountsDto.DataInfoResp) {
		tmpRow := sheet1.AddRow()
		tmpRow.AddCell().SetString(info.Module)
		tmpRow.AddCell().SetString(info.AppName)
		tmpRow.AddCell().SetString(fmt.Sprintf("%d", info.BookId))
		tmpRow.AddCell().SetString(info.BookName)
		tmpRow.AddCell().SetString(info.Media)
		tmpRow.AddCell().SetString(info.Distributor)
		tmpRow.AddCell().SetString(info.Region)
		tmpRow.AddCell().SetString(fmt.Sprintf("%d", info.OptimizerId))
		tmpRow.AddCell().SetString(info.OptimizerName)
		tmpRow.AddCell().SetString(info.AdvertiserId)
		tmpRow.AddCell().SetString(info.AdvertiserName)
		if listType == accountsDao.ExportTypeAccount {
			tmpRow.AddCell().SetString(info.AdvertiserStatus)
			percentCell := tmpRow.AddCell()
			percentCell.SetFloat(accountsRepo.AccountPoint)
			percentCell.NumFmt = "0%"
		}
		if listType == accountsDao.ExportTypePromotion {
			tmpRow.AddCell().SetString(fmt.Sprintf("%d", info.PromotionId))
			tmpRow.AddCell().SetString(info.PromotionName)
			tmpRow.AddCell().SetString(info.PromotionUrl)
		}
		tmpRow.AddCell().SetString(info.CreatedAt)
		tmpRow.AddCell().SetString(info.UpdatedAt)
	}
	return xlFile, nil
}

// BatchAction 批量账户操作
// 1. 批量关停需要验证最近7天花费是否为0；
// 2. 批量上线，可以直接操作
func (s *AccountService) BatchAction(req *accountsDto.BatchActionParams) error {
	accountStatusDao := accountsDao.NewAccountStatusDao(s.Ctx)
	accountDistributorDao := accountsDao.NewAccountDistributorDao(s.Ctx)
	var accountInfoList []accountsRepo.AccountStatusEntity
	if req.ActionType == accountsDao.StatusClose {
		// 验证最近7天花费是否为0
		now := time.Now()
		startTime, _ := timeUtil.GetDayTime(now.AddDate(0, 0, -7))
		endTime, _ := timeUtil.GetDayTime(now)
		reportDataDao := dao.NewReportDataDao(s.Ctx)
		advertiserId, err := reportDataDao.GetMediaCostByAdvertiserId(startTime.Format(time.DateTime), endTime.Format(time.DateTime), req.AdvertiserId)
		if err != nil {
			return err
		}
		newAdvertiserId := []string{}
		for _, i := range req.AdvertiserId {
			if !utils.ContainsString(advertiserId, i) {
				newAdvertiserId = append(newAdvertiserId, i)
			}
		}
		accountList, err := accountDistributorDao.GetDataById(newAdvertiserId)
		if err != nil {
			return err
		}
		for _, entity := range accountList {
			accountInfoList = append(accountInfoList, accountsRepo.AccountStatusEntity{
				Media:        entity.Media,
				AdvertiserId: entity.AdvertiserId,
				Status:       accountsDao.StatusClose,
			})
		}
	} else if req.ActionType == accountsDao.StatusOpen { // 如果要开启账户，需要查询多少是停用状态的
		ids, err := accountStatusDao.FindByIds(req.AdvertiserId)
		if err != nil {
			return err
		}
		for _, entity := range ids {
			accountInfoList = append(accountInfoList, accountsRepo.AccountStatusEntity{
				Media:        entity.Media,
				AdvertiserId: entity.AdvertiserId,
				Status:       accountsDao.StatusOpen,
			})
		}
	}
	err := accountStatusDao.Updates(accountInfoList)
	return err
}

func (s *AccountService) Update(req *accountsDto.UpdateParams) error {
	var info accountsRepo.AccountStatusEntity
	info.Media = req.Media
	info.AdvertiserId = req.AdvertiserId
	info.Status = req.AdvertiserStatus
	accountStatusDao := accountsDao.NewAccountStatusDao(s.Ctx)
	err := accountStatusDao.Update(info)
	return err
}

func (s *AccountService) Import(req *accountsDto.ImportParams) ([]string, error) {
	fileInfo := req.FileInfo
	data, err := s.excelDataTrans(fileInfo)
	if err != nil {
		return nil, err
	}
	optimizerInfoDao := accountsDao.NewOptimizerInfoDao(s.Ctx)
	opList, err := optimizerInfoDao.OptimizerInfoList()
	if err != nil {
		return nil, err
	}
	var opMap = make(map[string]string)
	for _, info := range opList {
		if _, ok := opMap[info.NickName]; !ok {
			opMap[info.NickName] = info.Region
		}
	}
	var accountList []*accountsRepo.AccountDistributorEntity
	var advertiserIdSlice []string
	for i, datum := range data {
		// 过滤空行
		if strings.Join(datum, "") == "" {
			continue
		}
		if i == 0 {
			// 如果第一行为title的刷，就直接去掉
			h := strings.Join(datum, ",")
			if excelTitle == strings.ToUpper(h) {
				continue
			}
		}
		media := datum[3]
		distributor := datum[4]
		advertiserId := datum[7]
		appName := datum[0]
		bookName := datum[2]
		optimizerName := datum[6]
		advertiserName := datum[8]

		apuCreateTime, er := time.Parse(time.DateTime, datum[9])
		if er != nil {
			continue
		}
		bookId, _ := strconv.ParseInt(datum[1], 10, 64)
		optimizerId, _ := strconv.ParseInt(datum[5], 10, 64)
		region := ""
		if re, ok := opMap[optimizerName]; ok {
			region = re
		}
		if region == "" {
			continue
		}
		accountList = append(accountList, &accountsRepo.AccountDistributorEntity{
			Module:         accountsRepo.DefaultModuleName,
			Media:          media,
			Distributor:    distributor,
			AdvertiserId:   advertiserId,
			OptimizerId:    optimizerId,
			AppName:        appName,
			BookId:         bookId,
			BookName:       bookName,
			Region:         region,
			OptimizerName:  optimizerName,
			AdvertiserName: advertiserName,
			ApuCreateTime:  apuCreateTime,
			DpuCreateTime:  apuCreateTime,
		})
		advertiserIdSlice = append(advertiserIdSlice, advertiserId)
	}
	if len(advertiserIdSlice) > 0 {
		accountDistributorDao := accountsDao.NewAccountDistributorDao(s.Ctx)
		e := accountDistributorDao.Insert(accountList)
		if e != nil {
			return nil, e
		}
	}
	return advertiserIdSlice, nil
}

func (s *AccountService) excelDataTrans(fileInfo []byte) ([][]string, error) {
	// 创建一个临时文件
	tempFile, err := ioutil.TempFile("", "base64decoded_excel")
	if err != nil {
		log.Errorf("[account import] Error creating temp file: %v", err)
		return nil, err
	}
	defer tempFile.Close()
	defer os.Remove(tempFile.Name())
	// 将解码后的数据写入临时文件
	if _, err := tempFile.Write(fileInfo); err != nil {
		log.Errorf("[account import] Error writing to temp file: %v", err)
		return nil, err
	}
	// 刷新文件内容到磁盘
	if err := tempFile.Sync(); err != nil {
		log.Errorf("[account import] Error syncing temp file: %v", err)
		return nil, err
	}
	// 打开 Excel 文件
	file, err := xlsx.OpenFile(tempFile.Name())
	if err != nil {
		log.Errorf("[account import] 打开文件失败：%v", err)
		return nil, err
	}
	var data [][]string
	// 遍历每个工作表
	for _, sheet := range file.Sheets {
		// 遍历工作表中的每一行
		for _, row := range sheet.Rows {
			var info []string
			// 遍历行中的每一个单元格
			for _, cell := range row.Cells {
				// 去除空格和换行符
				cleanStr := ""
				if cell.IsTime() {
					t, e := cell.GetTime(false)
					if e != nil {
						log.Debugf("[account import] 时间格式有问题；数据：%s", row.Cells)
						continue
					}
					cleanStr = t.Format(time.DateTime)
				} else {
					cleanStr = strings.TrimSuffix(strings.TrimSuffix(strings.TrimSuffix(cell.Value, " "), "\n"), "\t")
				}
				if cleanStr == "" {
					log.Debugf("[account import] 数据字段为空；数据：%s", row.Cells)
					continue
				}
				info = append(info, cleanStr)
			}
			data = append(data, info)
		}
	}
	return data, err
}
