package accounts

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	accountsRepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"strings"
)

type AccountStatusDao struct {
	Ctx context.Context
}

func NewAccountStatusDao(ctx context.Context) *AccountStatusDao {
	return &AccountStatusDao{Ctx: ctx}
}

func (s *AccountStatusDao) Update(data accountsRepo.AccountStatusEntity) error {
	info := accountsRepo.AccountStatusEntity{}
	db := dorisdb.DorisClient()
	db = db.Table(accountsRepo.AccountStatusTableName())
	err := db.Where("media=?", data.Media).Where("advertiser_id=?", data.AdvertiserId).First(&info).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return err
	}
	if info.Media != "" {
		data.CreatedAt = info.CreatedAt
	}
	err = db.Save(&data).Error
	return err
}

// Updates 批量更新信息
func (s *AccountStatusDao) Updates(data []accountsRepo.AccountStatusEntity) error {
	batchSize := 5000
	eg := new(errgroup.Group)
	count := len(data)
	batchPage := count / batchSize
	if count%batchSize != 0 {
		batchPage += 1
	}
	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}
		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()
			e = s.batchInsert(tx, data[start:end])
			return e
		})
	}
	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}
	tx.Commit()
	return err
}

func (s *AccountStatusDao) batchInsert(tx *gorm.DB, data []accountsRepo.AccountStatusEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := fmt.Sprintf("INSERT INTO %s(%s) VALUES ", accountsRepo.AccountStatusTableName(), "media, advertiser_id, status")
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?),"
		vals = append(vals,
			v.Media,
			v.AdvertiserId,
			v.Status,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")
	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// FindByIds 根据advertiser_id 批量获取关停账户
func (s *AccountStatusDao) FindByIds(advertiserIdSlice []string) ([]accountsRepo.AccountStatusEntity, error) {
	var res []accountsRepo.AccountStatusEntity
	db := dorisdb.DorisClient()
	q0 := db.Table(accountsRepo.AccountStatusTableName())
	q0 = q0.Select("advertiser_id,media")
	q0 = q0.Where("advertiser_id in (?)", advertiserIdSlice)
	err := q0.Where("status=?", StatusClose).Group("advertiser_id,media").Find(&res).Error
	q0.Debug()
	return res, err
}

func (s *AccountStatusDao) UpdateById(info *accountsRepo.AccountStatusEntity) error {
	db := dorisdb.DorisClient()
	err := db.Model(&accountsRepo.AccountStatusEntity{}).
		Select("media", "advertiser_id", "status", "created_at").
		Where("media = ? and oauth_id = ?", info.Media, info.AdvertiserId).
		Updates(info).Error
	return err
}
