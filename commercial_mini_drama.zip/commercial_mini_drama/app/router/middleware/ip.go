package middleware

import (
	"github.com/gin-gonic/gin"
	"goserver/app/library/myerror"
	"goserver/app/library/utils"
)

func IpMiddleware() gin.HandlerFunc {
	return func(context *gin.Context) {
		request := context.Request
		ip := utils.ClientPublicIP(request)
		if ip != "127.0.0.1" {
			panic(myerror.ForbiddenServerError)
		}
	}
}
