package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const AccountStatusEntityTable = "account_status"

type AccountStatusEntity struct {
	Media        string    `gorm:"column:media"`         // 媒体
	AdvertiserId string    `gorm:"column:advertiser_id"` // 广告主id
	Status       int64     `gorm:"column:status"`        // 账号状态 0: 正常 1: 关停
	CreatedAt    time.Time `gorm:"column:created_at"`
}

func (*AccountStatusEntity) TableName() string {
	return AccountStatusTableName()
}

func AccountStatusTableName() string {
	if repository.IsDebugTable(AccountStatusEntityTable) {
		return AccountStatusEntityTable + "_dev"
	} else {
		return AccountStatusEntityTable
	}
}
