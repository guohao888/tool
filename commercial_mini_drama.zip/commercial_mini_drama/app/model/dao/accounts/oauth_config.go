package accounts

import (
	"context"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/dto/page"
	"goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"time"
)

type OauthConfigDao struct {
	Ctx context.Context
}

func NewOauthConfigDao(ctx context.Context) *OauthConfigDao {
	return &OauthConfigDao{Ctx: ctx}
}

func (d *OauthConfigDao) OneByMediaAppId(media string, appId string) (*accountrepo.OauthConfigEntity, error) {
	db := dorisdb.DorisClient()

	var res accountrepo.OauthConfigEntity
	err := db.Table(accountrepo.OauthConfigTableName()).
		Where("media = ? and app_id = ?", media, appId).
		First(&res).
		Error

	return &res, err
}

func (s *OauthConfigDao) CommonWhere(q *gorm.DB, params *accountdto.ConfigListParams) *gorm.DB {
	if params.AuthType != "" {
		q = q.Where("auth_type = ?", params.AuthType)
	}
	if len(params.Media) > 0 {
		q = q.Where("media in (?)", params.Media)
	}
	return q
}

func (d *OauthConfigDao) ConfigList(params *accountdto.ConfigListParams) (*page.Paginator, error) {
	db := dorisdb.DorisClient()
	oauthConfigTableName := accountrepo.OauthConfigTableName()

	q := db.Table(oauthConfigTableName)  // 分页
	q2 := db.Table(oauthConfigTableName) // 总数

	q = d.CommonWhere(q, params)
	q2 = d.CommonWhere(q2, params)

	// 总数量
	var total int64
	err := q2.Count(&total).Error
	if err != nil {
		return nil, err
	}

	// 分页
	pagination := params.Pagination
	q = q.Select("*").
		Order("created_at desc, app_id desc").
		Offset(pagination.GetOffset()).
		Limit(pagination.GetLimit())

	// 分页数据
	var res []accountrepo.OauthConfigEntity
	err = q.Find(&res).Error
	if err != nil {
		return nil, err
	}

	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)
	return &paginator, nil
}

func (d *OauthConfigDao) ListByMedia(media string) ([]accountrepo.OauthConfigEntity, error) {
	db := dorisdb.DorisClient()

	var res []accountrepo.OauthConfigEntity
	err := db.Table(accountrepo.OauthConfigTableName()).
		Where("media = ?", media).
		Find(&res).
		Error

	return res, err
}

func (d *OauthConfigDao) DistinctAppIds(media string) ([]string, error) {
	db := dorisdb.DorisClient()

	var res []string
	err := db.Table(accountrepo.OauthConfigTableName()).
		Where("media = ?", media).
		Order("app_id asc").
		Pluck("DISTINCT app_id", &res).
		Error
	return res, err
}

func (d *OauthConfigDao) Create(data *accountrepo.OauthConfigEntity) error {
	// 参数校验
	if err := d.validateOauthConfig(data); err != nil {
		return err
	}

	// 检查是否已存在相同记录
	exists, err := d.checkExists(data.Media, data.AppID)
	if err != nil {
		return err
	}
	if exists {
		return fmt.Errorf("已存在相同的 media 和 app_id 记录")
	}

	db := dorisdb.DorisClient()
	return db.Table(accountrepo.OauthConfigTableName()).Create(data).Error
}

func (d *OauthConfigDao) validateOauthConfig(data *accountrepo.OauthConfigEntity) error {
	// 必填字段校验
	if data.Media == "" {
		return fmt.Errorf("media 不能为空")
	}
	if data.AppID == "" {
		return fmt.Errorf("app_id 不能为空")
	}
	if data.AppSecret == "" {
		return fmt.Errorf("app_secret 不能为空")
	}
	if data.AuthType == "" {
		return fmt.Errorf("auth_type 不能为空")
	}

	// 授权类型校验
	if !accountrepo.IsValidAuthType(data.AuthType) {
		return fmt.Errorf("无效的授权类型: %s, 有效值: %v", data.AuthType, repository.AuthTypeZhangGuan+" "+repository.AuthTypeXieGuan)
	}

	return nil
}

func (d *OauthConfigDao) checkExists(media, appId string) (bool, error) {
	db := dorisdb.DorisClient()
	var count int64
	err := db.Table(accountrepo.OauthConfigTableName()).
		Where("media = ? AND app_id = ?", media, appId).
		Count(&count).Error
	if err != nil {
		return false, err
	}
	return count > 0, nil
}

func (d *OauthConfigDao) Update(data *accountrepo.OauthConfigEntity) error {
	// 参数校验
	if err := d.validateOauthConfig(data); err != nil {
		return err
	}

	db := dorisdb.DorisClient()
	result := db.Table(accountrepo.OauthConfigTableName()).
		Where("media = ? AND app_id = ? AND app_secret = ?", data.Media, data.AppID, data.AppSecret).
		Updates(map[string]interface{}{
			"auth_type":  data.AuthType,
			"updated_at": time.Now(),
		})
	if result.Error != nil {
		return result.Error
	} else if result.RowsAffected == 0 {
		return errors.New("未找到匹配的记录")
	} else {
		return nil
	}
}

func (d *OauthConfigDao) Delete(media, appId string) error {
	db := dorisdb.DorisClient()
	return db.Table(accountrepo.OauthConfigTableName()).
		Where("media = ? AND app_id = ?", media, appId).
		Delete(&accountrepo.OauthConfigEntity{}).Error
}
