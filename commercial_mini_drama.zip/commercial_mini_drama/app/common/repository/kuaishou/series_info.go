package kuaishou

import (
	"goserver/app/common/repository"
)

const SeriesInfo = "kuaishou_series_info"

type SeriesInfoEntity struct {
	AdvertiserId int64  `gorm:"column:advertiser_id"` // 用户快手号id
	SeriesId     int64  `gorm:"column:series_id"`     // 短剧id
	SeriesName   string `gorm:"column:series_name"`   // 短剧名称
	AuditStatus  int    `gorm:"column:audit_status"`  // 审核状态 枚举：1: 待提交 2: 审核中 3: 发布成功 4: 审核未通过 5: 发布中
	SellStatus   int    `gorm:"column:sell_status"`   // 售卖状态 枚举：1 : 已上架 2 : 已下架 9 : 平台风控下架
}

func (*SeriesInfoEntity) TableName() string {
	return SeriesInfo
}

func SeriesInfoTableName() string {
	if repository.IsDebugTable(SeriesInfo) {
		return SeriesInfo // + "_dev"
	} else {
		return SeriesInfo
	}
}
