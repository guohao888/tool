package cipher

import (
	"crypto/hmac"
	"crypto/sha1"
	"encoding/base64"
)

func HmacSha1Base64(key, data string) string {
	k := []byte(key)
	mac := hmac.New(sha1.New, k)
	mac.Write([]byte(data))
	// 进行base64编码
	res := base64.StdEncoding.EncodeToString(mac.Sum(nil))

	return res
}
