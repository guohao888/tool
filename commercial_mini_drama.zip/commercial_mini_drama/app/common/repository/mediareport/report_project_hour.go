package mediareport

import (
	"github.com/shopspring/decimal"
	"goserver/app/common/repository"
	"time"
)

const ReportProjectHourEntityTable = "report_project_hour"

// ReportProjectHourEntity 巨量小时项目维度消耗
type ReportProjectHourEntity struct {
	SearchDate                        time.Time       `gorm:"column:search_date"`                            // 日期
	SearchHour                        string          `gorm:"column:search_hour"`                            // 小时
	AdvertiserId                      string          `gorm:"column:advertiser_id"`                          // 广告主ID
	ProjectId                         string          `gorm:"column:project_id"`                             // 项目id
	ProjectName                       string          `gorm:"column:project_name"`                           // 项目名称
	ShowCnt                           int64           `gorm:"column:show_cnt"`                               // 展现数
	Click                             int64           `gorm:"column:click"`                                  // 点击数
	Active                            int64           `gorm:"column:active"`                                 // 激活数
	ActivePay                         int64           `gorm:"column:active_pay"`                             // 首次付费数
	Cost                              decimal.Decimal `gorm:"column:cost"`                                   // 总花费
	ConvertCnt                        int64           `gorm:"column:convert_cnt"`                            // 转化数
	StatAttributionMicroGame24HAmount decimal.Decimal `gorm:"column:stat_attribution_micro_game_24h_amount"` // 24小时变现金额（激活时间）
	AttributionMicroGame24HRoi        decimal.Decimal `gorm:"column:attribution_micro_game_24h_roi"`         // 激活后24小时变现ROI
	StatMicroGame0DAmount             decimal.Decimal `gorm:"column:stat_micro_game_0d_amount"`              // 原生短剧当日变现（结算）
	AttributionMicroGame0DLtv         decimal.Decimal `gorm:"column:attribution_micro_game_0d_ltv"`          // 小程序/小游戏当日LTV
	AttributionMicroGame3DLtv         decimal.Decimal `gorm:"column:attribution_micro_game_3d_ltv"`          // 小程序/小游戏激活后三日LTV
	AttributionMicroGame7DLtv         decimal.Decimal `gorm:"column:attribution_micro_game_7d_ltv"`          // 小程序/小游戏激活后七日LTV
	CreatedTime                       time.Time       `gorm:"column:created_time"`                           // 数据创建时间
	UpdatedTime                       time.Time       `gorm:"column:updated_time"`                           // 数据更新时间
}

func (*ReportProjectHourEntity) TableName() string {
	return ReportProjectHourEntityTable
}

func ReportProjectHourTableName() string {
	if repository.IsDebugTable(ReportProjectHourEntityTable) {
		return ReportProjectHourEntityTable + "_dev"
	} else {
		return ReportProjectHourEntityTable
	}
}
