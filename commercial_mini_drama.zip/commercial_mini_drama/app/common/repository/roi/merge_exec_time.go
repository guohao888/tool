package roi

import (
	"goserver/app/common/repository"
	"time"
)

const MergeTimeDataTable = "merge_exec_time"

// MergeExecTime 定义 merge_exec_time 表的结构体
type MergeExecTime struct {
	ExecTime time.Time `gorm:"column:exec_time;type:datetime;not null;default:CURRENT_TIMESTAMP" json:"exec_time"`
}

func (*MergeExecTime) TableName() string {
	return ReportDataTableName()
}

func MergeTimeDataTableName() string {
	if repository.IsDebugTable(MergeTimeDataTable) {
		return MergeTimeDataTable
	} else {
		return MergeTimeDataTable
	}
}
