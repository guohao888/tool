package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/golang/freetype"
	"github.com/spf13/viper"
	"github.com/tealeg/xlsx"
	"github.com/xxl-job/xxl-job-executor-go"
	"golang.org/x/image/font/gofont/goregular"
	"golang.org/x/sync/errgroup"
	report "goserver/app/common/dto/widthtable"
	repo "goserver/app/common/repository/material"
	"goserver/app/common/repository/warning"
	noticeCommon "goserver/app/library/utils/notice/common"
	"goserver/app/model/dao/accounts"
	kuaishoudao "goserver/app/model/dao/kuaishou"
	"goserver/app/model/dao/material"
	meidareportdao "goserver/app/model/dao/mediareport"
	dao "goserver/app/model/dao/roi"
	warningdao "goserver/app/model/dao/warning"
	accountsService "goserver/app/model/service/accounts"
	"goserver/app/model/service/roi"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"io/ioutil"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"time"
)

func SyncTuituiMsg(ctx context.Context, _ *xxl.RunReq) (msg string) {
	syncService := material.NewReportDataDao(ctx)
	info, err := syncService.HourTuituiInfo()
	if err != nil {
		return "同步时报信息失败"
	}
	err = sendTuituiMsg(info)
	if err != nil {
		return "发送推推消息失败"
	}
	return "同步推推时报信息成功"
}

func sendTuituiMsg(info repo.ReportHourlyMaterialEntity) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	text := &noticeCommon.Text{
		Content: "\n" + "日期：" + info.Date[0:10] + " \n" +
			"小时：" + strconv.Itoa(time.Now().Hour()) + " \n" +
			"消耗：" + info.MediaCost.String() + " \n" +
			"收入：" + info.Income.String() + " \n" +
			"利润：" + info.Income.Sub(info.MediaCost).String() + " \n" +
			"ROI：" + fmt.Sprintf("%.2f", info.Roi) + " \n ",
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649034245", "7652669649036275"},
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

func SyncTuituiMsgDay(ctx context.Context, _ *xxl.RunReq) (msg string) {
	syncService := material.NewReportDataDao(ctx)
	now := time.Now()
	var startDate string
	endDate := now.AddDate(0, 0, -1).Format(time.DateOnly)
	// 月初第一天 累计显示上月整体收入
	if now.Day() == 1 {
		startDate = time.Date(now.Year(), now.Month()-1, 1, 0, 0, 0, 0, time.UTC).Format(time.DateOnly)
	} else {
		startDate = time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, time.UTC).Format(time.DateOnly)
	}
	info, err := syncService.DayTuituiInfo(endDate)
	if err != nil {
		return "同步日报信息失败"
	}
	accInfo, err := syncService.AccDayTuituiInfo(startDate, endDate)
	if err != nil {
		return "同步日报信息失败"
	}
	err = sendTuituiMsgDay(info, accInfo, startDate, endDate)
	if err != nil {
		return "发送推推消息失败"
	}
	return "同步推推日报信息成功"
}

func sendTuituiMsgDay(info, accInfo repo.ReportHourlyMaterialEntity, startDate, endDate string) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	text := &noticeCommon.Text{
		Content: "\n" + "【日报】:" +
			"\n" + "日期：" + endDate + " \n" +
			"消耗：" + info.MediaCost.String() + " \n" +
			"收入：" + info.Income.String() + " \n" +
			"利润：" + info.Income.Sub(info.MediaCost).String() + " \n" +
			"ROI：" + fmt.Sprintf("%.2f", info.Roi) + " \n " +
			"\n" +
			"【月累计】:" +
			"\n" + "日期：" + startDate + "~" + endDate + " \n" +
			"消耗：" + accInfo.MediaCost.String() + " \n" +
			"收入：" + accInfo.Income.String() + " \n" +
			"利润：" + accInfo.Income.Sub(accInfo.MediaCost).String() + " \n" +
			"ROI：" + fmt.Sprintf("%.2f", accInfo.Roi) + " \n ",
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649034245", "7652669649036275"},
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

func SyncTuituiMsgSubtractBillDay(ctx context.Context, _ *xxl.RunReq) (msg string) {
	syncService := material.NewReportDataDao(ctx)
	now := time.Now()
	var startDate string
	endDate := now.AddDate(0, 0, -1).Format(time.DateOnly)
	// 月初第一天 累计显示上月整体收入
	if now.Day() == 1 {
		startDate = time.Date(now.Year(), now.Month()-1, 1, 0, 0, 0, 0, time.UTC).Format(time.DateOnly)
	} else {
		startDate = time.Date(now.Year(), now.Month(), 1, 0, 0, 0, 0, time.UTC).Format(time.DateOnly)
	}
	info, err := syncService.DaySubtractBillTuituiInfo(endDate)
	if err != nil {
		return "同步日报信息失败"
	}
	accInfo, err := syncService.AccDaySubtractBillTuituiInfo(startDate, endDate)
	if err != nil {
		return "同步日报信息失败"
	}
	err = sendTuituiMsgDay(info, accInfo, startDate, endDate)
	if err != nil {
		return "发送推推消息失败"
	}
	return "同步推推日报信息成功"
}

type KV struct {
	Key   string
	Value float64
}

func SyncTuituiHourMsgExcel(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	syncService := material.NewReportDataDao(ctx)
	// 获取消耗信息
	list, err := syncService.HourTuituiCostList()
	if err != nil {
		return "同步时报信息失败"
	}
	incomeL, err := syncService.HourTuituiIncomeList()
	if err != nil {
		return "同步时报信息失败"
	}
	m := make(map[string][]KV)
	for _, v := range list {
		m[v.SearchHour] = append(m[v.SearchHour], KV{Key: v.Manager, Value: v.MediaCost})
	}
	for k, v := range m {
		sum := float64(0)
		for _, vv := range v {
			sum += vv.Value
		}
		m[k] = append(m[k], KV{Key: "AD账面消耗", Value: sum})
		m[k] = append(m[k], KV{Key: "实际消耗（返点2%）", Value: sum / 1.02})
	}
	for _, v := range incomeL {
		adCost := float64(0)
		for _, vv := range m[v.SearchHour] {
			if vv.Key == "实际消耗（返点2%）" {
				adCost = vv.Value
			}
		}
		m[v.SearchHour] = append(m[v.SearchHour], KV{Key: "番茄收入", Value: v.Income})
		m[v.SearchHour] = append(m[v.SearchHour], KV{Key: "番茄实际收入", Value: v.RealIncome})
		m[v.SearchHour] = append(m[v.SearchHour], KV{Key: "ROI", Value: v.Income / adCost})
		m[v.SearchHour] = append(m[v.SearchHour], KV{Key: "利润", Value: v.Income - adCost})
	}
	UploadMedia(m, params.IsHistory)
	return "同步推推时报信息成功"
}

func SyncTuituiDayMsgExcel(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	syncService := material.NewReportDataDao(ctx)
	// 获取消耗信息
	list, err := syncService.DayTuituiCostList()
	if err != nil {
		return "同步日报信息失败"
	}
	incomeL, err := syncService.DayTuituiIncomeList()
	if err != nil {
		return "同步日报信息失败"
	}
	m := make(map[string][]KV)
	for _, v := range list {
		m[v.SearchDate] = append(m[v.SearchDate], KV{Key: v.Manager, Value: v.MediaCost})
	}
	for k, v := range m {
		sum := float64(0)
		for _, vv := range v {
			sum += vv.Value
		}
		m[k] = append(m[k], KV{Key: "AD账面消耗", Value: sum})
		m[k] = append(m[k], KV{Key: "实际消耗（返点2%）", Value: sum / 1.02})
	}
	for _, v := range incomeL {
		adCost := float64(0)
		for _, vv := range m[v.SearchDate] {
			if vv.Key == "实际消耗（返点2%）" {
				adCost = vv.Value
			}
		}
		m[v.SearchDate+v.Manager] = append(m[v.SearchDate], KV{Key: "番茄收入", Value: v.Income})
		m[v.SearchDate] = append(m[v.SearchDate], KV{Key: "番茄实际收入", Value: v.RealIncome})
		m[v.SearchDate] = append(m[v.SearchDate], KV{Key: "ROI", Value: v.Income / adCost})
		m[v.SearchDate] = append(m[v.SearchDate], KV{Key: "利润", Value: v.Income - adCost})
	}
	UploadMedia(m, params.IsHistory)
	return "同步推推日报信息成功"
}

func UploadMedia(m map[string][]KV, isHour int) {
	file, err := createExcel(m, isHour)
	if err != nil {
		return
	}
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	filePath := ""
	if isHour == 1 {
		filePath = "/drama/" + "短剧IAA日报( 2025-03-01 ~" + time.Now().AddDate(0, 0, -1).Format(time.DateOnly) + ").xlsx"
	} else {
		filePath = "/drama/" + "短剧IAA时报(" + time.Now().Format(time.DateOnly) + ").xlsx"
	}
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return
	}
	msg := &noticeCommon.GroupMessage{
		Togroups:   []string{"7652669649034245"},
		Msgtype:    "attachment",
		Attachment: &noticeCommon.Attachment{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return
	}
	return
}

func createExcel(m map[string][]KV, isHour int) (*os.File, error) {
	// 1. 创建新 Excel 文件和工作表
	file := xlsx.NewFile()
	sheet, err := file.AddSheet("Sheet1")
	if err != nil {
		return nil, fmt.Errorf("创建工作表失败: %v", err)
	}
	title := []string{"日期"}
	list := make([]KV, 0)
	nk := ""
	for k, v := range m {
		if len(v) > len(list) {
			nk = k
			list = v
		}
	}
	if isHour == 0 {
		title = append(title, "小时")
		list = append(m[nk][len(list)-6:], m[nk][0:len(list)-6]...)
	} else {
		list = append(m[nk][len(list)-6:], m[nk][0:len(list)-6]...)
	}
	for _, v := range list {
		title = append(title, v.Key)
	}
	row := sheet.AddRow()
	for _, v := range title {
		row.AddCell().Value = v
	}
	keys := make([]string, 0, len(m))
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	mm := make(map[string]float64)
	if isHour == 0 {
		title = title[2:]
	} else {
		title = title[1:]
	}
	for _, k := range keys {
		row = sheet.AddRow()
		if isHour == 0 {
			row.AddCell().Value = time.Now().Format(time.DateOnly)
			row.AddCell().Value = k
		} else {
			row.AddCell().Value = k[0:10]
		}
		for _, vv := range m[k] {
			mm[k+vv.Key] = vv.Value
		}

		for _, vv := range title {
			row.AddCell().SetFloat(mm[k+vv])
			//row.AddCell().Value = fmt.Sprintf("%.2f", mm[k+vv])
		}
	}

	// 3. 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.xlsx")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close() // 立即关闭以便后续操作

	// 4. 将 Excel 写入临时文件
	if fileErr := file.Write(tempFile); fileErr != nil {
		_ = os.Remove(tempFile.Name()) // 写入失败时清理文件
		return nil, fmt.Errorf("写入 Excel 失败: %v", fileErr)
	}

	// 5. 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}

	return outputFile, nil
}

func SyncTuituiROIImage(ctx context.Context, param *xxl.RunReq) (msg string) {
	columns := []string{"时间", "剧名", "消耗", "近一小时消耗", "ROI", "利润"} //"剧目ID",
	syncService := material.NewReportDataDao(ctx)
	list, err := syncService.ROITuituiInfo()
	if err != nil {
		return "同步时报信息失败"
	}
	data := &QueryResult{
		Columns: columns,
		Rows:    list,
	}
	UploadMediaPng(data)
	return "成功"
}

func UploadMediaPng(result *QueryResult) {
	file, err := generatePNG(result)
	if err != nil {
		return
	}
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	filePath := "/drama/短剧ROI预警"
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652738368403504"},
		Msgtype:  "image",
		Image:    &noticeCommon.Image{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return
	}
	return
}

// QueryResult 查询结果结构
type QueryResult struct {
	Columns []string
	Rows    []material.ROIStruct
}

type ProjectReportResult struct {
	Columns []string
	Rows    any
}

// ImageConfig 图片配置
type ImageConfig struct {
	Width           int
	Height          int
	BackgroundColor color.RGBA
	TextColor       color.Color
	HeaderColor     color.Color
	RowColor        color.Color
	AlternateColor  color.Color
	FontSize        float64
	HeaderFontSize  float64
	Padding         int
	LineHeight      int
	Title           string
	FontPath        string // 字体路径
}

// 生成PNG图片
func generatePNG(result *QueryResult) (*os.File, error) {
	// 图片配置
	config := ImageConfig{
		Width:           1200,
		Height:          500,
		BackgroundColor: color.RGBA{255, 255, 255, 255}, // 白色背景
		TextColor:       color.RGBA{0, 0, 0, 255},       // 黑色文字
		HeaderColor:     color.RGBA{200, 200, 200, 255}, // 灰色表头
		RowColor:        color.RGBA{255, 255, 255, 255}, // 白色行
		AlternateColor:  color.RGBA{240, 240, 240, 255}, // 浅灰色交替行
		FontSize:        12,
		HeaderFontSize:  14,
		Padding:         10,
		LineHeight:      30,
	}

	// 计算图片高度
	numRows := len(result.Rows)
	headerHeight := config.LineHeight
	rowHeight := config.LineHeight
	totalHeight := headerHeight + (numRows * rowHeight) + (config.Padding * 2)

	// 如果计算的高度小于配置的高度，使用配置的高度
	if totalHeight < config.Height {
		totalHeight = config.Height
	}

	// 创建图片
	img := image.NewRGBA(image.Rect(0, 0, config.Width, totalHeight))

	// 填充背景色
	draw.Draw(img, img.Bounds(), &image.Uniform{config.BackgroundColor}, image.Point{}, draw.Src)

	// 创建绘图上下文
	c := freetype.NewContext()
	c.SetDPI(72)

	// 尝试加载支持中文的系统字体
	var fontBytes []byte
	var err error
	exPath, err := os.Getwd()
	if nil != err {
		panic(err)
	}
	path := filepath.Join(exPath, "conf", "fonts", "MSYH.TTC")
	// 检查文件存在性
	if _, err := os.Stat(path); os.IsNotExist(err) {
		return nil, fmt.Errorf("字体文件不存在: %s\n检查路径是否匹配您的操作系统", path)
	}
	fontBytes, err = ioutil.ReadFile(path)

	// 如果所有系统字体都失败，使用内置字体
	if err != nil {
		fontBytes = goregular.TTF
	}

	font, err := freetype.ParseFont(fontBytes)
	if err != nil {
		return nil, fmt.Errorf("解析字体失败: %v", err)
	}

	c.SetFont(font)
	c.SetClip(img.Bounds())
	c.SetDst(img)
	c.SetSrc(image.NewUniform(config.TextColor))

	// 绘制标题
	c.SetFontSize(16)
	title := "抖小今日累计消耗大于500, ROI低于0.5的剧目"
	//titleWidth := int(c.PointToFixed(float64(len(title))))
	//titleX := (config.Width - titleWidth)
	c.DrawString(title, freetype.Pt(20, 40))

	// 绘制时间戳
	c.SetFontSize(10)
	timestamp := fmt.Sprintf("生成时间: %s", time.Now().Add(-900*time.Second).Format(time.DateTime))
	c.DrawString(timestamp, freetype.Pt(config.Width-200, 40))

	// 计算列宽
	colWidth := (config.Width - (config.Padding * 2)) / len(result.Columns)

	// 绘制表头
	c.SetFontSize(config.HeaderFontSize)
	c.SetSrc(image.NewUniform(config.TextColor))

	// 绘制表头背景
	headerRect := image.Rect(config.Padding, 60, config.Width-config.Padding, 60+headerHeight)
	draw.Draw(img, headerRect, &image.Uniform{config.HeaderColor}, image.Point{}, draw.Src)

	// 绘制表头文字
	x := config.Padding
	for _, col := range result.Columns {
		c.DrawString(col, freetype.Pt(x+5, 80))
		x += colWidth
	}

	// 绘制表格内容
	c.SetFontSize(config.FontSize)
	y := 60 + headerHeight

	// 使用反射获取结构体字段值
	dataValue := reflect.ValueOf(result.Rows)
	if dataValue.Kind() != reflect.Slice {
		return nil, fmt.Errorf("数据必须是切片类型")
	}

	for i := 0; i < dataValue.Len(); i++ {
		// 交替行颜色
		rowBgColor := config.RowColor
		if i%2 == 1 {
			rowBgColor = config.AlternateColor
		}

		// 绘制行背景
		rowRect := image.Rect(config.Padding, y, config.Width-config.Padding, y+rowHeight)
		draw.Draw(img, rowRect, &image.Uniform{rowBgColor}, image.Point{}, draw.Src)

		// 获取当前行的结构体
		rowStruct := dataValue.Index(i)
		if rowStruct.Kind() != reflect.Struct {
			return nil, fmt.Errorf("切片元素必须是结构体类型")
		}

		// 绘制单元格内容
		x := config.Padding
		for j := 0; j < rowStruct.NumField(); j++ {
			field := rowStruct.Field(j)
			cellStr := fmt.Sprintf("%v", field.Interface())
			c.DrawString(cellStr, freetype.Pt(x+5, y+20))
			x += colWidth
		}
		y += rowHeight
	}

	// 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.png")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close() // 立即关闭以便后续操作

	// 4. 将 Excel 写入临时文件
	if fileErr := png.Encode(tempFile, img); fileErr != nil {
		_ = os.Remove(tempFile.Name()) // 写入失败时清理文件
		return nil, fmt.Errorf("写入 PNG 失败: %v", fileErr)
	}

	// 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}

	return outputFile, nil
}

/****************************       剧目       ****************************/

func SyncTuituiAlbumImage(ctx context.Context, param *xxl.RunReq) (msg string) {
	//columns := []string{"小时", "剧名", "剧目ID", "时速消耗", "当日累计消耗"}
	syncService := material.NewReportDataDao(ctx)
	list, err := syncService.FindAlbumSpeed()
	if err != nil {
		return "同步时报信息失败"
	}
	err = sentAlbumSpeed(list)
	if err != nil {
		return "同步时报信息失败"
	}
	//data := &QueryResult2{
	//	Columns: columns,
	//	Rows:    list,
	//}
	//UploadMediaPngAlbum(data)
	return "成功"
}

func sentAlbumSpeed(infos []warning.AlbumImage) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	var str string
	if len(infos) == 0 {
		str += "本小时无数据"
	} else {
		for k, v := range infos {
			strconv.Itoa(k + 1)
			str += strconv.Itoa(k+1) + ". " +
				"📗【剧目名称】：" + v.BookName + " " +
				"🔹【剧目ID】：" + v.BookId + " " +
				"🔹【时速消耗】：" + fmt.Sprintf("%.2f", v.Speed) + " " +
				"🔹【累计消耗】：" + fmt.Sprintf("%.2f", v.Cost) + " " +
				"🔹【ROI】：" + fmt.Sprintf("%.2f", v.Roi) + " \n"
		}
	}
	text := &noticeCommon.Text{
		Content: "\n" + "媒体：头条   日期：" + time.Now().Format(time.DateTime) + " " + " \n" + str + " \n",
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649042289"},
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

func UploadMediaPngAlbum(result *QueryResult2) {
	file, err := generatePNGAlbum(result)
	if err != nil {
		return
	}
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	filePath := "/drama/短剧剧目"
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649042289"},
		Msgtype:  "image",
		Image:    &noticeCommon.Image{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return
	}
	return
}

// QueryResult2 查询结果结构
type QueryResult2 struct {
	Columns []string
	Rows    []warning.AlbumImage
}

// 生成PNG图片
func generatePNGAlbum(result *QueryResult2) (*os.File, error) {
	// 图片配置
	config := ImageConfig{
		Width:           1200,
		Height:          500,
		BackgroundColor: color.RGBA{255, 255, 255, 255}, // 白色背景
		TextColor:       color.RGBA{0, 0, 0, 255},       // 黑色文字
		HeaderColor:     color.RGBA{200, 200, 200, 255}, // 灰色表头
		RowColor:        color.RGBA{255, 255, 255, 255}, // 白色行
		AlternateColor:  color.RGBA{240, 240, 240, 255}, // 浅灰色交替行
		FontSize:        12,
		HeaderFontSize:  14,
		Padding:         10,
		LineHeight:      30,
	}

	// 计算图片高度
	numRows := len(result.Rows)
	headerHeight := config.LineHeight
	rowHeight := config.LineHeight
	totalHeight := headerHeight + (numRows * rowHeight) + (config.Padding * 2)

	// 如果计算的高度小于配置的高度，使用配置的高度
	if totalHeight < config.Height {
		totalHeight = config.Height
	}

	// 创建图片
	img := image.NewRGBA(image.Rect(0, 0, config.Width, totalHeight))

	// 填充背景色
	draw.Draw(img, img.Bounds(), &image.Uniform{config.BackgroundColor}, image.Point{}, draw.Src)

	// 创建绘图上下文
	c := freetype.NewContext()
	c.SetDPI(72)

	// 尝试加载支持中文的系统字体
	var fontBytes []byte
	var err error
	exPath, err := os.Getwd()
	if nil != err {
		panic(err)
	}
	path := filepath.Join(exPath, "conf", "fonts", "MSYH.TTC")
	// 检查文件存在性
	if _, err := os.Stat(path); os.IsNotExist(err) {
		return nil, fmt.Errorf("字体文件不存在: %s\n检查路径是否匹配您的操作系统", path)
	}
	fontBytes, err = ioutil.ReadFile(path)

	// 如果所有系统字体都失败，使用内置字体
	if err != nil {
		fontBytes = goregular.TTF
	}

	font, err := freetype.ParseFont(fontBytes)
	if err != nil {
		return nil, fmt.Errorf("解析字体失败: %v", err)
	}

	c.SetFont(font)
	c.SetClip(img.Bounds())
	c.SetDst(img)
	c.SetSrc(image.NewUniform(config.TextColor))

	// 绘制标题
	c.SetFontSize(10)
	title := "短剧ROI预警"
	titleWidth := int(c.PointToFixed(float64(len(title)) * 12))
	titleX := (config.Width - titleWidth) / 2
	c.DrawString(title, freetype.Pt(titleX, 40))

	// 绘制时间戳
	c.SetFontSize(10)
	timestamp := fmt.Sprintf("生成时间: %s", time.Now().Add(-900*time.Second).Format(time.DateTime))
	c.DrawString(timestamp, freetype.Pt(config.Width-200, 40))

	// 计算列宽
	colWidth := (config.Width - (config.Padding * 2)) / len(result.Columns)

	// 绘制表头
	c.SetFontSize(config.HeaderFontSize)
	c.SetSrc(image.NewUniform(config.TextColor))

	// 绘制表头背景
	headerRect := image.Rect(config.Padding, 60, config.Width-config.Padding, 60+headerHeight)
	draw.Draw(img, headerRect, &image.Uniform{config.HeaderColor}, image.Point{}, draw.Src)

	// 绘制表头文字
	x := config.Padding
	for _, col := range result.Columns {
		c.DrawString(col, freetype.Pt(x+5, 80))
		x += colWidth
	}

	// 绘制表格内容
	c.SetFontSize(config.FontSize)
	y := 60 + headerHeight

	// 使用反射获取结构体字段值
	dataValue := reflect.ValueOf(result.Rows)
	if dataValue.Kind() != reflect.Slice {
		return nil, fmt.Errorf("数据必须是切片类型")
	}

	for i := 0; i < dataValue.Len(); i++ {
		// 交替行颜色
		rowBgColor := config.RowColor
		if i%2 == 1 {
			rowBgColor = config.AlternateColor
		}

		// 绘制行背景
		rowRect := image.Rect(config.Padding, y, config.Width-config.Padding, y+rowHeight)
		draw.Draw(img, rowRect, &image.Uniform{rowBgColor}, image.Point{}, draw.Src)

		// 获取当前行的结构体
		rowStruct := dataValue.Index(i)
		if rowStruct.Kind() != reflect.Struct {
			return nil, fmt.Errorf("切片元素必须是结构体类型")
		}

		// 绘制单元格内容
		x := config.Padding
		for j := 0; j < rowStruct.NumField(); j++ {
			field := rowStruct.Field(j)
			cellStr := fmt.Sprintf("%v", field.Interface())
			c.DrawString(cellStr, freetype.Pt(x+5, y+20))
			x += colWidth
		}
		y += rowHeight
	}

	// 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.png")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close() // 立即关闭以便后续操作

	// 4. 将 Excel 写入临时文件
	if fileErr := png.Encode(tempFile, img); fileErr != nil {
		_ = os.Remove(tempFile.Name()) // 写入失败时清理文件
		return nil, fmt.Errorf("写入 PNG 失败: %v", fileErr)
	}

	// 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}

	return outputFile, nil
}

// SendShutdownMsg 服务重启推推推送
func SendShutdownMsg() error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	text := &noticeCommon.Text{
		Content: "\n" + "服务器重启： 时间：" + time.Now().Format(time.DateTime) + " \n",
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649034245"},
		At:       []string{"18210166869"},
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

/************************************************ 快手推推播报 ************************************************/

func SyncKuaishouTuituiMsg(ctx context.Context, _ *xxl.RunReq) (msg string) {
	adDetailHourDao := kuaishoudao.NewAdDetailHourDao(ctx)
	infos, err := adDetailHourDao.CostAndIncome()
	if err != nil {
		return "同步时报信息失败"
	}
	err = sendKuaishouTuituiMsg(infos)
	if err != nil {
		return "发送快手近一小时消耗推推消息失败"
	}
	return "发送快手近一小时消耗推推消息成功"
}

func sendKuaishouTuituiMsg(infos []kuaishoudao.CostAndIncomeStruct) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	var str string
	var msgTo string
	if len(infos) == 0 {
		str += "本小时无数据"
	} else {
		for k, v := range infos {
			if k == len(infos)-1 {
				msgTo += v.Optimizer
			} else {
				msgTo += v.Optimizer + ","
			}
			str += strconv.Itoa(k+1) + "." +
				"🔹【账号】：" + v.AccountId + " " +
				"🔹【账号名称】：" + v.AccountName + " " +
				"🔹【近1小时消耗】：" + fmt.Sprintf("%.2f", v.Cost) + " " +
				"🔹【ROI】：" + fmt.Sprintf("%.2f", v.Roi) + " \n"
		}
	}
	var toUser []string
	var mssg []string
	for _, vv := range strings.Split(msgTo, ",") {
		mssg = append(mssg, vv)
	}
	optimizerDao := accounts.NewOptimizerInfoDao(context.Background())
	opList, opErr := optimizerDao.OptimizerInfoListByNamePhone(mssg)
	if opErr != nil {
		return opErr
	}
	for _, v := range opList {
		toUser = append(toUser, v.Phone)
	}
	text := &noticeCommon.Text{
		Content: "\n" + "媒体：快手   日期：" + time.Now().Format(time.DateOnly) + " " + "小时：" + strconv.Itoa(time.Now().Hour()) + " " + " \n" + str + " \n",
	}
	if len(infos) == 0 {
		return nil
	}
	msg := &noticeCommon.SingleMessage{
		Tousers: toUser,
		Msgtype: "text",
		Text:    text,
	}
	resp, err := client.SendMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

func SyncKuaishouSeriesTuituiMsg(ctx context.Context, _ *xxl.RunReq) (msg string) {
	adDetailDao := kuaishoudao.NewAdDetailDao(ctx)
	infos, err := adDetailDao.SeriesCost()
	if err != nil {
		return "同步时报信息失败"
	}
	err = sendKuaishouSeriesTuituiMsg(infos)
	if err != nil {
		return "发送快手近一小时消耗推推消息失败"
	}
	return "发送快手近一小时消耗推推消息成功"
}

func sendKuaishouSeriesTuituiMsg(infos []kuaishoudao.SeriesMsg) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	var str string
	if len(infos) == 0 {
		str += "本小时无数据"
	} else {
		for k, v := range infos {
			strconv.Itoa(k + 1)
			str += strconv.Itoa(k+1) + ". " +
				"📗【剧目名称】：" + v.SeriesName + " " +
				"🔹【剧目ID】：" + v.SeriesId + " " +
				"🔹【累计消耗】：" + fmt.Sprintf("%.2f", v.Cost) + " " +
				"🔹【近1小时消耗】：" + fmt.Sprintf("%.2f", v.Hcost) + " " +
				"🔹【ROI】：" + fmt.Sprintf("%.2f", v.Roi) + " \n"
		}
	}
	text := &noticeCommon.Text{
		Content: "\n" + "媒体：快手   日期：" + time.Now().Format(time.DateTime) + " " + " \n" + str + " \n",
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649060123"},
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

/************************************************ 端原生推推播报 ************************************************/

func SyncRawRoiImage(ctx context.Context, param *xxl.RunReq) (msg string) {
	columns := []string{"日期", "时间", "实际消耗", "实际收入", "实际ROI"}
	syncService := meidareportdao.NewReportProjectHourDao(ctx)
	list, err := syncService.FindRawRoi()
	if err != nil {
		return "同步时报信息失败"
	}
	sumList, err := syncService.FindRawRoiSum()
	if err != nil {
		return "同步时报信息失败"
	}
	sumList = append(sumList, list...)
	data := &QueryResult3{
		Columns: columns,
		Rows:    sumList,
	}
	UploadRawRoiPNG(data)
	return "成功"
}

func UploadRawRoiPNG(result *QueryResult3) {
	file, err := generatePNGRawROI(result)
	if err != nil {
		return
	}
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	filePath := "/drama/端原生"
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649072959"},
		Msgtype:  "image",
		Image:    &noticeCommon.Image{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return
	}
	return
}

// QueryResult3 查询结果结构
type QueryResult3 struct {
	Columns []string
	Rows    []warning.RawRoi
}

// 生成PNG图片
func generatePNGRawROI(result *QueryResult3) (*os.File, error) {
	// 图片配置
	config := ImageConfig{
		Width:           1200,
		Height:          500,
		BackgroundColor: color.RGBA{255, 255, 255, 255}, // 白色背景
		TextColor:       color.RGBA{0, 0, 0, 255},       // 黑色文字
		HeaderColor:     color.RGBA{200, 200, 200, 255}, // 灰色表头
		RowColor:        color.RGBA{255, 255, 255, 255}, // 白色行
		AlternateColor:  color.RGBA{240, 240, 240, 255}, // 浅灰色交替行
		FontSize:        12,
		HeaderFontSize:  14,
		Padding:         10,
		LineHeight:      30,
	}

	// 计算图片高度
	numRows := len(result.Rows)
	headerHeight := config.LineHeight
	rowHeight := config.LineHeight
	totalHeight := headerHeight + (numRows * rowHeight) + (config.Padding * 2)

	// 如果计算的高度小于配置的高度，使用配置的高度
	if totalHeight < config.Height {
		totalHeight = config.Height
	}

	// 创建图片
	img := image.NewRGBA(image.Rect(0, 0, config.Width, totalHeight))

	// 填充背景色
	draw.Draw(img, img.Bounds(), &image.Uniform{config.BackgroundColor}, image.Point{}, draw.Src)

	// 创建绘图上下文
	c := freetype.NewContext()
	c.SetDPI(72)

	// 尝试加载支持中文的系统字体
	var fontBytes []byte
	var err error
	exPath, err := os.Getwd()
	if nil != err {
		panic(err)
	}
	path := filepath.Join(exPath, "conf", "fonts", "MSYH.TTC")
	// 检查文件存在性
	if _, err := os.Stat(path); os.IsNotExist(err) {
		return nil, fmt.Errorf("字体文件不存在: %s\n检查路径是否匹配您的操作系统", path)
	}
	fontBytes, err = ioutil.ReadFile(path)

	// 如果所有系统字体都失败，使用内置字体
	if err != nil {
		fontBytes = goregular.TTF
	}

	font, err := freetype.ParseFont(fontBytes)
	if err != nil {
		return nil, fmt.Errorf("解析字体失败: %v", err)
	}

	c.SetFont(font)
	c.SetClip(img.Bounds())
	c.SetDst(img)
	c.SetSrc(image.NewUniform(config.TextColor))

	// 绘制标题
	c.SetFontSize(10)
	title := "短剧ROI预警"
	titleWidth := int(c.PointToFixed(float64(len(title)) * 12))
	titleX := (config.Width - titleWidth) / 2
	c.DrawString(title, freetype.Pt(titleX, 40))

	// 绘制时间戳
	c.SetFontSize(10)
	timestamp := fmt.Sprintf("生成时间: %s", time.Now().Add(-900*time.Second).Format(time.DateTime))
	c.DrawString(timestamp, freetype.Pt(config.Width-200, 40))

	// 计算列宽
	colWidth := (config.Width - (config.Padding * 2)) / len(result.Columns)

	// 绘制表头
	c.SetFontSize(config.HeaderFontSize)
	c.SetSrc(image.NewUniform(config.TextColor))

	// 绘制表头背景
	headerRect := image.Rect(config.Padding, 60, config.Width-config.Padding, 60+headerHeight)
	draw.Draw(img, headerRect, &image.Uniform{config.HeaderColor}, image.Point{}, draw.Src)

	// 绘制表头文字
	x := config.Padding
	for _, col := range result.Columns {
		c.DrawString(col, freetype.Pt(x+5, 80))
		x += colWidth
	}

	// 绘制表格内容
	c.SetFontSize(config.FontSize)
	y := 60 + headerHeight

	// 使用反射获取结构体字段值
	dataValue := reflect.ValueOf(result.Rows)
	if dataValue.Kind() != reflect.Slice {
		return nil, fmt.Errorf("数据必须是切片类型")
	}

	for i := 0; i < dataValue.Len(); i++ {
		// 交替行颜色
		rowBgColor := config.RowColor
		if i%2 == 1 {
			rowBgColor = config.AlternateColor
		}

		// 绘制行背景
		rowRect := image.Rect(config.Padding, y, config.Width-config.Padding, y+rowHeight)
		draw.Draw(img, rowRect, &image.Uniform{rowBgColor}, image.Point{}, draw.Src)

		// 获取当前行的结构体
		rowStruct := dataValue.Index(i)
		if rowStruct.Kind() != reflect.Struct {
			return nil, fmt.Errorf("切片元素必须是结构体类型")
		}

		// 绘制单元格内容
		x := config.Padding
		for j := 0; j < rowStruct.NumField(); j++ {
			field := rowStruct.Field(j)
			cellStr := fmt.Sprintf("%v", field.Interface())
			c.DrawString(cellStr, freetype.Pt(x+5, y+20))
			x += colWidth
		}
		y += rowHeight
	}

	// 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.png")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close() // 立即关闭以便后续操作

	// 4. 将 Excel 写入临时文件
	if fileErr := png.Encode(tempFile, img); fileErr != nil {
		_ = os.Remove(tempFile.Name()) // 写入失败时清理文件
		return nil, fmt.Errorf("写入 PNG 失败: %v", fileErr)
	}

	// 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}

	return outputFile, nil
}

func SyncRawAlbumMsg(ctx context.Context, _ *xxl.RunReq) (msg string) {
	syncService := meidareportdao.NewReportProjectHourDao(ctx)
	list, err := syncService.FindRawAlbum("500")
	if err != nil {
		return "同步时报信息失败"
	}
	err = sendRawAlbumMsg(list)
	if err != nil {
		return "发送端原生近一小时消耗推推消息失败"
	}
	return "发送端原生近一小时消耗推推消息成功"
}

func sendRawAlbumMsg(infos []meidareportdao.RawAlbumMsg) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	var str string
	if len(infos) == 0 {
		str += "本小时无数据"
	} else {
		for k, v := range infos {
			strconv.Itoa(k + 1)
			str += strconv.Itoa(k+1) + ". " +
				"📗【剧目名称】：" + v.Name + " " +
				"🔹【累计消耗】：" + fmt.Sprintf("%.2f", v.Cost) + " " +
				"🔹【近1小时消耗】：" + fmt.Sprintf("%.2f", v.Hcost) + " " +
				"🔹【ROI】：" + fmt.Sprintf("%.2f", v.Roi) + " \n"
		}
	}
	text := &noticeCommon.Text{
		Content: "\n" + "【端原生今日累计消耗大于500且实时ROI小于70%的剧目】  日期：" + time.Now().Format(time.DateTime) + " " + " \n" + str + " \n",
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652738368403504"}, //7652669649072959
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

func SyncRawAlbumSpeedMsg(ctx context.Context, _ *xxl.RunReq) (msg string) {
	syncService := meidareportdao.NewReportProjectHourDao(ctx)
	list, err := syncService.FindRawAlbumSpeed("200")
	if err != nil {
		return "同步时报信息失败"
	}
	err = sendRawAlbumTuituiMsg(list)
	if err != nil {
		return "发送端原生时速消耗推推消息失败"
	}
	return "发送端原生时速消耗推推消息成功"
}

func sendRawAlbumTuituiMsg(infos []meidareportdao.RawAlbumMsg) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	var str string
	if len(infos) == 0 {
		str += "本小时无数据"
	} else {
		for k, v := range infos {
			strconv.Itoa(k + 1)
			str += strconv.Itoa(k+1) + ". " +
				"📗【剧目名称】：" + v.Name + " " +
				"🔹【累计消耗】：" + fmt.Sprintf("%.2f", v.Cost) + " " +
				"🔹【时速消耗】：" + fmt.Sprintf("%.2f", v.Hcost) + " " +
				"🔹【ROI】：" + fmt.Sprintf("%.2f", v.Roi) + " \n"
		}
	}
	text := &noticeCommon.Text{
		Content: "\n" + "【时速消耗大于200的剧目】 日期：" + time.Now().Format(time.DateTime) + " " + " \n" + str + " \n",
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649072959"},
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

// 商品库数据推送
func SyncTuituiHourImageExcel(ctx context.Context, param *xxl.RunReq) (msg string) {
	// 商品库今日分时数据
	eg := errgroup.Group{}
	eg.Go(func() error {
		productDataRes, err := QueryProductTodayReportData(ctx)
		if err != nil {
			return err
		}
		SendProductImageMsg(productDataRes)
		SendProductExcelRepostMsg(productDataRes)
		return nil
	})
	//剧目在商品库的统计
	eg.Go(func() error {
		bookData, err := QueryDataOfBook(ctx)
		if err != nil {
			return err
		}
		err = SendTuiTuiBookTextMsg(bookData)
		return err
	})
	// 地区统计
	eg.Go(func() error {
		regionData, err := QueryReginData(ctx)
		if err != nil {
			return err
		}
		err = SendBookRegionMsg(regionData)

		return err
	})
	// 投手统计
	eg.Go(func() error {
		optimizeData, err := QueryOptimizerData(ctx)
		if err != nil {
			return err
		}
		SendProductImageMsg(optimizeData)
		SendProductExcelRepostMsg(optimizeData)
		return nil
	})

	if err := eg.Wait(); err != nil {
		return "获取数据失败了" + err.Error()
	}
	return "成功"
}

// 商品库数据查询
func QueryProductTodayReportData(ctx context.Context) (result *noticeCommon.QueryResult, err error) {
	syncService := roi.NewReportService(ctx, false)
	// 获取商品库数据
	list, err := syncService.GetTuiTuiReportData()
	if err != nil {
		return result, fmt.Errorf("商品库今日分时统计失败:" + err.Error())
	}
	var columns = []string{"日期", "时间", "累计消耗", "今日ROI", "分时消耗", "分时ROI", "消耗环比(对比上一个小时)", "ROI环比(环比上一个小时)"}
	data := &noticeCommon.QueryResult{
		Columns:   columns,
		Rows:      list,
		Title:     "商品库今日分时数据 日期: " + time.Now().Format(time.DateTime),
		ExcelName: "商品库今日分时统计",
		GroupNum:  noticeCommon.NewTimesGroupNum,
	}
	return data, nil

}
func SendProductImageMsg(result *noticeCommon.QueryResult) {
	file, err := noticeCommon.GeneratePNGRawROI(result)
	if err != nil {
		return
	}
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	filePath := "/cost/data"
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{result.GroupNum},
		Msgtype:  "image",
		Image:    &noticeCommon.Image{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return
	}
	return
}

// excel 格式数据导出
func SendProductExcelRepostMsg(result *noticeCommon.QueryResult) {
	file, err := CreateExcelFile(result)
	if err != nil {
		return
	}
	noticeCommon.SendExcelRepostMsg(result, file)
}

func CreateExcelFile(result *noticeCommon.QueryResult) (*os.File, error) {
	file := xlsx.NewFile()
	// 1. 添加一个工作表（Sheet）
	sheet, err := file.AddSheet("Sheet1")
	if err != nil {
		return nil, fmt.Errorf("创建工作表失败: %v", err)
	}
	var sheet2 = &xlsx.Sheet{}
	if len(result.Column2) > 0 {
		sheet2, err = file.AddSheet("Sheet2")
		if err != nil {
			return nil, fmt.Errorf("创建工作表失败: %v", err)
		}
	}
	// 2.  添加表头行
	headerRow := sheet.AddRow()
	for _, column := range result.Columns {
		cell := headerRow.AddCell()
		cell.Value = column
	}
	if len(result.Column2) > 0 {
		headerRow2 := sheet2.AddRow()
		for _, column := range result.Column2 {
			cell := headerRow2.AddCell()
			cell.Value = column
		}
	}
	// 3. 添加数据行
	switch result.Rows.(type) {
	case []roi.ProductTodayReportDataVO:
		for _, row := range result.Rows.([]roi.ProductTodayReportDataVO) {
			dataRow := sheet.AddRow()
			dataRow.AddCell().SetString(row.Date)
			dataRow.AddCell().SetString(row.Hour)
			dataRow.AddCell().SetFloat(row.DayCost)
			dataRow.AddCell().SetString(row.DayRoi)
			dataRow.AddCell().SetString(row.HourCost)
			dataRow.AddCell().SetString(row.HourRoi)
			dataRow.AddCell().SetString(row.CostRatio)
			dataRow.AddCell().SetString(row.RoiRatio)

		}
		// "投手", "日期", "今日累计消耗", "今日ROI", "今日累计消耗环比",
		//"今日ROI环比", "商品库消耗", "商品库ROI", "商品库消耗环比", "商品库ROI环比"
	case []roi.OptimizeDataVo:
		for _, row := range result.Rows.([]roi.OptimizeDataVo) {
			dataRow := sheet.AddRow()
			dataRow.AddCell().SetString(row.OptimizeName)
			dataRow.AddCell().SetString(row.Date)
			dataRow.AddCell().SetString(row.DayCost)
			dataRow.AddCell().SetString(row.DayRoi)
			dataRow.AddCell().SetString(row.CostRadio)
			dataRow.AddCell().SetString(row.RoiRadio)
			dataRow.AddCell().SetString(row.DayProductCost)
			dataRow.AddCell().SetString(row.DayProductRoi)
			dataRow.AddCell().SetString(row.ProductRadio)
			dataRow.AddCell().SetString(row.ProductRoiRadio)
		}
	case []accountsService.AccountAccess:

		for _, row := range result.Rows.([]accountsService.AccountAccess) {
			//dataRow := sheet.AddRow()
			//dataRow.AddCell().SetString(row.AccountID)
			//dataRow.AddCell().SetString(row.UserID)
			dataRow2 := sheet2.AddRow()
			dataRow2.AddCell().SetString(row.AccountID)
			dataRow2.AddCell().SetString(row.ProjectID)
			dataRow2.AddCell().SetString(row.ResMsg)
		}
		for _, row := range result.Rows2.([]accountsService.AccountAccess) {
			dataRow := sheet.AddRow()
			dataRow.AddCell().SetString(row.AccountID)
			dataRow.AddCell().SetString(row.UserID)
		}

	case []roi.AccountDataInfo:
		for _, row := range result.Rows.([]roi.AccountDataInfo) {
			// 账户数据
			dataRow := sheet.AddRow()
			dataRow.AddCell().SetString(row.Date)
			dataRow.AddCell().SetString(row.AccountID)
			dataRow.AddCell().SetString(row.AccountName)
			dataRow.AddCell().SetFloat(row.Cost)
			dataRow.AddCell().SetFloat(row.Income)
			dataRow.AddCell().SetString(row.Roi)
			dataRow.AddCell().SetString(row.TodayIncome)
			dataRow.AddCell().SetString(row.ThreeDayIncome)
			dataRow.AddCell().SetString(row.IncomeRoi24)
			dataRow.AddCell().SetString(row.TodayIncomeRoi)
			dataRow.AddCell().SetString(row.ThreeIncomeRoi)
		}

		for _, row := range result.Rows2.([]roi.AccountDataInfo) {
			// 账管数据
			dataRow := sheet2.AddRow()
			//dataRow.AddCell().SetString(row.AccountID)
			//dataRow.AddCell().SetString(row.AccountName)
			dataRow.AddCell().SetString(row.Date)
			dataRow.AddCell().SetString(row.UserID)
			dataRow.AddCell().SetString(row.UserName)
			dataRow.AddCell().SetFloat(row.Cost)
			dataRow.AddCell().SetFloat(row.Income)
			dataRow.AddCell().SetString(row.Roi)
			dataRow.AddCell().SetString(row.TodayIncome)
			dataRow.AddCell().SetString(row.ThreeDayIncome)
			dataRow.AddCell().SetString(row.IncomeRoi24)
			dataRow.AddCell().SetString(row.TodayIncomeRoi)
			dataRow.AddCell().SetString(row.ThreeIncomeRoi)

		}

	}

	// 4. 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.xlsx")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close() // 立即关闭以便后续操作

	// 5. 将 Excel 写入临时文件
	if fileErr := file.Write(tempFile); fileErr != nil {
		_ = os.Remove(tempFile.Name()) // 写入失败时清理文件
		return nil, fmt.Errorf("写入 Excel 失败: %v", fileErr)
	}

	// 6. 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}
	return outputFile, nil

}

// 剧目在商品库的统计
func SendTuiTuiBookTextMsg(result *noticeCommon.QueryResult) error {
	if result == nil {
		return nil
	}
	return noticeCommon.SendTuituiTextMsg(result.Content, result.GroupNum, result.At)

}

// 查询剧目在商品库的统计
func QueryDataOfBook(ctx context.Context) (result *noticeCommon.QueryResult, err error) {
	syncService := roi.NewReportService(ctx, false)
	// 查找当前小时的剧目数据
	currentHourBookData, err := syncService.GetBookData(dao.CurHour)
	if err != nil {
		return nil, fmt.Errorf("查询剧目当前小时剧目数据失败%w", err)
	}
	// 查找上个小时的剧目数据
	lastHourBookData, err := syncService.GetBookData(dao.LastHour)
	if err != nil {
		return nil, fmt.Errorf("查询剧目上个小时剧目数据失败%w", err)
	}
	// 查找当天的累计消耗
	todayBookData, err := syncService.GetBookData(dao.Daily)
	if err != nil {
		return nil, fmt.Errorf("查询剧目当天累计消耗失败%w", err)
	}
	// 计算当前小时和上个小时的剧目数据
	return CalculateBookData(currentHourBookData, lastHourBookData, todayBookData)

}

func CalculateBookData(curBook, lastBook, todayBook []roi.ProductBookData) (*noticeCommon.QueryResult, error) {
	var curMap = make(map[int64]roi.ProductBookData, len(curBook))
	var lastMap = make(map[int64]roi.ProductBookData, len(lastBook))
	var todayMap = make(map[int64]roi.ProductBookData, len(todayBook))
	var resultList []roi.ProductBookDataVO
	for _, book := range curBook {
		if book.BookID == 0 {
			continue
		}
		curMap[book.BookID] = book
	}
	for _, book := range lastBook {
		if book.BookID == 0 {
			continue
		}
		lastMap[book.BookID] = book
	}
	for _, book := range todayBook {
		if book.BookID == 0 {
			continue
		}
		todayMap[book.BookID] = book
	}

	for _, book := range curBook {

		productBookDataVo := roi.ProductBookDataVO{}
		productBookDataVo.BookID = book.BookID
		productBookDataVo.BookName = book.BookName
		lastBookData, ok := lastMap[book.BookID]
		// 过滤时速消耗差小于300的剧目
		if book.HourCost-lastBookData.HourCost < 300 {
			continue
		}
		if ok {
			productBookDataVo.HourDiffOfLast = fmt.Sprintf("%.2f", book.HourCost-lastBookData.HourCost) // 时速消耗
			productBookDataVo.CostRadio = "0.00"
			productBookDataVo.RoiRadio = "0.00"
			if lastBookData.HourCost != 0 {
				productBookDataVo.CostRadio = fmt.Sprintf("%.2f%%", (book.HourCost-lastBookData.HourCost)/lastBookData.HourCost*100) // 消耗环比
			}
			if lastBookData.HourRoi != 0 {
				productBookDataVo.RoiRadio = fmt.Sprintf("%.2f%%", (book.HourRoi-lastBookData.HourRoi)/lastBookData.HourRoi*100) // ROI环比
			}

		}
		todayBookData, ok := todayMap[book.BookID]
		if ok {
			productBookDataVo.DayCost = fmt.Sprintf("%.2f", todayBookData.DayCost)
			productBookDataVo.DayRoi = fmt.Sprintf("%.2f%%", todayBookData.DayRoi*100)
		}

		resultList = append(resultList, productBookDataVo)

	}
	if len(resultList) == 0 {
		return nil, fmt.Errorf("没有剧目数据")
	}
	// resultList 按照剧目排序
	sort.Slice(resultList, func(i, j int) bool {
		return resultList[i].BookID < resultList[j].BookID
	})

	var contentSlice []string
	for k, book := range resultList {
		bookContent := fmt.Sprintf("%d", k+1) + ". " + fmt.Sprintf("📗【剧目名称】: %s 🔹【剧目ID】: %d 🔹【时速消耗】: %s🔹【累计消耗】: %s  🔹【ROI】: %s  🔹【消耗环比】: %s 🔹【ROI环比】:%s", book.BookName, book.BookID, book.HourDiffOfLast, book.DayCost, book.DayRoi, book.CostRadio, book.RoiRadio)
		contentSlice = append(contentSlice, bookContent)
	}

	// 发送标题
	titleContent := "标题：商品库剧目时速消耗大于300推送  日期:" + time.Now().Format(time.DateTime) + "\n"
	contentSlice = append([]string{titleContent}, contentSlice...)
	contentStr := strings.Join(contentSlice, "\n")
	return &noticeCommon.QueryResult{
		Title:    "剧目在商品库的统计",
		Content:  contentStr,
		GroupNum: noticeCommon.NewTimesGroupNum,
	}, nil
}

// 商品库by地区统计
func SendBookRegionMsg(result *noticeCommon.QueryResult) error {

	if result == nil {
		return nil
	}
	return noticeCommon.SendTuituiTextMsg(result.Content, result.GroupNum)
}

func QueryReginData(ctx context.Context) (result *noticeCommon.QueryResult, err error) {
	syncService := roi.NewReportService(ctx, false)
	// 查找当前小时region数据
	currentHourReginData, err := syncService.GetProductByRegin(dao.CurHour)
	if err != nil {
		return result, err
	}
	// 查找上个小时region数据
	lastHourReginData, err := syncService.GetProductByRegin(dao.LastHour)
	if err != nil {
		return result, err
	}
	// 查找当天累计
	dailyReginData, err := syncService.GetProductByRegin(dao.Daily)
	if err != nil {
		return result, err
	}
	// 计算region数据
	return CalculateRegionData(currentHourReginData, lastHourReginData, dailyReginData)

}

// 计算region数据
func CalculateRegionData(curData, lastData, dailyData []roi.ProductRegionData) (*noticeCommon.QueryResult, error) {
	curMap := make(map[string]roi.ProductRegionData)
	lastMap := make(map[string]roi.ProductRegionData)
	dailyMap := make(map[string]roi.ProductRegionData)
	var resultList []roi.ProductRegionDataVO

	for _, val := range curData {
		curMap[val.Region] = val
	}
	for _, val := range lastData {
		lastMap[val.Region] = val
	}
	for _, val := range dailyData {
		dailyMap[val.Region] = val
	}

	for _, val := range curMap {

		productRegionDataVo := roi.ProductRegionDataVO{}
		if val.Region == "" {
			val.Region = "其他"
		}
		productRegionDataVo.Region = val.Region
		lastVal, ok := lastMap[val.Region]
		productRegionDataVo.CostRadio = "0%"
		productRegionDataVo.RoiRadio = "0%"

		if ok {
			// 计算消耗环比和roi环比
			productRegionDataVo.CostRadio = fmt.Sprintf("%.2f%%", (val.HourCost-lastVal.HourCost)/lastVal.HourCost*100)
			productRegionDataVo.RoiRadio = fmt.Sprintf("%.2f%%", (val.HourRoi-lastVal.HourRoi)/lastVal.HourRoi*100)

		}
		dailyVal, ok := dailyMap[val.Region]
		productRegionDataVo.DayCost = "0.00"
		productRegionDataVo.DayRoi = "0.00"
		if ok {
			productRegionDataVo.DayCost = fmt.Sprintf("%.2f", dailyVal.DayCost)
			productRegionDataVo.DayCostFloat = dailyVal.DayCost
			productRegionDataVo.DayRoi = fmt.Sprintf("%.2f%%", dailyVal.DayRoi*100)
		}

		resultList = append(resultList, productRegionDataVo)
	}
	// resultList按照地名排序
	sort.Slice(resultList, func(i, j int) bool {
		return resultList[i].DayCostFloat > resultList[j].DayCostFloat
	})

	var contentSlice []string
	for k, re := range resultList {
		bookContent := fmt.Sprintf("%d", k+1) + ". " + fmt.Sprintf("🔹【地区】: %s 🔹【累计消耗】: %s 🔹【ROI】: %s"+
			"  🔹【消耗环比】: %s  🔹【ROI环比】 : %s", re.Region, re.DayCost, re.DayRoi, re.CostRadio, re.RoiRadio)
		contentSlice = append(contentSlice, bookContent)
	}
	// 标题：各地区商品库明细 日期：2025-07-16 17:05:00
	// 发送标题
	titleContent := "标题: 各地区商品库明细  日期:" + time.Now().Format(time.DateTime) + "\n"
	contentSlice = append([]string{titleContent}, contentSlice...)
	contentStr := strings.Join(contentSlice, "\n")
	return &noticeCommon.QueryResult{
		Title:    "商品库by地区统计",
		Content:  contentStr,
		GroupNum: noticeCommon.NewTimesGroupNum,
	}, nil

}

type OptimizeData struct {
	HourData            []roi.OptimizeData
	LastHourData        []roi.OptimizeData
	TodayData           []roi.OptimizeData
	ProductHourData     []roi.OptimizeData
	ProductLastHourData []roi.OptimizeData
	ProductTodayData    []roi.OptimizeData
}

// 获取投手数据
func QueryOptimizerData(ctx context.Context) (result *noticeCommon.QueryResult, err error) {
	syncService := roi.NewReportService(ctx, false)
	// 查找当前小时投手库统计数据
	currentHourOptimizeData, err := syncService.GetDataByOptimize(dao.CurHour, false)
	if err != nil {
		return result, err
	}
	// 查找上个小时投手统计数据
	lastHourOptimizeData, err := syncService.GetDataByOptimize(dao.LastHour, false)
	if err != nil {
		return result, err
	}
	// 查找投手当天累计
	curTodayOptimizeData, err := syncService.GetDataByOptimize(dao.Daily, false)
	if err != nil {
		return result, err
	}
	// 查找当前小时商品库统计
	currentHourProductData, err := syncService.GetDataByOptimize(dao.CurHour, true)
	if err != nil {
		return result, err
	}
	// 查找上个小时商品库统计
	lastHourProductData, err := syncService.GetDataByOptimize(dao.LastHour, true)
	if err != nil {
		return result, err
	}
	// 查找当天商品库统计
	dailyProductData, err := syncService.GetDataByOptimize(dao.Daily, true)
	if err != nil {
		return result, err
	}
	combineData := OptimizeData{
		HourData:            currentHourOptimizeData,
		LastHourData:        lastHourOptimizeData,
		ProductHourData:     currentHourProductData,
		ProductLastHourData: lastHourProductData,
		ProductTodayData:    dailyProductData,
		TodayData:           curTodayOptimizeData,
	}

	return CalculateOptimizeData(combineData)
}

func CalculateOptimizeData(combineData OptimizeData) (*noticeCommon.QueryResult, error) {
	curMap := make(map[int64]roi.OptimizeData)
	lastMap := make(map[int64]roi.OptimizeData)
	dailyMap := make(map[int64]roi.OptimizeData)
	productCurMap := make(map[int64]roi.OptimizeData)
	productLastMap := make(map[int64]roi.OptimizeData)
	productDailyMap := make(map[int64]roi.OptimizeData)
	var resultList []roi.OptimizeDataVo

	for _, val := range combineData.HourData {
		curMap[val.OptimizeID] = val
	}
	for _, val := range combineData.LastHourData {
		lastMap[val.OptimizeID] = val
	}
	for _, val := range combineData.TodayData {
		dailyMap[val.OptimizeID] = val
	}
	for _, val := range combineData.ProductHourData {
		productCurMap[val.OptimizeID] = val
	}
	for _, val := range combineData.ProductLastHourData {
		productLastMap[val.OptimizeID] = val
	}
	for _, val := range combineData.ProductTodayData {
		productDailyMap[val.OptimizeID] = val
	}
	for _, val := range curMap {
		optimizeDataVo := roi.OptimizeDataVo{}
		optimizeDataVo.OptimizeName = val.OptimizeName
		optimizeDataVo.CostRadio = "0%"
		optimizeDataVo.RoiRadio = "0%"
		optimizeDataVo.ProductRadio = "0%"
		optimizeDataVo.ProductRoiRadio = "0%"
		lastVal, ok := lastMap[val.OptimizeID] //上个小时
		if ok {
			// 计算今日消耗环比和roi环比
			if lastVal.HourCost != 0 {
				optimizeDataVo.CostRadio = fmt.Sprintf("%.2f%%", (val.HourCost-lastVal.HourCost)/lastVal.HourCost*100)

			}
			if lastVal.HourRoi != 0 {
				optimizeDataVo.RoiRadio = fmt.Sprintf("%.2f%%", (val.HourRoi-lastVal.HourRoi)/lastVal.HourRoi*100)
			}

		}
		// 今日累计消耗和roi
		dailyVal, ok := dailyMap[val.OptimizeID]
		if ok {
			optimizeDataVo.Date = dailyVal.Date.Format(time.DateOnly)
			optimizeDataVo.DayCost = fmt.Sprintf("%.2f", dailyVal.DayCost)
			optimizeDataVo.DayCostFloat = dailyVal.DayCost
			optimizeDataVo.DayRoi = fmt.Sprintf("%.2f%%", dailyVal.DayRoi*100)
		}
		productVal, ok := productCurMap[val.OptimizeID]
		if ok {
			productDayVal, ok := productDailyMap[val.OptimizeID]
			// 今日商品累计消耗和roi
			if ok {
				optimizeDataVo.DayProductCost = fmt.Sprintf("%.2f", productDayVal.DayCost)
				optimizeDataVo.DayProductRoi = fmt.Sprintf("%.2f%%", productDayVal.DayRoi*100)
			}
			// 上个小时商品数据
			productLastVal, ok := productLastMap[val.OptimizeID]
			if ok {
				if productLastVal.HourCost != 0 {
					optimizeDataVo.ProductRadio = fmt.Sprintf("%.2f%%", (productVal.HourCost-productLastVal.HourCost)/productLastVal.HourCost*100)
				}
				if productLastVal.HourRoi != 0 {
					optimizeDataVo.ProductRoiRadio = fmt.Sprintf("%.2f%%", (productVal.HourRoi-productLastVal.HourRoi)/productLastVal.HourRoi*100)
				}
			}
		}

		resultList = append(resultList, optimizeDataVo)
	}
	// resultList按照投手总消耗降序
	sort.Slice(resultList, func(i, j int) bool {
		return resultList[i].DayCostFloat > resultList[j].DayCostFloat
	})
	var columns = []string{"投手", "日期", "今日累计消耗", "今日ROI", "今日累计消耗环比", "今日ROI环比", "商品库消耗", "商品库ROI", "商品库消耗环比", "商品库ROI环比"}
	data := &noticeCommon.QueryResult{
		Columns:   columns,
		Rows:      resultList,
		Title:     "投手今日投放数据明细 日期: " + time.Now().Format(time.DateTime),
		ExcelName: "分投手数据",
		GroupNum:  noticeCommon.NewTimesGroupNum,
	}
	return data, nil

}

/*********************************              *********************************/

func SendDiffCostMsg(ctx context.Context, _ *xxl.RunReq) (msg string) {
	diffDao := warningdao.NewMsgWarningDao(ctx)
	info, err := diffDao.DiffCost()
	if err != nil {
		return "查询差异失败"
	}
	reportDataDao := dao.NewReportDataDao(ctx)
	lastTime, err := reportDataDao.GetProjectLastExecTime()
	if err != nil {
		return "查询最后执行时间失败"
	}
	err = sendDiffMsg(info, lastTime)
	if err != nil {
		return "发送推推消息失败"
	}
	return "同步推推时报信息成功"
}

func sendDiffMsg(info repo.ReportHourlyMaterialEntity, lastTime time.Time) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	text := &noticeCommon.Text{
		Content: "\n" + "最新执行 SWAP 时间：" + lastTime.Format(time.DateTime) + " \n" +
			"底表消耗：" + info.Cost.String() + " \n" +
			"roi查询消耗：" + info.MediaCost.String() + " \n" +
			"差异(底-roi)：" + info.Cost.Sub(info.MediaCost).String() + " \n",
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649077573"},
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

func QueryAccountData(ctx context.Context, typeInt int) (result *noticeCommon.QueryResult, err error) {
	syncService := roi.NewReportService(ctx, false)
	list, err := syncService.GetAccountInfo(typeInt)
	if err != nil {
		return result, fmt.Errorf("端原生数据获取失败:" + err.Error())
	}
	var columns = []string{
		"日期", "账户ID", "账户名称", "消耗", "收入", "ROI",
		"小程序/小游戏当日LTV", "小程序/小游戏激活后三日LTV", "激活后24小时变现ROI",
		"小程序/小游戏当日广告变现ROI", "小程序/小游戏激活后三日广告变现ROI",
	}
	var column2 = []string{
		"日期", "账管ID", "账管名称", "消耗", "收入", "ROI",
		"小程序/小游戏当日LTV", "小程序/小游戏激活后三日LTV", "激活后24小时变现ROI",
		"小程序/小游戏当日广告变现ROI", "小程序/小游戏激活后三日广告变现ROI",
	}
	var excelName string
	switch typeInt {
	case dao.Yesterday:
		excelName = "端原生账管前三日数据"
	case dao.Today:
		excelName = "端原生账管当日数据"
	}
	// 获取账管数据
	managerInfo, err := syncService.GetUserData(typeInt)
	if err != nil {
		return result, fmt.Errorf("获取账管数据失败:" + err.Error())
	}
	data := &noticeCommon.QueryResult{
		Columns:   columns,
		Column2:   column2,
		Rows:      list,
		Rows2:     managerInfo,
		Title:     "端原生账管昨日数据 日期: " + time.Now().Format(time.DateTime),
		ExcelName: excelName,
		GroupNum:  noticeCommon.NewTimesGroupName1,
	}
	return data, nil

}
func SyncTuituiAccountDataPush(ctx context.Context, param *xxl.RunReq) (msg string) {
	// 查询指定账户sql
	accountInfo, err := QueryAccountData(ctx, dao.Today)
	if err != nil {
		return fmt.Sprintf("查询账户数据失败:%s", err.Error())
	}
	//查询总消耗
	res, err := QueryAccount(ctx)
	if err != nil {
		return fmt.Sprintf("查询总消耗失败:%s", err.Error())
	}
	SendProductExcelRepostMsg(accountInfo)
	err = SendTuiTuiBookTextMsg(res)
	if err != nil {
		return fmt.Sprintf("发送消息失败:%s", err.Error())
	}
	return "成功"
}

func QueryAccount(ctx context.Context) (result *noticeCommon.QueryResult, err error) {
	syncService := roi.NewReportService(ctx, false)
	list, err := syncService.GetAccountData()
	if err != nil {
		return result, fmt.Errorf("查询失败:" + err.Error())
	}
	titleContent := "标题：端原生账户数据  日期:" + time.Now().Format(time.DateTime) + "\n"
	content := fmt.Sprintf("时间: %d\n总消耗: %0.2f\n总收入: %0.2f\nROI : %s\n ", list.Hour, list.Cost, list.Income, list.Roi)
	contentStr := titleContent + content
	return &noticeCommon.QueryResult{
		Title:    "端原生账户数据",
		Content:  contentStr,
		GroupNum: noticeCommon.NewTimesGroupName1,
	}, nil

}

// 查询昨日账管数据
func SyncTuituiAccountDataYesterday(ctx context.Context, param *xxl.RunReq) (msg string) {
	// 查询指定账户sql
	accountInfo, err := QueryAccountData(ctx, dao.Yesterday)
	if err != nil {
		return fmt.Sprintf("查询账户数据失败:%s", err.Error())
	}
	SendProductExcelRepostMsg(accountInfo)
	return "成功"
}

// 端原生数据推送
func SyncTuituiTextManageToday(ctx context.Context, param *xxl.RunReq) (msg string) {
	accountInfo, err := QueryManageToday(ctx, dao.Today)
	if err != nil {
		return fmt.Sprintf("账管数据失败:%s", err.Error())
	}
	_ = SendTuiTuiBookTextMsg(accountInfo)
	return "success"
}

func QueryManageToday(ctx context.Context, typeInt int) (result *noticeCommon.QueryResult, err error) {
	syncService := roi.NewReportService(ctx, false)
	list, err := syncService.GetMangeData(typeInt)
	if err != nil {
		return result, fmt.Errorf("查询失败:" + err.Error())
	}
	if len(list) == 0 {
		return result, fmt.Errorf("无数据")
	}
	titleContent := "当日账面消耗大于5000且账面ROI低于0.85的端原生管家\n"
	var contents []string
	for key, va := range list {
		content := fmt.Sprintf("%d、", key+1) + fmt.Sprintf("【账管】: %s 【账管ID】: %s 【账面消耗】: %0.2f 【原生短剧结算收入】: %0.2f 【ROI】: %s 【利润】: %s", va.UserName, va.UserID, va.Cost, va.Income, va.Roi, va.ProFit)
		contents = append(contents, content)
	}
	contentsStr := strings.Join(contents, "\n")
	contentStr := titleContent + contentsStr
	return &noticeCommon.QueryResult{
		Content:  contentStr,
		GroupNum: noticeCommon.NbnormalDataGroupNum,
	}, nil

}
