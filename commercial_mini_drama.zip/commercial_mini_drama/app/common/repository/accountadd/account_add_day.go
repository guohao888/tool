package accountadd

import "goserver/app/common/repository"

const AddAccountDayEntityTable = "account_add_day"

type AddAccountDayEntity struct {
	AdvertiserId string `gorm:"column:advertiser_id"` // 广告主id
	CreatedTime  string `gorm:"column:created_time"`  // 推送时间
	Status       int    `gorm:"column:status"`        // 推送状态
}

func (*AddAccountDayEntity) TableName() string {
	return AddAccountTableName()
}

func AddAccountDayTableName() string {
	if repository.IsDebugTable(AddAccountDayEntityTable) {
		return AddAccountDayEntityTable + "_dev"
	} else {
		return AddAccountDayEntityTable
	}
}
