package accounts

import (
	"encoding/json"
	"goserver/app/common/repository/accounts"
)

type CallbackToutiaoReq struct {
	Uid                string `json:"uid" form:"uid"`
	AppId              string `json:"app_id" form:"app_id"`
	MaterialAuthStatus int    `json:"material_auth_status" form:"material_auth_status"`
	State              string `json:"state" form:"state"`
	AuthCode           string `json:"auth_code" form:"auth_code"`
	Scope              string `json:"scope" form:"scope"`
}

type OauthIdsStruct struct {
	OauthIds []string `json:"oauth_ids"`
}

type OauthRefreshExecutorParams struct {
	OauthIdsStruct
}

func (p OauthIdsStruct) ToMap() map[string]struct{} {
	m := make(map[string]struct{})

	if len(p.OauthIds) > 0 {
		for _, oauthId := range p.OauthIds {
			m[oauthId] = struct{}{}
		}
	}
	return m
}

type OauthAccountSyncExecutorParams struct {
	MasterAppId string `json:"master_app_id"`
}

type CallbackKuaishouReq struct {
	State    string `json:"state" form:"state"`
	AuthCode string `json:"auth_code" form:"auth_code"`
}

func (r *CallbackKuaishouReq) GetState() (*accounts.CallbackKuaishouState, error) {
	if r.State == "" {
		return nil, nil
	}

	var state accounts.CallbackKuaishouState
	err := json.Unmarshal([]byte(r.State), &state)
	if err != nil {
		return nil, err
	}
	return &state, nil
}

type OauthCheckValidityParams struct {
	OauthIdsStruct
	Media []string `json:"media"`
}
