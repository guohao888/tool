package synctable

import (
	"github.com/avast/retry-go"
	"goserver/app/model/dao/roi"
	"time"
)

// QueryAndSaveFinalInfosHistory 查询保存最终数据-历史
func (p *ProjectCostService) QueryAndSaveFinalInfosHistory() map[string]string {
	finalDao := roi.NewReportDataDao(p.Ctx)

	var execTime string
	errList := make(map[string]string)
	startDate := time.Now().Add(-172800 * time.Second)
	endDate := time.Now().Add(-86400 * time.Second)
	for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
		err := retry.Do(func() error {
			execTime = currentDate.Format(time.DateOnly)
			errHasCostAndIncome := finalDao.AggHasCostAndIncomePromotionDataHistory(execTime)
			if errHasCostAndIncome != nil {
				errList[execTime] = errHasCostAndIncome.Error()
				return errHasCostAndIncome
			}
			errHasCostNoIncome := finalDao.AggNoCostPromotionDataHistory(execTime)
			if errHasCostNoIncome != nil {
				errList[execTime] = errHasCostNoIncome.Error()
				return errHasCostNoIncome
			}
			// 执行账单数据
			err := finalDao.BuildAggProjectFinalBillEntity(execTime)
			if err != nil {
				errList[execTime] = err.Error()
			}
			return nil
		}, retry.Delay(time.Second*300), retry.Attempts(3))
		if err != nil {
			errList[execTime] = err.Error()
			return errList
		}
	}
	return errList
}

// QueryAndSaveFinalInfosToday 查询保存最终数据-今日
func (p *ProjectCostService) QueryAndSaveFinalInfosToday() map[string]string {
	finalDao := roi.NewReportDataDao(p.Ctx)

	var execTime string
	errList := make(map[string]string)
	execTime = time.Now().Format(time.DateOnly)
	//errHasCostAndIncome := finalDao.AggHasCostAndIncomePromotionDataToday(execTime)
	//if errHasCostAndIncome != nil {
	//	errList[execTime] = errHasCostAndIncome.Error()
	//}
	errHasCostNoIncome := finalDao.AggHasCostNoIncomePromotionDataToday(execTime)
	if errHasCostNoIncome != nil {
		errList[execTime] = errHasCostNoIncome.Error()
	}
	return errList
}
