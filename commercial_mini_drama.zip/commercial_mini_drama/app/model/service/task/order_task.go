package task

import (
	"context"
	"goserver/app/common/dto/fanqie"
	"goserver/app/common/dto/spidto"
	"goserver/app/common/dto/subscribedto"
	"goserver/app/library/kafka"
	"goserver/app/library/log"
	"goserver/app/library/myerror"
	f "goserver/app/model/service/fanqie"
	"goserver/app/model/service/spi"
	"goserver/app/model/service/subscribe"

	"github.com/spf13/viper"
)

func ExecUserKafka2DB() {
	dbPrefix := "kafka_user"
	// 获取 kafka 配置信息
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	groupID := "mini_drama_report_user"
	// 设置回调方法
	newFunc := func(users []fanqie.TomatoUserReq) {
		tomatoIAAUserService := f.NewTomatoUserService(context.Background())
		err := tomatoIAAUserService.SaveUserInfos(users)
		if err != nil {
			log.Errorf("用户数据同步kafka数据到DB失败, err: %s", myerror.DBExecError.Message)
			return
		}
	}
	// 阻塞消费数据 2000条提交一次
	consumer, err := kafka.NewUserConsumer(brokers, groupID, topic, newFunc)
	if err != nil {
		return
	}
	consumer.Consume(context.Background())
}

func ExecIAAOrderKafka2DB() {
	// 获取 kafka 配置信息
	dbPrefix := "kafka_iaa_order"
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	groupID := "mini_drama_report_iaa_order"
	// 设置回调方法
	newFunc := func(orders []fanqie.TomatoIAAOrderReq) {
		tomatoIAAOrderService := f.NewTomatoIAAOrderService(context.Background())
		err := tomatoIAAOrderService.SaveIAAOrderInfos(orders)
		if err != nil {
			log.Errorf("IAA订单数据同步kafka数据到DB失败, err: %s", myerror.DBExecError.Message)
			return
		}
		return
	}
	// 阻塞消费数据 2000条提交一次
	consumer, err := kafka.NewIOrderConsumer(brokers, groupID, topic, newFunc)
	if err != nil {
		return
	}
	consumer.Consume(context.Background())
}

func ExecIAPOrderKafka2DB() {
	// 获取 kafka 配置信息
	dbPrefix := "kafka_iap_order"
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	groupID := "mini_drama_report_iap_order"
	// 设置回调方法
	newFunc := func(orders []fanqie.TomatoIAPOrderReq) {
		tomatoIAAOrderService := f.NewTomatoIAPOrderService(context.Background())
		err := tomatoIAAOrderService.SaveIAPOrderInfos(orders)
		if err != nil {
			log.Errorf("IAP订单数据同步kafka数据到DB失败, err: %s", myerror.DBExecError.Message)
			return
		}
		return
	}
	// 阻塞消费数据 2000条提交一次
	consumer, err := kafka.NewPOrderConsumer(brokers, groupID, topic, newFunc)
	if err != nil {
		return
	}
	consumer.Consume(context.Background())
}

func ExecSpiMaterialKafka2DB() {
	// 获取 kafka 配置信息
	dbPrefix := "kafka_spi_material"
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	groupID := "mini_drama_spi_material"

	// 设置回调方法
	newFunc := func(reqs []spidto.SpiMaterialRequest) {
		SpiMaterialService := spi.NewSpiMaterialService(context.Background())
		err := SpiMaterialService.SaveSpiMaterialInfos(reqs)
		if err != nil {
			log.Errorf("oceanengine spi 订阅数据kafka同步DB失败, err: %s", myerror.DBExecError.Message)
			return
		}
		return
	}
	// 阻塞消费数据 2000条提交一次
	consumer, err := kafka.NewConsumerSpiMaterial(brokers, groupID, topic, newFunc)
	if err != nil {
		log.Errorf("创建 SPI 素材消费者失败: err=%s", err.Error())
		return
	}
	consumer.Consume(context.Background())
}

func ExecSubscribeKafka2DB() {
	// 获取 kafka 配置信息
	dbPrefix := "kafka_subscribe"
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	groupID := "mini_drama_subscribe"

	// 设置回调方法
	beforeFunc := func(reqs []subscribedto.PostInfoReq) {
		subscribeService := subscribe.NewSubscribedService(context.Background())
		err := subscribeService.InsertBeforeTask(reqs)
		if err != nil {
			log.Errorf("订阅账号数据kafka同步DB失败, err: %s", myerror.DBExecError.Message)
			return
		}
		return
	}
	// 设置回调方法
	todayFunc := func(reqs []subscribedto.PostInfoReq) {
		subscribeService := subscribe.NewSubscribedService(context.Background())
		err := subscribeService.InsertTodayTask(reqs)
		if err != nil {
			log.Errorf("订阅账号数据kafka同步DB失败, err: %s", myerror.DBExecError.Message)
			return
		}
		return
	}
	// 阻塞消费数据 2000条提交一次
	consumer, err := kafka.NewSubscribeConsumer(brokers, groupID, topic, beforeFunc, todayFunc)
	if err != nil {
		return
	}
	consumer.Consume(context.Background())
}

//func BatchPushUsers(ctx context.Context, param *xxl.RunReq) (msg string) {
//	// 获取 kafka 配置信息
//	dbPrefix := "kafka_user"
//	brokers := []string{viper.GetString(dbPrefix + ".broker")}
//	topic := viper.GetString(dbPrefix + ".topic_name")
//	// 获取生产者
//	producer, err := kafka.NewKafkaProducer(brokers, topic)
//	if err != nil {
//		return
//	}
//	glu := gl.GetGluList()
//	list := glu.GetList()
//	for _, item := range list {
//		err = producer.AddUsers(item)
//		if err != nil {
//			log.Errorf("保存用户数据到kafka失败:err :%s", err.Error())
//			continue
//		}
//	}
//	return "推送用户数据到kafka成功"
//}
//
//func BatchPushIAAOrders(ctx context.Context, param *xxl.RunReq) (msg string) {
//	// 获取 kafka 配置信息
//	dbPrefix := "kafka_iaa_order"
//	brokers := []string{viper.GetString(dbPrefix + ".broker")}
//	topic := viper.GetString(dbPrefix + ".topic_name")
//	// 获取生产者
//	producer, err := kafka.NewKafkaProducer(brokers, topic)
//	if err != nil {
//		return
//	}
//	glio := gl.GetGlioList()
//	list := glio.GetList()
//	for _, item := range list {
//		err = producer.AddIAAOrders(item)
//		if err != nil {
//			log.Errorf("保存到IAA订单数据kafka失败:err :%s", err.Error())
//			continue
//		}
//	}
//	return "推送IAA订单数据到kafka成功"
//}
//
//func BatchPushIAPOrders(ctx context.Context, param *xxl.RunReq) (msg string) {
//	// 获取 kafka 配置信息
//	dbPrefix := "kafka_iap_order"
//	brokers := []string{viper.GetString(dbPrefix + ".broker")}
//	topic := viper.GetString(dbPrefix + ".topic_name")
//	// 获取生产者
//	producer, err := kafka.NewKafkaProducer(brokers, topic)
//	if err != nil {
//		return
//	}
//	glpo := gl.GetGlpoList()
//	list := glpo.GetList()
//	for _, item := range list {
//		err = producer.AddIAPOrders(item)
//		if err != nil {
//			log.Errorf("保存IAP订单数据到kafka失败:err :%s", err.Error())
//			continue
//		}
//	}
//	return "推送IAP订单数据到kafka成功"
//}
