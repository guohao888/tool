package accounts

import (
	"context"
	accountdto "goserver/app/common/dto/accounts"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/library/playlet"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
)

type OauthAccountService struct {
	Ctx context.Context
}

func NewOauthAccountService(ctx context.Context) *OauthAccountService {
	return &OauthAccountService{Ctx: ctx}
}

func (s *OauthAccountService) OauthAccountSync(media string, params accountdto.OauthAccountSyncExecutorParams) error {
	oauthDao := accountdao.NewOauthDao(s.Ctx)
	list, err := oauthDao.ListOauthByMediaAppIds(media, []string{params.MasterAppId})
	if err != nil {
		log.Errorf("[OauthAccountService.OauthAccountSync] 根据媒体获取oauth授权列表错误, err: %s", err)
		return err
	}

	oauthAccountDao := accountdao.NewOauthAccountDao(s.Ctx)

	for _, oauth := range list {
		accountIds, err := s.GetOauthAccounts(oauth)
		if err != nil {
			log.Errorf("[OauthAccountService.OauthAccountSync] 同步账号查询接口数据失败, oauth_id: %s, err: %s", oauth.OauthId, err)
			return err
		}

		err = oauthAccountDao.InsertBatchSize(media, oauth.OauthId, oauth.UserId, accountIds, 1000)
		if err != nil {
			log.Errorf("[OauthAccountService.OauthAccountSync] 同步账号写入数据失败, oauth_id: %s, err: %s", oauth.OauthId, err)
			return err
		}
	}

	return nil
}

func (s *OauthAccountService) GetOauthAccounts(o accountrepo.OauthEntity) (accountIds []playlet.AdvertiserInfo, err error) {
	// 调用更新授权令牌接口
	switch o.Media {
	case repo.MediaToutiao:
		// 获取授权账户下的子账号
		advertiserIds, err := toutiao.AllOauth2MajordomoAdvertiserId(s.Ctx, o.AccessToken)
		if err != nil {
			return nil, err
		}
		accountIds = append(accountIds, advertiserIds...)
	case repo.MediaKuaishou:
		// todo 快手oauth授权账户同步
	}

	return accountIds, nil
}
