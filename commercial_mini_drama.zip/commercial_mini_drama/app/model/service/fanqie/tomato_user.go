package fanqie

import (
	"context"
	dto "goserver/app/common/dto/fanqie"
	"goserver/app/model/dao/fanqie"
)

// TomatoUserService 番茄用户Service
type TomatoUserService struct {
	Ctx context.Context
}

// NewTomatoUserService 创建上下文用户Service
func NewTomatoUserService(ctx context.Context) *TomatoUserService {
	return &TomatoUserService{Ctx: ctx}
}

// SaveUserInfos 保存用户数据
func (t *TomatoUserService) SaveUserInfos(req []dto.TomatoUserReq) error {
	tomatoIAAIUserDao := fanqie.NewTomatoUserDao(t.Ctx)
	err := tomatoIAAIUserDao.Req2Entity(req)
	return err
}
