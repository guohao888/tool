package roi

import (
	"context"
	"goserver/app/common/repository/roi"
	"goserver/app/library/driver/dorisdb"
	"strings"
)

type FilterOptionsDao struct {
	Ctx context.Context
}

const ValueTypeMedia = "media"
const ValueTypeDeliveryProduct = "delivery_product"

func NewFilterOptionsDao(ctx context.Context) *FilterOptionsDao {
	return &FilterOptionsDao{Ctx: ctx}
}

// OptionsAry 获取过滤选项列表
func (d *FilterOptionsDao) OptionsAry(valueType string) (res []string, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(roi.ReportFilterOptionsTableName())
	q = q.Where("value_type=?", valueType)
	q = q.Order("sort ASC")
	err = q.Pluck("filter_value", &res).Error
	if err != nil {
		return
	}
	return
}

// SelectOptionEnum 获取具体选项
func (d *FilterOptionsDao) SelectOptionEnum(valueType string, filterValue string) (res []string, err error) {
	var rt roi.ReportFilterOptions
	db := dorisdb.DorisClient()
	q := db.Table(roi.ReportFilterOptionsTableName())
	q = q.Select("enum_value")
	q = q.Where("value_type=?", valueType)
	q = q.Where("filter_value=?", filterValue)
	err = q.First(&rt).Error
	if err != nil {
		return
	}
	if rt.EnumValue != "" {
		res = strings.Split(rt.EnumValue, ",")
	}
	return
}
