package entrance

import (
	"fmt"
	"goserver/app/library/config"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/library/driver/mysqldb"
	"goserver/app/library/driver/redisdb"
	"goserver/app/library/kafka"
	"goserver/app/library/log"
	"os"
	"path/filepath"
	"strings"
)

var Entrance *entrance

type entrance struct {
	ConfigPath string
	TplPath    string
}

func NewEntrance() {
	Entrance = &entrance{}
}

func (e *entrance) InitEnv(cfg string, tpl string) {
	e.ConfigPath = cfg
	e.TplPath = tpl

	//默认使用local 配置文件
	if strings.EqualFold("default", e.ConfigPath) {
		exPath, err := os.Getwd()
		if nil != err {
			panic(err)
		}
		e.ConfigPath = exPath + "/conf/local"
	}

	//默认使用debug 配置文件
	if strings.EqualFold("default", e.TplPath) {
		exPath, err := os.Getwd()
		if nil != err {
			panic(err)
		}
		e.TplPath = exPath + "/template"
	}

	// print basic info.
	fmt.Printf("config file base path: %s. \n", e.ConfigPath)
	fmt.Printf("tpl file base path: %s. \n", e.TplPath)
}

func (e *entrance) LoadConfig() {
	path := filepath.Join(e.ConfigPath, "config.yml")
	err := config.Init(path)
	if nil != err {
		panic(err)
	}
}

func (e *entrance) InitLogSystem() {
	log.InitLogrusLog()      //业务日志
	log.InitLogrusCmdLog()   //command 日志
	log.InitLogrusDotLog()   //打点  日志
	log.InitLogrusEventLog() //event 日志
	log.Debug("Init Log System success.")
}

func (e *entrance) InitMySQL() {
	err := mysqldb.InitMysql()
	if err != nil {
		panic(fmt.Sprintf("Init Mysql Failed. err: %s", err.Error()))
	}
}

func (e *entrance) InitStarRocks() {
	err := dorisdb.InitDoris()
	if err != nil {
		panic(fmt.Sprintf("Init StarRocks Failed. err: %s", err.Error()))
	}
}

func (e *entrance) InitRedis() {
	redisdb.NewRedisPool()
	redisdb.Test()
	redisdb.InitRedSync() // 分布式锁
	redisdb.NewRedisCluster()
	redisdb.ClusterTest()

	log.Debug("Init redis success.")
}

func (e *entrance) InitKafka() {
	err := kafka.InitIOrderClient()
	if err != nil {
		panic(fmt.Sprintf("InitIOrderClient Failed. err: %s", err.Error()))
	}
	err = kafka.InitPOrderClient()
	if err != nil {
		panic(fmt.Sprintf("InitPOrderClient Failed. err: %s", err.Error()))
	}
	err = kafka.InitUserClient()
	if err != nil {
		panic(fmt.Sprintf("InitUserClient Failed. err: %s", err.Error()))
	}
	err = kafka.InitSpiMaterialClient()
	if err != nil {
		panic(fmt.Sprintf("InitSpiMaterialClient Failed. err: %s", err.Error()))
	}
	err = kafka.InitISubscribeClient()
	if err != nil {
		panic(fmt.Sprintf("InitISubscribeClient Failed. err: %s", err.Error()))
	}
}
