package kuaishou

import (
	"context"
	"fmt"
	repo "goserver/app/common/repository"
	kuaishouEntity "goserver/app/common/repository/kuaishou"
	"goserver/app/library/playlet/kuaishou"
	accountdao "goserver/app/model/dao/accounts"
	kuaishoudao "goserver/app/model/dao/kuaishou"
	"strconv"
)

type SeriesService struct {
	Ctx context.Context
}

func NewSeriesService(ctx context.Context) *SeriesService {
	return &SeriesService{Ctx: ctx}
}

func (r *SeriesService) KuaishouSeriesInfo(ctx context.Context) error {
	// 获取所有token
	oauthDao := accountdao.NewOauthDao(ctx)
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaKuaishou, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	for _, oa := range oauthList {
		advertiserId, _ := strconv.Atoi(oa.UserId)
		res, err := kuaishou.ReportQuerySeriesInfo(ctx, kuaishou.ReportQueryAccountInfoReq{
			OauthId:      oa.OauthId,
			AccessToken:  oa.AccessToken,
			AdvertiserId: int64(advertiserId),
		})
		if res != nil && res.Code != kuaishou.CodeSuccess {
			return err
		}
		var list []*kuaishouEntity.SeriesInfoEntity
		if res == nil {
			continue
		}
		for _, v := range res.Data {
			seriesId, _ := strconv.Atoi(v.SeriesId)
			info := &kuaishouEntity.SeriesInfoEntity{
				AdvertiserId: int64(advertiserId),
				SeriesId:     int64(seriesId),
				SeriesName:   v.SeriesName,
				AuditStatus:  v.AuditStatus,
				SellStatus:   v.SellStatus,
			}
			list = append(list, info)
		}
		seriesDao := kuaishoudao.NewSeriesDao(ctx)
		insertErr := seriesDao.InsertBatchSize(list, 2000)
		if insertErr != nil {
			return insertErr
		}
	}
	return nil
}
