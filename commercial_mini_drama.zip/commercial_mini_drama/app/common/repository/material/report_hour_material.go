package material

import (
	"github.com/shopspring/decimal"
	"goserver/app/common/repository"
)

const ReportHourlyMaterialTable = "material_report_hourly"

type ReportHourlyMaterialEntity struct {
	Date              string `gorm:"column:date" json:"date"`                             // 时间点
	Hour              int    `gorm:"column:hour" json:"hour"`                             // 小时
	Media             string `gorm:"column:media" json:"media"`                           // 媒体
	BookID            int64  `gorm:"column:book_id" json:"book_id"`                       // 剧目ID
	BookName          string `gorm:"column:book_name" json:"book_name"`                   // 剧目名称
	PayType           string `gorm:"column:pay_type" json:"pay_type"`                     // 付费类型 1: IAA 2: IAP
	AppID             string `gorm:"column:app_id" json:"app_id"`                         // 公众号/快应用/小程序id（分销平台id）【v1.2】
	AppName           string `gorm:"column:app_name" json:"app_name"`                     // 小程序名称（应用包名）
	OptimizerID       int64  `gorm:"column:optimizer_id" json:"optimizer_id"`             // 投手ID
	OptimizerNickname string `gorm:"column:optimizer_nickname" json:"optimizer_nickname"` // 投手昵称
	AccountID         string `gorm:"column:account_id" json:"account_id"`                 // 媒体账户ID
	AccountName       string `gorm:"column:account_name" json:"account_name"`             // 媒体账户名称-广告主名称
	PromotionID       string `gorm:"column:promotion_id" json:"promotion_id"`             // 广告ID
	PromotionName     string `gorm:"column:promotion_name" json:"promotion_name"`         // 广告名称
	MidID             string `gorm:"column:mid_id" json:"mid_id"`                         // 图片或视频ID
	MidType           string `gorm:"column:mid_type" json:"mid_type"`                     // 素材类型 视频或者图片
	MaterialName      string `gorm:"column:material_name" json:"material_name"`           // 素材名称
	MaterialCover     string `gorm:"column:material_cover" json:"material_cover"`         // 素材封面
	EditorName        string `gorm:"column:editor_name" json:"editor_name"`               // 剪辑师
	EditorRegion      string `gorm:"column:editor_region" json:"editor_region"`           // 剪辑师地区
	DataType          int    `gorm:"column:data_type" json:"data_type"`                   // 数据行类型 0: 正常消耗行 2: 账户维度0点的赠款及返点比例行

	SpendingCampaignsCount int             `gorm:"column:spending_campaigns_count" json:"spending_campaigns_count"` // 关联有消耗计划数(素材名字维度)
	MediaCost              decimal.Decimal `gorm:"column:media_cost" json:"media_cost"`                             // 媒体消耗
	RewardCost             decimal.Decimal `gorm:"column:reward_cost" json:"reward_cost"`                           // 账户赠款
	SharedWalletCost       decimal.Decimal `gorm:"column:shared_wallet_cost" json:"shared_wallet_cost"`             // 账户共享赠款
	MediaRebateRate        decimal.Decimal `gorm:"column:media_rebate_rate" json:"media_rebate_rate"`               // 媒体返点比例
	ShowCount              int             `gorm:"column:show_count" json:"show_count"`                             // 展示数
	ClickCount             int             `gorm:"column:click_count" json:"click_count"`                           // 点击数
	MediaActiveCount       int             `gorm:"column:media_active_count" json:"media_active_count"`             // 媒体激活数
	MediaConvertCount      int             `gorm:"column:media_convert_count" json:"media_convert_count"`           // 媒体转化数
	MediaFirstPayCount     int             `gorm:"column:media_first_pay_count" json:"media_first_pay_count"`       // 媒体首日付费数
	Income                 decimal.Decimal `gorm:"column:income" json:"income"`                                     // 实际收入(分成后)
	ActiveCount            int             `gorm:"column:active_count" json:"active_count"`                         // 实际激活数
	NewPayCount            int             `gorm:"column:new_pay_count" json:"new_pay_count"`                       // 实际新增用户付费数
	ActivePayCount         int             `gorm:"column:active_pay_count" json:"active_pay_count"`                 // 实际活跃用户付费数
	FirstIncome            decimal.Decimal `gorm:"column:first_income" json:"first_income"`                         // 首日新增收入
	NewSumIncome           decimal.Decimal `gorm:"column:new_sum_income" json:"new_sum_income"`                     // 新用户累计收入(日周天维度取hour=0的)
	Income2                decimal.Decimal `gorm:"column:income2" json:"income2"`                                   // 新用户2日收入(日周天维度取hour=0的)
	Income3                decimal.Decimal `gorm:"column:income3" json:"income3"`                                   // 新用户3日收入(日周天维度取hour=0的)
	Income4                decimal.Decimal `gorm:"column:income4" json:"income4"`                                   // 新用户4日收入(日周天维度取hour=0的)
	Income5                decimal.Decimal `gorm:"column:income5" json:"income5"`                                   // 新用户4日收入(日周天维度取hour=0的)
	Income6                decimal.Decimal `gorm:"column:income6" json:"income6"`                                   // 新用户4日收入(日周天维度取hour=0的)
	Income7                decimal.Decimal `gorm:"column:income7" json:"income7"`                                   // 新用户4日收入(日周天维度取hour=0的)

	Cost              decimal.Decimal `gorm:"column:cost" json:"cost"`                                 // 实际消耗=媒体消耗/(1+返点比例2%)
	CostHb            decimal.Decimal `gorm:"column:cost_hb" json:"cost_hb"`                           // 消耗环比(上个时段)
	ClickRate         float64         `gorm:"column:click_rate" json:"click_rate"`                     // 点击率=点击数/展示数
	ShowCost          float64         `gorm:"column:show_cost" json:"show_cost"`                       // 千展成本=(媒体消耗/展示数)*1000
	ClickCost         float64         `gorm:"column:click_cost" json:"click_cost"`                     // 点击成本=媒体消耗/点击数
	MediaActiveCost   float64         `gorm:"column:media_active_cost" json:"media_active_cost"`       // 媒体激活成本=实际消耗/媒体激活数
	MediaActiveRate   float64         `gorm:"column:media_active_rate" json:"media_active_rate"`       // 媒体激活率=媒体激活数/点击数
	MediaConvertCost  float64         `gorm:"column:media_convert_cost" json:"media_convert_cost"`     // 媒体转化成本=实际消耗/媒体转化数
	MediaFirstPayCost float64         `gorm:"column:media_first_pay_cost" json:"media_first_pay_cost"` // 媒体首日付费成本=实际消耗/首日付费数
	Roi               float64         `gorm:"column:roi" json:"roi"`                                   // 实际收入(分成后)/实际花费
	ActiveCost        float64         `gorm:"column:active_cost" json:"active_cost"`                   // 实际激活成本=实际消耗/实际激活数
	FirstRoi          float64         `gorm:"column:first_roi" json:"first_roi"`                       // 首日新增ROI=首日新增收入/实际消耗
	NewSumRoi         float64         `gorm:"column:new_sum_roi" json:"new_sum_roi"`                   // 新用户累计ROI=新用户累计收入/实际消耗
	AvgIpu            float64         `gorm:"column:avg_ipu" json:"avg_ipu"`                           // 人均IPU次数=激励广告点击次数/实际新增用户付费数
	Arpu              float64         `gorm:"column:arpu" json:"arpu"`                                 // ARPU=首日新增收入/实际新增用户付费数
	Profit            decimal.Decimal `gorm:"column:profit" json:"profit"`                             // 日利润=实际收入(分成后)-实际消耗
	Roi2              float64         `gorm:"column:roi2" json:"roi2"`                                 // 新用户2日ROI=新用户2日收入/实际花费
	Roi3              float64         `gorm:"column:roi3" json:"roi3"`                                 // 新用户3日ROI=新用户3日收入/实际花费
	Roi4              float64         `gorm:"column:roi4" json:"roi4"`                                 // 新用户4日ROI=新用户4日收入/实际花费
	Roi5              float64         `gorm:"column:roi5" json:"roi5"`                                 // 新用户5日ROI=新用户5日收入/实际花费
	Roi6              float64         `gorm:"column:roi6" json:"roi6"`                                 // 新用户6日ROI=新用户6日收入/实际花费
	Roi7              float64         `gorm:"column:roi7" json:"roi7"`                                 // 新用户7日ROI=新用户7日收入/实际花费
}

var ExcelNumColumn = []string{"book_id", "optimizer_id", "hour",
	"show_count", "click_count", "spending_campaigns_count",
	"media_active_count", "media_convert_count", "media_first_pay_count",
	"active_count", "new_pay_count", "active_pay_count"}

var ExcelStringColumn = []string{"media", "book_name", "pay_type", "app_id", "app_name",
	"mid_id", "material_cover", "material_name", "optimizer_nickname", "editor_name", "editor_region",
	"account_id", "account_name", "promotion_id", "promotion_name"}

func (*ReportHourlyMaterialEntity) TableName() string {
	return ReportHourlyMaterialTableName()
}

func ReportHourlyMaterialTableName() string {
	if repository.IsDebugTable(ReportHourlyMaterialTable) {
		return ReportHourlyMaterialTable + "_dev"
	} else {
		return ReportHourlyMaterialTable
	}
}

// Calculate 计算指标处理
func (r *ReportHourlyMaterialEntity) Calculate() *ReportHourlyMaterialEntity {
	if r.ShowCount > 0 {
		// 点击率=点击数/展示数
		r.ClickRate = float64(r.ClickCount) / float64(r.ShowCount)
		// 千展成本=(媒体消耗/展示数)*1000
		r.ShowCost, _ = r.Cost.Div(decimal.NewFromInt(int64(r.ShowCount))).Float64()
		r.ShowCost *= 1000.0
	}
	if r.ClickCount > 0 {
		// 点击成本=媒体消耗/点击数
		r.ClickCost, _ = r.Cost.Div(decimal.NewFromInt(int64(r.ClickCount))).Float64()
		// 媒体激活率=媒体激活数/点击数
		r.MediaActiveCost = float64(r.MediaActiveCount) / float64(r.ClickCount)
	}
	if r.MediaActiveCount > 0 {
		// 媒体激活成本=实际消耗/媒体激活数
		r.MediaActiveCost, _ = r.Cost.Div(decimal.NewFromInt(int64(r.MediaActiveCount))).Float64()
	}
	if r.MediaConvertCount > 0 {
		// 媒体转化成本=实际消耗/媒体转化数
		r.MediaConvertCost, _ = r.Cost.Div(decimal.NewFromInt(int64(r.MediaConvertCount))).Float64()
	}
	if r.MediaFirstPayCount > 0 {
		// 媒体首日付费成本=实际消耗/首日付费数
		r.MediaFirstPayCost, _ = r.Cost.Div(decimal.NewFromInt(int64(r.MediaFirstPayCount))).Float64()
	}
	if r.Cost.Cmp(decimal.NewFromInt(0)) > 0 {
		// ROI=实际收入(分成后)/实际花费
		r.Roi, _ = r.Income.Div(r.Cost).Float64()
		// 首日新增ROI=首日新增收入/实际消耗
		r.FirstRoi, _ = r.FirstIncome.Div(r.Cost).Float64()
		// 新用户累计ROI=新用户累计收入/实际消耗
		r.NewSumRoi, _ = r.NewSumIncome.Div(r.Cost).Float64()
		// 新用户2日ROI=新用户2日收入/实际花费
		r.Roi2, _ = r.Income2.Div(r.Cost).Float64()
		// 新用户3日ROI=新用户3日收入/实际花费
		r.Roi3, _ = r.Income3.Div(r.Cost).Float64()
		// 新用户4日ROI=新用户4日收入/实际花费
		r.Roi4, _ = r.Income4.Div(r.Cost).Float64()
		// 新用户5日ROI=新用户5日收入/实际花费
		r.Roi5, _ = r.Income5.Div(r.Cost).Float64()
		// 新用户6日ROI=新用户6日收入/实际花费
		r.Roi6, _ = r.Income6.Div(r.Cost).Float64()
		// 新用户7日ROI=新用户7日收入/实际花费
		r.Roi7, _ = r.Income7.Div(r.Cost).Float64()
	}
	if r.ActiveCount > 0 {
		// 实际激活成本=实际消耗/实际激活数
		r.ActiveCost, _ = r.Cost.Div(decimal.NewFromInt(int64(r.ActiveCount))).Float64()
	}
	if r.NewPayCount > 0 {
		// 人均IPU次数=激励广告点击次数/实际新增用户付费数
		r.AvgIpu = float64(r.ClickCount) / float64(r.NewPayCount)
		// ARPU=首日新增收入/实际新增用户付费数
		r.Arpu, _ = r.FirstIncome.Div(decimal.NewFromInt(int64(r.NewPayCount))).Float64()
	}
	// 日利润=实际收入(分成后)-实际消耗
	r.Profit = r.Income.Sub(r.Cost)
	return r
}
