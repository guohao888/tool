package common

import (
	"fmt"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"os"
	"path/filepath"
	"reflect"
	"time"

	"github.com/golang/freetype"
	"golang.org/x/image/font/gofont/goregular"
)

// 商品库时报&日数据推送
const NewTimesGroupNum = "7652669649076830"
const NewTimesGroupName1 = "7652669649085358"

// 7652669649092606
const NbnormalDataGroupNum = "7652669649092606"

// QueryResult 定义表格数据结构
type QueryResult struct {
	Columns   []string    `json:"columns,omitempty"`
	Column2   []string    `json:"columns2,omitempty"`
	Rows      interface{} //
	Rows2     interface{}
	Content   string `json:"content,omitempty"`
	Title     string `json:"title,omitempty"`
	ExcelName string `json:"excel_name,omitempty"`
	GroupNum  string
	At        string `json:"at"` // 发送群内指定的人员
}

// ImageConfig 图片生成配置
type ImageConfig struct {
	Width           int
	Height          int
	BackgroundColor color.RGBA
	TextColor       color.RGBA
	HeaderColor     color.RGBA
	RowColor        color.RGBA
	AlternateColor  color.RGBA
	FontSize        float64
	HeaderFontSize  float64
	Padding         int
	LineHeight      int
	FontPath        string // 字体路径
	Title           string // 标题
}

// NewDefaultImageConfig 创建默认配置
func NewDefaultImageConfig(title string) ImageConfig {
	return ImageConfig{
		Width:           1500,
		Height:          200,
		BackgroundColor: color.RGBA{255, 255, 255, 255}, // 白色背景
		TextColor:       color.RGBA{0, 0, 0, 255},       // 黑色文字
		HeaderColor:     color.RGBA{200, 200, 200, 255}, // 灰色表头
		RowColor:        color.RGBA{255, 255, 255, 255}, // 白色行
		AlternateColor:  color.RGBA{240, 240, 240, 255}, // 浅灰色交替行
		FontSize:        12,
		HeaderFontSize:  14,
		Padding:         5,
		LineHeight:      30,
		Title:           title,
	}
}

// GeneratePNGRawROI 生成ROI数据的PNG图片
func GeneratePNGRawROI(result *QueryResult) (*os.File, error) {
	// 1. 初始化配置
	config := NewDefaultImageConfig(result.Title)
	config.FontPath = getDefaultFontPath()

	// 2. 验证输入数据
	if err := validateResult(result); err != nil {
		return nil, err
	}

	// 3. 计算图片尺寸
	numRows := getRowCount(result.Rows)
	totalHeight := calculateImageHeight(config, numRows)

	// 4. 创建图片和绘图上下文
	img := createImage(config.Width, totalHeight, config.BackgroundColor)
	ctx, err := createDrawingContext(img, config)
	if err != nil {
		return nil, err
	}

	// 5. 绘制内容
	if err := drawContent(ctx, img, config, result, numRows); err != nil {
		return nil, err
	}

	// 6. 生成临时文件
	return saveImageToTempFile(img)
}

// 获取默认字体路径
func getDefaultFontPath() string {
	exPath, err := os.Getwd()
	if err != nil {
		return ""
	}
	return filepath.Join(exPath, "conf", "fonts", "MSYH.TTC")
}

// 验证结果数据有效性
func validateResult(result *QueryResult) error {
	if result == nil {
		return fmt.Errorf("结果数据不能为空")
	}

	rowsVal := reflect.ValueOf(result.Rows)
	if rowsVal.Kind() != reflect.Slice {
		return fmt.Errorf("Rows必须是切片类型")
	}

	if rowsVal.Len() > 0 && rowsVal.Index(0).Kind() != reflect.Struct {
		return fmt.Errorf("切片元素必须是结构体类型")
	}

	return nil
}

// 获取数据行数
func getRowCount(rows interface{}) int {
	if rows == nil {
		return 0
	}
	return reflect.ValueOf(rows).Len()
}

// 计算图片高度
func calculateImageHeight(config ImageConfig, numRows int) int {
	headerHeight := config.LineHeight
	contentHeight := numRows * config.LineHeight
	totalHeight := 60 + headerHeight + contentHeight + (config.Padding * 2) // 60为标题区域高度

	if totalHeight < config.Height {
		return config.Height
	}
	return totalHeight
}

// 创建图片
func createImage(width, height int, bgColor color.RGBA) *image.RGBA {
	img := image.NewRGBA(image.Rect(0, 0, width, height))
	draw.Draw(img, img.Bounds(), &image.Uniform{bgColor}, image.Point{}, draw.Src)
	return img
}

// 创建绘图上下文
func createDrawingContext(img *image.RGBA, config ImageConfig) (*freetype.Context, error) {
	// 加载字体
	fontBytes, err := loadFont(config.FontPath)
	if err != nil {
		return nil, err
	}

	// 解析字体
	font, err := freetype.ParseFont(fontBytes)
	if err != nil {
		return nil, fmt.Errorf("解析字体失败: %v", err)
	}

	// 初始化上下文
	ctx := freetype.NewContext()
	ctx.SetDPI(72)
	ctx.SetFont(font)
	ctx.SetClip(img.Bounds())
	ctx.SetDst(img)
	ctx.SetSrc(image.NewUniform(config.TextColor))

	return ctx, nil
}

// 加载字体文件
func loadFont(fontPath string) ([]byte, error) {
	// 尝试加载指定字体
	if fontPath != "" {
		if _, err := os.Stat(fontPath); err == nil {
			return os.ReadFile(fontPath)
		}
	}

	// 使用内置字体作为 fallback
	return goregular.TTF, nil
}

// 绘制图片内容
func drawContent(ctx *freetype.Context, img *image.RGBA, config ImageConfig, result *QueryResult, numRows int) error {
	// 绘制标题
	if err := drawTitle(ctx, config); err != nil {
		return err
	}

	// 绘制时间戳
	if err := drawTimestamp(ctx, config); err != nil {
		return err
	}

	// 绘制表头
	if err := drawHeader(ctx, img, config, result.Columns); err != nil {
		return err
	}

	// 绘制表格内容
	if err := drawTableRows(ctx, img, config, result, numRows); err != nil {
		return err
	}

	return nil
}

// 绘制标题
func drawTitle(ctx *freetype.Context, config ImageConfig) error {
	ctx.SetFontSize(16)
	//titleWidth := estimateTextWidth(ctx, config.Title, 10)
	//titleX := (config.Width - titleWidth) / 2
	titleX := config.Padding + 5
	_, err := ctx.DrawString(config.Title, freetype.Pt(titleX, 40))
	return err
}

// 绘制时间戳
func drawTimestamp(ctx *freetype.Context, config ImageConfig) error {
	ctx.SetFontSize(16)
	timestamp := fmt.Sprintf("生成时间: %s", time.Now().Add(-900*time.Second).Format(time.DateTime))

	_, err := ctx.DrawString(timestamp, freetype.Pt(config.Width-200, 40))
	return err
}

// 绘制表头
func drawHeader(ctx *freetype.Context, img *image.RGBA, config ImageConfig, columns []string) error {
	colWidth := calculateColumnWidth(config, len(columns))
	headerY := 60

	// 绘制表头背景
	headerRect := image.Rect(config.Padding, headerY, config.Width-config.Padding, headerY+config.LineHeight)
	draw.Draw(img, headerRect, &image.Uniform{config.HeaderColor}, image.Point{}, draw.Src)

	// 绘制表头文字
	ctx.SetFontSize(config.HeaderFontSize)
	x := config.Padding

	for _, col := range columns {
		if _, err := ctx.DrawString(col, freetype.Pt(x+5, headerY+20)); err != nil {
			return err
		}
		x += colWidth
	}

	return nil
}

// 绘制表格行数据
func drawTableRows(ctx *freetype.Context, img *image.RGBA, config ImageConfig, result *QueryResult, numRows int) error {
	colWidth := calculateColumnWidth(config, len(result.Columns))
	y := 60 + config.LineHeight // 从表头下方开始
	rowsVal := reflect.ValueOf(result.Rows)

	ctx.SetFontSize(config.FontSize)

	for i := 0; i < numRows; i++ {
		// 设置行背景色
		rowColor := config.RowColor
		if i%2 == 1 {
			rowColor = config.AlternateColor
		}

		// 绘制行背景
		rowRect := image.Rect(config.Padding, y, config.Width-config.Padding, y+config.LineHeight)
		draw.Draw(img, rowRect, &image.Uniform{rowColor}, image.Point{}, draw.Src)

		// 绘制行内容
		rowStruct := rowsVal.Index(i)
		x := config.Padding

		for j := 0; j < rowStruct.NumField(); j++ {
			field := rowStruct.Field(j)
			cellStr := fmt.Sprintf("%v", field.Interface())

			if _, err := ctx.DrawString(cellStr, freetype.Pt(x+5, y+20)); err != nil {
				return err
			}
			x += colWidth
		}

		y += config.LineHeight
	}

	return nil
}

// 计算列宽
func calculateColumnWidth(config ImageConfig, colCount int) int {
	if colCount == 0 {
		return 0
	}
	return (config.Width - (config.Padding * 2)) / colCount
}

// 估算文本宽度
func estimateTextWidth(ctx *freetype.Context, text string, fontSize float64) int {
	return int(float64(len(text)) * fontSize)
}

// 保存图片到临时文件
func saveImageToTempFile(img *image.RGBA) (*os.File, error) {
	// 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.png")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close()

	// 写入图片
	if err := png.Encode(tempFile, img); err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("写入PNG失败: %v", err)
	}

	// 重新打开文件以获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}

	return outputFile, nil
}
