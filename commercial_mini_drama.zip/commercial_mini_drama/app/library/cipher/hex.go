package cipher

import "encoding/hex"

const hexTable = "0123456789ABCDEF"

func HexEncodeToString(src []byte) string {
	dst := make([]byte, hex.EncodedLen(len(src)))
	HexEncode(dst, src)
	return string(dst)
}

func HexEncode(dst, src []byte) int {
	j := 0
	for _, v := range src {
		dst[j] = hexTable[v>>4]
		dst[j+1] = hexTable[v&0x0f]
		j += 2
	}
	return len(src) * 2
}
