package accounts

import (
	"context"
	accountdto "goserver/app/common/dto/accounts"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/library/playlet"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
)

type AssistAccountService struct {
	Ctx context.Context
}

func NewAssistAccountService(ctx context.Context) *AssistAccountService {
	return &AssistAccountService{Ctx: ctx}
}

func (s *AssistAccountService) AssistAccountSync(media string, params accountdto.OauthAccountSyncExecutorParams) error {
	oauthAssistDao := accountdao.NewOauthAssistDao(s.Ctx)
	list, err := oauthAssistDao.ListOauthByMediaAppIds(media, []string{params.MasterAppId})
	if err != nil {
		log.Errorf("[AssistAccountService.AssistAccountSync] 根据媒体获取oauth授权列表错误, err: %s", err)
		return err
	}

	assistAccountDao := accountdao.NewAssistAccountDao(s.Ctx)

	for _, oauth := range list {
		accountIds, err := s.GetOauthAccounts(oauth)
		if err != nil {
			log.Errorf("[AssistAccountService.AssistAccountSync] 同步账号查询接口数据失败, oauth_id: %s, err: %s", oauth.OauthId, err)
			return err
		}

		err = assistAccountDao.InsertBatchSize(media, oauth.OauthId, oauth.UserId, accountIds, 1000)
		if err != nil {
			log.Errorf("[AssistAccountService.AssistAccountSync] 同步账号写入数据失败, oauth_id: %s, err: %s", oauth.OauthId, err)
			return err
		}
	}

	return nil
}

func (s *AssistAccountService) GetOauthAccounts(o accountrepo.OauthAssistEntity) (accountIds []playlet.AdvertiserInfo, err error) {
	// 调用更新授权令牌接口
	switch o.Media {
	case repo.MediaToutiao:
		// 获取授权账户下的子账号
		advertiserIds, err := toutiao.AllOauth2MajordomoAssistAdvertiserId(s.Ctx, o.AccessToken)
		if err != nil {
			return nil, err
		}
		accountIds = append(accountIds, advertiserIds...)
	case repo.MediaKuaishou:
		// todo 快手oauth授权账户同步
	}

	return accountIds, nil
}
