package material

import (
	"context"
	"goserver/app/common"
	"goserver/app/common/dto/materialdto"
	repo "goserver/app/common/repository/material"
	dao "goserver/app/model/dao/material"
)

type ReportService struct {
	Ctx context.Context
}

func NewReportService(ctx context.Context) *ReportService {
	return &ReportService{Ctx: ctx}
}

func (s *ReportService) ReportParams() (params *materialdto.Params, err error) {
	params = &materialdto.Params{}
	materialDao := dao.NewReportDataDao(s.Ctx)
	//时间周期
	params.GroupType = []materialdto.IDLabel{}
	for _, row := range materialdto.GroupTypeArr {
		params.GroupType = append(params.GroupType, row)
	}
	//媒体
	params.Media = materialdto.SelectOption{Name: "媒体", Value: make([]materialdto.IDLabel, 0)}
	var IDLabels []materialdto.IDLabel
	IDLabels, err = materialDao.MediaAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.Media.Value = append(params.Media.Value, row)
	}
	//剧目名称
	params.BookID = materialdto.SelectOption{Name: "剧目名称", Value: make([]materialdto.IDLabel, 0)}
	IDLabels, err = materialDao.BookAry("", 100)
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.BookID.Value = append(params.BookID.Value, row)
	}
	//付费类型
	params.PayType = materialdto.SelectOption{Name: "付费类型", Value: make([]materialdto.IDLabel, 0)}
	for _, row := range materialdto.PayTypeArr {
		params.PayType.Value = append(params.PayType.Value, row)
	}
	//应用包名
	params.AppName = materialdto.SelectOption{Name: "应用包名", Value: make([]materialdto.IDLabel, 0)}
	IDLabels, err = materialDao.AppAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.AppName.Value = append(params.AppName.Value, row)
	}
	//素材名称
	params.MaterialName = materialdto.SelectOption{Name: "素材名称", Value: make([]materialdto.IDLabel, 0)}
	IDLabels, err = materialDao.MaterialAry("", 100)
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.MaterialName.Value = append(params.MaterialName.Value, row)
	}
	//投放人员
	params.OptimizerID = materialdto.SelectOption{Name: "投放人员", Value: make([]materialdto.IDLabel, 0)}
	IDLabels, err = materialDao.OptimizerAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.OptimizerID.Value = append(params.OptimizerID.Value, row)
	}
	//剪辑师
	params.EditorName = materialdto.SelectOption{Name: "剪辑师", Value: make([]materialdto.IDLabel, 0)}
	IDLabels, err = materialDao.EditorAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.EditorName.Value = append(params.EditorName.Value, row)
	}
	//剪辑师地域
	params.EditorRegion = materialdto.SelectOption{Name: "剪辑师地域", Value: make([]materialdto.IDLabel, 0)}
	IDLabels, err = materialDao.EditorRegionAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.EditorRegion.Value = append(params.EditorRegion.Value, row)
	}
	//账户名称
	params.AccountID = materialdto.SelectOption{Name: "账户名称", Value: make([]materialdto.IDLabel, 0)}
	IDLabels, err = materialDao.AccountAry("", 100)
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.AccountID.Value = append(params.AccountID.Value, row)
	}
	//维度聚合
	params.GroupBy = materialdto.SelectOption{Name: "维度聚合", Value: make([]materialdto.IDLabel, 0)}
	for _, row := range materialdto.GroupByArr {
		params.GroupBy.Value = append(params.GroupBy.Value, row)
	}
	//指标筛选
	params.KpiFilter = []materialdto.KpiOption{}
	for i, row := range materialdto.KpiFilterArr {
		if row.Label != "" {
			row.ID = i + 1
			params.KpiFilter = append(params.KpiFilter, row)
		}
	}
	return
}

func (s *ReportService) ReportOptionSearch(keywords, searchType string) (result []materialdto.IDLabel, err error) {
	materialDao := dao.NewReportDataDao(s.Ctx)
	if searchType == "book" {
		result, err = materialDao.BookAry(keywords, 100)
	} else if searchType == "account" {
		result, err = materialDao.AccountAry(keywords, 100)
	} else if searchType == "material" {
		result, err = materialDao.MaterialAry(keywords, 100)
	}
	return
}

func (s *ReportService) ReportData(params *materialdto.ReportDataReq) (*common.Paginator, error) {
	materialDao := dao.NewReportDataDao(s.Ctx)
	// 分页数据
	paginator, err := materialDao.ReportData(params)
	if err != nil {
		return nil, err
	}
	return paginator, err
}

func (s *ReportService) Export(params *materialdto.ReportDataReq) (result *[]repo.ReportHourlyMaterialEntity, err error) {
	materialDao := dao.NewReportDataDao(s.Ctx)
	result, err = materialDao.ExportData(params)
	return
}
