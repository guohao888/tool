package raw

import (
	"goserver/app/common/repository"
	"time"
)

const ReferralEntityTable = "raw_referral_config"

// ReferralEntity 端原生配置表
type ReferralEntity struct {
	HashId         string    `gorm:"column:hash_id"`         // 主键id
	ReferralUrl    string    `gorm:"column:referral_url"`    // 推广链接
	BookName       string    `gorm:"column:book_name"`       // 剧目名称
	CopyrightOwner string    `gorm:"column:copyright_owner"` // 版权方
	CreatedTime    time.Time `gorm:"column:created_time"`    // 创建时间
}

func (*ReferralEntity) TableName() string {
	return ReferralEntityTable
}

func MaterialDayTableName() string {
	if repository.IsDebugTable(ReferralEntityTable) {
		return ReferralEntityTable + "_dev"
	} else {
		return ReferralEntityTable
	}
}
