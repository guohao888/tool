package font

import (
	"fmt"
	"io/ioutil"
	"sync"

	"golang.org/x/image/font"
	"golang.org/x/image/font/opentype"
)

// FontManager 管理字体加载和缓存
type FontManager struct {
	fonts map[string][]byte
	mu    sync.RWMutex
}

var (
	instance *FontManager
	once     sync.Once
)

// GetInstance 返回FontManager的单例实例
func GetInstance() *FontManager {
	once.Do(func() {
		instance = &FontManager{
			fonts: make(map[string][]byte),
		}
	})
	return instance
}

// LoadFont 从文件加载字体
func (fm *FontManager) LoadFont(name, path string) error {
	fm.mu.Lock()
	defer fm.mu.Unlock()

	// 如果字体已经加载，直接返回
	if _, exists := fm.fonts[name]; exists {
		return nil
	}

	// 读取字体文件
	fontBytes, err := ioutil.ReadFile(path)
	if err != nil {
		return err
	}

	// 缓存字体数据
	fm.fonts[name] = fontBytes
	return nil
}

// GetFont 获取已加载的字体数据
func (fm *FontManager) GetFont(name string) ([]byte, error) {
	fm.mu.RLock()
	defer fm.mu.RUnlock()

	fontBytes, exists := fm.fonts[name]
	if !exists {
		return nil, fmt.Errorf("font %s not loaded", name)
	}
	return fontBytes, nil
}

// CreateFace 创建指定大小的字体
func (fm *FontManager) CreateFace(name string, size float64) (font.Face, error) {
	fontBytes, err := fm.GetFont(name)
	if err != nil {
		return nil, err
	}

	// 解析字体
	f, err := opentype.Parse(fontBytes)
	if err != nil {
		return nil, err
	}

	// 创建字体
	face, err := opentype.NewFace(f, &opentype.FaceOptions{
		Size:    size,
		DPI:     72,
		Hinting: font.HintingFull,
	})
	if err != nil {
		return nil, err
	}

	return face, nil
}
