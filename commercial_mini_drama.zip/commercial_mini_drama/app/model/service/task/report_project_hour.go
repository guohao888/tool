package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	mediaRepo "goserver/app/model/service/mediareport"
	"time"
)

/***********************         新授权逻辑 令牌桶方式获取消耗  start       ***********************/

/*
	执行参数：
	{
		"is_history":0,
		"is_fast":2
	}
*/
// SyncReportProjectLimitTodayFast 拉取头条消耗数据 快队列 实时数据
func SyncReportProjectLimitTodayFast(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("项目级消耗报表快队列参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("同步项目级消耗报表快队列数据时间错误, err: %s", err)
	}
	//
	reportProjectHourService := mediaRepo.NewReportProjectHourService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportProjectHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("同步项目级消耗报表快队列数据失败, err: %s", err)
		}
	}
	return "同步项目级消耗报表快队列数据成功"
}

/*
	执行参数：
	{
		"is_history":0,
		"is_fast":1
	}
*/

// SyncReportProjectLimitTodaySlow 拉取头条消耗数据 慢队列 实时数据
func SyncReportProjectLimitTodaySlow(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("项目级消耗报表慢队列参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("同步项目级消耗报表慢队列数据时间错误, err: %s", err)
	}
	//
	reportProjectHourService := mediaRepo.NewReportProjectHourService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportProjectHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("同步项目级消耗报表慢队列数据失败, err: %s", err)
		}
	}
	return "同步项目级消耗报表慢队列数据成功"
}

/*
	执行参数：
	{
		"is_history":1,
		"is_fast":0
	}
*/
// SyncReportProjectLimitHistory 拉取头条消耗数据 历史数据
func SyncReportProjectLimitHistory(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("项目级消耗历史报表参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("同步项目级消耗历史报表数据时间错误, err: %s", err)
	}
	//
	reportProjectHourService := mediaRepo.NewReportProjectHourService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportProjectHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("同步项目级消耗历史报表数据失败, err: %s", err)
		}
	}
	return "同步项目级消耗历史报表数据成功"
}

/***********************         新授权逻辑 令牌桶方式获取消耗  end       ***********************/

// SyncReportProjectLimitReplenish 补充拉取项目级历史消耗
func SyncReportProjectLimitReplenish(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("项目级消耗报表快队列参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("补充同步项目级消耗报表快队列数据时间错误, err: %s", err)
	}
	//
	reportProjectHourService := mediaRepo.NewReportProjectHourService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportProjectHourService.DistributeReportAccountsReplenish(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("补充同步项目级消耗报表快队列数据失败, err: %s", err)
		}
	}
	return "补充同步项目级消耗报表快队列数据成功"
}

// SyncReportProjectLimitTodaySubscribe 按照订阅消息拉取项目维度账号消耗 当日
func SyncReportProjectLimitTodaySubscribe(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("项目级消耗报表快队列参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("同步项目级消耗报表快队列数据时间错误, err: %s", err)
	}
	//
	reportProjectHourService := mediaRepo.NewReportProjectHourService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportProjectHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("同步项目级消耗报表快队列数据失败, err: %s", err)
		}
	}
	return "同步项目级消耗报表快队列数据成功"
}

// SyncReportProjectLimitBeforeSubscribe 按照订阅消息拉取项目维度账号消耗 稳定
func SyncReportProjectLimitBeforeSubscribe(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("项目级消耗报表快队列参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("同步项目级消耗报表快队列数据时间错误, err: %s", err)
	}
	//
	reportProjectHourService := mediaRepo.NewReportProjectHourService(ctx)
	for _, crontabDate := range crontabDateList {
		fmt.Println("正在执行：", crontabDate.Format(time.DateOnly))
		err = reportProjectHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("同步项目级消耗报表快队列数据失败, err: %s", err)
		}
	}
	return "同步项目级消耗报表快队列数据成功"
}
