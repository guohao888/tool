package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const AccountDistributorTable = "account_distributor"
const DefaultModuleName = "短剧"
const AccountPoint = 0.02 // 账户返点

type AccountDistributorEntity struct {
	Module         string    `gorm:"column:module" json:"module"`                 // 模块
	Media          string    `gorm:"column:media" json:"media"`                   // 媒体
	Distributor    string    `gorm:"column:distributor" json:"distributor"`       // 分销商
	AdvertiserId   string    `gorm:"column:advertiser_id" json:"advertiser_id"`   // 广告主id
	OptimizerId    int64     `gorm:"column:optimizer_id" json:"optimizer_id"`     // 投手ID
	AppName        string    `gorm:"column:app_name" json:"app_name"`             // 广告主名称
	BookId         int64     `gorm:"column:book_id" json:"book_id"`               // 剧目ID
	BookName       string    `gorm:"column:book_name" json:"book_name"`           // 剧目名称
	Region         string    `gorm:"column:region" json:"region"`                 // 地区
	OptimizerName  string    `gorm:"column:optimizer_name" json:"optimizer_name"` // 投手名称
	AdvertiserName string    `gorm:"gorm:advertiser_name" json:"advertiser_name"` // 广告主名称
	PromotionId    int64     `gorm:"gorm:promotion_id" json:"promotion_id"`       // 推广链接ID
	PromotionName  string    `gorm:"gorm:promotion_name" json:"promotion_name"`   // 推广连接名称
	PromotionUrl   string    `gorm:"column:promotion_url" json:"promotion_url"`   // 推广链地址
	ApuCreateTime  time.Time `columns:"apu_create_time" json:"apu_create_time"`   // 广告主推广链创建时间
	DpuCreateTime  time.Time `columns:"dpu_create_time" json:"dpu_create_time"`   // 分销商推广链创建时间
	CreatedAt      time.Time `gorm:"column:created_at" json:"created_at"`         // 创建时间
	UpdatedAt      time.Time `gorm:"column:updated_at" json:"updated_at"`         // 更新时间
	Status         int64     `gorm:"column:status"`                               // 账号状态 0: 正常 1: 关停
}

func (*AccountDistributorEntity) TableName() string {
	return AccountDistributorTableName()
}

func AccountDistributorColumns() []string {
	return []string{
		"module",
		"media",
		"distributor",
		"advertiser_id",
		"optimizer_id",
		"app_name",
		"book_id",
		"book_name",
		"region",
		"optimizer_name",
		"advertiser_name",
		"apu_create_time",
		"dpu_create_time",
	}
}

func AccountDistributorTableName() string {
	if repository.IsDebugTable(AccountDistributorTable) {
		return AccountDistributorTable + "_dev"
	} else {
		return AccountDistributorTable
	}
}
