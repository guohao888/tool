package promotion

import (
	"goserver/app/common"
	"goserver/app/common/dto/page"
	"goserver/app/library/myerror"

	"github.com/gin-gonic/gin"
)

type PackageList struct {
	PackageList []PackageDetail `json:"package_list"`
}

type PackageDetail struct {
	AppId   int64  `json:"app_id"`
	AppName string `json:"app_name"`
}

type PackageListReq struct {
	common.CommonParams
}

func NewPackageListReq(c *gin.Context) *PackageListReq {
	req := &PackageListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

type BoundPackageList struct {
	PackageList []BoundPackageDetail `json:"package_list"`
}

type BoundPackageDetail struct {
	AppId          int64  `json:"app_id"`
	AppName        string `json:"app_name"`
	Channel        int    `json:"channel"`
	NickName       string `json:"nick_name"`
	BoundPackageId string `json:"bound_package_id"`
}

type BoundPackageListReq struct {
	common.CommonParams
	AppId int64 `json:"app_id" binding:"required"`
}

func NewBoundPackageListReq(c *gin.Context) *BoundPackageListReq {
	req := &BoundPackageListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

type BookMeatReq struct {
	common.CommonParams
	BookId string `json:"book_id" binding:"required"`
}

func NewBookMeatReq(c *gin.Context) *BookMeatReq {
	req := &BookMeatReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

type BookMeta struct {
	Abstract                string `json:"abstract"`
	Author                  string `json:"author"`
	BookId                  string `json:"book_id"`
	BookName                string `json:"book_name"`
	Category                string `json:"category"`
	ChapterAmount           int64  `json:"chapter_amount"`
	CreationStatus          int64  `json:"creation_status"`
	Genre                   int64  `json:"genre"`
	LengthType              int64  `json:"length_type"`
	ThumbUrl                string `json:"thumb_url"`
	WordCount               int64  `json:"word_count"`
	AdEpisode               int64  `json:"ad_episode"`
	AppTypePermissionStatus int64  `json:"app_type_permission_status"`
}

type AdCallbackConfigList struct {
	ConfigList []AdCallbackConfigDetail `json:"config_list"`
}

type AdCallbackConfigDetail struct {
	ConfigId   int    `json:"config_id"`
	ConfigName string `json:"config_name"`
}

type AdCallbackConfigReq struct {
	common.CommonParams
	BoundPackageID string `json:"bound_package_id" binding:"required"`
}

func NewAdCallbackConfigReq(c *gin.Context) *AdCallbackConfigReq {
	req := &AdCallbackConfigReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

type CreateReq struct {
	common.CommonParams
	PromotionNameFormat  string   `json:"promotion_name_format" binding:"required"`
	PackageID            int      `json:"package_id" binding:"required"`
	PackageName          string   `json:"package_name" binding:"required"`
	AppName              string   `json:"app_name" binding:"required"`
	BoundPackageID       string   `json:"bound_package_id" binding:"required"`
	BoundPackageName     string   `json:"bound_package_name" binding:"required"`
	BookID               string   `json:"book_id" binding:"required"`
	BookName             string   `json:"book_name" binding:"required"`
	BookIndex            int64    `json:"book_index" binding:"required"`
	AdEpisode            int64    `json:"ad_episode" binding:"required"`
	AdCallbackConfigID   int64    `json:"ad_callback_config_id" binding:"required"`
	AdCallbackConfigName string   `json:"ad_callback_config_name" binding:"required"`
	AdvertiserIDs        []string `json:"advertiser_ids" binding:"required"`
}

func NewCreateReqReq(c *gin.Context) *CreateReq {
	req := &CreateReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

type RetryReq struct {
	common.CommonParams
	RequestId string `json:"request_id" binding:"required"`
}

func NewRetryReqReq(c *gin.Context) *RetryReq {
	req := &RetryReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

type ListInfo struct {
	RequestId           string `json:"request_id"`
	PromotionId         string `json:"promotion_id"`
	PromotionName       string `json:"promotion_name"`
	PromotionNameFormat string `json:"promotion_name_format"`
	PackageId           int64  `json:"package_id"`
	BoundPackageId      string `json:"bound_package_id"`
	AdCallbackConfigId  int64  `json:"ad_callback_config_id"`
	BookId              string `json:"book_id"`
	BookName            string `json:"book_name"`
	AppName             string `json:"app_name"`
	InstanceId          string `json:"instance_id"`
	AdvertiserId        string `json:"advertiser_id"`
	AdvertiserName      string `json:"advertiser_name"`
	CreateTime          string `json:"create_time"`
	UserName            string `json:"user_name"`
	FailedReason        string `json:"failed_reason"`
	StateCode           int64  `json:"state_code"`
}

type ListReq struct {
	common.CommonParams
	page.Pagination
	AppType        int64  `json:"app_type"`
	PackageId      int64  `json:"package_id"`
	BoundPackageId int64  `json:"bound_package_id"`
	BookId         string `json:"book_id"`
	UserName       string `json:"user_name"`
	StateCode      int64  `json:"state_code"`
}

func NewListReq(c *gin.Context) *ListReq {
	req := &ListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

type ListFilterOptions struct {
	AppType      []FilterOption           `json:"app_type"`
	Package      []FilterOption           `json:"package"`
	BoundPackage map[int64][]FilterOption `json:"bound_package"`
	Status       []FilterOption           `json:"status"`
}

type FilterOption struct {
	Value    int64  `json:"value"`
	ShowName string `json:"showName"`
}

type ListOptionsReq struct {
	common.CommonParams
}

func NewListOptionsReq(c *gin.Context) *ListOptionsReq {
	req := &ListOptionsReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}
