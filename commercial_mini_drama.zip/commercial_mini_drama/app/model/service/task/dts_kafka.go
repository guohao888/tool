package task

import (
	"context"
	"crypto/tls"
	"github.com/IBM/sarama"
	"github.com/spf13/viper"
	dts "goserver/app/library/dts/data_subscription"
	"log"
	"time"
)

func ExecDtsKafka2DB() {
	dbPrefix := "kafka_dts_report"
	username := viper.GetString(dbPrefix + ".user_name")
	password := viper.GetString(dbPrefix + ".password")
	topic := viper.GetString(dbPrefix + ".topic")
	group := viper.GetString(dbPrefix + ".group")
	addr := []string{viper.GetString(dbPrefix + ".addr")}

	config := sarama.NewConfig()
	config.Version = sarama.V2_8_0_0

	// 启用 TLS
	config.Net.TLS.Enable = true
	config.Net.TLS.Config = &tls.Config{
		InsecureSkipVerify: true,
	}

	config.Net.SASL.User = username
	config.Net.SASL.Password = password
	config.Net.SASL.Enable = true
	config.Net.SASL.Mechanism = sarama.SASLTypePlaintext

	// 使用更新的偏移量策略
	config.Consumer.Offsets.Initial = sarama.OffsetNewest
	config.Consumer.Offsets.AutoCommit.Enable = true // 启用自动提交

	// 初始化处理器，调整参数
	handler := dts.NewHandler(10, topic, 1000, 30*time.Second) // 增加工作协程和批量大小
	defer handler.Close()

	cons, err := sarama.NewConsumerGroup(addr, group, config)
	if err != nil {
		log.Fatalf("Error creating consumer group: %v", err)
	}
	defer cons.Close()

	// 使用更健壮的重试机制
	retryCount := 0
	maxRetries := 5

	for {
		err = cons.Consume(context.Background(), []string{handler.Topic}, handler)
		if err != nil {
			log.Printf("Error consuming: %v", err)

			retryCount++
			if retryCount > maxRetries {
				log.Fatalf("Max retries exceeded: %v", err)
			}

			// 指数退避重试
			backoff := time.Duration(1<<uint(retryCount)) * time.Second
			log.Printf("Retrying in %v", backoff)
			time.Sleep(backoff)
		} else {
			retryCount = 0 // 重置重试计数
		}
	}
}

func ExecDtsMaterialDayKafka2DB() {

	dbPrefix := "kafka_dts_material_day"
	// 获取 kafka 配置信息
	username := viper.GetString(dbPrefix + ".user_name")
	password := viper.GetString(dbPrefix + ".password")
	topic := viper.GetString(dbPrefix + ".topic")
	group := viper.GetString(dbPrefix + ".group")
	addr := []string{viper.GetString(dbPrefix + ".addr")}

	// 设置配置信息
	config := sarama.NewConfig()
	config.Version = sarama.V2_8_0_0 // 使用更新的版本

	// 1. 启用 TLS (必须)
	config.Net.TLS.Enable = true
	config.Net.TLS.Config = &tls.Config{
		InsecureSkipVerify: true, // 测试环境可跳过证书验证
	}

	config.Net.SASL.User = username
	config.Net.SASL.Password = password
	config.Net.SASL.Enable = true
	config.Consumer.Offsets.Initial = sarama.OffsetNewest
	config.Net.SASL.Mechanism = sarama.SASLTypePlaintext // 设置机制为 PLAIN

	// 初始化处理器，调整参数
	handler := dts.NewMaterialDayHandler(10, topic, 1000, 30*time.Second) // 增加工作协程和批量大小
	defer handler.Close()

	cons, err := sarama.NewConsumerGroup(addr, group, config)
	if err != nil {
		log.Fatalf("Error creating consumer group: %v", err)
	}
	defer cons.Close()

	// 使用更健壮的重试机制
	retryCount := 0
	maxRetries := 5

	for {
		err = cons.Consume(context.Background(), []string{handler.Topic}, handler)
		if err != nil {
			log.Printf("Error consuming: %v", err)

			retryCount++
			if retryCount > maxRetries {
				log.Fatalf("Max retries exceeded: %v", err)
			}

			// 指数退避重试
			backoff := time.Duration(1<<uint(retryCount)) * time.Second
			log.Printf("Retrying in %v", backoff)
			time.Sleep(backoff)
		} else {
			retryCount = 0 // 重置重试计数
		}
	}
}

func ExecDtsMaterialHourKafka2DB() {

	dbPrefix := "kafka_dts_material_hour"
	// 获取 kafka 配置信息
	username := viper.GetString(dbPrefix + ".user_name")
	password := viper.GetString(dbPrefix + ".password")
	topic := viper.GetString(dbPrefix + ".topic")
	group := viper.GetString(dbPrefix + ".group")
	addr := []string{viper.GetString(dbPrefix + ".addr")}

	// 设置配置信息
	config := sarama.NewConfig()
	config.Version = sarama.V2_8_0_0 // 使用更新的版本

	// 1. 启用 TLS (必须)
	config.Net.TLS.Enable = true
	config.Net.TLS.Config = &tls.Config{
		InsecureSkipVerify: true, // 测试环境可跳过证书验证
	}

	config.Net.SASL.User = username
	config.Net.SASL.Password = password
	config.Net.SASL.Enable = true
	config.Consumer.Offsets.Initial = sarama.OffsetNewest
	config.Net.SASL.Mechanism = sarama.SASLTypePlaintext // 设置机制为 PLAIN

	// 初始化处理器，调整参数
	handler := dts.NewMaterialHourHandler(10, topic, 1000, 30*time.Second) // 增加工作协程和批量大小
	defer handler.Close()

	cons, err := sarama.NewConsumerGroup(addr, group, config)
	if err != nil {
		log.Fatalf("Error creating consumer group: %v", err)
	}
	defer cons.Close()

	// 使用更健壮的重试机制
	retryCount := 0
	maxRetries := 5

	for {
		err = cons.Consume(context.Background(), []string{handler.Topic}, handler)
		if err != nil {
			log.Printf("Error consuming: %v", err)

			retryCount++
			if retryCount > maxRetries {
				log.Fatalf("Max retries exceeded: %v", err)
			}

			// 指数退避重试
			backoff := time.Duration(1<<uint(retryCount)) * time.Second
			log.Printf("Retrying in %v", backoff)
			time.Sleep(backoff)
		} else {
			retryCount = 0 // 重置重试计数
		}
	}
}

//func ExecDtsKafka2DB() {
//
//	dbPrefix := "kafka_dts_report"
//	// 获取 kafka 配置信息
//	username := viper.GetString(dbPrefix + ".user_name")
//	password := viper.GetString(dbPrefix + ".password")
//	topic := viper.GetString(dbPrefix + ".topic")
//	group := viper.GetString(dbPrefix + ".group")
//	addr := []string{viper.GetString(dbPrefix + ".addr")}
//
//	// 设置配置信息
//	config := sarama.NewConfig()
//	config.Version = sarama.V2_8_0_0 // 使用更新的版本
//
//	// 1. 启用 TLS (必须)
//	config.Net.TLS.Enable = true
//	config.Net.TLS.Config = &tls.Config{
//		InsecureSkipVerify: true, // 测试环境可跳过证书验证
//	}
//
//	config.Net.SASL.User = username
//	config.Net.SASL.Password = password
//	config.Net.SASL.Enable = true
//	config.Consumer.Offsets.Initial = sarama.OffsetNewest
//	config.Net.SASL.Mechanism = sarama.SASLTypePlaintext // 设置机制为 PLAIN
//
//	// 初始化处理器（1个工作协程）
//	handler := dts.NewHandler(5, topic)
//	defer handler.Close()
//
//	cons, err := sarama.NewConsumerGroup(addr, group, config)
//	if err != nil {
//		panic(err)
//	}
//	defer cons.Close()
//
//	// 阻塞消费数据 1000条提交一次
//	for {
//		err = cons.Consume(context.Background(), []string{handler.Topic}, handler)
//		if err != nil {
//			log.Fatalln(err)
//		}
//	}
//}
