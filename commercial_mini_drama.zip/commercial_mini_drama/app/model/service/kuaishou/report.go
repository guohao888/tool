package kuaishou

import (
	"context"
	ksdto "goserver/app/common/dto/kuaishoudto"
	"goserver/app/common/dto/roidto"
	ksdao "goserver/app/model/dao/kuaishou"
)

type KsReportService struct {
	Ctx context.Context
}

func NewKsReportService(ctx context.Context) *KsReportService {
	return &KsReportService{Ctx: ctx}
}

func (s *KsReportService) CoreDataFilterOptions(req *ksdto.FilterOptionsReq) (*ksdto.CoreDataFilterOptions, error) {
	options := &ksdto.CoreDataFilterOptions{}
	seriesDataDao := ksdao.NewSeriesDao(s.Ctx)
	//时间周期
	options.GroupType = []ksdto.IDLabel{}
	for _, row := range ksdto.GroupTypeArr {
		options.GroupType = append(options.GroupType, row)
	}
	//剧目名称
	options.SeriesName = ksdto.SelectOption{Name: "剧目名称", Value: make([]ksdto.IDLabel, 0)}
	IDLabels, err := seriesDataDao.GetSeriesInfoByKeywords("", 100)
	if err != nil {
		return nil, err
	}
	options.SeriesName.Value = append(options.SeriesName.Value, ksdto.IDLabel{
		ID:        "",
		Label:     "全部",
		IsDefault: true,
	})
	for _, row := range IDLabels {
		info := ksdto.IDLabel{
			ID:        row.SeriesName,
			Label:     row.SeriesName,
			IsDefault: false,
		}
		options.SeriesName.Value = append(options.SeriesName.Value, info)
	}
	//付费类型
	options.SeriesType = ksdto.SelectOption2{Name: "付费类型", Value: make([]ksdto.IDLabel2, 0)}
	options.SeriesType.Value = append(options.SeriesType.Value, ksdto.IDLabel2{
		ID:        0,
		Label:     "全部",
		IsDefault: true,
	})
	for _, row := range ksdto.SeriesTypeArr {
		options.SeriesType.Value = append(options.SeriesType.Value, row)
	}
	//流量来源
	options.ResourceType = ksdto.SelectOption2{Name: "流量来源", Value: make([]ksdto.IDLabel2, 0)}
	options.ResourceType.Value = append(options.ResourceType.Value, ksdto.IDLabel2{
		ID:        0,
		Label:     "全部",
		IsDefault: true,
	})
	for _, row := range ksdto.ResourceTypeArr {
		options.ResourceType.Value = append(options.ResourceType.Value, row)
	}
	//指标筛选
	options.KpiFilter = []ksdto.KpiOption{}
	for i, row := range ksdto.CoreDataFilterArr {
		if row.Label != "" {
			row.ID = i + 1
			options.KpiFilter = append(options.KpiFilter, row)
		}
	}
	return options, nil
}

func (s *KsReportService) AdDataFilterOptions(req *ksdto.FilterOptionsReq) (*ksdto.AdDataFilterOptions, error) {
	options := &ksdto.AdDataFilterOptions{}
	//时间周期
	options.GroupType = []ksdto.IDLabel{}
	for _, row := range ksdto.GroupTypeArr {
		options.GroupType = append(options.GroupType, row)
	}
	//付费类型
	options.SeriesType = ksdto.SelectOption2{Name: "付费类型", Value: make([]ksdto.IDLabel2, 0)}
	options.SeriesType.Value = append(options.SeriesType.Value, ksdto.IDLabel2{
		ID:        0,
		Label:     "全部",
		IsDefault: true,
	})
	for _, row := range ksdto.SeriesTypeArr {
		options.SeriesType.Value = append(options.SeriesType.Value, row)
	}

	//账户名称
	acctDao := ksdao.NewAccountDao(s.Ctx)
	options.AccountName = ksdto.SelectOption{Name: "账户名称", Value: make([]ksdto.IDLabel, 0)}
	acctInfos, err := acctDao.GetAccountInfoByKeywords("", 100)
	if err != nil {
		return nil, err
	}
	options.AccountName.Value = append(options.AccountName.Value, ksdto.IDLabel{
		ID:        "",
		Label:     "全部",
		IsDefault: true,
	})
	for _, row := range acctInfos {
		info := ksdto.IDLabel{
			ID:        row.AccountName,
			Label:     row.AccountName,
			IsDefault: false,
		}
		options.AccountName.Value = append(options.AccountName.Value, info)
	}

	//剧目名称
	seriesDataDao := ksdao.NewSeriesDao(s.Ctx)
	options.SeriesName = ksdto.SelectOption{Name: "剧目名称", Value: make([]ksdto.IDLabel, 0)}
	seriesInfos, err := seriesDataDao.GetSeriesInfoByKeywords("", 100)
	if err != nil {
		return nil, err
	}
	options.SeriesName.Value = append(options.SeriesName.Value, ksdto.IDLabel{
		ID:        "",
		Label:     "全部",
		IsDefault: true,
	})
	for _, row := range seriesInfos {
		info := ksdto.IDLabel{
			ID:        row.SeriesName,
			Label:     row.SeriesName,
			IsDefault: false,
		}
		options.SeriesName.Value = append(options.SeriesName.Value, info)
	}

	//投放人员
	options.OptimizerName = ksdto.SelectOption{Name: "投放人员", Value: make([]ksdto.IDLabel, 0)}
	optInfos, err := acctDao.GetAllOptimizerNickname()
	if err != nil {
		return nil, err
	}
	options.OptimizerName.Value = append(options.OptimizerName.Value, ksdto.IDLabel{
		ID:        "",
		Label:     "全部",
		IsDefault: true,
	})
	for _, row := range optInfos {
		if row == "" {
			row = "-"
		}
		info := ksdto.IDLabel{
			ID:        row,
			Label:     row,
			IsDefault: false,
		}
		options.OptimizerName.Value = append(options.OptimizerName.Value, info)
	}

	//维度聚合
	options.GroupBy = ksdto.SelectOption{Name: "维度聚合", Value: make([]ksdto.IDLabel, 0)}
	for _, row := range ksdto.AdDataGroupByArr {
		options.GroupBy.Value = append(options.GroupBy.Value, row)
	}

	//指标筛选
	options.KpiFilter = []ksdto.KpiOption{}
	for i, row := range ksdto.AdDataFilterArr {
		if row.Label != "" {
			row.ID = i + 1
			options.KpiFilter = append(options.KpiFilter, row)
		}
	}
	return options, nil
}

func (s *KsReportService) DataFilterSearch(req *ksdto.FilterSearchReq) ([]roidto.IDLabel, error) {
	var result []roidto.IDLabel
	var err error
	if req.SearchType == "series" {
		seriesDataDao := ksdao.NewSeriesDao(s.Ctx)
		infos, err := seriesDataDao.GetSeriesInfoByKeywords(req.Keywords, 100)
		if err == nil {
			for _, v := range infos {
				row := roidto.IDLabel{
					ID:        v.SeriesName,
					Label:     v.SeriesName,
					IsDefault: false,
				}
				result = append(result, row)
			}
		}
	} else if req.SearchType == "account" {
		accountDataDao := ksdao.NewAccountDao(s.Ctx)
		infos, err := accountDataDao.GetAccountInfoByKeywords(req.Keywords, 100)
		if err == nil {
			for _, v := range infos {
				row := roidto.IDLabel{
					ID:        v.AccountName,
					Label:     v.AccountName,
					IsDefault: false,
				}
				result = append(result, row)
			}
		}
	}
	return result, err
}
