package toutiao

import (
	"context"
	"fmt"
	"github.com/avast/retry-go"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"github.com/shopspring/decimal"
	"goserver/app/library/limiter"
	"strconv"
	"time"
)

type FundDailyStatV2Req struct {
	AccessToken  string `json:"access_token"`
	AdvertiserId int64  `json:"advertiser_id"`
	StartTime    string `json:"start_time"`
	EndTime      string `json:"end_time"`
	Page         int64  `json:"page,omitempty"`
	PageSize     int64  `json:"page_size,omitempty"`
}

// FundDailyStatV2 https://open.oceanengine.com/labels/7/docs/1696710526682112
func FundDailyStatV2(ctx context.Context, request FundDailyStatV2Req, appId string) (*models.AdvertiserFundDailyStatV2Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiFundDailyStatV2)

	if request.PageSize > MaxPageSize {
		request.PageSize = MaxPageSize
	}

	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.BILL)

	var res *models.AdvertiserFundDailyStatV2Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		latestAccessToken := request.AccessToken

		res, _, e = apiClient.AdvertiserFundDailyStatV2Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(request.AdvertiserId).
			StartDate(request.StartTime).
			EndDate(request.EndTime).
			Page(request.Page).
			PageSize(request.PageSize).
			Execute()

		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("获取头条账户日流水失败, %w", RespStructError)
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("获取头条账户日流水失败, code: %d, message: %s, %w", *res.Code, *res.Message, RespCodeError)
		}
		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

type AllFundDailyStatV2Req struct {
	AccessToken  string `json:"access_token"`
	AdvertiserId int64  `json:"advertiser_id"`
	StartTime    string `json:"start_time"`
	EndTime      string `json:"end_time"`
}

type BillRows []*models.AdvertiserFundDailyStatV2ResponseDataListInner

func AllFundDailyStatV2(ctx context.Context, req AllFundDailyStatV2Req, appId string) (BillRows, error) {
	page := int64(1)
	pageSizeMax := int64(100)

	var rows BillRows
	for {
		resp, err := FundDailyStatV2(ctx, FundDailyStatV2Req{
			AccessToken:  req.AccessToken,
			AdvertiserId: req.AdvertiserId,
			StartTime:    req.StartTime,
			EndTime:      req.EndTime,
			Page:         page,
			PageSize:     pageSizeMax,
		}, appId)
		if err != nil {
			return nil, err
		}
		if len(resp.Data.List) == 0 {
			return nil, nil
		}

		rows = append(rows, resp.Data.List...)

		if int64(len(resp.Data.List)) < pageSizeMax || int64(len(resp.Data.List)) == *resp.Data.PageInfo.TotalNumber {
			break
		}

		page++
	}

	return rows, nil
}

type FundDaily struct {
	AdvertiserId      string
	SearchDate        time.Time
	Balance           decimal.Decimal
	GrantBalance      decimal.Decimal
	NonGrantBalance   decimal.Decimal
	CashCost          decimal.Decimal
	Cost              decimal.Decimal
	Frozen            decimal.Decimal
	Income            decimal.Decimal
	RewardCost        decimal.Decimal
	SharedWalletCost  decimal.Decimal
	CompanyWalletCost decimal.Decimal
	TransferIn        decimal.Decimal
	TransferOut       decimal.Decimal
}

func (r BillRows) DataRows2InnerTransformFundDaily() []FundDaily {
	res := make([]FundDaily, 0, len(r))

	for _, v := range r {
		advertiserId := strconv.Itoa(int(*v.AdvertiserId))
		searchDate, _ := time.ParseInLocation(time.DateOnly, *v.Date, time.Local)
		balance := decimal.NewFromFloat(*v.Balance)
		grantBalance := decimal.NewFromFloat(*v.GrantBalance)
		nonGrantBalance := decimal.NewFromFloat(*v.NonGrantBalance)
		cashCost := decimal.NewFromFloat(*v.CashCost)
		cost := decimal.NewFromFloat(*v.Cost)
		frozen := decimal.NewFromFloat(*v.Frozen)
		income := decimal.NewFromFloat(*v.Income)
		rewardCost := decimal.NewFromFloat(*v.RewardCost)
		sharedWalletCost := decimal.NewFromFloat(*v.SharedWalletCost)
		companyWalletCost := decimal.NewFromFloat(*v.CompanyWalletCost)
		transferIn := decimal.NewFromFloat(*v.TransferIn)
		transferOut := decimal.NewFromFloat(*v.TransferOut)

		fundDaily := FundDaily{
			AdvertiserId:      advertiserId,
			SearchDate:        searchDate,
			Balance:           balance,
			GrantBalance:      grantBalance,
			NonGrantBalance:   nonGrantBalance,
			CashCost:          cashCost,
			Cost:              cost,
			Frozen:            frozen,
			Income:            income,
			RewardCost:        rewardCost,
			SharedWalletCost:  sharedWalletCost,
			CompanyWalletCost: companyWalletCost,
			TransferIn:        transferIn,
			TransferOut:       transferOut,
		}

		res = append(res, fundDaily)
	}

	return res
}
