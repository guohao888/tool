package kuaishou

import (
	"encoding/json"
	"fmt"
	"goserver/app/library/playlet/kuaishou/middleware"
	"io"
	"resty.dev/v3"
	"time"
)

var client *resty.Client

func init() {
	keyLimiter := middleware.NewKeyLimiter(
		middleware.WithAppIdConfig(map[string]*middleware.RateConfig{
			"165915581": {Rate: 5000 / 60, Burst: 5000 / 60}, // 五级，QPM为5000
		}),
		middleware.WithCtxAppIdKey(middleware.CtxAppIdKey),
		middleware.WithCtxPathKey(middleware.CtxPathKey),
		middleware.WithCtxAdvertiserId(middleware.CtxAdvertiserId),
	)

	client = resty.New().
		SetBaseURL("https://ad.e.kuaishou.com").
		SetResponseBodyUnlimitedReads(true).
		EnableGenerateCurlCmd().
		SetRequestMiddlewares(
			middleware.RequestAccessToken,         // 最新的accessToken
			resty.PrepareRequestMiddleware,        // 默认要添加的
			keyLimiter.RequestLimiterMiddleware(), // 自定义限流
		).
		EnableDebug().
		SetLogger(&NoneLogger{}).
		SetResponseMiddlewares(
			resty.AutoParseResponseMiddleware,  // 默认要添加的
			resty.SaveToFileResponseMiddleware, // 默认要添加的
			middleware.ResponseLogMiddleware,   // 自定义请求响应日志
		)

	// debug
	/*
		client = client.
			//SetDebugLogFormatter(resty.DebugLogFormatter). // 这个打印的日志太多了
			//SetDebugLogFormatter(DebugSimpleLogFormatter).
			SetDebugBodyLimit(1048576). // 1MB
			SetDebugLogCurlCmd(true).
			SetLogger(&Logger{})
	*/

	// retry
	client = client.
		EnableRetryDefaultConditions().
		AddRetryConditions(ApplyRetryCodeConditions).
		SetAllowNonIdempotentRetry(true).
		SetRetryCount(3).
		SetRetryWaitTime(500 * time.Millisecond).
		SetRetryMaxWaitTime(3 * time.Second)
}

func DebugSimpleLogFormatter(dl *resty.DebugLog) string {
	logMsg := fmt.Sprintf("curl_cmd: %s, resp_body: %s", dl.Request.CurlCmd, dl.Response.Body)
	return logMsg
}

func ApplyRetryCodeConditions(response *resty.Response, err error) bool {
	bytes, err := io.ReadAll(response.Body)
	if err != nil {
		return false
	}

	var resp CommonRespField
	err = json.Unmarshal(bytes, &resp)
	if err != nil {
		return false
	}

	// 根据code枚举值进行重试
	// https://developers.e.kuaishou.com/docs?docType=DSP&documentId=2985&menuId=3732
	retryCode := map[int]struct{}{
		400001: {}, // 请求过于频繁
		402000: {}, // access token 过期
		410000: {}, // 获取报表数据异常
	}
	if _, ok := retryCode[resp.Code]; ok {
		return true
	}

	return false
}
