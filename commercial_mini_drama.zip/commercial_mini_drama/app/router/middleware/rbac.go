package middleware

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common"
	"goserver/app/model/service/rbac"
)

func RbacMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		common.GetRequest(c)
		rbacService := &rbac.RbacService{Ctx: c}
		rbacService.SetUserRbac()
	}
}
