package time

import (
	"errors"
	"fmt"
	"time"
)

func NowInMillSecond() int64 {
	//return time.Now().UnixNano() / 1000000
	return time.Now().UnixNano() / int64(time.Millisecond)
}

func BeforeThreeUnixTime() int64 {
	return time.Now().Add(-3 * time.Minute).Unix()
}

func NowInSecond() int {
	return int(time.Now().Unix())
}

func StringFromMillSecond(ts int64) string {
	return time.Unix(ts/1000, ts%1000).Format("2006-01-02 15:04:05")
}

func StringFromSecond(ts int64) string {
	return time.Unix(ts, 0).Format("2006-01-02 15:04:05")
}

func GetFormatCurrentTime() string {
	return time.Now().Format("2006-01-02 15:04:05")
}

func TimeFormat(oldTime string, oldFormat string, newFormat string) (new string, err error) {
	b, err := time.Parse(oldFormat, oldTime)

	if err != nil {
		return "", err
	}

	return b.Format(newFormat), nil
}

func GetDays(start string, end string) ([]string, error) {
	format := "2006-01-02"
	b, err := time.Parse(format, start)
	if err != nil {
		return nil, err
	}

	e, err := time.Parse(format, end)
	if err != nil {
		return nil, err
	}

	day := b
	days := []string{}

	for {
		days = append(days, day.Format(format))
		day = day.AddDate(0, 0, 1)
		if day.After(e) {
			break
		}
	}

	return days, nil
}

// GetTenMinuteTime 获取指定时间，最近的整十分钟时间
func GetTenMinuteTime(t time.Time) (time.Time, error) {
	return time.ParseInLocation("2006-01-02 15:04:05", fmt.Sprintf("%s:%02d:00", t.Format("2006-01-02 15"), t.Minute()/10*10), time.Local)
}

func GetQuarterHour(t time.Time) time.Time {
	return t.Truncate(15 * time.Minute)
}

func GetParseTenMinuteTime(s string) (time.Time, error) {
	var res time.Time
	if s == "" {
		return res, errors.New("value is empty")
	}

	t, err := time.ParseInLocation(time.DateTime, s, time.Local)
	if err != nil {
		return res, err
	}
	return GetTenMinuteTime(t)
}

// GetDayTime 获取指定时间，最近的整天时间
func GetDayTime(t time.Time) (time.Time, error) {
	return time.ParseInLocation(time.DateTime, t.Format(time.DateOnly+" 00:00:00"), time.Local)
}

func GetParseDayTime(s string) (time.Time, error) {
	var res time.Time
	if s == "" {
		return res, errors.New("value is empty")
	}

	t, err := time.ParseInLocation(time.DateTime, s, time.Local)
	if err != nil {
		return res, err
	}
	return GetTenMinuteTime(t)
}

// GetHourTime 获取指定时间，最近的整小时时间
func GetHourTime(t time.Time) (time.Time, error) {
	return time.ParseInLocation("2006-01-02 15:04:05", t.Format("2006-01-02 15:00:00"), time.Local)
}

func XAxis(start time.Time, end time.Time, interval time.Duration, format string) []string {
	if format == "" {
		format = "15:04"
	}

	var x []string
	for start.Before(end) {
		x = append(x, start.Format(format))
		start = start.Add(interval)
	}

	return x
}

func Reformat(oldTime string, oldFormat string, newFormat string) (string, error) {
	b, err := time.ParseInLocation(oldFormat, oldTime, time.Local)
	if err != nil {
		return "", err
	}

	return b.Format(newFormat), nil
}

func GetPointTime(crontabTime time.Time) (time.Time, error) {
	crontabTenMinuteTime, _ := GetTenMinuteTime(crontabTime)
	pointTime, err := GetTenMinuteTime(crontabTenMinuteTime.Add(-1 * time.Minute))
	return pointTime, err
}

// 获取当天开始时间
func GetTodayStart() time.Time {
	now := time.Now()
	// 构造当天的0点时间
	return time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, now.Location())
}

// 获取当天的结束时间
func GetTodayEnd() time.Time {
	// 在当天开始时间基础上加24小时再减1秒
	return GetTodayStart().Add(24 * time.Hour).Add(-1 * time.Second)
}
