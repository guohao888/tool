package redisdb

import (
	"context"
	"github.com/go-redsync/redsync/v4"
	"github.com/go-redsync/redsync/v4/redis/redigo"
	"goserver/app/library/log"
	"time"
)

var (
	RedSync *redsync.Redsync
)

func InitRedSync() {
	pool := redigo.NewPool(RedisPool)
	RedSync = redsync.New(pool)
}

func MutexExtend(ctx context.Context, mutex *redsync.Mutex, d time.Duration) {
	ticker := time.NewTicker(d)
	defer ticker.Stop()

	mutexName := mutex.Name()
	for {
		select {
		case t := <-ticker.C:
			log.Debugf("mutexName: %s, 锁续期开始, t: %s", mutexName, t.Format(time.RFC3339))
			ok, err := mutex.Extend()
			if err != nil {
				log.Debugf("mutexName: %s, mutex extend failed, err: %s", mutexName, err)
			}
			if !ok {
				log.Debugf("mutexName: %s, Expected a valid mutex", mutexName)
			}
		case <-ctx.Done():
			log.Debugf("mutexName: %s, 锁续期结束", mutexName)
			return
		}
	}
}
