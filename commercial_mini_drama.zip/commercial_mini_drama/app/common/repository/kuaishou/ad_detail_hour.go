package kuaishou

import (
	"goserver/app/common/repository"
	"time"
)

const AdDetailHourTable = "kuaishou_ad_detail_hour"

type AdDetailHourEntity struct {
	AdvertiserId              int64     `gorm:"column:advertiser_id"`
	AccountId                 int64     `gorm:"column:account_id"`
	Date                      time.Time `gorm:"column:date"`
	Hour                      int64     `gorm:"column:hour"`
	TotalCharge               float64   `gorm:"column:total_charge"`
	EventPayPurchaseAmount    float64   `gorm:"column:event_pay_purchase_amount"`
	MiniGameIaaPurchaseAmount float64   `gorm:"column:mini_game_iaa_purchase_amount"`
}

func (*AdDetailHourEntity) TableName() string {
	return AdDetailTable
}

func AdDetailHourTableName() string {
	if repository.IsDebugTable(AdDetailHourTable) {
		return AdDetailHourTable + "_dev"
	} else {
		return AdDetailHourTable
	}
}
