package toutiao

import (
	"context"
	"errors"
	"fmt"
	"github.com/avast/retry-go"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"github.com/shopspring/decimal"
	"goserver/app/library/limiter"
	"goserver/app/library/playlet"
	"goserver/app/library/playlet/cache"
	"net/url"
	"strconv"
	"strings"
	"time"
)

const (
	MaxPageSize = 100
)

const (
	MaterialTypeImage = "image"
	MaterialTypeVideo = "video"
)

const (
	AdvertiserRole1 = 1 // 普通广告主
	AdvertiserRole2 = 2 // 纵横组织账户
	AdvertiserRole3 = 3 // 一级代理商
	AdvertiserRole4 = 4 // 二级代理商
	AdvertiserRole5 = 5 // 协作者授权的纵横组织
	AdvertiserRole6 = 6 // 星图账号
)

const (
	AccountSourceAD         = "AD"
	AccountSourceENTERPRISE = "ENTERPRISE"
	AccountSourceLOCAL      = "LOCAL"
)

const (
	CtxPathKey                        = "toutiao_url_path"
	CtxAppIdKey                       = "toutiao_app_id"
	OpenApi2MajordomoAdvertiserSelect = "/open_api/2/majordomo/advertiser/select/" // 广告主列表（纵横组织）
	OpenApiV30ReportCustomGet         = "/open_api/v3.0/report/custom/get/"        // 自定义报表
	OpenApiFundDailyStatV2            = "/open_api/2/advertiser/fund/daily_stat/"
	OpenApiVideoGet                   = "/open_api/2/file/video/get/"
	OpenApiProjectWeekScheduleUpdate  = "/open_api/v3.0/project/week_schedule/update/" // 项目拉空
	LocalPromotionListV30Api          = "/open_api/v3.0/local/promotion/list/"
	ToolsLogSearchV2Api               = "/open_api/2/tools/log_search/"             // 操作日志查询
	Oauth2AppAccessTokenApi           = "/open_api/oauth2/app_access_token/"        // 获取APP Access Token
	SubscribeAccountsAddV30Api        = "/open_api/v3.0/subscribe/accounts/add/"    // 新增 Adv 订阅
	SubscribeAccountsRemoveV30Api     = "/open_api/v3.0/subscribe/accounts/remove/" // 取消 Adv 订阅
	FileMaterialList                  = "/open_api/2/file/material/list/"           // 获取素材标签列表
	AgentAdvertiserUpdateV2Api        = "/open_api/2/agent/advertiser/update/"      // 更新广告主信息
)

var MaterialAllowImageModeValue = []string{
	"2",   // 小图
	"3",   // 大图横图
	"5",   // 横版视频
	"15",  // 竖版视频
	"16",  // 大图竖图
	"148", // 搜索大图
	"157", // 搜索小图
	"4",   // 组图
	"156", // 搜索橱窗
	"131", // 穿山甲开屏图片
	"154", // 穿山甲开屏视频
	//"188", // 联盟卡券
	//"180", // 图文
	//"10000", // 标题
}

var (
	RespStructError             = errors.New("resp struct is nil")
	RespCodeError               = errors.New("resp code error")
	RespCodeErrorToManyRequests = errors.New("too many requests by this developer. please retry in some time")
	RespCodeErrorAccessToken    = errors.New("access token error")
)

type MajordomoAdvertiserSelectV2Req struct {
	AccessToken  string
	AdvertiserId int64
}

// MajordomoAdvertiserSelectV2 广告主列表（纵横组织）
// https://open.oceanengine.com/labels/7/docs/1699352157034496
func MajordomoAdvertiserSelectV2(ctx context.Context, req MajordomoAdvertiserSelectV2Req) (*models.MajordomoAdvertiserSelectV2Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApi2MajordomoAdvertiserSelect)

	var resp *models.MajordomoAdvertiserSelectV2Response
	err := retry.Do(func() error {
		latestAccessToken, e := cache.GetLatestAccessToken(req.AccessToken)
		if e != nil {
			return e
		}

		resp, _, e = apiClient.MajordomoAdvertiserSelectV2Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(req.AdvertiserId).
			Execute()
		if e != nil {
			return e
		}
		if resp == nil {
			return fmt.Errorf("获取纵横组织下资产账户列表失败, %w", RespStructError)
		}
		if *resp.Code != CodeSuccess {
			return fmt.Errorf("获取纵横组织下资产账户列表失败, %w", RespCodeError)
		}
		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))

	return resp, err
}

// MajordomoAdvertiserSelectV2Assist 广告主列表（纵横组织）
// https://open.oceanengine.com/labels/7/docs/1699352157034496
func MajordomoAdvertiserSelectV2Assist(ctx context.Context, req MajordomoAdvertiserSelectV2Req) (*models.MajordomoAdvertiserSelectV2Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApi2MajordomoAdvertiserSelect)

	var resp *models.MajordomoAdvertiserSelectV2Response
	err := retry.Do(func() error {
		var e error
		resp, _, e = apiClient.MajordomoAdvertiserSelectV2Api().
			Get(ctx).
			AccessToken(req.AccessToken).
			AdvertiserId(req.AdvertiserId).
			Execute()
		if e != nil {
			return e
		}
		if resp == nil {
			return fmt.Errorf("获取纵横组织下资产账户列表失败, %w", RespStructError)
		}
		if *resp.Code != CodeSuccess {
			return fmt.Errorf("获取纵横组织下资产账户列表失败, %w", RespCodeError)
		}
		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))

	return resp, err
}

type ReportCustomGetV30Req struct {
	AccessToken  string                                   `json:"access_token"`
	Dimensions   []string                                 `json:"dimensions"`
	AdvertiserId int64                                    `json:"advertiser_id"`
	Metrics      []string                                 `json:"metrics"`
	Filters      []*models.ReportCustomGetV30FiltersInner `json:"filters"`
	StartTime    string                                   `json:"start_time"`
	EndTime      string                                   `json:"end_time"`
	OrderBy      []*models.ReportCustomGetV30OrderByInner `json:"order_by"`
	Page         int32                                    `json:"page,omitempty"`
	PageSize     int32                                    `json:"page_size,omitempty"`
	DataTopic    models.ReportCustomGetV30DataTopic       `json:"data_topic,omitempty"`
}

// ReportCustomGetV30 自定义报表
// https://open.oceanengine.com/labels/7/docs/1741387668314126
func ReportCustomGetV30(ctx context.Context, request ReportCustomGetV30Req, appId string) (*models.ReportCustomGetV30Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiV30ReportCustomGet)

	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.CUSTOM)

	if request.PageSize > MaxPageSize {
		request.PageSize = MaxPageSize
	}

	var res *models.ReportCustomGetV30Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		latestAccessToken := request.AccessToken
		res, _, e = apiClient.ReportCustomGetV30Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			Dimensions(request.Dimensions).
			AdvertiserId(request.AdvertiserId).
			Metrics(request.Metrics).
			Filters(request.Filters).
			OrderBy(request.OrderBy).
			StartTime(request.StartTime).
			EndTime(request.EndTime).
			Page(request.Page).
			PageSize(request.PageSize).
			DataTopic(request.DataTopic).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("获取头条自定义报表失败, %w", RespStructError)
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("获取头条自定义报表失败, code: %d, message: %s, %w", *res.Code, *res.Message, RespCodeError)
		}
		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

type AllReportCustomGetV30Req struct {
	AccessToken  string                                   `json:"access_token"`
	Dimensions   []string                                 `json:"dimensions"`
	AdvertiserId int64                                    `json:"advertiser_id"`
	Metrics      []string                                 `json:"metrics"`
	Filters      []*models.ReportCustomGetV30FiltersInner `json:"filters"`
	StartTime    string                                   `json:"start_time"`
	EndTime      string                                   `json:"end_time"`
	OrderBy      []*models.ReportCustomGetV30OrderByInner `json:"order_by"`
	DataTopic    models.ReportCustomGetV30DataTopic       `json:"data_topic,omitempty"`
}

type Rows []*models.ReportCustomGetV30ResponseDataRowsInner

type Material struct {
	CdpProjectId      int64
	CdpProjectName    string
	CdpPromotionId    int64
	CdpPromotionName  string
	ImageMode         string
	MaterialId        int64
	MaterialFileName  string
	StatTimeDay       string
	Active            int
	ActivePay         int
	ClickCnt          int
	DownloadFinishCnt int
	GameAddiction     int
	ShowCnt           int
	ConvertCnt        int // 转化数据
	ReportCnt         int // 举报数
	DislikeCnt        int // 不感兴趣数
	StatCost          decimal.Decimal
}

func (r Rows) DataRowsInnerTransformMaterial() []Material {
	res := make([]Material, 0, len(r))

	for _, v := range r {
		cdpProjectId, _ := strconv.ParseInt(v.Dimensions["cdp_project_id"], 10, 64)
		cdpPromotionId, _ := strconv.ParseInt(v.Dimensions["cdp_promotion_id"], 10, 64)
		materialId, _ := strconv.ParseInt(v.Dimensions["material_id"], 10, 64)

		active, _ := strconv.Atoi(v.Metrics["active"])
		activePay, _ := strconv.Atoi(v.Metrics["active_pay"])
		clickCnt, _ := strconv.Atoi(v.Metrics["click_cnt"])
		downloadFinishCnt, _ := strconv.Atoi(v.Metrics["download_finish_cnt"])
		gameAddiction, _ := strconv.Atoi(v.Metrics["game_addiction"])
		showCnt, _ := strconv.Atoi(v.Metrics["show_cnt"])
		convertCnt, _ := strconv.Atoi(v.Metrics["convert_cnt"])
		dislikeCnt, _ := strconv.Atoi(v.Metrics["dislike_cnt"])
		reportCnt, _ := strconv.Atoi(v.Metrics["report_cnt"])
		statCost, _ := decimal.NewFromString(v.Metrics["stat_cost"])

		imageMode := v.Dimensions["image_mode"]

		material := Material{
			CdpProjectId:      cdpProjectId,
			CdpProjectName:    v.Dimensions["cdp_project_name"],
			CdpPromotionId:    cdpPromotionId,
			CdpPromotionName:  v.Dimensions["cdp_promotion_name"],
			ImageMode:         imageMode,
			MaterialId:        materialId,
			StatTimeDay:       v.Dimensions["stat_time_hour"],
			Active:            active,
			ActivePay:         activePay,
			ClickCnt:          clickCnt,
			DownloadFinishCnt: downloadFinishCnt,
			GameAddiction:     gameAddiction,
			ShowCnt:           showCnt,
			ConvertCnt:        convertCnt, // 转化数
			DislikeCnt:        dislikeCnt, // 不感兴趣数
			ReportCnt:         reportCnt,  // 举报数
			StatCost:          statCost,
		}

		res = append(res, material)
	}

	return res
}

type BaseMaterial struct {
	StatTimeDay                       string
	CdpProjectId                      string
	CdpProjectName                    string
	CdpPromotionId                    string
	CdpPromotionName                  string
	AdPlatformCdpPromotionBid         string
	Active                            int64
	ActivePay                         int64
	ClickCnt                          int64
	ShowCnt                           int64
	ConvertCnt                        int64 // 转化数据
	ConversionCost                    decimal.Decimal
	StatCost                          decimal.Decimal
	StatAttributionMicroGame24HAmount decimal.Decimal
	AttributionMicroGame24HRoi        decimal.Decimal
	StatMicroGame0DAmount             decimal.Decimal
	AttributionMicroGame0DTtv         decimal.Decimal
	AttributionMicroGame3DTtv         decimal.Decimal
	AttributionMicroGame7DTtv         decimal.Decimal
}

func (r Rows) DataRows2InnerTransformMaterial() []BaseMaterial {
	res := make([]BaseMaterial, 0, len(r))

	for _, v := range r {
		active, _ := strconv.Atoi(v.Metrics["active"])
		activePay, _ := strconv.Atoi(v.Metrics["active_pay"])
		clickCnt, _ := strconv.Atoi(v.Metrics["click_cnt"])
		showCnt, _ := strconv.Atoi(v.Metrics["show_cnt"])
		convertCnt, _ := strconv.Atoi(v.Metrics["convert_cnt"])
		statCost, _ := decimal.NewFromString(v.Metrics["stat_cost"])
		statAttributionAmount, _ := decimal.NewFromString(v.Metrics["stat_attribution_micro_game_24h_amount"])
		attributionRoi, _ := decimal.NewFromString(v.Metrics["attribution_micro_game_24h_roi"])
		statMicroGame0DAmount, _ := decimal.NewFromString(v.Metrics["stat_micro_game_0d_amount"])
		attributionMicroGame0DTtv, _ := decimal.NewFromString(v.Metrics["attribution_micro_game_0d_ltv"])
		attributionMicroGame3DTtv, _ := decimal.NewFromString(v.Metrics["attribution_micro_game_3d_ltv"])
		attributionMicroGame7DTtv, _ := decimal.NewFromString(v.Metrics["attribution_micro_game_7d_ltv"])
		var conversionCost decimal.Decimal
		var adPlatformCdpPromotionBid string
		if v.Metrics["conversion_cost"] != "" {
			conversionCost, _ = decimal.NewFromString(v.Metrics["conversion_cost"])
		}
		if v.Dimensions["ad_platform_cdp_promotion_bid"] != "" {
			adPlatformCdpPromotionBid = v.Dimensions["ad_platform_cdp_promotion_bid"]
		}
		material := BaseMaterial{
			CdpProjectId:                      v.Dimensions["cdp_project_id"],
			CdpProjectName:                    v.Dimensions["cdp_project_name"],
			CdpPromotionId:                    v.Dimensions["cdp_promotion_id"],
			CdpPromotionName:                  v.Dimensions["cdp_promotion_name"],
			StatTimeDay:                       v.Dimensions["stat_time_hour"],
			AdPlatformCdpPromotionBid:         adPlatformCdpPromotionBid,
			Active:                            int64(active),
			ActivePay:                         int64(activePay),
			ClickCnt:                          int64(clickCnt),
			ShowCnt:                           int64(showCnt),
			ConvertCnt:                        int64(convertCnt), // 转化数
			StatCost:                          statCost,
			ConversionCost:                    conversionCost,
			StatAttributionMicroGame24HAmount: statAttributionAmount,
			AttributionMicroGame24HRoi:        attributionRoi,
			StatMicroGame0DAmount:             statMicroGame0DAmount,
			AttributionMicroGame0DTtv:         attributionMicroGame0DTtv,
			AttributionMicroGame3DTtv:         attributionMicroGame3DTtv,
			AttributionMicroGame7DTtv:         attributionMicroGame7DTtv,
		}

		res = append(res, material)
	}

	return res
}

func AllReportCustomGetV30(ctx context.Context, req AllReportCustomGetV30Req, appId string) (Rows, error) {
	page := int32(1)
	pageSizeMax := int32(100)

	var rows Rows
	for {
		resp, err := ReportCustomGetV30(ctx, ReportCustomGetV30Req{
			AccessToken:  req.AccessToken,
			Dimensions:   req.Dimensions,
			AdvertiserId: req.AdvertiserId,
			Metrics:      req.Metrics,
			Filters:      req.Filters,
			StartTime:    req.StartTime,
			EndTime:      req.EndTime,
			OrderBy:      req.OrderBy,
			Page:         page,
			PageSize:     pageSizeMax,
			DataTopic:    req.DataTopic,
		}, appId)
		if err != nil {
			return nil, err
		}
		if len(resp.Data.Rows) == 0 {
			return rows, nil
		}

		rows = append(rows, resp.Data.Rows...)

		if int32(len(resp.Data.Rows)) < pageSizeMax {
			break
		}

		page++
	}

	return rows, nil
}

func AllOauth2MajordomoAdvertiserId(ctx context.Context, accessToken string) ([]playlet.AdvertiserInfo, error) {
	list, err := Oauth2AdvertiserGetByAdvertiserRole(ctx, accessToken, AdvertiserRole1, AdvertiserRole2)
	if err != nil {
		return nil, err
	}

	var advertiserIds []playlet.AdvertiserInfo
	for _, v := range list {

		switch *v.AdvertiserRole {
		case AdvertiserRole1:
			advertiserId := strconv.FormatInt(*v.AdvertiserId, 10)
			advertiserIds = append(advertiserIds, playlet.AdvertiserInfo{
				AdvertiserId:   advertiserId,
				AdvertiserName: *v.AdvertiserName,
			})
		case AdvertiserRole2:
			resp, err := MajordomoAdvertiserSelectV2(ctx, MajordomoAdvertiserSelectV2Req{
				AccessToken:  accessToken,
				AdvertiserId: *v.AdvertiserId,
			})
			if err != nil || resp.Data == nil {
				continue
			}
			for _, vv := range resp.Data.List {
				adId := strconv.FormatInt(*vv.AdvertiserId, 10)
				advertiserIds = append(advertiserIds, playlet.AdvertiserInfo{
					AdvertiserId:   adId,
					AdvertiserName: *vv.AdvertiserName,
				})
			}
		}
	}

	return advertiserIds, nil
}

func AllOauth2MajordomoAssistAdvertiserId(ctx context.Context, accessToken string) ([]playlet.AdvertiserInfo, error) {
	list, err := Oauth2AdvertiserGetByAdvertiserRoleAssist(ctx, accessToken, AdvertiserRole5, AdvertiserRole6)
	if err != nil {
		return nil, err
	}
	var advertiserIds []playlet.AdvertiserInfo
	for _, v := range list {

		switch *v.AdvertiserRole {
		case AdvertiserRole1:
			advertiserId := strconv.FormatInt(*v.AdvertiserId, 10)
			advertiserIds = append(advertiserIds, playlet.AdvertiserInfo{
				AdvertiserId:   advertiserId,
				AdvertiserName: *v.AdvertiserName,
			})
		case AdvertiserRole5, AdvertiserRole6:
			resp, err := MajordomoAdvertiserSelectV2Assist(ctx, MajordomoAdvertiserSelectV2Req{
				AccessToken:  accessToken,
				AdvertiserId: *v.AdvertiserId,
			})
			if err != nil || resp.Data == nil {
				continue
			}
			for _, vv := range resp.Data.List {
				adId := strconv.FormatInt(*vv.AdvertiserId, 10)
				advertiserIds = append(advertiserIds, playlet.AdvertiserInfo{
					AdvertiserId: adId,
					AdvertiserName: func() string {
						if vv.AdvertiserName == nil {
							return ""
						} else {
							return *vv.AdvertiserName
						}
					}(),
				})
			}
		}
	}
	return advertiserIds, nil
}

/************************************   头条视频  ************************************/

type VideoRows []*models.FileVideoGetV2ResponseDataListInner

func AllFileVideoGetV2(ctx context.Context, req FileVideoGetReq, appId string) (VideoRows, error) {
	page := int64(1)
	pageSizeMax := int64(100)

	var rows VideoRows
	for {
		resp, err := FileVideoGet(ctx, FileVideoGetReq{
			AccessToken:  req.AccessToken,
			AdvertiserId: req.AdvertiserId,
			Filtering:    req.Filtering,
			Page:         page,
			PageSize:     pageSizeMax,
		}, appId)
		if err != nil {
			return nil, err
		}
		if len(resp.Data.List) == 0 {
			return nil, nil
		}

		rows = append(rows, resp.Data.List...)

		if int64(len(resp.Data.List)) < pageSizeMax || *resp.Data.PageInfo.Page <= page {
			break
		}

		page++
	}

	return rows, nil
}

type FileVideoGetReq struct {
	AccessToken  string                         `json:"access_token"`
	AdvertiserId int64                          `json:"advertiser_id"`
	Filtering    models.FileVideoGetV2Filtering `json:"filtering"`
	Page         int64                          `json:"page,omitempty"`
	PageSize     int64                          `json:"page_size,omitempty"`
}

// FileVideoGet 获取头条视频素材
// https://open.oceanengine.com/labels/7/docs/1741387668314126
func FileVideoGet(ctx context.Context, request FileVideoGetReq, appId string) (*models.FileVideoGetV2Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiVideoGet)

	if request.PageSize > MaxPageSize {
		request.PageSize = MaxPageSize
	}

	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.VIDEO)

	var res *models.FileVideoGetV2Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		latestAccessToken := request.AccessToken
		res, _, e = apiClient.FileVideoGetV2Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(request.AdvertiserId).
			Filtering(request.Filtering).
			Page(request.Page).
			PageSize(request.PageSize).
			Execute()

		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("获取头条视频素材, %w", RespStructError)
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("获取头条视频素材, code: %d, message: %s, %w", *res.Code, *res.Message, RespCodeError)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

/************************************   头条素材  ************************************/

type BaseMedia struct {
	StatTimeDay      string
	CdpPromotionId   string
	CdpProjectId     string
	CdpPromotionName string
	MaterialId       string
	Active           int64
	ActivePay        int64
	ClickCnt         int64
	ShowCnt          int64
	ConvertCnt       int64 // 转化数据
	StatCost         decimal.Decimal
}

func (r Rows) DataRows2InnerTransformMedia() []BaseMedia {
	res := make([]BaseMedia, 0, len(r))

	for _, v := range r {
		active, _ := strconv.Atoi(v.Metrics["active"])
		activePay, _ := strconv.Atoi(v.Metrics["active_pay"])
		clickCnt, _ := strconv.Atoi(v.Metrics["click_cnt"])
		showCnt, _ := strconv.Atoi(v.Metrics["show_cnt"])
		convertCnt, _ := strconv.Atoi(v.Metrics["convert_cnt"])
		statCost, _ := decimal.NewFromString(v.Metrics["stat_cost"])

		baseMedia := BaseMedia{
			StatTimeDay:      v.Dimensions["stat_time_hour"],
			CdpProjectId:     v.Dimensions["cdp_project_id"],
			CdpPromotionId:   v.Dimensions["cdp_promotion_id"],
			CdpPromotionName: v.Dimensions["cdp_promotion_name"],
			MaterialId:       v.Dimensions["material_id"],
			Active:           int64(active),
			ActivePay:        int64(activePay),
			ClickCnt:         int64(clickCnt),
			ShowCnt:          int64(showCnt),
			ConvertCnt:       int64(convertCnt), // 转化数
			StatCost:         statCost,
		}

		res = append(res, baseMedia)
	}
	return res
}

/************************************   素材拒审   ************************************/

type RejectReasonGetReq struct {
	AccessToken  string  `json:"access_token"`
	AdvertiserId int64   `json:"advertiser_id"`
	PromotionIds []int64 `json:"promotion_ids"`
}

type RejectMaterialInfo struct {
	PromotionId   int64
	Type          string
	Item          string
	RejectReason  string
	Suggestion    string
	AuditPlatform string
}

type RejectPromotionInfo struct {
	PromotionId  int64
	Content      string
	RejectReason string
	Suggestion   string
}

func DataRows2InnerTransformRejectMaterial(reject *models.PromotionRejectReasonGetV30Response) []RejectMaterialInfo {
	res := make([]RejectMaterialInfo, 0, len(reject.Data.List))
	for _, v := range reject.Data.List {
		promotionId := func() int64 {
			if v.PromotionId == nil {
				return 0
			} else {
				return *v.PromotionId
			}
		}()
		for _, vv := range v.MaterialReject {
			if vv.Type == nil {
				continue
			}
			if *vv.Type == "CREATIVE_VIDEO" {
				rejectMaterialInfo := RejectMaterialInfo{
					PromotionId: promotionId,
					Type: func() string {
						if vv.Type == nil {
							return ""
						} else {
							return string(*vv.Type)
						}
					}(),
					Item: func() string {
						if vv.Item == nil {
							return ""
						}
						return *vv.Item
					}(),
					RejectReason: strings.Join(vv.RejectReason, ","),
					Suggestion:   strings.Join(vv.Suggestion, ","),
					AuditPlatform: func() string {
						if vv.Item == nil {
							return ""
						}
						return *vv.Item
					}(),
				}
				res = append(res, rejectMaterialInfo)
			}
		}
	}
	return res
}

func DataRows2InnerTransformRejectPromotion(reject *models.PromotionRejectReasonGetV30Response) []RejectPromotionInfo {
	res := make([]RejectPromotionInfo, 0, len(reject.Data.List))
	for _, v := range reject.Data.List {
		promotionId := *v.PromotionId
		for _, vv := range v.PromotionReject {
			rejectPromotionInfo := RejectPromotionInfo{
				PromotionId:  promotionId,
				Content:      string(*vv.Content),
				RejectReason: strings.Join(vv.RejectReason, ","),
				Suggestion:   strings.Join(vv.Suggestion, ","),
			}
			res = append(res, rejectPromotionInfo)
		}
	}
	return res
}

func RejectReasonGet(ctx context.Context, request RejectReasonGetReq, appId string) (*models.PromotionRejectReasonGetV30Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiVideoGet)

	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.REJECT)

	var res *models.PromotionRejectReasonGetV30Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		res, _, e = apiClient.PromotionRejectReasonGetV30Api().
			Get(ctx).
			AccessToken(request.AccessToken).
			AdvertiserId(request.AdvertiserId).
			PromotionIds(request.PromotionIds).
			Execute()

		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("获取头条审核建议失败, %w", RespStructError)
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("获取头条审核建议, code: %d, message: %s, %w", *res.Code, *res.Message, RespCodeError)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

/************************************   项目列表   ************************************/

type ProjectGetReq struct {
	AccessToken       string `json:"access_token"`
	AdvertiserId      int64  `json:"advertiser_id"`
	Page              int64  `json:"page,omitempty"`
	PageSize          int64  `json:"page_size,omitempty"`
	ProjectCreateTime string `json:"project_create_time,omitempty"`
}

type ProjectRow []*models.ProjectListV30ResponseDataListInner

func AllProjectListGet(ctx context.Context, req ProjectGetReq) (ProjectRow, error) {
	page := int64(1)
	pageSizeMax := int64(100)

	var rows ProjectRow
	for {
		resp, err := ProjectListGet(ctx, ProjectGetReq{
			AccessToken:  req.AccessToken,
			AdvertiserId: req.AdvertiserId,
			Page:         page,
			PageSize:     pageSizeMax,
		})
		if err != nil {
			return nil, err
		}
		if len(resp.Data.List) == 0 {
			return rows, nil
		}

		rows = append(rows, resp.Data.List...)

		if int64(len(resp.Data.List)) < pageSizeMax || *resp.Data.PageInfo.Page <= page {
			break
		}

		page++
	}

	return rows, nil
}

func ProjectListGet(ctx context.Context, request ProjectGetReq) (*models.ProjectListV30Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiVideoGet)

	var res *models.ProjectListV30Response
	err := retry.Do(func() error {
		var e error
		res, _, e = apiClient.ProjectListV30Api().
			Get(ctx).
			AccessToken(request.AccessToken).
			AdvertiserId(request.AdvertiserId).
			//Filtering(models.ProjectListV30Filtering{
			//	ProjectCreateTime: &request.ProjectCreateTime,
			//}).
			Page(request.Page).
			PageSize(request.PageSize).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("获取头条项目列表失败, %w", RespStructError)
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("获取头条项目列表, code: %d, message: %s, %w", *res.Code, *res.Message, RespCodeError)
		}
		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

/*****************************   拉空操作   */

type ProjectWeekScheduleUpdateReq struct {
	AccessToken string `json:"access_token"`
	Info        models.ProjectWeekScheduleUpdateV30Request
}

// WeekSchedule 项目拉空
// https://open.oceanengine.com/labels/7/docs/1741387668314126
func WeekSchedule(ctx context.Context, request ProjectWeekScheduleUpdateReq, appId string) (*models.ProjectWeekScheduleUpdateV30Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiProjectWeekScheduleUpdate)
	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.REJECT)
	var res *models.ProjectWeekScheduleUpdateV30Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		latestAccessToken := request.AccessToken
		res, _, e = apiClient.ProjectWeekScheduleUpdateV30Api().
			Post(ctx).
			AccessToken(latestAccessToken).
			ProjectWeekScheduleUpdateV30Request(request.Info).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("批量更新项目投放时段, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("批量更新项目投放时段, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

// 拉空请求
func PullEmptyApi(ctx context.Context, request ProjectWeekScheduleUpdateReq) (*models.ProjectWeekScheduleUpdateV30Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiProjectWeekScheduleUpdate)
	var res *models.ProjectWeekScheduleUpdateV30Response
	err := retry.Do(func() error {
		var e error
		latestAccessToken := request.AccessToken
		res, _, e = apiClient.ProjectWeekScheduleUpdateV30Api().
			Post(ctx).
			AccessToken(latestAccessToken).
			ProjectWeekScheduleUpdateV30Request(request.Info).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("批量更新项目投放时段, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("批量更新项目投放时段, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return nil, err
	}
	return res, nil
}

/***************************************     获取广告列表    ***************************************/

type AllPromotionListReq struct {
	AccessToken  string `json:"access_token"`
	AdvertiserId int64  `json:"advertiser_id"`
	ModifyTime   string `json:"modify_time"`
	Page         int64  `json:"page,omitempty"`
	PageSize     int64  `json:"page_size,omitempty"`
}

func AllPromotionList(ctx context.Context, req AllPromotionListReq, appId string) ([]*models.PromotionListV30ResponseDataListInner, error) {
	page := int64(1)
	pageSizeMax := int64(10)

	var rows []*models.PromotionListV30ResponseDataListInner
	for {
		resp, err := PromotionList(ctx, AllPromotionListReq{
			AccessToken:  req.AccessToken,
			AdvertiserId: req.AdvertiserId,
			Page:         page,
			PageSize:     pageSizeMax,
		}, appId)
		if err != nil {
			return nil, err
		}
		if len(resp.Data.List) == 0 {
			return rows, nil
		}

		rows = append(rows, resp.Data.List...)

		if int64(len(resp.Data.List)) < pageSizeMax || *resp.Data.PageInfo.TotalPage == page {
			break
		}
		page++
	}

	return rows, nil
}

type PromotionInfos struct {
	AdvertiserId         string
	ProjectId            string
	PromotionId          string
	PromotionModifyDate  time.Time // 组合主键
	PromotionCreateTime  string    // 广告创建时间，格式yyyy-MM-dd HH:mm:ss
	PromotionModifyTime  string    // 广告更新时间，格式yyyy-MM-dd HH:mm:ss
	AppId                string    // 小程序/小游戏id
	StartPath            string    // 启动路径
	Params               string    // 页面监测参数
	Url                  string    // 字节小程序调起链接
	Code                 string    // 截取code 字符串
	ScheduleTime         string    // 广告的投放时段
	StatusFirst          string
	PlayletSeriesUrlList string // 短剧合集链接url
	HashRes              string // hash_res 值
}

func DataRows2Inner(list []*models.PromotionListV30ResponseDataListInner) []PromotionInfos {
	if len(list) == 0 {
		return nil
	}
	res := make([]PromotionInfos, 0)
	for _, v := range list {
		if v.AdvertiserId == nil {
			continue
		}
		advertiserStr := strconv.Itoa(int(*v.AdvertiserId))
		projectIdStr := strconv.Itoa(int(*v.ProjectId))
		promotionIdStr := strconv.Itoa(int(*v.PromotionId))
		var modifyDate time.Time
		var (
			code, playletUrl, hashRes, appid, startPath string
		)
		if v.PromotionModifyTime == nil {
			modifyDate, _ = time.ParseInLocation(time.DateTime, *v.PromotionCreateTime, time.Local)
		} else {
			modifyDate, _ = time.ParseInLocation(time.DateTime, *v.PromotionModifyTime, time.Local)
		}
		if v.PromotionMaterials.MiniProgramInfo != nil {
			if v.PromotionMaterials.MiniProgramInfo != nil {
				appid = func() string {
					if v.PromotionMaterials.MiniProgramInfo.AppId == nil {
						return ""
					} else {
						return *v.PromotionMaterials.MiniProgramInfo.AppId
					}
				}()
				startPath = func() string {
					if v.PromotionMaterials.MiniProgramInfo.StartPath == nil {
						return ""
					} else {
						return *v.PromotionMaterials.MiniProgramInfo.StartPath
					}
				}()
			}
			if v.PromotionMaterials.MiniProgramInfo.Params != nil {
				param := strings.Split(*v.PromotionMaterials.MiniProgramInfo.Params, "&")[0]
				pares, _ := url.ParseQuery(param)
				code = pares.Get("code")
			}
			if code == "" {
				if v.PromotionMaterials.MiniProgramInfo.Url != nil {
					code = getCode(*v.PromotionMaterials.MiniProgramInfo.Url)
					if code == "" {
						rawParse, _ := url.QueryUnescape(*v.PromotionMaterials.MiniProgramInfo.Url)
						urlPares, _ := url.ParseQuery(rawParse)
						code = urlPares.Get("code")
						if code == "" {
							code = urlPares.Get("·code")
						}
					}
				}
			}
		}
		if len(v.PromotionMaterials.PlayletSeriesUrlList) != 0 {
			playletUrl = v.PromotionMaterials.PlayletSeriesUrlList[0]
			parsedURL, err := url.Parse(playletUrl)
			if err != nil {
				hashRes = ""
			} else {
				queryParams := parsedURL.Query()
				hashRes = queryParams.Get("playlet_id")
			}
		}
		info := PromotionInfos{
			AdvertiserId:        advertiserStr,
			ProjectId:           projectIdStr,
			PromotionId:         promotionIdStr,
			PromotionModifyDate: modifyDate,
			PromotionCreateTime: func() string {
				if v.PromotionCreateTime == nil {
					return ""
				} else {
					return *v.PromotionCreateTime
				}
			}(),
			PromotionModifyTime: func() string {
				if v.PromotionModifyTime == nil {
					return ""
				} else {
					return *v.PromotionModifyTime
				}
			}(),
			AppId:     appid,
			StartPath: startPath,
			Code:      code,
			ScheduleTime: func() string {
				if v.ScheduleTime == nil {
					return ""
				} else {
					return *v.ScheduleTime
				}
			}(),
			StatusFirst: func() string {
				if v.StatusFirst == nil {
					return ""
				}
				return string(*v.StatusFirst.Ptr())
			}(),
			PlayletSeriesUrlList: playletUrl,
			HashRes:              hashRes,
		}
		res = append(res, info)
	}
	return res
}

func getCode(pUrl string) string {
	var code string
	// 1. 整体解码
	decoded, _ := url.QueryUnescape(pUrl)
	// 2. 解析为URL对象
	parsedURL, _ := url.Parse(decoded)
	// 3. 获取顶级查询参数
	topParams, _ := url.ParseQuery(parsedURL.RawQuery)

	// 4. 获取并解码start_page
	startPage := topParams.Get("start_page")
	decodedStartPage, _ := url.QueryUnescape(startPage) // 关键步骤：二次解码
	// 5. 解析start_page中的查询参数
	if strings.Contains(decodedStartPage, "?") {
		parts := strings.Split(strings.Replace(decodedStartPage, " ", "", -1), "?")
		nestedParams, _ := url.ParseQuery(parts[1])
		code = nestedParams.Get("code")
		if code == "" {
			code = nestedParams.Get("·code")
		}

	}
	return code
}

func PromotionList(ctx context.Context, request AllPromotionListReq, appId string) (*models.PromotionListV30Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, LocalPromotionListV30Api)

	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.REJECT)
	var res *models.PromotionListV30Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		latestAccessToken := request.AccessToken
		res, _, e = apiClient.PromotionListV30Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(request.AdvertiserId).
			Filtering(models.PromotionListV30Filtering{StatusFirst: models.PROMOTION_STATUS_ALL_PromotionListV30FilteringStatusFirst.Ptr()}).
			Page(request.Page).
			PageSize(request.PageSize).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("获取广告列表失败, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("获取广告列表, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

func AllProductDetail(ctx context.Context, req AllProductDetailReq, appId string) ([]*models.DpaDetailGetV2ResponseDataListInner, error) {
	page := int32(1)
	pageSizeMax := int32(20)

	var rows []*models.DpaDetailGetV2ResponseDataListInner
	for {
		resp, err := GetProductDetail(ctx, AllProductDetailReq{
			AccessToken:       req.AccessToken,
			AdvertiserId:      req.AdvertiserId,
			ProductPlatformId: req.ProductPlatformId,
			Filtering:         req.Filtering,
			Page:              page,
			PageSize:          pageSizeMax,
		}, appId)
		if err != nil {
			return nil, err
		}
		if len(resp.Data.List) == 0 {
			return rows, nil
		}

		rows = append(rows, resp.Data.List...)

		if int32(len(resp.Data.List)) < pageSizeMax || *resp.Data.PageInfo.TotalPage == int64(page) {
			break
		}
		page++
	}

	return rows, nil
}

type AllProductDetailReq struct {
	AccessToken       string                         `json:"access_token"`
	AdvertiserId      int64                          `json:"advertiser_id"`
	ProductPlatformId int64                          `json:"product_platform_id"`
	Filtering         models.DpaDetailGetV2Filtering `json:"filtering"`
	Page              int32                          `json:"page,omitempty"`
	PageSize          int32                          `json:"page_size,omitempty"`
}

func GetProductDetail(ctx context.Context, request AllProductDetailReq, appId string) (*models.DpaDetailGetV2Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, LocalPromotionListV30Api)

	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.REJECT)
	var res *models.DpaDetailGetV2Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		latestAccessToken := request.AccessToken
		res, _, e = apiClient.DpaDetailGetV2Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(request.AdvertiserId).
			ProductPlatformId(request.ProductPlatformId).
			Filtering(request.Filtering).
			Page(request.Page).
			PageSize(request.PageSize).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("获取商品列表失败, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("获取商品列表, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

type AllLogSearchReq struct {
	AccessToken  string `json:"access_token"`
	AdvertiserId int64  `json:"advertiser_id"`
	StartTime    string `json:"start_time"`
	EndTime      string `json:"end_time"`
	Page         int64  `json:"page,omitempty"`
	PageSize     int64  `json:"page_size,omitempty"`
}

func AllLogSearch(ctx context.Context, req AllLogSearchReq, appId string) ([]*models.ToolsLogSearchV2ResponseDataLogsInner, error) {
	page := int64(1)
	pageSizeMax := int64(20)

	var rows []*models.ToolsLogSearchV2ResponseDataLogsInner
	for {
		resp, err := GetLogSearch(ctx, AllLogSearchReq{
			AccessToken:  req.AccessToken,
			AdvertiserId: req.AdvertiserId,
			StartTime:    req.StartTime,
			EndTime:      req.EndTime,
			Page:         page,
			PageSize:     pageSizeMax,
		}, appId)
		if err != nil {
			return nil, err
		}
		if len(resp.Data.Logs) == 0 {
			return rows, nil
		}

		rows = append(rows, resp.Data.Logs...)

		if int64(len(resp.Data.Logs)) < pageSizeMax || *resp.Data.PageInfo.TotalPage == page {
			break
		}
		page++
	}

	return rows, nil
}

func GetLogSearch(ctx context.Context, request AllLogSearchReq, appId string) (*models.ToolsLogSearchV2Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, ToolsLogSearchV2Api)
	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.REJECT)
	var res *models.ToolsLogSearchV2Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		latestAccessToken := request.AccessToken
		res, _, e = apiClient.ToolsLogSearchV2Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(request.AdvertiserId).
			StartTime(&request.StartTime).
			EndTime(&request.EndTime).
			Page(request.Page).
			PageSize(request.PageSize).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("操作日志查询失败, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("操作日志查询, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

func GetAppAccessToken(ctx context.Context, appId int64, secret string) (string, error) {
	ctx = context.WithValue(ctx, CtxPathKey, Oauth2AppAccessTokenApi)
	var res *models.Oauth2AppAccessTokenResponse
	var accessToken string
	err := retry.Do(func() error {
		var e error
		res, _, e = apiClient.Oauth2AppAccessTokenApi().
			Post(ctx).
			Oauth2AppAccessTokenRequest(models.Oauth2AppAccessTokenRequest{
				AppId:  appId,
				Secret: secret,
			}).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("获取APP Access Token失败, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("获取APP Access Token, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return "", err
	}
	accessToken = func() string {
		if res.Data.AccessToken == nil {
			return ""
		}
		return *res.Data.AccessToken
	}()
	return accessToken, nil
}

func SubscribeAccountAdd(ctx context.Context, appAccessToken string, request models.SubscribeAccountsAddV30Request, appId string, token string) ([]int64, error) {
	ctx = context.WithValue(ctx, CtxPathKey, SubscribeAccountsAddV30Api)
	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.REJECT)

	var res *models.SubscribeAccountsAddV30Response
	var failList []int64
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		res, _, e = apiClient.SubscribeAccountsAddV30Api().
			Post(ctx).
			AccessToken(token).
			APPAccessToken(appAccessToken).
			SubscribeAccountsAddV30Request(request).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("新增 Adv 订阅失败, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("新增 Adv 订阅, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return []int64{}, err
	}
	failList = append(failList, res.Data.FailedAdvertiserIds...)
	return failList, nil
}

func SubscribeAccountRemove(ctx context.Context, appAccessToken string, request models.SubscribeAccountsRemoveV30Request, appId string, token string) ([]int64, error) {
	ctx = context.WithValue(ctx, CtxPathKey, SubscribeAccountsRemoveV30Api)
	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.REJECT)

	var res *models.SubscribeAccountsRemoveV30Response
	var failList []int64
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		res, _, e = apiClient.SubscribeAccountsRemoveV30Api().
			Post(ctx).
			AccessToken(token).
			APPAccessToken(appAccessToken).
			SubscribeAccountsRemoveV30Request(request).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("取消 Adv 订阅失败, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("取消 Adv 订阅, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		failList = append(failList, res.Data.FailedAdvertierIds...)
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return failList, err
	}
	return failList, nil
}

func AllFileMaterialList(ctx context.Context, req AllFileMaterialReq, appId string) ([]*models.FileMaterialListV2ResponseDataMaterialsInner, error) {
	page := int32(1)
	pageSizeMax := int32(200)

	var rows []*models.FileMaterialListV2ResponseDataMaterialsInner
	propertiesFilter := make([]*models.FileMaterialListV2PropertiesFilter, 4)
	propertiesFilter = append(propertiesFilter,
		models.FIRST_PUBLISH_MATERIAL_FileMaterialListV2PropertiesFilter.Ptr(),
		models.AD_HIGH_QUALITY_MATERIAL_FileMaterialListV2PropertiesFilter.Ptr(),
		models.INEFFICIENT_MATERIAL_FileMaterialListV2PropertiesFilter.Ptr(),
		models.AD_LOW_QUALITY_MATERIAL_FileMaterialListV2PropertiesFilter.Ptr())
	for {
		resp, err := GetFileMaterialList(ctx, AllFileMaterialReq{
			AccessToken:      req.AccessToken,
			AdvertiserId:     req.AdvertiserId,
			PropertiesFilter: propertiesFilter,
			StartTime:        req.StartTime,
			EndTime:          req.EndTime,
			Page:             page,
			PageSize:         pageSizeMax,
		}, appId)
		if err != nil {
			return nil, err
		}
		if len(resp.Data.Materials) == 0 {
			return rows, nil
		}

		rows = append(rows, resp.Data.Materials...)

		if int32(len(resp.Data.Materials)) < pageSizeMax || *resp.Data.PageInfo.TotalPage == int64(page) {
			break
		}
		page++
	}

	return rows, nil
}

type AllFileMaterialReq struct {
	AccessToken      string                                       `json:"access_token"`
	AdvertiserId     int64                                        `json:"advertiser_id"`
	PropertiesFilter []*models.FileMaterialListV2PropertiesFilter `json:"properties_filter,omitempty"`
	StartTime        string                                       `json:"start_time,omitempty"`
	EndTime          string                                       `json:"end_time,omitempty"`
	Page             int32                                        `json:"page,omitempty"`
	PageSize         int32                                        `json:"page_size,omitempty"`
}

func GetFileMaterialList(ctx context.Context, request AllFileMaterialReq, appId string) (*models.FileMaterialListV2Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, FileMaterialList)

	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.REJECT)
	var res *models.FileMaterialListV2Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		latestAccessToken := request.AccessToken
		res, _, e = apiClient.FileMaterialListV2Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(request.AdvertiserId).
			MaterialSource(models.AD_FileMaterialListV2MaterialSource).
			PropertiesFilter(request.PropertiesFilter).
			StartTime(request.StartTime).
			EndTime(request.EndTime).
			Page(request.Page).
			PageSize(request.PageSize).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("获取素材标签列表失败, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("获取素材标签列表, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return res, nil
}

func UpdateAdvertiser(ctx context.Context, advertiserId int64, advertiserName, accessToken, appId string) (*models.AgentAdvertiserUpdateV2Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, AgentAdvertiserUpdateV2Api)

	// 获取令牌桶
	l := limiter.ManagerLimiterClient()
	ll := l.GetLimiter(appId, limiter.REJECT)
	var res *models.AgentAdvertiserUpdateV2Response
	err := retry.Do(func() error {
		var e error
		waitErr := ll.Wait(context.Background())
		if waitErr != nil {
			return waitErr
		}
		res, _, e = apiClient.AgentAdvertiserUpdateV2Api().
			Post(ctx).
			AccessToken(accessToken).
			AgentAdvertiserUpdateV2Request(models.AgentAdvertiserUpdateV2Request{
				AdvertiserId: advertiserId,
				Name:         &advertiserName,
			}).
			Execute()
		if e != nil {
			return e
		}
		if res == nil {
			return fmt.Errorf("更新广告主信息失败, %s", e.Error())
		}
		if *res.Code != CodeSuccess {
			return fmt.Errorf("更新广告主信息, code: %d, message: %s, %w", *res.Code, *res.Message, e)
		}
		return nil
	}, retry.Delay(time.Millisecond*1000), retry.Attempts(3))
	if err != nil {
		return nil, err
	}
	return res, nil
}
