package lianshan

import (
	"github.com/mitchellh/mapstructure"
	"goserver/app/common/repository"
	"time"
)

const MaterialHourEntityTable = "lianshan_material_hour"

// MaterialHourEntity 巨量素材小时报表
type MaterialHourEntity struct {
	ID                        int64     `gorm:"column:id" json:"id"`                                                        // 主键id
	AdvertiserID              int64     `gorm:"column:advertiser_id" json:"advertiser_id"`                                  // 账户ID
	MaterialID                int64     `gorm:"column:material_id" json:"material_id"`                                      // 基础素材ID
	CdpProjectID              int64     `gorm:"column:cdp_project_id" json:"cdp_project_id"`                                // 项目ID
	LandingType               int64     `gorm:"column:landing_type" json:"landing_type"`                                    // 推广目的
	ExternalAction            int64     `gorm:"column:external_action" json:"external_action"`                              // 转化目标
	Pricing                   int64     `gorm:"column:pricing" json:"pricing"`                                              // 计费类型
	DeliveryMode              int64     `gorm:"column:delivery_mode" json:"delivery_mode"`                                  // 投放模式
	CdpPromotionID            int64     `gorm:"column:cdp_promotion_id" json:"cdp_promotion_id"`                            // 广告ID
	AppCode                   int64     `gorm:"column:app_code" json:"app_code"`                                            // 首选位置
	ImageMode                 int64     `gorm:"column:image_mode" json:"image_mode"`                                        // 基础素材类型
	StatTimeHour              int64     `gorm:"column:stat_time_hour" json:"stat_time_hour"`                                // 时间-小时
	StatCost                  float64   `gorm:"column:stat_cost" json:"stat_cost"`                                          // 消耗
	ShowCnt                   int64     `gorm:"column:show_cnt" json:"show_cnt"`                                            // 展示数
	ClickCnt                  int64     `gorm:"column:click_cnt" json:"click_cnt"`                                          // 点击数
	ConvertCnt                int64     `gorm:"column:convert_cnt" json:"convert_cnt"`                                      // 转化数
	CpmPlatform               float64   `gorm:"column:cpm_platform" json:"cpm_platform"`                                    // 平均千次展现费用(元)
	Ctr                       float64   `gorm:"column:ctr" json:"ctr"`                                                      // 点击率
	CpcPlatform               float64   `gorm:"column:cpc_platform" json:"cpc_platform"`                                    // 平均点击单价(元)
	AttributionConvertCnt     float64   `gorm:"column:attribution_convert_cnt" json:"attribution_convert_cnt"`              // 转化数(计费时间)
	AttributionConvertCost    float64   `gorm:"column:attribution_convert_cost" json:"attribution_convert_cost"`            // 转化成本(计费时间)
	AttributionConversionRate float64   `gorm:"column:attribution_conversion_rate" json:"attribution_conversion_rate"`      // 转化率(计费时间)
	ConversionRate            float64   `gorm:"column:conversion_rate" json:"conversion_rate"`                              // 转化率
	AttributionMicroGame0dLtv float64   `gorm:"column:attribution_micro_game_0d_ltv" json:"attribution_micro_game_0_d_ltv"` // 小程序/小游戏当日LTV
	AttributionMicroGame3dLtv float64   `gorm:"column:attribution_micro_game_3d_ltv" json:"attribution_micro_game_3_d_ltv"` // 小程序/小游戏激活后三日LTV
	TotalPlay                 float64   `gorm:"column:total_play" json:"total_play"`                                        // 播放量
	PlayDuration3s            float64   `gorm:"column:play_duration_3s" json:"play_duration_3_s"`                           // 3秒播放数
	ValidPlay                 float64   `gorm:"column:valid_play" json:"valid_play"`                                        // 有效播放数
	ValidPlayCost             float64   `gorm:"column:valid_play_cost" json:"valid_play_cost"`                              // 有效播放成本
	PlayOverRate              float64   `gorm:"column:play_over_rate" json:"play_over_rate"`                                // 完播率
	DyLike                    float64   `gorm:"column:dy_like" json:"dy_like"`                                              // 点赞数
	DislikeCnt                float64   `gorm:"column:dislike_cnt" json:"dislike_cnt"`                                      // 不感兴趣数
	PlayDuration3sRate        float64   `gorm:"column:play_duration_3s_rate" json:"play_duration_3_s_rate"`                 // 3秒播放率
	StatTime                  time.Time `gorm:"column:stat_time" json:"stat_time"`                                          // 数据产生时间
	UID                       string    `gorm:"column:uid" json:"uid"`                                                      // 对应docId
	CreateTime                time.Time `gorm:"column:create_time" json:"create_time"`                                      // 记录创建时间
	UpdateTime                time.Time `gorm:"column:update_time" json:"update_time"`                                      // 记录修改时间
}

func (*MaterialHourEntity) TableName() string {
	return MaterialHourEntityTable
}

func MaterialHourTableName() string {
	if repository.IsDebugTable(MaterialHourEntityTable) {
		return MaterialHourEntityTable + "_dev"
	} else {
		return MaterialHourEntityTable
	}
}

func ConvertHourToStruct(listMap []map[string]interface{}) (list []MaterialHourEntity) {
	for _, data := range listMap {
		var p MaterialHourEntity
		config := &mapstructure.DecoderConfig{
			TagName:          "json", // 使用标签匹配
			Result:           &p,     // 结果指针
			WeaklyTypedInput: true,   // 允许弱类型转换
		}
		decoder, _ := mapstructure.NewDecoder(config)
		decoder.Decode(data)
		list = append(list, p)
	}
	return
}
