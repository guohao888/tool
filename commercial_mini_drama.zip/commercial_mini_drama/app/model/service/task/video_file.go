package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	mediaRepo "goserver/app/model/service/mediareport"
)

/***********************         新授权逻辑 令牌桶方式获取素材视频  start       ***********************/

// SyncVideoFile 拉取头条视频信息
func SyncVideoFile(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("同步报表数据时间错误, err: %s", err)
	}

	videoFileService := mediaRepo.NewVideoFileService(ctx)
	for _, crontabDate := range crontabDateList {
		err = videoFileService.DistributeVideoAccounts(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("拉取视频数据失败, err: %s", err)
		}
	}
	return "拉取视频数据成功"
}

/***********************         新授权逻辑 令牌桶方式获取素材视频  start       ***********************/
