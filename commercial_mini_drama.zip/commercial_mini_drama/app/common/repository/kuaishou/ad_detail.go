package kuaishou

import (
	"goserver/app/common/repository"
	"time"
)

const AdDetailTable = "kuaishou_ad_detail"

type AdDetailEntity struct {
	AdvertiserId                                  int64     `gorm:"column:advertiser_id"`                                         // 用户快手号id
	Date                                          time.Time `gorm:"column:date"`                                                  // 日期（yyyy-MM-dd hh:mm:ss）
	IsToday                                       int       `gorm:"column:is_today"`                                              // 数据类型  1 当天 2 历史
	SeriesType                                    int       `gorm:"column:series_type"`                                           // 短剧类型，1-IAA短剧，2-IAP短剧
	Likes                                         int64     `gorm:"column:likes"`                                                 // 点赞数
	Share                                         int64     `gorm:"column:share"`                                                 // 分享数
	PhotoClick                                    int64     `gorm:"column:photo_click"`                                           // 封面点击数
	Impression                                    int64     `gorm:"column:impression"`                                            // 封面曝光数
	EventPay                                      int64     `gorm:"column:event_pay"`                                             // 付费次数
	T0DirectPaidCnt                               float64   `gorm:"column:t0_direct_paid_cnt"`                                    // 付费次数(计费时间)
	EventPayPurchaseAmount                        float64   `gorm:"column:event_pay_purchase_amount"`                             // 付费金额
	T0DirectPaidAmt                               float64   `gorm:"column:t0_direct_paid_amt"`                                    // 付费金额(计费时间)
	AdShow                                        int64     `gorm:"column:ad_show"`                                               // 广告曝光
	TotalCharge                                   float64   `gorm:"column:total_charge"`                                          // 消耗
	EventAppInvoked                               int64     `gorm:"column:event_app_invoked"`                                     // 唤起应用数
	EventPayPurchaseAmountFirstDay                float64   `gorm:"column:event_pay_purchase_amount_first_day"`                   // 激活当日付费金额
	EventPayPurchaseAmountOneDayByConversion      float64   `gorm:"column:event_pay_purchase_amount_one_day_by_conversion"`       // 激活后24h付费金额(激活时间)
	EventPayPurchaseAmountWeekByConversion        float64   `gorm:"column:event_pay_purchase_amount_week_by_conversion"`          // 激活后七日付费金额
	EventPayPurchaseAmountThreeDayByConversion    float64   `gorm:"column:event_pay_purchase_amount_three_day_by_conversion"`     // 激活后三日付费金额
	Conversion                                    int64     `gorm:"column:conversion"`                                            // 激活数
	T0DirectConversionCnt                         int64     `gorm:"column:t0_direct_conversion_cnt"`                              // 激活数(计费时间)
	Negative                                      int64     `gorm:"column:negative"`                                              // 减少此类作品数
	Report                                        int64     `gorm:"column:report"`                                                // 举报数
	Block                                         int64     `gorm:"column:block"`                                                 // 拉黑数
	Comment                                       int64     `gorm:"column:comment"`                                               // 评论数
	EventPayFirstDay                              int64     `gorm:"column:event_pay_first_day"`                                   // 首日付费次数
	PlayedNum                                     int64     `gorm:"column:played_num"`                                            // 素材曝光数
	PlayedThreeSeconds                            int64     `gorm:"column:played_three_seconds"`                                  // 3s播放数
	AdPhotoPlayed75percent                        int64     `gorm:"column:ad_photo_played75percent"`                              // 75%播放进度数
	PlayedEnd                                     int64     `gorm:"column:played_end"`                                            // 完播数
	Follow                                        int64     `gorm:"column:follow"`                                                // 新增粉丝数
	EventNewUserPay                               int64     `gorm:"column:event_new_user_pay"`                                    // 新增付费人数
	AdItemClick                                   int64     `gorm:"column:ad_item_click"`                                         // 行为数
	T7PaidCnt                                     int64     `gorm:"column:t7_paid_cnt"`                                           // 7日累计付费次数
	T7PaidAmt                                     float64   `gorm:"column:t7_paid_amt"`                                           // 7日累计付费金额
	ConversionNumByImpression7d                   int64     `gorm:"column:conversion_num_by_impression7d"`                        // 转化数(计费时间)
	DeepConversionNumByImpression7d               int64     `gorm:"column:deep_conversion_num_by_impression7d"`                   // 深度转化数(计费时间)
	ConversionNum                                 int64     `gorm:"column:conversion_num"`                                        // 转化数(回传时间)
	DeepConversionNum                             int64     `gorm:"column:deep_conversion_num"`                                   // 深度转化数
	T0PaidCnt                                     int64     `gorm:"column:t0_paid_cnt"`                                           // 当日累计付费次数
	T0PaidAmt                                     float64   `gorm:"column:t0_paid_amt"`                                           // 当日累计付费金额
	Play3sRatio                                   float64   `gorm:"column:play3s_ratio"`                                          // 3s播放率
	AdPhotoPlayed75PercentRatio                   float64   `gorm:"column:ad_photo_played_75percent_ratio"`                       // 75%进度播放率
	T7PaidRoi                                     float64   `gorm:"column:t7_paid_roi"`                                           // 7日累计ROI
	T0PaidRoi                                     float64   `gorm:"column:t0_paid_roi"`                                           // 当日累计ROI
	PhotoClickRatio                               float64   `gorm:"column:photo_click_ratio"`                                     // 封面点击率
	EventPayCost                                  float64   `gorm:"column:event_pay_cost"`                                        // 付费次数成本
	EventPayRoi                                   float64   `gorm:"column:event_pay_roi"`                                         // 付费ROI
	EventAppInvokedCost                           float64   `gorm:"column:event_app_invoked_cost"`                                // 唤起应用成本
	EventAppInvokedRatio                          float64   `gorm:"column:event_app_invoked_ratio"`                               // 唤起应用率
	ConversionCost                                float64   `gorm:"column:conversion_cost"`                                       // 激活单价
	EventPayFirstDayRoi                           float64   `gorm:"column:event_pay_first_day_roi"`                               // 激活当日ROI
	EventPayPurchaseAmountOneDayByConversionRoi   float64   `gorm:"column:event_pay_purchase_amount_one_day_by_conversion_roi"`   // 激活后24h-ROI(激活时间)
	EventPayPurchaseAmountThreeDayByConversionRoi float64   `gorm:"column:event_pay_purchase_amount_three_day_by_conversion_roi"` // 激活后3日ROI
	EventPayPurchaseAmountWeekByConversionRoi     float64   `gorm:"column:event_pay_purchase_amount_week_by_conversion_roi"`      // 激活后7日ROI
	PhotoClickCost                                float64   `gorm:"column:photo_click_cost"`                                      // 平均封面点击单价（元）
	Impression1kCost                              float64   `gorm:"column:impression1k_cost"`                                     // 平均千次封面曝光花费（元）
	Click1kCost                                   float64   `gorm:"column:click1k_cost"`                                          // 平均千次素材曝光花费（元）
	ActionCost                                    float64   `gorm:"column:action_cost"`                                           // 平均行为单价（元）
	DeepConversionCostByImpression7d              float64   `gorm:"column:deep_conversion_cost_by_impression7d"`                  // 深度转化成本(计费时间)，单位元
	DeepConversionRatioByImpression7d             float64   `gorm:"column:deep_conversion_ratio_by_impression7d"`                 // 深度转化率(计费时间)
	EventPayFirstDayCost                          float64   `gorm:"column:event_pay_first_day_cost"`                              // 首日付费次数成本，单位元
	ActionRatio                                   float64   `gorm:"column:action_ratio"`                                          // 素材点击率
	PlayEndRatio                                  float64   `gorm:"column:play_end_ratio"`                                        // 完播率
	EventNewUserPayCost                           float64   `gorm:"column:event_new_user_pay_cost"`                               // 新增付费人数成本，单位元
	EventNewUserPayRatio                          float64   `gorm:"column:event_new_user_pay_ratio"`                              // 新增付费人数率
	ActionNewRatio                                float64   `gorm:"column:action_new_ratio"`                                      // 行为率
	ConversionCostByImpression7d                  float64   `gorm:"column:conversion_cost_by_impression7d"`                       // 转化成本(计费时间)，单位元
	ConversionRatioByImpression7d                 float64   `gorm:"column:conversion_ratio_by_impression7d"`                      // 转化率(计费时间)
	KeyAction                                     int64     `gorm:"column:key_action"`                                            // 关键行为数
	AdPhotoPlayed75percentRatio                   float64   `gorm:"column:ad_photo_played75percent_ratio"`                        // 75%进度播放数
	MiniGameIaaRoi                                float64   `gorm:"column:mini_game_iaa_roi"`                                     // IAA广告变现ROI
	MiniGameIaaPurchaseAmount                     float64   `gorm:"column:mini_game_iaa_purchase_amount"`                         // IAA广告变现LTV（元）
	AccountId                                     int64     `gorm:"column:account_id"`                                            // 账号ID
	SeriesId                                      int64     `gorm:"column:series_id"`                                             // 短剧ID
	RechargeRate                                  float64   `gorm:"column:recharge_rate"`                                         // 充值几率

	DateStr                         string  `gorm:"column:date_str"`                             // 日期
	Media                           string  `gorm:"column:media"`                                // 媒体  固定快手
	SeriesName                      string  `gorm:"column:series_name"`                          // 短剧ID
	AccountName                     string  `gorm:"column:account_name"`                         // 账户名
	ActualEventPayPurchaseAmount    float64 `gorm:"column:actual_event_pay_purchase_amount"`     // 实际付费金额
	ActualCharge                    float64 `gorm:"column:actual_charge"`                        // 实际消耗
	ActualT0PaidMmt                 float64 `gorm:"column:actual_t0_paid_amt"`                   // 当日累计实际付费金额
	ActualT0PaidRoi                 float64 `gorm:"column:actual_t0_paid_roi"`                   // 当日累计实际RO
	ActualMiniGameIaaPurchaseAmount float64 `gorm:"column:actual_mini_game_iaa_purchase_amount"` // 实际IAA广告变现LTV（元）
}

func (*AdDetailEntity) TableName() string {
	return AdDetailTable
}

func AdDetailTableName() string {
	if repository.IsDebugTable(AdDetailTable) {
		return AdDetailTable // + "_dev"
	} else {
		return AdDetailTable
	}
}
