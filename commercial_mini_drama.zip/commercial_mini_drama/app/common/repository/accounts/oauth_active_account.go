package accounts

import (
	"goserver/app/common/repository"
	"strconv"
	"time"
)

const OauthActiveAccountView = "oauth_active_account_view" // 活跃广告主视图 (主要信息是广告主 和 授权id的关系)

type OauthActiveAccountEntity struct {
	Media          string    `gorm:"column:media"`           // 媒体
	AdvertiserId   string    `gorm:"column:advertiser_id"`   // 广告主id
	AdvertiserName string    `gorm:"column:advertiser_name"` // 广告主名称
	OauthId        string    `gorm:"column:oauth_id"`        // 授权唯一标识
	Status         int       `gorm:"column:status"`          // 状态 0:启用 1:默认
	UpdatedAt      time.Time `gorm:"column:updated_at"`      // 更新时间
}

func (*OauthActiveAccountEntity) TableName() string {
	return OauthAccountTableName()
}

func (e *OauthActiveAccountEntity) GetAdvertiserId() (int64, error) {
	return strconv.ParseInt(e.AdvertiserId, 10, 64)
}

func OauthActiveAccountTableName() string {
	if repository.IsDebugTable(OauthActiveAccountView) {
		return OauthActiveAccountView + "_dev"
	} else {
		return OauthActiveAccountView
	}
}

type OauthActiveAccountEntityList []OauthActiveAccountEntity
