package myerror

type MyErr struct {
	Code    int
	Message string
}

func (err MyErr) Error() string {
	return err.Message
}

var (
	// Common errors
	OK                   = &MyErr{Code: 0, Message: "success"}
	BusinessFailure      = &MyErr{Code: 400, Message: "业务处理失败"}
	ForbiddenServerError = &MyErr{Code: 403, Message: "权限错误"}
	InternalServerError  = &MyErr{Code: 500, Message: "内部错误"}

	NoLogin = &MyErr{Code: 1004, Message: "用户未登录"}

	//安全类错误码
	SignError             = &MyErr{Code: 10000, Message: "签名校验失败"}
	ReplayError           = &MyErr{Code: 10001, Message: "签名已被使用"}
	PermissionError       = &MyErr{Code: 10002, Message: "权限校验失败"}
	PermissionDeniedError = &MyErr{Code: 10003, Message: "操作权限不足"}
	//参数类错误码
	ParamsError = &MyErr{Code: 20000, Message: "参数错误"}

	//公用的数据查询类错误
	DBQueryDataError = &MyErr{Code: 21000, Message: "获取数据失败"}
	DBExecError      = &MyErr{Code: 21001, Message: "数据操作失败"}
	CronExecError    = &MyErr{Code: 21002, Message: "定时任务执行失败"}

	ExportExcelError = &MyErr{Code: 40000, Message: "导出excel文件失败"}

	TimeOverdueError = &MyErr{Code: 50000, Message: "签名时间已经过期"}

	AccountInsertError            = &MyErr{Code: 30001, Message: "账户添加失败"}
	AccountDataListError          = &MyErr{Code: 30002, Message: "账户列表获取失败"}
	AddOptionsListError           = &MyErr{Code: 30003, Message: "筛选项拉取失败"}
	BatchActionError              = &MyErr{Code: 30004, Message: "批量账户操作失败"}
	AccountUpdateError            = &MyErr{Code: 30005, Message: "账户信息编辑失败"}
	AccountImportError            = &MyErr{Code: 30006, Message: "批量导入账户失败"}
	AccountSyncPromotionUrl       = &MyErr{Code: 30007, Message: "批量同步账户推广链接失败"}
	AccountOauthConfigInsertError = &MyErr{Code: 30008, Message: "Oauth AppID配置添加失败"}
	AccountOauthConfigUpdateError = &MyErr{Code: 30009, Message: "Oauth AppID配置更新失败"}

	OauthAccessTokenError = &MyErr{Code: 90000, Message: "oauth2.0授权回调失败"}

	KafkaExecError       = &MyErr{Code: 22000, Message: "数据存储Kafka失败"}
	SaveCoefficientError = &MyErr{Code: 23000, Message: "保存IAA系数失败"}
	CoefficientListError = &MyErr{Code: 24000, Message: "获取系数列表失败"}

	SaveWarningError = &MyErr{Code: 25000, Message: "保存告警信息失败"}
	FindWarningError = &MyErr{Code: 25100, Message: "获取告警列表失败"}

	SaveOrUpdateMonitorError = &MyErr{Code: 26000, Message: "保存/修改盯盘信息失败"}
	FindMonitorError         = &MyErr{Code: 26100, Message: "获取盯盘列表失败"}
	DeleteMonitorError       = &MyErr{Code: 26200, Message: "删除盯盘任务失败"}
	GetOptimizerAccountError = &MyErr{Code: 26300, Message: "获取投手推推信息失败"}

	AddOptimizerError             = &MyErr{Code: 26100, Message: "保存优化师信息失败"}
	OptimizerIdEmptyError         = &MyErr{Code: 26101, Message: "优化师ID不能为空"}
	OptimizerNameEmptyError       = &MyErr{Code: 26102, Message: "优化师名称不能为空"}
	OptimizerSignEmptyError       = &MyErr{Code: 26103, Message: "优化师更新标识不能为空"}
	OptimizerNameExistError       = &MyErr{Code: 26104, Message: "优化师名称已存在"}
	OptimizerIdNoExistError       = &MyErr{Code: 26105, Message: "优化师ID不存在"}
	OptimizerExistSetCityError    = &MyErr{Code: 26106, Message: "当前优化师已配置地区"}
	OptimizerNotExistSetCityError = &MyErr{Code: 26107, Message: "当前优化师未配置地区"}
	OptimizerPhoneMaxError        = &MyErr{Code: 26108, Message: "手机号最多支持20字符"}

	AddOptimizerCityError          = &MyErr{Code: 26200, Message: "保存优化师地区信息失败"}
	OptimizerCityNameEmptyError    = &MyErr{Code: 26201, Message: "优化师地区名称不能为空"}
	OptimizerCityNameMaxError      = &MyErr{Code: 26202, Message: "优化师地区名称不能超过10个字符"}
	OptimizerCityIdEmptyError      = &MyErr{Code: 26203, Message: "优化师地区主键不能为空"}
	OptimizerCitySignEmptyError    = &MyErr{Code: 26204, Message: "优化师地区更新标识不能为空"}
	OptimizerCityExistError        = &MyErr{Code: 26205, Message: "该地区已存在，请重新配置"}
	OptimizerCityPrimaryError      = &MyErr{Code: 26206, Message: "优化师地区主键异常"}
	OptimizerCityPrimaryExistError = &MyErr{Code: 26207, Message: "优化师地区ID不存在"}

	AddOptimizerCityRelationError         = &MyErr{Code: 26300, Message: "设置优化师地区失败"}
	OptimizerCityRelationSignEmptyError   = &MyErr{Code: 26301, Message: "设置优化师地区更新标识不能为空"}
	OptimizerCityRelationIdEmptyError     = &MyErr{Code: 26302, Message: "设置优化师地区主键不能为空"}
	OptimizerCityRelationStatusEmptyError = &MyErr{Code: 26303, Message: "设置优化师地区状态不能为空"}
	OptimizerCityRelationPrimaryError     = &MyErr{Code: 26304, Message: "优化师地区关联主键异常"}
	OptimizerCityRelationIdNoExistError   = &MyErr{Code: 26305, Message: "当前优化师地区关联ID不存在"}

	OptimizerCityRelationViewListError = &MyErr{Code: 26400, Message: "优化师地区列表查询失败"}

	MiniAppFilterOptionsError = &MyErr{Code: 27001, Message: "筛选项获取失败"}

	ReferralImportError          = &MyErr{Code: 37001, Message: "导入端元生推广链失败"}
	ReferralImportFileError      = &MyErr{Code: 37002, Message: "绑定参数失败"}
	ReferralImportOpenFileError  = &MyErr{Code: 37003, Message: "base64解码失败"}
	ReferralImportFileParseError = &MyErr{Code: 37004, Message: "文件解析失败"}
)
