package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	mediaRepo "goserver/app/model/service/mediareport"
)

/***********************         新授权逻辑 令牌桶方式获取素材  start       ***********************/

/*
	执行参数：
	{
		"is_history":0,
		"is_fast":2
	}
*/

// SyncMediaReportFast 拉取头条媒体素材数据 快队列
func SyncMediaReportFast(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("媒体素材参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("媒体素材数据时间错误, err: %s", err)
	}
	//
	reportMediaService := mediaRepo.NewReportMediaService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportMediaService.DistributeMediaAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("同步媒体素材快队列数据失败, err: %s", err)
		}
	}
	return "同步媒体素材快队列数据成功"
}

/*
	执行参数：
	{
		"is_history":0,
		"is_fast":1
	}
*/

// SyncMediaReportSlow 拉取头条媒体素材数据 慢队列
func SyncMediaReportSlow(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("媒体素材参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("同步媒体素材慢队列数据时间错误, err: %s", err)
	}
	//
	reportMediaService := mediaRepo.NewReportMediaService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportMediaService.DistributeMediaAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("同步媒体素材慢队列数据失败, err: %s", err)
		}
	}
	return "同步媒体素材慢队列数据成功"
}

/***********************         新授权逻辑 令牌桶方式获取素材  end       ***********************/

func SyncMediaReportSpi(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("媒体素材参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("媒体素材数据时间错误, err: %s", err)
	}
	//
	reportMediaService := mediaRepo.NewReportMediaService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportMediaService.DistributeMediaAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("同步媒体素材快队列数据失败, err: %s", err)
		}
	}
	return "同步媒体素材快队列数据成功"
}
