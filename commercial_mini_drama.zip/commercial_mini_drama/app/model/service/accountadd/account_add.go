package accountadd

import (
	"context"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	accountAddEntity "goserver/app/common/repository/accountadd"
	"goserver/app/library/playlet/toutiao"
	"goserver/app/library/utils"
	timeUtil "goserver/app/library/utils/time"
	"goserver/app/model/dao"
	"goserver/app/model/dao/accountadd"
	spi "goserver/app/model/dao/roi"
	"strconv"
	"time"
)

// AccountAddService 增加对 Adv 的订阅 service
type AccountAddService struct {
	Ctx context.Context
}

func NewAccountAddService(ctx context.Context) *AccountAddService {
	return &AccountAddService{Ctx: ctx}
}

const (
	appId     = 1828357902271577
	secret    = "705fd412de1cb3437e3e27348ea83b5d1f0587ed"
	taskId    = 1840395971901770
	taskIdDay = 1840396270725771
)

func (aa *AccountAddService) SubscribeAccountAdd(crontabTime time.Time, ctx context.Context) error {
	pointDate, _ := timeUtil.GetDayTime(crontabTime)
	// 查询订阅活跃账号
	spiDao := spi.NewSpiMaterialDao(aa.Ctx)
	activeList, err := spiDao.GetSubscribeAccount(pointDate.Format(time.DateOnly))
	if err != nil {
		return fmt.Errorf("获取素材spi订阅失败, err: %v", err)
	}
	if len(activeList) == 0 {
		return fmt.Errorf("推送列表为空")
	}
	pushMap := make(map[int64][]int64)
	tokenMap := make(map[int64]string)
	accountAddInfos := make([]*accountAddEntity.AddAccountEntity, 0, 400)
	for _, v := range activeList {
		pushMap[v.UserId] = append(pushMap[v.UserId], v.AdvertiserId)
		tokenMap[v.UserId] = v.AccessToken
	}

	appAccessToken, tokenErr := toutiao.GetAppAccessToken(ctx, appId, secret)
	if tokenErr != nil {
		return fmt.Errorf("获取appToken失败, err: %v", tokenErr)
	}
	accountAddDao := accountadd.NewAddAccountDao(ctx)

	for k, pushList := range pushMap {
		batchPage := dao.BatchPage(len(pushList), 400)
		for i := 0; i < batchPage; i++ {
			start := i * 400
			end := (i + 1) * 400
			if end > len(pushList) {
				end = len(pushList)
			}
			failList, pushErr := toutiao.SubscribeAccountAdd(ctx, appAccessToken, models.SubscribeAccountsAddV30Request{
				AdvertiserIds:   pushList[start:end],
				AppId:           appId,
				CoreUserId:      k,
				SubscribeTaskId: taskId,
			}, strconv.Itoa(appId), tokenMap[k])
			if pushErr != nil {
				return fmt.Errorf("推送素材订阅失败, err: %v", pushErr)
			}
			for _, v := range utils.ArrayUnique(append(pushList[start:end], failList...)) {
				info := &accountAddEntity.AddAccountEntity{
					AdvertiserId: strconv.Itoa(int(v)),
					CreatedTime:  time.Now().Format(time.DateOnly),
					Status:       1, // 推送成功
				}
				accountAddInfos = append(accountAddInfos, info)
			}
			insertErr := accountAddDao.InsertBatchSize(accountAddInfos, 400)
			if insertErr != nil {
				return fmt.Errorf("保存推送数据失败, err: %v", insertErr)
			}
		}
	}
	return nil
}

func (aa *AccountAddService) SubscribeAccountRemove(ctx context.Context) error {
	// 查询订阅活跃账号
	spiDao := spi.NewSpiMaterialDao(aa.Ctx)
	start := time.Now().Format(time.DateOnly)
	end := time.Now().Add(-604800 * time.Second).Format(time.DateOnly) // 7天前
	noActiveList, err := spiDao.GetSubscribeAccountRemove(start, end)
	if err != nil {
		return fmt.Errorf("获取素材spi订阅失败, err: %v", err)
	}
	if len(noActiveList) == 0 {
		return fmt.Errorf("推送列表为空")
	}
	pushMap := make(map[int64][]int64)
	tokenMap := make(map[int64]string)
	accountAddInfos := make([]*accountAddEntity.AddAccountEntity, 0, 400)
	for _, v := range noActiveList {
		pushMap[v.UserId] = append(pushMap[v.UserId], v.AdvertiserId)
		tokenMap[v.UserId] = v.AccessToken
	}
	accountAddDao := accountadd.NewAddAccountDao(ctx)
	appAccessToken, tokenErr := toutiao.GetAppAccessToken(ctx, appId, secret)
	if tokenErr != nil {
		return fmt.Errorf("获取appToken失败, err: %v", tokenErr)
	}
	for k, pushList := range pushMap {
		failList, pushErr := toutiao.SubscribeAccountRemove(ctx, appAccessToken, models.SubscribeAccountsRemoveV30Request{
			AdvertiserIds:   pushList,
			AppId:           appId,
			CoreUserId:      k,
			SubscribeTaskId: taskId,
		}, strconv.Itoa(appId), tokenMap[k])
		if pushErr != nil {
			return fmt.Errorf("推送素材取消订阅失败, err: %v", pushErr)
		}
		for _, v := range utils.ArrayUnique(append(pushList, failList...)) {
			info := &accountAddEntity.AddAccountEntity{
				AdvertiserId: strconv.Itoa(int(v)),
				CreatedTime:  time.Now().Format(time.DateOnly),
				Status:       2, // 取消推送
			}
			accountAddInfos = append(accountAddInfos, info)
		}
		insertErr := accountAddDao.InsertBatchSize(accountAddInfos, 400)
		if insertErr != nil {
			return fmt.Errorf("保存推送数据失败, err: %v", insertErr)
		}
	}
	return nil
}

func (aa *AccountAddService) SubscribeAccountAddDay(crontabTime time.Time, ctx context.Context) error {
	pointDate, _ := timeUtil.GetDayTime(crontabTime)
	// 查询订阅活跃账号
	spiDao := spi.NewSpiMaterialDao(aa.Ctx)
	activeList, err := spiDao.GetSubscribeAccountDay(pointDate.Format(time.DateOnly))
	if err != nil {
		return fmt.Errorf("获取天级素材spi订阅失败, err: %v", err)
	}
	if len(activeList) == 0 {
		return fmt.Errorf("推送列表为空")
	}
	pushMap := make(map[int64][]int64)
	tokenMap := make(map[int64]string)
	accountAddInfos := make([]*accountAddEntity.AddAccountDayEntity, 0, 400)
	for _, v := range activeList {
		pushMap[v.UserId] = append(pushMap[v.UserId], v.AdvertiserId)
		tokenMap[v.UserId] = v.AccessToken
	}

	appAccessToken, tokenErr := toutiao.GetAppAccessToken(ctx, appId, secret)
	if tokenErr != nil {
		return fmt.Errorf("获取appToken失败, err: %v", tokenErr)
	}
	accountAddDayDao := accountadd.NewAddAccountDayDao(ctx)
	for k, pushList := range pushMap {
		batchPage := dao.BatchPage(len(pushList), 400)
		for i := 0; i < batchPage; i++ {
			start := i * 400
			end := (i + 1) * 400
			if end > len(pushList) {
				end = len(pushList)
			}
			failList, pushErr := toutiao.SubscribeAccountAdd(ctx, appAccessToken, models.SubscribeAccountsAddV30Request{
				AdvertiserIds:   pushList[start:end],
				AppId:           appId,
				CoreUserId:      k,
				SubscribeTaskId: taskIdDay,
			}, strconv.Itoa(appId), tokenMap[k])
			if pushErr != nil {
				return fmt.Errorf("推送天级素材订阅失败, err: %v", pushErr)
			}
			for _, v := range utils.ArrayUnique(append(pushList[start:end], failList...)) {
				info := &accountAddEntity.AddAccountDayEntity{
					AdvertiserId: strconv.Itoa(int(v)),
					CreatedTime:  time.Now().Format(time.DateOnly),
					Status:       1, // 推送成功
				}
				accountAddInfos = append(accountAddInfos, info)
			}
			insertErr := accountAddDayDao.InsertBatchSize(accountAddInfos, 400)
			if insertErr != nil {
				return fmt.Errorf("保存天级推送数据失败, err: %v", insertErr)
			}
		}
	}
	return nil
}

func (aa *AccountAddService) SubscribeAccountRemoveDay(ctx context.Context) error {
	// 查询订阅活跃账号
	spiDao := spi.NewSpiMaterialDao(aa.Ctx)
	start := time.Now().Format(time.DateOnly)
	end := time.Now().Add(-604800 * time.Second).Format(time.DateOnly) // 7天前
	noActiveList, err := spiDao.GetSubscribeAccountRemoveDay(start, end)
	if err != nil {
		return fmt.Errorf("获取天级素材spi订阅失败, err: %v", err)
	}
	if len(noActiveList) == 0 {
		return fmt.Errorf("推送列表为空")
	}
	pushMap := make(map[int64][]int64)
	tokenMap := make(map[int64]string)
	accountAddInfos := make([]*accountAddEntity.AddAccountDayEntity, 0, 400)
	for _, v := range noActiveList {
		pushMap[v.UserId] = append(pushMap[v.UserId], v.AdvertiserId)
		tokenMap[v.UserId] = v.AccessToken
	}

	accountAddDayDao := accountadd.NewAddAccountDayDao(ctx)
	appAccessToken, tokenErr := toutiao.GetAppAccessToken(ctx, appId, secret)
	if tokenErr != nil {
		return fmt.Errorf("获取appToken失败, err: %v", tokenErr)
	}
	for k, pushList := range pushMap {
		failList, pushErr := toutiao.SubscribeAccountRemove(ctx, appAccessToken, models.SubscribeAccountsRemoveV30Request{
			AdvertiserIds:   pushList,
			AppId:           appId,
			CoreUserId:      k,
			SubscribeTaskId: taskId,
		}, strconv.Itoa(appId), tokenMap[k])
		if pushErr != nil {
			return fmt.Errorf("推送天级素材取消订阅失败, err: %v", pushErr)
		}
		for _, v := range utils.ArrayUnique(append(pushList, failList...)) {
			info := &accountAddEntity.AddAccountDayEntity{
				AdvertiserId: strconv.Itoa(int(v)),
				CreatedTime:  time.Now().Format(time.DateOnly),
				Status:       2, // 取消推送
			}
			accountAddInfos = append(accountAddInfos, info)
		}
		insertErr := accountAddDayDao.InsertBatchSize(accountAddInfos, 400)
		if insertErr != nil {
			return fmt.Errorf("保存天级推送数据失败, err: %v", insertErr)
		}
	}
	return nil
}
