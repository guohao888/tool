package kuaishou

import (
	"context"
	"fmt"
	"goserver/app/common"
	"goserver/app/common/dto/kuaishoudto"
	"goserver/app/common/repository/kuaishou"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strconv"
	"strings"
	"time"

	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
)

// CoreDataDao 核心数据
type CoreDataDao struct {
	Ctx context.Context
}

func NewCoreDataDao(ctx context.Context) *CoreDataDao {
	return &CoreDataDao{Ctx: ctx}
}

type sqlQuery struct {
	ItemSql    string
	CountSql   string
	SummarySql string
}

// GetNewlySpentSeries 获取昨日有消耗今日无消耗的剧目信息
func (c *CoreDataDao) GetNewlySpentSeries(todayDate, yesterdayDate, tomorrowDate string) (map[int64]string, error) {
	db := dorisdb.DorisClient()
	type item struct {
		SeriesId   int64  `gorm:"column:series_id"`
		SeriesName string `gorm:"column:series_name"`
	}
	sql := fmt.Sprintf(`SELECT 
    DISTINCT today.series_id,sinfo.series_name
FROM 
    kuaishou_core_data today
LEFT JOIN (
    SELECT DISTINCT 
        series_id
    FROM 
        kuaishou_core_data
    WHERE 
        date >= '%s'
        AND date < '%s'
        AND total_charge > 0
) yesterday_has_cost ON today.series_id = yesterday_has_cost.series_id
LEFT JOIN kuaishou_series_info sinfo ON today.advertiser_id=sinfo.advertiser_id AND today.series_id=sinfo.series_id
WHERE 
    today.date >= '%s'
    AND today.date < '%s'
    AND today.total_charge > 0
    AND yesterday_has_cost.series_id IS NULL`, yesterdayDate, todayDate, todayDate, tomorrowDate)
	var books []item
	err := db.Raw(sql).Scan(&books).Error
	if err != nil {
		return nil, err
	}
	res := make(map[int64]string, len(books))
	for _, v := range books {
		res[v.SeriesId] = v.SeriesName
	}
	return res, nil
}

func (c *CoreDataDao) GetNewlySpentBooksRoiInfo(date string, hour int64, seriesIds []string) ([]kuaishou.NewlySpentSeriesRoiInfo, error) {
	db := dorisdb.DorisClient()
	hourStr := fmt.Sprintf("%02d", hour)
	preHourStr := fmt.Sprintf("%02d", hour-1)
	seriesIdStr := strings.Join(seriesIds, ",")

	sql := fmt.Sprintf(`SELECT
	series_id,
	date as date_time,
	SUM(total_charge) AS total_charge,
	sum(pay_amt) AS pay_amt,
	sum(hb_total_charge) AS hb_total_charge,
	sum(hb_pay_amt) AS hb_pay_amt
FROM
	(
		SELECT
			series_id,
			DATE,
			SUM(total_charge) AS total_charge,
    		SUM(mini_game_iaa_purchase_amount) AS pay_amt,
			0.0 AS hb_total_charge,
			0.0 AS hb_pay_amt
		FROM
			kuaishou_core_data
		WHERE
			source = 0
			AND DATE >= '%s'
			AND DATE <= '%s %s:00:00'
			AND series_id in(%s)
		GROUP BY
			series_id,
			DATE
		UNION ALL
		SELECT
			series_id,
			DATE_FORMAT(DATE_ADD(DATE, INTERVAL 1 HOUR), '%%Y-%%m-%%d %%H:00:00') AS DATE,
			0.0 AS total_charge,
			0.0 AS pay_amt,
			SUM(total_charge) AS hb_total_charge,
    		SUM(mini_game_iaa_purchase_amount) AS hb_pay_amt
		FROM
			kuaishou_core_data
		WHERE
			source = 0
			AND DATE >= '%s'
			AND DATE <= '%s %s:00:00'
			AND series_id in(%s)
		GROUP BY
			series_id,
			DATE_FORMAT(DATE_ADD(DATE, INTERVAL 1 HOUR), '%%Y-%%m-%%d %%H:00:00')
	) combined_data
GROUP BY
    series_id,
    date
ORDER BY
	DATE DESC,
	total_charge DESC`, date, date, hourStr, seriesIdStr, date, date, preHourStr, seriesIdStr)

	var rois []kuaishou.NewlySpentSeriesRoiInfo
	err := db.Raw(sql).Scan(&rois).Error
	if err != nil {
		return nil, err
	}
	return rois, nil
}

// GetManagerRoiInfo 注意字段名与实际含义有差异
func (c *CoreDataDao) GetManagerRoiInfo(dateToday string, dateYesterday string, hour int64) ([]kuaishou.ManagerRoiInfo, error) {
	db := dorisdb.DorisClient()
	hourStr := fmt.Sprintf("%02d", hour)
	sql := fmt.Sprintf(`SELECT
    advertiser_id,
    date AS date_time,
    SUM(actual_charge) AS actual_charge,
    SUM(actual_pay_amt) AS actual_pay_amt,
    SUM(actual_event_pay_roi) AS actual_event_pay_roi,
    SUM(hb_actual_charge) AS hb_actual_charge,
    SUM(hb_actual_pay_amt) AS hb_actual_pay_amt,
    SUM(hb_actual_event_pay_roi) AS hb_actual_event_pay_roi
FROM
    (
        -- 当前日数据
        SELECT
            advertiser_id,
            date,
            SUM(total_charge) / 1000 / 1.072 AS actual_charge,
            SUM(mini_game_iaa_purchase_amount) * 0.9 * 0.99 AS actual_pay_amt,
            SUM(mini_game_iaa_purchase_amount) * 0.9 * 0.99 * 1000 / (SUM(total_charge) / 1.072) AS actual_event_pay_roi,
            0.0 AS hb_actual_charge,
            0.0 AS hb_actual_pay_amt,
            0.0 AS hb_actual_event_pay_roi
        FROM
            kuaishou_core_data
        WHERE
            date >= '%s 00:00:00'
            AND date <= '%s %s:00:00'
            AND source = 0
        GROUP BY
            advertiser_id,
            date
        
        UNION ALL
        
        -- 上日数据（作为环比数据）
        SELECT
            advertiser_id,
            DATE_FORMAT(DATE_ADD(date, INTERVAL 1 DAY), '%%Y-%%m-%%d %%H:00:00') AS date,
            0.0 AS actual_charge,
            0.0 AS actual_pay_amt,
            0.0 AS actual_event_pay_roi,
            SUM(total_charge) /1000 / 1.072 AS hb_actual_charge,
            SUM(mini_game_iaa_purchase_amount) * 0.9 * 0.99 AS hb_actual_pay_amt,
			SUM(mini_game_iaa_purchase_amount) * 0.9 * 0.99 * 1000 / (SUM(total_charge) / 1.072) AS hb_actual_event_pay_roi
        FROM
            kuaishou_core_data
        WHERE
            date >= '%s 00:00:00'
            AND date <= '%s %s:00:00'
            AND source = 0
        GROUP BY
            advertiser_id,
            DATE_FORMAT(DATE_ADD(date, INTERVAL 1 DAY), '%%Y-%%m-%%d %%H:00:00')
    ) t
GROUP BY
    advertiser_id,
    date
ORDER BY
    date DESC,
    advertiser_id DESC`, dateToday, dateToday, hourStr, dateYesterday, dateYesterday, hourStr)
	var rois []kuaishou.ManagerRoiInfo
	err := db.Raw(sql).Scan(&rois).Error
	if err != nil {
		return nil, err
	}
	return rois, nil
}

// GetLastCostIncomeInfo 统计消耗、IAA收入、IAA ROI
func (c *CoreDataDao) GetLastCostIncomeInfo(dateToday string, hour int64) ([]kuaishou.LastCostIncomeInfo, error) {
	db := dorisdb.DorisClient()
	hourStr := fmt.Sprintf("%02d", hour)
	sql := fmt.Sprintf(`SELECT
    '汇总' AS date,
    '' AS hour,
	SUM(total_charge) / 1000 / 1.072 AS actual_charge,
	SUM(mini_game_iaa_purchase_amount) * 0.9 * 0.99 AS actual_mini_game_iaa_purchase_amount,
	SUM(mini_game_iaa_purchase_amount) * 0.9 * 0.99 * 1000 / (SUM(total_charge) / 1.072) AS actual_mini_game_iaa_roi
FROM
	kuaishou_core_data
WHERE
	DATE >= '%s 00:00:00'
	AND DATE <= '%s %s:00:00'
	AND source = 0`, dateToday, dateToday, hourStr)

	sql2 := fmt.Sprintf(`SELECT
	DATE(date) AS date,
	DATE_FORMAT(date, '%%H') AS hour,
	SUM(total_charge) / 1000 / 1.072 AS actual_charge,
	SUM(mini_game_iaa_purchase_amount) * 0.9 * 0.99 AS actual_mini_game_iaa_purchase_amount,
	SUM(mini_game_iaa_purchase_amount) * 0.9 * 0.99 * 1000 / (SUM(total_charge) / 1.072) AS actual_mini_game_iaa_roi
FROM
	kuaishou_core_data
WHERE
	DATE >= '%s 00:00:00'
	AND DATE <= '%s %s:00:00'
	AND source = 0
GROUP BY
	DATE
ORDER BY
    CASE WHEN hour = '' THEN 0 ELSE 1 END,  -- 汇总行(HOUR为空)排在最前
	hour desc`, dateToday, dateToday, hourStr)
	sql = sql +
		" UNION ALL " +
		sql2
	var rois []kuaishou.LastCostIncomeInfo
	err := db.Raw(sql).Scan(&rois).Error
	if err != nil {
		return nil, err
	}
	return rois, nil
}

func (c *CoreDataDao) List(req *kuaishoudto.CoreDataListReq) ([]kuaishou.CoreDataEntity, int64, error) {
	db := dorisdb.DorisClient()
	querySql := c.getQuerySql(req)

	pagination := req.Pagination
	limit := pagination.GetLimit()
	offset := pagination.GetOffset()

	// 总量
	type Dist struct {
		Cnt int64 `gorm:"column:cnt"`
	}
	var dist Dist
	countSql := querySql.CountSql
	err := db.Raw(countSql).Scan(&dist).Error
	if err != nil {
		return nil, 0, err
	}

	// 分页明细
	var items []kuaishou.CoreDataEntity

	itemSql := querySql.ItemSql +
		" LIMIT " + strconv.FormatInt(limit, 10) + " OFFSET " + strconv.FormatInt(offset, 10)

	err = db.Raw(itemSql).Scan(&items).Error
	if err != nil {
		return nil, 0, err
	}

	// 汇总数据
	var summaryItem kuaishou.CoreDataEntity
	summarySql := querySql.SummarySql
	err = db.Raw(summarySql).Scan(&summaryItem).Error
	if err != nil {
		return nil, 0, err
	}

	// 拼接数据
	var list []kuaishou.CoreDataEntity
	list = append(list, summaryItem)
	list = append(list, items...)

	return list, dist.Cnt, nil
}

func (c *CoreDataDao) Export(req *kuaishoudto.CoreDataListReq) (result []kuaishou.CoreDataEntity, err error) {
	db := dorisdb.DorisClient()
	querySql := c.getQuerySql(req)

	// 明细
	var items []kuaishou.CoreDataEntity
	itemSql := querySql.ItemSql
	err = db.Raw(itemSql).Scan(&items).Error
	if err != nil {
		return nil, err
	}

	// 汇总数据
	var summaryItem kuaishou.CoreDataEntity
	summarySql := querySql.SummarySql
	err = db.Raw(summarySql).Scan(&summaryItem).Error
	if err != nil {
		return nil, err
	}

	// 拼接数据
	var list []kuaishou.CoreDataEntity
	list = append(list, summaryItem)
	list = append(list, items...)

	return list, nil
}

func (c *CoreDataDao) getQuerySql(req *kuaishoudto.CoreDataListReq) *sqlQuery {
	tableName := kuaishou.CoreDataTableName() + " as c"
	seriesTableName := kuaishou.SeriesInfoTableName() + " as s"
	var columns, groups, kpis, where, sorts []string
	var filterStr string

	// 查询字段 + 分组条件
	if req.GroupType == "w" {
		columns = append(columns, "DATE_FORMAT(c.date, '%xW%v') AS date_str")
		groups = append(groups, "DATE_FORMAT(c.date, '%xW%v')")
	} else if req.GroupType == "m" {
		columns = append(columns, "DATE_FORMAT(c.date, '%Y-%m') AS date_str")
		groups = append(groups, "DATE_FORMAT(c.date, '%Y-%m')")
	} else {
		columns = append(columns, "DATE_FORMAT(c.date, '%Y-%m-%d') AS date_str")
		groups = append(groups, "DATE_FORMAT(c.date, '%Y-%m-%d')")
	}

	for k, _ := range kuaishoudto.CoreDataGroupByMapping {
		if k == "series_name" {
			continue
		}
		columns = append(columns, "c."+k+" AS "+k)
		groups = append(groups, "c."+k)
	}
	columns = append(columns, "s.series_name as series_name")
	groups = append(groups, "s.series_name")
	columns = append(columns, "c.series_id as series_id")
	groups = append(groups, "c.series_id")

	summaryColumns := []string{
		"STR_TO_DATE('1970-01-01', '%Y-%m-%d') as date",
		"0 as series_id",
		"'' as series_name",
	}

	where = append(where, "1=1")

	// 获取当前日期
	today := time.Now().Format("2006-01-02")
	if req.StartDate >= today {
		where = append(where, "c.date>='"+req.StartDate+"' AND c.date<'"+req.EndDate+"'")
		where = append(where, "c.source=0")
	} else if req.EndDate <= today {
		where = append(where, "c.date>='"+req.StartDate+"' AND c.date<'"+req.EndDate+"'")
		where = append(where, "c.source=1")
	} else {
		querySql := "SELECT * FROM " + kuaishou.CoreDataTableName() + " WHERE source=1 AND date>='" + req.StartDate + "' AND date<'" + today + "'" +
			" UNION ALL " +
			"SELECT * FROM " + kuaishou.CoreDataTableName() + " WHERE source=0 AND date>='" + today + "' AND date<'" + req.EndDate + "'"
		tableName = "(" + querySql + ") as c"
	}

	// 过滤条件
	if req.SeriesType > 0 {
		filterStr = "c.series_type=" + strconv.Itoa(int(req.SeriesType))
		where = append(where, filterStr)
	}

	if req.ResourceType > 0 {
		filterStr = "c.resource_type=" + strconv.Itoa(int(req.ResourceType))
		where = append(where, filterStr)
	}

	if req.SeriesID != "" {
		filterStr = "c.series_id=" + req.SeriesID
		where = append(where, filterStr)
	}

	if req.SeriesName != "" {
		filterStr = "s.series_name='" + req.SeriesName + "'"
		where = append(where, filterStr)
	}

	// 排序 (sort)
	if len(req.Sorts) == 0 {
		req.Sorts = append(req.Sorts,
			common.Sort{Key: "date_str", Order: "asc"},
			common.Sort{Key: "total_charge", Order: "desc"},
		)
	}
	for _, sort := range req.Sorts {
		if sort.Key == "date" {
			sort.Key = "date_str"
		}
		sorts = append(sorts, fmt.Sprintf("%s %s", sort.Key, sort.Order))
	}

	sumKpis := []string{
		"total_charge",                          // 媒体消耗
		"pay_amt",                               // 付费金额 IAP
		"fans_user_num",                         // 粉丝净增量
		"pay_user_count",                        // 付费人数
		"pay_count",                             // 付费订单数
		"display_play_cnt",                      // 播放数
		"display_like_cnt",                      // 点赞数
		"display_comment_cnt",                   // 评论数
		"display_collect_cnt",                   // 收藏数
		"mini_game_iaa_purchase_amount",         // IAA广告变现LTV（含返货，元）
		"mini_game_iaa_purchase_amount_divided", // IAA广告变现LTV（不含返货，元）
	}

	for _, kpi := range sumKpis {
		kpis = append(kpis, "SUM(c."+kpi+") AS "+kpi)
	}

	complexKpis := []string{
		"SUM(c.total_charge)/1.072 as actual_charge",                                                                                       // 实际消耗
		"SUM(c.pay_amt)*0.9*0.99 as actual_pay_amt",                                                                                        // 实际付费金额 IAP
		"SUM(CASE WHEN c.resource_type=2 THEN (c.pay_amt) ELSE 0 END)*1000/SUM(c.total_charge) as event_pay_roi",                           // 商业化ROI
		"(SUM(CASE WHEN c.resource_type=2 THEN (c.pay_amt) ELSE 0 END)*0.9*0.99)*1000/(SUM(c.total_charge)/1.072) as actual_event_pay_roi", // 商业化实际ROI
		"SUM(c.pay_amt)*1000/SUM(c.total_charge) as event_pay_roi_all",                                                                     // 全域ROI 待处理
		"SUM(c.mini_game_iaa_purchase_amount)*1000/SUM(c.total_charge) as mini_game_iaa_roi",                                               // IAA广告变现ROI（含返货）
		"SUM(c.mini_game_iaa_purchase_amount_divided)*1000/SUM(c.total_charge) as mini_game_iaa_divided_roi",                               // IAA广告变现ROI（不含返货）
		"SUM(c.mini_game_iaa_purchase_amount)*0.9*0.99 as actual_mini_game_iaa_purchase_amount",                                            // 实际IAA广告变现LTV（含返货）
		"SUM(c.mini_game_iaa_purchase_amount)*0.9*0.99*1000/(SUM(c.total_charge)/1.072) as actual_mini_game_iaa_roi",                       // 实际IAA广告变现ROI（含返货）
	}

	countBaseSql := "SELECT " + strings.Join(columns, ",") +
		" FROM " + tableName +
		" LEFT JOIN " + seriesTableName +
		" ON c.series_id=s.series_id AND c.advertiser_id=s.advertiser_id" +
		" WHERE " + strings.Join(where, " AND ") +
		" GROUP BY " + strings.Join(groups, ",")

	itemBaseSql := "SELECT " + strings.Join(columns, ",") + "," + strings.Join(kpis, ",") + "," + strings.Join(complexKpis, ",") +
		" FROM " + tableName +
		" LEFT JOIN " + seriesTableName +
		" ON c.series_id=s.series_id AND c.advertiser_id=s.advertiser_id" +
		" WHERE " + strings.Join(where, " AND ") +
		" GROUP BY " + strings.Join(groups, ",")

	summaryBaseSql := "SELECT c.*" +
		" FROM " + tableName +
		" LEFT JOIN " + seriesTableName +
		" ON c.series_id=s.series_id AND c.advertiser_id=s.advertiser_id" +
		" WHERE " + strings.Join(where, " AND ")

	// 总量
	countSql := "SELECT COUNT(*) as cnt" + " FROM (" + countBaseSql + ") t"

	// 分页明细
	itemSql := itemBaseSql + " ORDER BY " + strings.Join(sorts, ",")

	// 汇总数据
	summarySql := "SELECT " + strings.Join(summaryColumns, ",") + "," + strings.Join(kpis, ",") + "," + strings.Join(complexKpis, ",") +
		" FROM (" + summaryBaseSql + ") c"

	return &sqlQuery{
		CountSql:   countSql,
		ItemSql:    itemSql,
		SummarySql: summarySql,
	}
}

// InsertBatchSize 插入更新数据
func (c *CoreDataDao) InsertBatchSize(data []*kuaishou.CoreDataEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = c.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (c *CoreDataDao) buildInsertSentence(tx *gorm.DB, data []*kuaishou.CoreDataEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + kuaishou.CoreDataTableName() + " ( advertiser_id, date, resource_type, source, series_id, series_type, total_charge, accu_fans_user_num, fans_user_num, event_pay_roi, event_pay_roi_all, pay_user_count, pay_count, pay_amt, is_fans_user, display_play_cnt, display_like_cnt, display_comment_cnt, display_collect_cnt, mini_game_iaa_roi, mini_game_iaa_purchase_amount, mini_game_iaa_purchase_amount_divided, mini_game_iaa_divided_roi ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.Date,
			v.ResourceType,
			v.Source,
			v.SeriesId,
			v.SeriesType,
			v.TotalCharge,
			v.AccuFansUserNum,
			v.FansUserNum,
			v.EventPayRoi,
			v.EventPayRoiAll,
			v.PayUserCount,
			v.PayCount,
			v.PayAmt,
			v.IsFansUser,
			v.DisplayPlayCnt,
			v.DisplayLikeCnt,
			v.DisplayCommentCnt,
			v.DisplayCollectCnt,
			v.MiniGameIaaRoi,
			v.MiniGameIaaPurchaseAmount,
			v.MiniGameIaaPurchaseAmountDivide,
			v.MiniGameIaaDividedRoi,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
