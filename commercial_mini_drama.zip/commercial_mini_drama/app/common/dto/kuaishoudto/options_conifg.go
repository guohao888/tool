package kuaishoudto

type IDLabel struct {
	ID        string `json:"id"`
	Label     string `json:"label"`
	IsDefault bool   `json:"isdefault"`
}

type IDLabel2 struct {
	ID        int64  `json:"id"`
	Label     string `json:"label"`
	IsDefault bool   `json:"isdefault"`
}

type SelectOption struct {
	Name  string    `json:"name"`
	Value []IDLabel `json:"value"`
}

type SelectOption2 struct {
	Name  string     `json:"name"`
	Value []IDLabel2 `json:"value"`
}

type KpiOption struct {
	ID        int    `json:"id"`
	Label     string `json:"label"`
	Prop      string `json:"prop"`
	Format    string `json:"format"`
	SortAble  bool   `json:"sortable"`
	IsDefault bool   `json:"isdefault"`
}

//---------------

var GroupTypeArr = []IDLabel{
	{ID: "d", Label: "日", IsDefault: true},
	{ID: "w", Label: "周"},
	{ID: "m", Label: "月"},
}

var GroupTypeMapping = map[string]string{
	"d": "日",
	"w": "周",
	"m": "月",
	"h": "小时",
}

var SeriesTypeArr = []IDLabel2{
	{ID: 1, Label: "IAA"},
	{ID: 2, Label: "IAP"},
}

var SeriesTypeMapping = map[int64]string{
	1: "IAA",
	2: "IAP",
}

var ResourceTypeArr = []IDLabel2{
	{ID: 1, Label: "自然流量"},
	{ID: 2, Label: "商业流量"},
}

var ResourceTypeMapping = map[int64]string{
	1: "自然流量",
	2: "商业流量",
}

//-----------------

var CoreDataGroupByArr = []IDLabel{
	{ID: "series_name", Label: "剧目名称", IsDefault: false},
}

var CoreDataGroupByMapping = map[string]string{
	"series_name": "剧目名称",
}

var AdDataGroupByArr = []IDLabel{
	{ID: "media", Label: "投放载体", IsDefault: true},
	{ID: "account_name", Label: "账户名称", IsDefault: true},
	{ID: "series_name", Label: "剧目名称", IsDefault: false},
}

var AdDataGroupByMapping = map[string]string{
	"media":        "投放载体",
	"account_name": "账户名称",
	"series_name":  "剧目名称",
}

//-----------------

var CoreDataExcelNumColumn = []string{
	"fans_user_num",
	"pay_user_count",
	"pay_count",
	"display_play_cnt",
	"display_like_cnt",
	"display_comment_cnt",
	"display_collect_cnt",
}

var CoreDataExcelStringColumn = []string{
	"media",
	"series_id",
	"series_type",
	"resource_type",
	"series_name",
}

var CoreDataFilterArr = []KpiOption{
	{Label: "媒体消耗", Prop: "total_charge", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "实际消耗", Prop: "actual_charge", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "粉丝净增量", Prop: "fans_user_num", Format: "num", SortAble: false},
	{Label: "商业化ROI", Prop: "event_pay_roi", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "商业化实际ROI", Prop: "actual_event_pay_roi", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "全域ROI", Prop: "event_pay_roi_all", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "付费人数", Prop: "pay_user_count", Format: "num", SortAble: true, IsDefault: true},
	{Label: "付费订单数", Prop: "pay_count", Format: "num", SortAble: true, IsDefault: true},
	{Label: "付费金额", Prop: "pay_amt", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "实际付费金额", Prop: "actual_pay_amt", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "播放数", Prop: "display_play_cnt", Format: "num", SortAble: false},
	{Label: "点赞数", Prop: "display_like_cnt", Format: "num", SortAble: false},
	{Label: "评论数", Prop: "display_comment_cnt", Format: "num", SortAble: false},
	{Label: "收藏数", Prop: "display_collect_cnt", Format: "num", SortAble: false},
	{Label: "IAA广告变现ROI（含返货）", Prop: "mini_game_iaa_roi", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "实际IAA广告变现ROI（含返货）", Prop: "actual_mini_game_iaa_roi", Format: "rate", SortAble: false},
	{Label: "IAA广告变现LTV（含返货，元）", Prop: "mini_game_iaa_purchase_amount", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "实际IAA广告变现LTV（含返货）", Prop: "actual_mini_game_iaa_purchase_amount", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "IAA广告变现LTV（不含返货，元）", Prop: "mini_game_iaa_purchase_amount_divided", Format: "cost", SortAble: false},
	{Label: "IAA广告变现ROI（不含返货）", Prop: "mini_game_iaa_divided_roi", Format: "rate", SortAble: false},
}

var CoreDataSortKpiMapping = map[string]string{
	"date":                                 "日期",
	"total_charge":                         "媒体消耗",
	"actual_charge":                        "实际消耗",
	"event_pay_roi":                        "商业化ROI",
	"actual_event_pay_roi":                 "商业化实际ROI",
	"event_pay_roi_all":                    "全域ROI",
	"pay_user_count":                       "付费人数",
	"pay_count":                            "付费订单数",
	"pay_amt":                              "付费金额",
	"actual_pay_amt":                       "实际付费金额",
	"mini_game_iaa_roi":                    "IAA广告变现ROI（含返货）",
	"actual_mini_game_iaa_roi":             "实际IAA广告变现ROI（含返货）",
	"mini_game_iaa_purchase_amount":        "IAA广告变现LTV（含返货，元）",
	"actual_mini_game_iaa_purchase_amount": "实际IAA广告变现LTV（含返货）",
}

var CoreDataKpiMapping = map[string]string{
	"total_charge":                          "媒体消耗",
	"actual_charge":                         "实际消耗",
	"fans_user_num":                         "粉丝净增量",
	"event_pay_roi":                         "商业化ROI",
	"actual_event_pay_roi":                  "商业化实际ROI",
	"event_pay_roi_all":                     "全域ROI",
	"pay_user_count":                        "付费人数",
	"pay_count":                             "付费订单数",
	"pay_amt":                               "付费金额",
	"actual_pay_amt":                        "实际付费金额",
	"display_play_cnt":                      "播放数",
	"display_like_cnt":                      "点赞数",
	"display_comment_cnt":                   "评论数",
	"display_collect_cnt":                   "收藏数",
	"mini_game_iaa_roi":                     "IAA广告变现ROI（含返货）",
	"actual_mini_game_iaa_roi":              "实际IAA广告变现ROI（含返货）",
	"mini_game_iaa_purchase_amount":         "IAA广告变现LTV（含返货，元）",
	"actual_mini_game_iaa_purchase_amount":  "实际IAA广告变现LTV（含返货）",
	"mini_game_iaa_purchase_amount_divided": "IAA广告变现LTV（不含返货，元）",
	"mini_game_iaa_divided_roi":             "IAA广告变现ROI（不含返货）",
}

var AdDataExcelNumColumn = []string{
	"likes",
	"share",
	"photo_click",
	"impression",
	"event_pay",
	"t0_direct_paid_cnt",
	"ad_show",
	"event_app_invoked",
	"conversion",
	"t0_direct_conversion_cnt",
	"negative",
	"report",
	"block",
	"comment",
	"event_pay_first_day",
	"played_num",
	"played_three_seconds",
	"ad_photo_played75percent",
	"played_end",
	"follow",
	"event_new_user_pay",
	"ad_item_click",
	"t7_paid_cnt",
	"conversion_num_by_impression7d",
	"deep_conversion_num_by_impression7d",
	"conversion_num",
	"deep_conversion_num",
	"t0_paid_cnt",
	"key_action",
	"ad_photo_played75percent_ratio",
}

var AdDataExcelStringColumn = []string{
	"media",
	"series_id",
	"account_id",
	"series_name",
	"account_name",
	"series_type",
	"optimizer_name",
}

var AdDataFilterArr = []KpiOption{
	{Label: "点赞数", Prop: "likes", Format: "num", SortAble: false, IsDefault: false},
	{Label: "分享数", Prop: "share", Format: "num", SortAble: false, IsDefault: false},
	{Label: "封面点击数", Prop: "photo_click", Format: "num", SortAble: false, IsDefault: false},
	{Label: "封面曝光数", Prop: "impression", Format: "num", SortAble: false, IsDefault: false},
	{Label: "付费次数", Prop: "event_pay", Format: "num", SortAble: true, IsDefault: false},
	{Label: "付费次数(计费时间)", Prop: "t0_direct_paid_cnt", Format: "num", SortAble: true, IsDefault: false},
	{Label: "付费金额", Prop: "event_pay_purchase_amount", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "实际付费金额", Prop: "actual_event_pay_purchase_amount", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "付费金额(计费时间)", Prop: "t0_direct_paid_amt", Format: "cost", SortAble: true, IsDefault: false},
	{Label: "广告曝光", Prop: "ad_show", Format: "num", SortAble: true, IsDefault: false},
	{Label: "媒体消耗", Prop: "total_charge", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "实际消耗", Prop: "actual_charge", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "唤起应用数", Prop: "event_app_invoked", Format: "num", SortAble: false, IsDefault: false},
	{Label: "激活当日付费金额", Prop: "event_pay_purchase_amount_first_day", Format: "cost", SortAble: true, IsDefault: false},
	{Label: "激活后24h付费金额(激活时间)", Prop: "event_pay_purchase_amount_one_day_by_conversion", Format: "cost", SortAble: true, IsDefault: false},
	{Label: "激活后七日付费金额", Prop: "event_pay_purchase_amount_week_by_conversion", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "激活后三日付费金额", Prop: "event_pay_purchase_amount_three_day_by_conversion", Format: "cost", SortAble: true, IsDefault: false},
	{Label: "激活数", Prop: "conversion", Format: "num", SortAble: true, IsDefault: false},
	{Label: "激活数(计费时间)", Prop: "t0_direct_conversion_cnt", Format: "num", SortAble: true, IsDefault: false},
	{Label: "减少此类作品数", Prop: "negative", Format: "num", SortAble: false, IsDefault: false},
	{Label: "举报数", Prop: "report", Format: "num", SortAble: false, IsDefault: false},
	{Label: "拉黑数", Prop: "block", Format: "num", SortAble: false, IsDefault: false},
	{Label: "评论数", Prop: "comment", Format: "num", SortAble: false, IsDefault: false},
	{Label: "首日付费次数", Prop: "event_pay_first_day", Format: "num", SortAble: false, IsDefault: false},
	{Label: "素材曝光数", Prop: "played_num", Format: "num", SortAble: false, IsDefault: false},
	{Label: "3s播放数", Prop: "played_three_seconds", Format: "num", SortAble: true, IsDefault: false},
	{Label: "75%播放进度数", Prop: "ad_photo_played75percent", Format: "num", SortAble: false, IsDefault: false},
	{Label: "完播数", Prop: "played_end", Format: "num", SortAble: false, IsDefault: false},
	{Label: "新增粉丝数", Prop: "follow", Format: "num", SortAble: false, IsDefault: false},
	{Label: "新增付费人数", Prop: "event_new_user_pay", Format: "num", SortAble: false, IsDefault: false},
	{Label: "行为数", Prop: "ad_item_click", Format: "num", SortAble: false, IsDefault: false},
	{Label: "7日累计付费次数", Prop: "t7_paid_cnt", Format: "num", SortAble: false, IsDefault: false},
	{Label: "7日累计付费金额", Prop: "t7_paid_amt", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "转化数(计费时间)", Prop: "conversion_num_by_impression7d", Format: "num", SortAble: true, IsDefault: false},
	{Label: "深度转化数(计费时间)", Prop: "deep_conversion_num_by_impression7d", Format: "num", SortAble: false, IsDefault: false},
	{Label: "转化数(回传时间)", Prop: "conversion_num", Format: "num", SortAble: true, IsDefault: false},
	{Label: "深度转化数", Prop: "deep_conversion_num", Format: "num", SortAble: false, IsDefault: false},
	{Label: "当日累计付费次数", Prop: "t0_paid_cnt", Format: "num", SortAble: true, IsDefault: false},
	{Label: "当日累计付费金额", Prop: "t0_paid_amt", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "当日累计实际付费金额", Prop: "actual_t0_paid_amt", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "3s播放率", Prop: "play3s_ratio", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "75%进度播放率", Prop: "ad_photo_played_75percent_ratio", Format: "rate", SortAble: false, IsDefault: false},
	{Label: "7日累计ROI", Prop: "t7_paid_roi", Format: "rate", SortAble: true, IsDefault: false},
	{Label: "当日累计ROI", Prop: "t0_paid_roi", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "当日累计实际ROI", Prop: "actual_t0_paid_roi", Format: "rate", SortAble: true, IsDefault: false},
	{Label: "封面点击率", Prop: "photo_click_ratio", Format: "rate", SortAble: false, IsDefault: false},
	{Label: "付费次数成本", Prop: "event_pay_cost", Format: "cost", SortAble: true, IsDefault: false},
	{Label: "付费ROI", Prop: "event_pay_roi", Format: "rate", SortAble: true, IsDefault: false},
	{Label: "唤起应用成本", Prop: "event_app_invoked_cost", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "唤起应用率", Prop: "event_app_invoked_ratio", Format: "rate", SortAble: false, IsDefault: false},
	{Label: "激活单价", Prop: "conversion_cost", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "平均封面点击单价（元", Prop: "photo_click_cost", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "平均千次封面曝光花费（元）", Prop: "impression1k_cost", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "平均千次素材曝光花费（元）", Prop: "click1k_cost", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "平均行为单价（元", Prop: "action_cost", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "深度转化成本(计费时间)，单位元", Prop: "deep_conversion_cost_by_impression7d", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "深度转化率(计费时间)", Prop: "deep_conversion_ratio_by_impression7d", Format: "rate", SortAble: false, IsDefault: false},
	{Label: "首日付费次数成本，单位元", Prop: "event_pay_first_day_cost", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "素材点击率", Prop: "action_ratio", Format: "rate", SortAble: false, IsDefault: false},
	{Label: "完播率", Prop: "play_end_ratio", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "新增付费人数成本，单位元", Prop: "event_new_user_pay_cost", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "行为率", Prop: "action_new_ratio", Format: "rate", SortAble: false, IsDefault: false},
	{Label: "转化成本(计费时间)，单位元", Prop: "conversion_cost_by_impression7d", Format: "cost", SortAble: false, IsDefault: false},
	{Label: "转化率(计费时间)", Prop: "conversion_ratio_by_impression7d", Format: "rate", SortAble: false, IsDefault: false},
	{Label: "关键行为数", Prop: "key_action", Format: "num", SortAble: false, IsDefault: false},
	{Label: "75%进度播放数", Prop: "ad_photo_played75percent_ratio", Format: "num", SortAble: false, IsDefault: false},
	{Label: "IAA广告变现ROI（含返货）", Prop: "mini_game_iaa_roi", Format: "rate", SortAble: true, IsDefault: false},
	{Label: "IAA广告变现LTV（元）", Prop: "mini_game_iaa_purchase_amount", Format: "cost", SortAble: true, IsDefault: false},
	{Label: "实际IAA广告变现LTV（元）", Prop: "actual_mini_game_iaa_purchase_amount", Format: "cost", SortAble: true, IsDefault: true},
}

var AdDataSortKpiMapping = map[string]string{
	"date":                                "日期",
	"event_pay":                           "付费次数",
	"t0_direct_paid_cnt":                  "付费次数(计费时间)",
	"event_pay_purchase_amount":           "付费金额",
	"actual_event_pay_purchase_amount":    "实际付费金额",
	"t0_direct_paid_amt":                  "付费金额(计费时间)",
	"ad_show":                             "广告曝光",
	"total_charge":                        "媒体消耗",
	"actual_charge":                       "实际消耗",
	"event_pay_purchase_amount_first_day": "激活当日付费金额",
	"event_pay_purchase_amount_one_day_by_conversion":   "激活后24h付费金额(激活时间)",
	"event_pay_purchase_amount_three_day_by_conversion": "激活后三日付费金额",
	"conversion":                           "激活数",
	"t0_direct_conversion_cnt":             "激活数(计费时间)",
	"played_three_seconds":                 "3s播放数",
	"conversion_num_by_impression7d":       "转化数(计费时间)",
	"conversion_num":                       "转化数(回传时间)",
	"t0_paid_cnt":                          "当日累计付费次数",
	"t0_paid_amt":                          "当日累计付费金额",
	"actual_t0_paid_amt":                   "当日累计实际付费金额",
	"play3s_ratio":                         "3s播放率",
	"t7_paid_roi":                          "7日累计ROI",
	"t0_paid_roi":                          "当日累计ROI",
	"actual_t0_paid_roi":                   "当日累计实际ROI",
	"event_pay_cost":                       "付费次数成本",
	"event_pay_roi":                        "付费ROI",
	"play_end_ratio":                       "完播率",
	"mini_game_iaa_roi":                    "IAA广告变现ROI（含返货）",
	"mini_game_iaa_purchase_amount":        "IAA广告变现LTV（元）",
	"actual_mini_game_iaa_purchase_amount": "实际IAA广告变现LTV（元）",
}

var AdDataKpiMapping = map[string]string{
	"likes":                               "点赞数",
	"share":                               "分享数",
	"photo_click":                         "封面点击数",
	"impression":                          "封面曝光数",
	"event_pay":                           "付费次数",
	"t0_direct_paid_cnt":                  "付费次数(计费时间)",
	"event_pay_purchase_amount":           "付费金额",
	"t0_direct_paid_amt":                  "付费金额(计费时间)",
	"ad_show":                             "广告曝光",
	"total_charge":                        "媒体消耗",
	"event_app_invoked":                   "唤起应用数",
	"event_pay_purchase_amount_first_day": "激活当日付费金额",
	"event_pay_purchase_amount_one_day_by_conversion":   "激活后24h付费金额(激活时间)",
	"event_pay_purchase_amount_week_by_conversion":      "激活后七日付费金额",
	"event_pay_purchase_amount_three_day_by_conversion": "激活后三日付费金额",
	"conversion":                            "激活数",
	"t0_direct_conversion_cnt":              "激活数(计费时间)",
	"negative":                              "减少此类作品数",
	"report":                                "举报数",
	"block":                                 "拉黑数",
	"comment":                               "评论数",
	"event_pay_first_day":                   "首日付费次数",
	"played_num":                            "素材曝光数",
	"played_three_seconds":                  "3s播放数",
	"ad_photo_played75percent":              "75%播放进度数",
	"played_end":                            "完播数",
	"follow":                                "新增粉丝数",
	"event_new_user_pay":                    "新增付费人数",
	"ad_item_click":                         "行为数",
	"t7_paid_cnt":                           "7日累计付费次数",
	"t7_paid_amt":                           "7日累计付费金额",
	"conversion_num_by_impression7d":        "转化数(计费时间)",
	"deep_conversion_num_by_impression7d":   "深度转化数(计费时间)",
	"conversion_num":                        "转化数(回传时间)",
	"deep_conversion_num":                   "深度转化数",
	"t0_paid_cnt":                           "当日累计付费次数",
	"t0_paid_amt":                           "当日累计付费金额",
	"event_pay_cost":                        "付费次数成本",
	"event_app_invoked_cost":                "唤起应用成本",
	"deep_conversion_cost_by_impression7d":  "深度转化成本(计费时间)，单位元",
	"event_pay_first_day_cost":              "首日付费次数成本，单位元",
	"event_new_user_pay_cost":               "新增付费人数成本，单位元",
	"key_action":                            "关键行为数",
	"ad_photo_played75percent_ratio":        "75%进度播放数",
	"actual_event_pay_purchase_amount":      "实际付费金额",
	"actual_charge":                         "实际消耗",
	"actual_t0_paid_amt":                    "当日累计实际付费金额",
	"play3s_ratio":                          "3s播放率",
	"ad_photo_played_75percent_ratio":       "75%进度播放率",
	"t7_paid_roi":                           "7日累计ROI",
	"t0_paid_roi":                           "当日累计ROI",
	"actual_t0_paid_roi":                    "当日累计实际ROI",
	"photo_click_ratio":                     "封面点击率",
	"event_pay_roi":                         "付费ROI",
	"event_app_invoked_ratio":               "唤起应用率",
	"conversion_cost":                       "激活单价",
	"photo_click_cost":                      "平均封面点击单价（元",
	"impression1k_cost":                     "平均千次封面曝光花费（元）",
	"click1k_cost":                          "平均千次素材曝光花费（元）",
	"action_cost":                           "平均行为单价（元",
	"deep_conversion_ratio_by_impression7d": "深度转化率(计费时间)",
	"action_ratio":                          "素材点击率",
	"play_end_ratio":                        "完播率",
	"action_new_ratio":                      "行为率",
	"conversion_cost_by_impression7d":       "转化成本(计费时间)，单位元",
	"conversion_ratio_by_impression7d":      "转化率(计费时间)",
	"mini_game_iaa_roi":                     "IAA广告变现ROI（含返货）",
	"mini_game_iaa_purchase_amount":         "IAA广告变现LTV（元）",
	"actual_mini_game_iaa_purchase_amount":  "实际IAA广告变现LTV（元）",
}
