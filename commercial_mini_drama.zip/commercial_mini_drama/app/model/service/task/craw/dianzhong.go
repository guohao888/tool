package craw

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	noticeCommon "goserver/app/library/utils/notice/common"
	"io"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

// 需要爬取的字段
type DianZhongField struct {
	BookName      string `json:"book_name"`
	AdvertiseLink string `json:"advertise_link"`
}

type ResultInfo struct {
	Rows []DianZhongField `json:"rows"`
}

const BusinessTypeDianZhong = 2

type FilterParams struct {
	CreateTime string `json:"create_time"` // 格式："开始时间 - 结束时间"
}

// OpParams 对应 op 参数的 JSON 结构（操作类型，如 RANGE 表示范围查询）
type OpParams struct {
	CreateTime string `json:"create_time"` // 固定值 "RANGE"
}

func buildTargetURL(
	protocol, host, path string,
	sort, order string,
	offset int,
	filter FilterParams,
	op OpParams,
	timestamp int64,
) (string, error) {
	// 步骤1：将 filter 结构体序列化为 JSON 字符串
	filterJSON, err := json.Marshal(filter)
	if err != nil {
		return "", fmt.Errorf("filter JSON 序列化失败：%v", err)
	}

	// 步骤2：将 op 结构体序列化为 JSON 字符串
	opJSON, err := json.Marshal(op)
	if err != nil {
		return "", fmt.Errorf("op JSON 序列化失败：%v", err)
	}

	// 步骤4：构建查询参数集合（所有 ? 后的键值对）
	queryParams := url.Values{}
	queryParams.Add("sort", sort)                          // 普通参数：排序字段
	queryParams.Add("order", order)                        // 普通参数：排序方向
	queryParams.Add("offset", strconv.Itoa(offset))        // 普通参数：偏移量（int 转 string）
	queryParams.Add("filter", string(filterJSON))          // URL 编码后的 JSON 参数
	queryParams.Add("op", string(opJSON))                  // URL 编码后的 JSON 参数
	queryParams.Add("_", strconv.FormatInt(timestamp, 10)) // 普通参数：时间戳（防 URL 缓存）

	// 步骤5：拼接完整 URL（协议+域名+路径+查询串）
	// 注意：url.URL 结构体可自动处理路径和查询串的格式，避免手动拼接错误
	fullURL := &url.URL{
		Scheme:   protocol,             // 协议（如 "https"）
		Host:     host,                 // 域名（如 "admin.wqxsw.com"）
		Path:     path,                 // 路径（如 "/admin/endnative/task/index"）
		RawQuery: queryParams.Encode(), // 编码后的查询串（自动拼接 & 分隔符）
	}

	// 返回最终 URL 字符串
	return fullURL.String(), nil
}
func SyncCrawDianZhongData(ctx context.Context, param *xxl.RunReq) (msg string) {

	// 3. 准备构造 URL 所需的参数
	// 3.1 基础 URL 信息
	protocol := "https"
	host := "admin.wqxsw.com"
	path := "/admin/endnative/task/index"

	// 3.2 普通查询参数
	sort := "id"
	order := "desc"
	offset := 0 // 偏移量，对应 URL 中的 offset=0
	nowStr := getTodayEndWithNano().Format("2006-01-02 15:04:05")
	startTime := Get7DaysAgoMidnight().Format("2006-01-02 15:04:05")
	// 3.3 filter 参数（时间范围：2025-08-14 00:00:00 到 2025-08-21 23:59:59）
	filter := FilterParams{
		CreateTime: fmt.Sprintf("%s - %s", startTime, nowStr),
	}
	// 3.4 op 参数（操作类型：RANGE 表示范围查询）
	op := OpParams{
		CreateTime: "RANGE",
	}
	timestamp := time.Now().UnixMilli()
	targetURL, err := buildTargetURL(
		protocol, host, path,
		sort, order, offset,
		filter, op,
		timestamp,
	)
	if err != nil {

		return
	}

	// 5. 打印结果（与原 URL 完全一致）
	//url := "https://admin.wqxsw.com/admin/endnative/task/index?sort=id&order=desc&offset=0&filter=%7B%22create_time%22%3A%222025-08-14+00%3A00%3A00+-+2025-08-21+23%3A59%3A59%22%7D&op=%7B%22create_time%22%3A%22RANGE%22%7D&_=1755759490881"
	// 构建请求
	req, err := http.NewRequest("GET", targetURL, nil)
	if err != nil {
		return
	}
	// 设置请求头
	req.Header.Set("accept", "application/json, text/javascript, */*; q=0.01")
	req.Header.Set("accept-language", "zh-CN,zh;q=0.9")
	req.Header.Set("content-type", "application/json")
	req.Header.Set("priority", "u=1, i")
	req.Header.Set("referer", "https://admin.wqxsw.com/admin/endnative/task/channel_index?addtabs=1")
	req.Header.Set("sec-ch-ua", `"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"`)
	req.Header.Set("sec-ch-ua-mobile", "?0")
	req.Header.Set("sec-ch-ua-platform", `"Windows"`)
	req.Header.Set("sec-fetch-dest", "empty")
	req.Header.Set("sec-fetch-mode", "cors")
	req.Header.Set("sec-fetch-site", "same-origin")
	req.Header.Set("user-agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36")
	req.Header.Set("x-requested-with", "XMLHttpRequest")

	// 获取cookie 数据
	config, err := getCrawConfig(BusinessTypeDianZhong)
	if err != nil {
		return fmt.Sprintf("获取配置失败: %v", err)
	}

	cookieMaps := ParseCookie(config.ReqCurl)
	var cookies []*http.Cookie
	for k, val := range cookieMaps {
		cookies = append(cookies, &http.Cookie{Name: k, Value: val})
	}
	// 设置 Cookie
	for _, cookie := range cookies {
		req.AddCookie(cookie)
	}
	// 发送请求
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {

		return
	}
	defer resp.Body.Close()
	// 读取响应数据
	body, err := io.ReadAll(resp.Body)
	if err != nil {

		return
	}

	var dianZhongField ResultInfo
	err = json.Unmarshal(body, &dianZhongField)
	if err != nil {
		// 大概率cookie过期，推推提示
		content := "日期: " + time.Now().Format("2006-01-02 15:04:05") + "\n【点众】Cookie已过期，请更换cookie信息"
		err = noticeCommon.SendTuituiTextMsg(content, GroupNum, strings.Split(AtPersonOfCookie, ",")...)
		if err != nil {
			return fmt.
				Sprintf("发送消息失败: %v", err)
		}

		return
	}
	var dianZhongList []*ResultData
	for _, item := range dianZhongField.Rows {
		feiShu := &ResultData{
			ReferralUrl:    item.AdvertiseLink,
			BookName:       item.BookName,
			HashID:         ParseUrl(item.AdvertiseLink),
			CopyrightOwner: "点众",
			CreatedTime:    time.Now(),
		}
		dianZhongList = append(dianZhongList, feiShu)
	}

	err = saveToDatabase(ctx, dianZhongList)
	if err != nil {
		return fmt.Sprintf("保存数据失败: %v", err)
	}
	return fmt.Sprintf("成功处理 %d 条数据", len(dianZhongList))
}

func getTodayEndWithNano() time.Time {
	now := time.Now()
	return time.Date(
		now.Year(),
		now.Month(),
		now.Day(),
		23, 59, 59, // 时分秒
		999999999, // 最大纳秒值
		now.Location(),
	)
}

func Get7DaysAgoMidnight() time.Time {
	// 1. 获取当前时间（当地时区）
	now := time.Now()
	// 2. 计算7天前的日期（年/月/日不变，仅时间减7天）
	sevenDaysAgoDate := now.AddDate(0, 0, -2)

	// 3. 构造7天前当天的00:00:00（时/分/秒/纳秒均设为0）
	return time.Date(
		sevenDaysAgoDate.Year(),  // 7天前的年
		sevenDaysAgoDate.Month(), // 7天前的月
		sevenDaysAgoDate.Day(),   // 7天前的日
		0, 0, 0,                  // 时:00, 分:00, 秒:00
		0,              // 纳秒:0（精确到秒）
		now.Location(), // 保持当地时区（避免时区偏差）
	)
}
