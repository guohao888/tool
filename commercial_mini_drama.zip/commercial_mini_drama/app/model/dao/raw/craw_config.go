package raw

import (
	"context"
	"goserver/app/common/repository/raw"
	"goserver/app/library/driver/dorisdb"
)

// 模拟抓取数据配置表
type CrawConfigDao struct {
	Ctx context.Context
}

func NewCrawConfigDao(ctx context.Context) *CrawConfigDao {
	return &CrawConfigDao{Ctx: ctx}
}

// 更新数据
func (r *CrawConfigDao) UpdateData(businessTpe int, entity raw.CrawConfigEntity) error {
	db := dorisdb.DorisClient()
	return db.Table(raw.CrawConfigTableName()).
		Where("business_type = ?", businessTpe).
		UpdateColumn(entity).Error
}
