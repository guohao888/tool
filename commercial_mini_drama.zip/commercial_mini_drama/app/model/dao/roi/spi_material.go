package roi

import (
	"context"
	"fmt"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/common/repository/roi"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"

	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
)

// SpiMaterialDao 处理SPI素材修改日志的数据库操作
type SpiMaterialDao struct {
	Ctx context.Context
}

// NewSpiMaterialDao 创建SpiMaterialDao的新实例
func NewSpiMaterialDao(ctx context.Context) *SpiMaterialDao {
	return &SpiMaterialDao{Ctx: ctx}
}

// InsertBatchSize 批量插入数据
func (m *SpiMaterialDao) InsertBatchSize(data []*roi.SPIMaterialModificationLog, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize
		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = m.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// buildInsertSentence 构建插入语句
func (m *SpiMaterialDao) buildInsertSentence(tx *gorm.DB, data []*roi.SPIMaterialModificationLog) error {
	if len(data) == 0 {
		return nil
	}

	columns := "message_id, advertiser_id, material_id, service_label, subscribe_task_id, core_user_id, app_id, publish_time, timestamp, nonce, created_at, updated_at"
	values := ""
	for i, entity := range data {
		if i > 0 {
			values += ", "
		}
		// 对字符串类型的字段进行转义处理
		messageID := strings.ReplaceAll(entity.MessageID, "'", "''")
		serviceLabel := strings.ReplaceAll(entity.ServiceLabel, "'", "''")

		values += fmt.Sprintf("('%s', %d, %d, '%s', %d, %d, %d, %d, %d, %d, '%s', '%s')",
			messageID,
			entity.AdvertiserID,
			entity.MaterialID,
			serviceLabel,
			entity.SubscribeTaskID,
			entity.CoreUserID,
			entity.AppID,
			entity.PublishTime,
			entity.Timestamp,
			entity.Nonce,
			entity.CreatedAt.Format("2006-01-02 15:04:05"),
			entity.UpdatedAt.Format("2006-01-02 15:04:05"))
	}

	sql := fmt.Sprintf("INSERT INTO %s (%s) VALUES %s", roi.SPIMaterialModificationLogTableName(), columns, values)

	// 执行 SQL 语句
	result := tx.Exec(sql)
	return result.Error
}

func (m *SpiMaterialDao) ListActiveQueue() ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT advertiser_id FROM spi_material_modification_log WHERE date(created_at) = CURRENT_DATE GROUP BY advertiser_id ) has  LEFT JOIN ( SELECT advertiser_id, min(user_id) as user_id FROM oauth_account GROUP BY advertiser_id ) ac ON has.advertiser_id = ac.advertiser_id"
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

type AdvertiserInfo struct {
	AdvertiserId int64
	UserId       int64
	AccessToken  string
}

func (m *SpiMaterialDao) GetSubscribeAccount(date string) ([]AdvertiserInfo, error) {
	db := dorisdb.DorisClient()
	var res []AdvertiserInfo
	//sql := "SELECT advertiser_id, user_id, access_token FROM ( select advertiser_id, user_id, oauth_id from oauth_account where advertiser_id = '1829089015751145' ) oa LEFT JOIN ( SELECT oauth_id, access_token FROM oauth) o ON oa.oauth_id = o.oauth_id "
	sql := "SELECT a.advertiser_id, user_id, access_token FROM ( SELECT a.advertiser_id FROM ( SELECT DISTINCT advertiser_id FROM spi_material_modification_log WHERE date(created_at) = '" + date + "' ) a LEFT JOIN ( SELECT advertiser_id FROM account_add WHERE `status` = 1 ) b ON a.advertiser_id = b.advertiser_id WHERE b.advertiser_id IS NULL ) a LEFT JOIN ( SELECT advertiser_id, user_id, access_token FROM ( SELECT advertiser_id, user_id FROM oauth_account ) oa LEFT JOIN ( SELECT user_id, access_token FROM oauth_push ) op ON oa.user_id = op.user_id ) b ON a.advertiser_id = b.advertiser_id "
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

func (m *SpiMaterialDao) GetSubscribeAccountRemove(start, end string) ([]AdvertiserInfo, error) {
	db := dorisdb.DorisClient()
	var res []AdvertiserInfo
	sql := "SELECT a.advertiser_id, user_id, access_token FROM ( SELECT a.advertiser_id FROM ( SELECT advertiser_id FROM account_add WHERE `status` = 1 ) a LEFT JOIN ( SELECT DISTINCT advertiser_id FROM report_project_hour WHERE date(search_date) BETWEEN '" + start + "' AND '" + end + "' AND cost > 0 ) b ON a.advertiser_id = b.advertiser_id WHERE b.advertiser_id IS NULL ) a LEFT JOIN ( SELECT advertiser_id, user_id, access_token FROM ( SELECT advertiser_id, user_id FROM oauth_account ) oa LEFT JOIN ( SELECT user_id, access_token FROM oauth_push ) op ON oa.user_id = op.user_id ) b ON a.advertiser_id = b.advertiser_id "
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

func (m *SpiMaterialDao) GetSubscribeAccountDay(date string) ([]AdvertiserInfo, error) {
	db := dorisdb.DorisClient()
	var res []AdvertiserInfo
	sql := "SELECT a.advertiser_id, user_id, access_token FROM ( SELECT a.advertiser_id FROM ( SELECT DISTINCT advertiser_id FROM spi_material_modification_log WHERE date(created_at) = '" + date + "' ) a LEFT JOIN ( SELECT advertiser_id FROM account_add_day WHERE `status` = 1 ) b ON a.advertiser_id = b.advertiser_id WHERE b.advertiser_id IS NULL ) a LEFT JOIN ( SELECT advertiser_id, user_id, access_token FROM ( SELECT advertiser_id, user_id FROM oauth_account ) oa LEFT JOIN ( SELECT user_id, access_token FROM oauth_push ) op ON oa.user_id = op.user_id ) b ON a.advertiser_id = b.advertiser_id "
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

func (m *SpiMaterialDao) GetSubscribeAccountRemoveDay(start, end string) ([]AdvertiserInfo, error) {
	db := dorisdb.DorisClient()
	var res []AdvertiserInfo
	sql := "SELECT a.advertiser_id, user_id, access_token FROM ( SELECT a.advertiser_id FROM ( SELECT advertiser_id FROM account_add_day WHERE `status` = 1 ) a LEFT JOIN ( SELECT DISTINCT advertiser_id FROM report_project_hour WHERE date(search_date) BETWEEN '" + start + "' AND '" + end + "' AND cost > 0 ) b ON a.advertiser_id = b.advertiser_id WHERE b.advertiser_id IS NULL ) a LEFT JOIN ( SELECT advertiser_id, user_id, access_token FROM ( SELECT advertiser_id, user_id FROM oauth_account ) oa LEFT JOIN ( SELECT user_id, access_token FROM oauth_push ) op ON oa.user_id = op.user_id ) b ON a.advertiser_id = b.advertiser_id "
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}
