package accounts

import (
	"context"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	accountscommon "goserver/app/common/repository/accounts"
	"goserver/app/library/utils"
	"goserver/app/model/dao/accounts"
	dao "goserver/app/model/dao/accounts"
	"goserver/app/model/service/warning"
	"strconv"
	"time"
)

type AccountPullEmptyService struct {
	Ctx context.Context
}

const (
	MapOne   = 1 //     时速消耗>1000，当日roi<30%
	MapTwo   = 2 //      时速消耗>500，当日roi<80%
	MapThree = 3
)

const (
	TaskOne   = 1 //
	TaskTwo   = 2
	TaskThree = 3
)

func NewAccountPullEmptyService(ctx context.Context) *AccountPullEmptyService {
	return &AccountPullEmptyService{Ctx: ctx}
}

// 账户维度
type AccountVo struct {
	AccountID  string   `json:"account_id"`
	DayRoi     float64  `json:"day_roi"`
	Hour       int      `json:"hour"`
	HourCost   float64  `json:"hour_cost"`
	ProjectIDs []string // 项目ID
	Token      string
	UserID     string // 管家账户ID
}

// 账户明细
type AccountAccess struct {
	AccountID string
	UserID    string
	ProjectID string
	ResMsg    string
}

// 拉空操作
func (p *AccountPullEmptyService) PullEmptyAction(accountList []AccountVo) (pullList []AccountAccess, err error) {
	// 拉空操作
	resList, err := p.SendAndPullEmpty(accountList)
	if err != nil {
		return nil, fmt.Errorf("拉空错误, err: %s", err)
	}
	// 格式化数据
	var pullEmptyList []AccountAccess
	for _, val := range resList {
		pullEmptyList = append(pullEmptyList, AccountAccess{
			AccountID: val.AccountID,
			UserID:    val.UserID,
			ProjectID: val.ProjectID,
			ResMsg:    val.ResMsg,
		})

	}
	// 保存记录
	return pullEmptyList, p.SavePullEmptyRecord(resList)
}

// 查找需要监控的账户
func (p *AccountPullEmptyService) FindAccountMonitor(mapType int) ([]AccountVo, error) {
	reportDataDao := dao.NewAccountPullEmptyDao(p.Ctx)
	// 获取当前小时的账户数据
	//var curMap = make(map[string]AccountVo)
	currentHourAccountList, err := reportDataDao.GetDataByAccount(dao.CurHour)
	if err != nil {
		return nil, err
	}
	curMap := formatAccountInfoList(currentHourAccountList)
	// 获取上一小时的账户数据
	lastHourAccountList, err := reportDataDao.GetDataByAccount(dao.LastHour)
	if err != nil {
		return nil, err
	}
	lastMap := formatAccountInfoList(lastHourAccountList)

	lastTwoAccountList, err := reportDataDao.GetDataByAccount(dao.LastTwoHour)
	if err != nil {
		return nil, err
	}
	lastTwoMap := formatAccountInfoList(lastTwoAccountList)
	// 获取当天的Roi数据
	todayAccountList, err := reportDataDao.GetDataByAccount(dao.Daily)
	if err != nil {
		return nil, err
	}
	todayMap := formatAccountInfoList(todayAccountList)
	// 需要拉空的账户时   时速消耗>1000，当日roi<30%
	var accountList []AccountVo
	for _, val := range curMap {
		lastVal, ok := lastMap[val.AccountID]
		dayVal, ok1 := todayMap[val.AccountID]
		lastTwoVal, ok2 := lastTwoMap[val.AccountID]
		switch mapType {
		case MapOne:
			if ok1 && dayVal.DayRoi < 30 && ok && val.HourCost-lastVal.HourCost > 1000 {
				accountList = append(accountList, val)
			}
		case MapTwo:
			// 上个小时差和上上个小时差都要满足
			if ok1 && dayVal.DayRoi < 80 && ok && val.HourCost-lastVal.HourCost > 500 && ok2 && lastVal.HourCost-lastTwoVal.HourCost > 500 {
				accountList = append(accountList, val)
			}

		case MapThree:
			if ok1 && dayVal.DayRoi < 90 && ok && val.HourCost-lastVal.HourCost > 5000 && ok2 && lastVal.HourCost-lastTwoVal.HourCost > 5000 {
				accountList = append(accountList, val)
			}

		}

	}
	if len(accountList) == 0 {
		return accountList, nil
	}
	// 获取账户下面的项目ID
	var accountID []string
	for _, va := range accountList {
		accountID = append(accountID, va.AccountID)
	}
	projectIDList, err := reportDataDao.GetProjectIDList(accountID)
	if err != nil {
		return nil, err
	}
	var projectIDMap = make(map[string][]string)
	for _, val := range projectIDList {
		projectIDMap[val.AccountID] = append(projectIDMap[val.AccountID], val.ProjectID)

	}
	for key, val := range accountList {
		accountList[key].ProjectIDs = projectIDMap[val.AccountID]
	}
	// 获取账户token
	var accountOauthMap = make(map[string]string)
	accountDao := accounts.NewOauthAccountDao(p.Ctx)
	accountInfoList, err := accountDao.FindAccountByAds(accountID)
	if err != nil {
		return nil, err
	}
	var oauthIDs []string
	for _, val := range accountInfoList {
		accountOauthMap[val.AdvertiserId] = val.OauthId
		oauthIDs = append(oauthIDs, val.OauthId)
	}
	// 根据oauthID 获取token
	oauthIDs = utils.SliceUniqStr(oauthIDs)
	oauthDao := accounts.NewOauthDao(p.Ctx)
	oauthList, err := oauthDao.GetTokenByOauthIDs(oauthIDs)
	if err != nil {
		return nil, err
	}
	var accountTokenMap = make(map[string]string)
	var accountUserIDMap = make(map[string]string)
	for _, val := range oauthList {
		accountTokenMap[val.OauthId] = val.AccessToken
		accountUserIDMap[val.OauthId] = val.UserId
	}
	for k, val := range accountList {
		if oauthID, ok := accountOauthMap[val.AccountID]; ok {
			accountList[k].Token = accountTokenMap[oauthID]
			accountList[k].UserID = accountUserIDMap[oauthID]
		}
	}

	return accountList, nil
}

func formatAccountInfoList(accountList []dao.AccountReportData) map[string]AccountVo {
	var curMap = make(map[string]AccountVo)
	for _, val := range accountList {
		curMap[val.AccountID] = AccountVo{
			AccountID: val.AccountID,
			DayRoi:    val.DayRoi,
			Hour:      val.Hour,
			HourCost:  val.HourCost,
		}
	}
	return curMap
}

type NewRequestMap struct {
	Projects []string
	Token    string
}

func BuildProjectWeekScheduleUpdateReq(accountList []AccountVo) (res map[int64][]*models.ProjectWeekScheduleUpdateV30RequestDataInner) {
	m := make(map[int64][]*models.ProjectWeekScheduleUpdateV30RequestDataInner)
	for _, v := range accountList {
		advertiserId, _ := strconv.Atoi(v.AccountID)
		if len(v.ProjectIDs) == 0 {
			continue
		}
		infos := getProjectRequestInfo(v.ProjectIDs)
		m[int64(advertiserId)] = infos
	}
	return m
}

func getProjectRequestInfo(projectIds []string) []*models.ProjectWeekScheduleUpdateV30RequestDataInner {
	var infos = make([]*models.ProjectWeekScheduleUpdateV30RequestDataInner, 0, len(projectIds))
	for _, ID := range projectIds {
		IDInt64, _ := strconv.ParseInt(ID, 10, 64)
		info := &models.ProjectWeekScheduleUpdateV30RequestDataInner{
			ProjectId:     IDInt64,
			ScheduleScene: models.REALTIME_ProjectWeekScheduleUpdateV30DataScheduleScene,
			ScheduleTime:  warning.BuildScheduleTime(),
		}
		infos = append(infos, info)
	}
	return infos
}

// 拉空数据，推送消息，并且入库明细
func (p *AccountPullEmptyService) SendAndPullEmpty(accountList []AccountVo) ([]*accountscommon.AccountEmptyEntity, error) {

	reqInfos := BuildProjectWeekScheduleUpdateReq(accountList)
	accountMap := make(map[int64]AccountVo)

	for _, v := range accountList {
		advertiserId, _ := strconv.ParseInt(v.AccountID, 10, 64)
		accountMap[advertiserId] = v
	}

	var result []*accountscommon.AccountEmptyEntity
	var count int
	for accountID, info := range reqInfos {
		count++
		if count%50 == 0 {
			time.Sleep(time.Second * 3)
		}
		// todo 测试存库数据，暂不拉空
		for _, val := range info {

			res := &accountscommon.AccountEmptyEntity{
				AccountID:   strconv.Itoa(int(accountID)),
				CreatedTime: time.Now(),
				UserID:      accountMap[accountID].UserID,
				ProjectID:   strconv.Itoa(int(val.ProjectId)),
				ResMsg:      "测试",
			}
			result = append(result, res)

		}

		//batchPage := dao2.BatchPage(len(info), 10)
		//for i := 0; i < batchPage; i++ {
		//	start := i * 10
		//	end := (i + 1) * 10
		//	if end > len(info) {
		//		end = len(info)
		//	}
		//	newReq := toutiao.ProjectWeekScheduleUpdateReq{
		//		AccessToken: accountMap[accountID].Token,
		//		Info: models.ProjectWeekScheduleUpdateV30Request{
		//			AdvertiserId: accountID,
		//			Data:         info[start:end],
		//		},
		//	}
		//	ctx := context.Background()
		//	res, err := toutiao.PullEmptyApi(ctx, newReq)
		//	if err != nil {
		//		return nil, err
		//	}
		//	if len(res.Data.Errors) > 0 {
		//		for _, errV := range res.Data.Errors {
		//			// 失败合集
		//			resInfo := &accountscommon.AccountEmptyEntity{
		//				AccountID:   strconv.Itoa(int(accountID)),
		//				ProjectID:   strconv.Itoa(int(*errV.ProjectId)),
		//				ResMsg:      *errV.ErrorMessage,
		//				CreatedTime: time.Now(),
		//				UserID:      accountMap[accountID].UserID,
		//			}
		//			result = append(result, resInfo)
		//
		//		}
		//	}
		//	if len(res.Data.ProjectIds) > 0 {
		//		for _, projectId := range res.Data.ProjectIds {
		//			// 成功合集
		//			resInfo := &accountscommon.AccountEmptyEntity{
		//				AccountID:   strconv.Itoa(int(accountID)),
		//				ProjectID:   strconv.Itoa(int(projectId)),
		//				ResMsg:      "成功",
		//				CreatedTime: time.Now(),
		//				UserID:      accountMap[accountID].UserID,
		//			}
		//			result = append(result, resInfo)
		//
		//		}
		//	}
		//}
	}

	//result = []*accountscommon.AccountEmptyEntity{
	//	{
	//		AccountID:   "234567",
	//		ProjectID:   "222",
	//		CreatedTime: time.Now(),
	//		UserID:      "444",
	//	},
	//	{
	//		AccountID:   "542342322",
	//		ProjectID:   "666",
	//		CreatedTime: time.Now(),
	//		UserID:      "45231",
	//	},
	//}

	return result, nil
}

func (p *AccountPullEmptyService) SavePullEmptyRecord(list []*accountscommon.AccountEmptyEntity) error {
	pullDao := accounts.NewAccountPullEmptyDao(p.Ctx)
	return pullDao.Create(list)

}

func FilterData(list []AccountAccess) []AccountAccess {
	// 过滤去重
	var accountMap = make(map[string]struct{})
	var accountSlice []AccountAccess
	for _, val := range list {

		if _, ok := accountMap[val.AccountID]; !ok {
			accountSlice = append(accountSlice, val)
		}
		accountMap[val.AccountID] = struct{}{}

	}
	return accountSlice
}
