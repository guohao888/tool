package account

import (
	"github.com/gin-gonic/gin"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	account "goserver/app/model/service/accounts"
)

func ConfigList(c *gin.Context) {
	r := response.Gin{Ctx: c}

	configListReq := accountdto.NewConfigListReq(c)

	oauthConfigService := account.NewOauthConfigService(c)
	paginator, _ := oauthConfigService.ConfigList(configListReq.Params)

	r.Response(myerror.OK.Code, myerror.OK.Message, paginator)
}
