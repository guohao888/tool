package roidto

import (
	"github.com/gin-gonic/gin"
	"github.com/shopspring/decimal"
	"goserver/app/common"
	"goserver/app/library/myerror"
	"goserver/app/library/utils"
	timeUtil "goserver/app/library/utils/time"
	"strings"
	"time"
)

type ReportParamsReq struct {
	common.CommonParams
}

func NewReportParamsReq(c *gin.Context) *ReportParamsReq {
	req := &ReportParamsReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

type CommonFilter struct {
	Media           []string `json:"media,omitempty"`            // 媒体
	Region          []string `json:"region,omitempty"`           // 地域
	PayType         []string `json:"pay_type,omitempty"`         // 支付类型
	AppName         []string `json:"app_name,omitempty"`         // 应用包名
	BookNames       []string `json:"book_name,omitempty"`        // 剧目名称
	BookID          string   `json:"book_id,omitempty"`          // 剧目ID
	OptimizerName   []string `json:"optimizer_id,omitempty"`     // 投放人员
	AccountID       []string `json:"account_id,omitempty"`       // 账户
	DeliveryProduct string   `json:"delivery_product,omitempty"` // 推广产品
	ProjectID       string   `json:"project_id,omitempty"`       // 推广组ID
	PromotionID     string   `json:"promotion_id,omitempty"`     // 推广计划ID
	MidID           string   `json:"mid_id,omitempty"`           // 推广创意ID
	UserID          []string `json:"user_id,omitempty"`          // 账管名称
	CopyRightOwner  []string `json:"copyright_owner"`            // 端原生版权方
}

// {"timestamp":1737353662745,"params":{"media":[],"region":[],"pay_type":[],"app_id":[],"book_id":[],"optimizer_id":[],"account_id":[],
// "group_by":["media","app_name","book_name","optimizer_nickname","account_name"],"project_id":"","promotion_id":"","mid_id":"",
// "start_date":"2025-01-20","end_date":"2025-01-20","group_type":"d","sorts":[],"page":1,"page_size":20},
// "token":"93c5a9de5f6c29d101aabffd4f47b1d6","sign":"bc5708c55f15cb19ca4e0e38a9b2e1c1"}
type ReportDataParams struct {
	StartDate         string        `json:"start_date" binding:"required"` // 起始时间
	EndDate           string        `json:"end_date" binding:"required"`   // 结束时间
	GroupType         string        `json:"group_type" binding:"required"` // 聚合时间类型 小时日周月选择
	GroupBy           []string      `json:"group_by" binding:"required"`   // 聚合维度
	CommonFilter                    //页面筛选
	common.Pagination               // 分页
	Sorts             []common.Sort `json:"sorts,omitempty"` // 多字段排序
	Kpi               []string      `json:"kpi,omitempty"`   // 指标筛选 - 导出的时候使用
	StartDateHb       string        `json:-`                 // 环比起始时间
	EndDateHb         string        `json:-`                 // 环比结束时间
	StartDateTb       string        `json:-`                 // 同比起始时间
	EndDateTb         string        `json:-`                 // 同比结束时间
	DaysOfHb          int           `json:-`                 // 环比天数
	Hour              string        `json:-`                 // 查询小时值 只有查询实时数据时才会用
	HourHb            string        `json:-`                 // 环比查询小时值
	HourTb            string        `json:-`                 // 同比查询小时值
	IsRealTimeQuery   bool          `json:-`                 // 是否是实时查询
	HasProjectId      bool          `json:-`                 // 聚合条件是否包含项目维度
}

type ReportDataReq struct {
	common.CommonParams
	ReportDataParams
}

type ReportOptionSearchReq struct {
	common.CommonParams
	Keywords   string `json:"keywords" binding:"required"`    // 起始时间
	SearchType string `json:"search_type" binding:"required"` // 结束时间
}

// NewReportDataReq proGroup 聚合维度是否可以包含推广计划promotion_id true可包含  false不可包含
func NewReportDataReq(c *gin.Context, paramsType string, proGroup bool) *ReportDataReq {
	req := &ReportDataReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	// 聚合条件不能包含promotion_id时强制置空
	if !proGroup {
		req.PromotionID = ""
		req.MidID = ""
	}
	//req.UserInfo = common.GetUserInfo(c)
	// 时间范围效验
	var err error
	req.StartDate, err = timeUtil.Reformat(req.StartDate, "2006-01-02", time.DateOnly)
	if err != nil {
		panic(myerror.ParamsError)
	}
	req.EndDate, err = timeUtil.Reformat(req.EndDate, "2006-01-02", time.DateOnly)
	if err != nil {
		panic(myerror.ParamsError)
	}
	if req.StartDate > req.EndDate {
		panic(myerror.ParamsError)
	}
	// 查询时段1 2025-01-13 ~ 2025-01-19
	// 环比时段1 2025-01-06 ~ 2025-01-12
	// 同比时段1 2024-12-13 ~ 2024-12-19
	// 查询时段2 2025-01-13 ~ 2025-01-14
	// 环比时段2 2025-01-11 ~ 2025-01-12
	// 同比时段2 2024-12-13 ~ 2024-12-14
	startTime, _ := time.ParseInLocation(time.DateOnly, req.StartDate, time.Local)
	endTime, _ := time.ParseInLocation(time.DateOnly, req.EndDate, time.Local)
	diff := endTime.Sub(startTime)
	req.DaysOfHb = int(diff.Hours()/24) + 1
	days := 0 - req.DaysOfHb
	// 查询时段1
	req.StartDate = startTime.Format("2006-01-02")
	req.EndDate = endTime.Format("2006-01-02")
	// 环比时段1
	startTimeHb := startTime.AddDate(0, 0, days)
	endTimeHb := endTime.AddDate(0, 0, days)
	startTimeTb := startTime.AddDate(0, -1, 0)
	endTimeTb := endTime.AddDate(0, -1, 0)
	req.StartDateHb = startTimeHb.Format("2006-01-02")
	req.EndDateHb = endTimeHb.Format("2006-01-02")
	req.StartDateTb = startTimeTb.Format("2006-01-02")
	req.EndDateTb = endTimeTb.Format("2006-01-02")

	// 查询实时数据的场景  环比取上一小时数据
	if req.GroupType == "h" && req.StartDate == req.EndDate {
		now := time.Now()
		todayDate := now.Format("2006-01-02")
		if todayDate == req.StartDate {
			//req.IsRealTimeQuery = true // 这需求又改回去了
		}
	}

	// 聚合时间类型效验
	if _, ok := GroupTypeMapping[req.GroupType]; !ok {
		panic(myerror.ParamsError)
	}
	// 聚合维度效验
	//if len(req.GroupBy) > 0 {
	//	groupMap := GetGroupByMapping(proGroup)
	//	for _, v := range req.GroupBy {
	//		if _, ok := groupMap[v]; !ok {
	//			panic(myerror.ParamsError)
	//		}
	//		if v == "project_id" {
	//			req.HasProjectId = true
	//		}
	//	}
	//	if req.HasProjectId {
	//		req.GroupBy = append(req.GroupBy, "project_name")
	//	}
	//}
	//// 如果聚合维度包含了 account_name, 则自动把 account_id 加进去
	//if utils.InArray("account_name", req.GroupBy) {
	//	req.GroupBy = append(req.GroupBy, "account_id")
	//}
	//if utils.InArray("book_name", req.GroupBy) {
	//	req.GroupBy = append(req.GroupBy, "book_id")
	//}
	// 聚合维度去重
	req.GroupBy = utils.ArrayUnique(req.GroupBy)

	// 筛选项效验
	if len(req.Media) > 0 {
		for i, val := range req.Media {
			req.Media[i] = utils.HtmlEncode(val)
		}
	}
	if len(req.Region) > 0 {
		for i, val := range req.Region {
			req.Region[i] = utils.HtmlEncode(val)
		}
	}
	if len(req.AppName) > 0 {
		for i, val := range req.AppName {
			req.AppName[i] = utils.HtmlEncode(val)
		}
	}
	if len(req.AccountID) > 0 {
		for i, val := range req.AccountID {
			req.AccountID[i] = utils.HtmlEncode(val)
		}
	}
	if len(req.PayType) > 0 {
		for _, payType := range req.PayType {
			if _, ok := PayTypeMapping[payType]; !ok {
				panic(myerror.ParamsError)
			}
		}
	}
	if len(req.OptimizerName) > 0 {
		for i, val := range req.OptimizerName {
			req.OptimizerName[i] = utils.HtmlEncode(val)
		}
	}
	if len(req.BookNames) > 0 {
		for i, val := range req.BookNames {
			req.BookNames[i] = utils.HtmlEncode(val)
		}
	}
	if len(req.BookNames) > 0 {
		for i, val := range req.BookNames {
			req.BookNames[i] = utils.HtmlEncode(val)
		}
	}
	//if len(req.DeliveryProduct) > 0 {
	//	for _, val := range req.DeliveryProduct {
	//		if _, ok := DeliveryProductMapping[val]; !ok {
	//			panic(myerror.ParamsError)
	//		}
	//	}
	//}
	if len(req.UserID) > 0 {
		for i, val := range req.UserID {
			req.UserID[i] = utils.HtmlEncode(val)
		}
	}

	// 分页传参效验
	if req.Page < 1 {
		req.Page = 1
	}
	if req.PageSize < 1 {
		req.PageSize = 25
	}
	// 排序字段效验
	if len(req.Sorts) > 0 {
		for _, v := range req.Sorts {
			if _, ok := SortKpiMapping[v.Key]; !ok {
				panic(myerror.ParamsError)
			}
			v.Order = strings.ToLower(v.Order)
			if v.Order != "asc" && v.Order != "desc" {
				panic(myerror.ParamsError)
			}
		}
	}
	//导出时做指标筛选效验
	//if paramsType == "export" {
	//	req.Kpi = utils.SliceUniqStr(req.Kpi) //去重
	//	if len(req.Kpi) == 0 {
	//		panic(myerror.ParamsError)
	//	}
	//	kpiMap := GetKpiMapping(proGroup)
	//	for _, v := range req.Kpi {
	//		if _, ok := kpiMap[v]; !ok {
	//			panic(myerror.ParamsError)
	//		}
	//	}
	//}
	return req
}

func NewReportOptionSearchReq(c *gin.Context) *ReportOptionSearchReq {
	req := &ReportOptionSearchReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	//参数效验
	req.Keywords = utils.HtmlEncode(req.Keywords)
	searchTypeArr := []string{"account", "book"}
	if req.Keywords == "" || !utils.InArray(req.SearchType, searchTypeArr) {
		panic(myerror.ParamsError)
	}
	return req
}

type TodayMarketDataReq struct {
	common.CommonParams
	Params TodayDataParams `json:"params"`
}

type TodayDataParams struct {
	Media           string `json:"media"`            // 媒体
	AccountId       string `json:"account_id"`       // 全匹配
	BookName        string `json:"book_name"`        // 模糊匹配
	DeliveryProduct string `json:"delivery_product"` // 推广产品
}

type TodayMarketDataResp struct {
	Cost           string `json:"cost" form:"cost"`                           // 今天实际消耗
	CostHbRate     string `json:"cost_hb_rate" form:"cost_hb_rate"`           // 环比昨日 (与昨天比，今天周四100 昨天周三80  （100 - 80）÷80×100% = 25%  )
	CostHbSameRate string `json:"cost_hb_same_rate" form:"cost_hb_same_rate"` // 环比昨日同期
	CostTbRate     string `json:"cost_tb_rate" form:"cost_tb_rate"`           // 同比昨日 (与上周的今天比，今天周四100 上周四80  （100 - 80）÷80×100% = 25%  )
	Roi            string `json:"roi" form:"roi"`                             // 今日ROI ROI = 今日总收入/今日实际总消耗
	RoiHbRate      string `json:"roi_hb_rate" form:"roi_hb_rate"`             // 环比昨日
	RoiTbRate      string `json:"roi_tb_rate" form:"roi_tb_rate"`             // 同比昨日
	RoiHbSameRate  string `json:"roi_hb_same_rate" form:"roi_hb_same_rate"`   // 同比昨日同期
}

func NewTodayMarketDataReq(c *gin.Context) *TodayMarketDataReq {
	req := &TodayMarketDataReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

type TodayTodayTimeDataReq struct {
	common.CommonParams
	TodayTodayTimeDataParams
}

type TodayTodayTimeDataParams struct {
	Source int             `json:"source" form:"source"` // 数据源 1=分时数据 2=趋势数据
	Params TodayDataParams `json:"params" from:"params"`
}

type TodayTimeDataResp struct {
	Index    int             `json:"index"`
	Hour     string          `json:"hour" form:"hour"`           // 时
	Cost     decimal.Decimal `json:"cost" form:"cost"`           // 实际消耗=(SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)
	Profit   decimal.Decimal `json:"profit" form:"profit"`       // 利润=实际收入-实际消耗  income-cost
	Roi      decimal.Decimal `json:"roi" form:"roi"`             // ROI=实际收入/实际消耗， income/cost
	ShowCost decimal.Decimal `json:"show_cost" form:"show_cost"` // 千展成本= SUM(cost)/SUM(show_count)
}

// NewTodayTimeDataReq 推推分时数据（今日）
func NewTodayTimeDataReq(c *gin.Context) *TodayTodayTimeDataReq {
	req := &TodayTodayTimeDataReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

type TodayBookRankingDataReq struct {
	common.CommonParams
	Params TodayDataParams `json:"params"`
}

type TodayBookRankingDataResp struct {
	Rank      int             `json:"rank" form:"rank"`             // 排名
	BookId    int             `json:"book_id" form:"book_id"`       // 短剧ID
	BookName  string          `json:"book_name" form:"book_name"`   // 短剧名称
	TotalCost decimal.Decimal `json:"total_cost" form:"total_cost"` // 消耗
	Cost      decimal.Decimal `json:"cost" form:"cost"`             // 实际消耗=(SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)
	Profit    decimal.Decimal `json:"profit" form:"profit"`         // 实际利润=实际收入-实际消耗  income-cost
	Roi       decimal.Decimal `json:"roi" form:"roi"`               // 实际ROI=实际收入/实际消耗， income/cost
}

// NewTodayBookRankingReq 推推今日短剧排名
func NewTodayBookRankingReq(c *gin.Context) *TodayBookRankingDataReq {
	req := &TodayBookRankingDataReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

type TodayRegionRankingReq struct {
	common.CommonParams
	Params TodayDataParams `json:"params"`
}

type TodayRegionRankingDataResp struct {
	Rank      int             `json:"rank" form:"rank"`             // 排名
	Region    string          `json:"region" form:"region"`         // 地区
	TotalCost decimal.Decimal `json:"total_cost" form:"total_cost"` // 消耗
	Cost      decimal.Decimal `json:"cost" form:"cost"`             // 实际消耗=(SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)
	Profit    decimal.Decimal `json:"profit" form:"profit"`         // 实际利润=实际收入-实际消耗  income-cost
	Roi       decimal.Decimal `json:"roi" form:"roi"`               // 实际ROI=实际收入/实际消耗， income/cost
}

// NewTodayRegionRankingReq 推推今日地区排名
func NewTodayRegionRankingReq(c *gin.Context) *TodayRegionRankingReq {
	req := &TodayRegionRankingReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}
