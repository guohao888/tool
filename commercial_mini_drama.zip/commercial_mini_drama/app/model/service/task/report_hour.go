package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	mediaRepo "goserver/app/model/service/mediareport"
)

/***********************         新授权逻辑 令牌桶方式获取消耗  start       ***********************/

///*
//	执行参数：
//	{
//		"is_history":0,
//		"is_fast":2
//	}
//*/
//// SyncReportLimitTodayFast 拉取头条消耗数据 快队列 实时数据
//func SyncReportLimitTodayFast(ctx context.Context, param *xxl.RunReq) (msg string) {
//	params := report.AccountReportSyncExecutorParams{}
//	if param.ExecutorParams != "" {
//		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
//		if err != nil {
//			return fmt.Sprintf("消耗报表快队列参数解析错误, err: %s", err)
//		}
//	}
//
//	crontabDateList, err := params.CrontabDateList()
//	if err != nil {
//		return fmt.Sprintf("同步消耗报表快队列数据时间错误, err: %s", err)
//	}
//	//
//	reportHourService := mediaRepo.NewReportHourService(ctx)
//	for _, crontabDate := range crontabDateList {
//		err = reportHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
//		if err != nil {
//			return fmt.Sprintf("同步消耗报表快队列数据失败, err: %s", err)
//		}
//	}
//	return "同步消耗报表快队列数据成功"
//}
//
///*
//	执行参数：
//	{
//		"is_history":0,
//		"is_fast":1
//	}
//*/
//
//// SyncReportLimitTodaySlow 拉取头条消耗数据 慢队列 实时数据
//func SyncReportLimitTodaySlow(ctx context.Context, param *xxl.RunReq) (msg string) {
//	params := report.AccountReportSyncExecutorParams{}
//	if param.ExecutorParams != "" {
//		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
//		if err != nil {
//			return fmt.Sprintf("消耗报表慢队列参数解析错误, err: %s", err)
//		}
//	}
//
//	crontabDateList, err := params.CrontabDateList()
//	if err != nil {
//		return fmt.Sprintf("同步消耗报表慢队列数据时间错误, err: %s", err)
//	}
//	//
//	reportHourService := mediaRepo.NewReportHourService(ctx)
//	for _, crontabDate := range crontabDateList {
//		err = reportHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
//		if err != nil {
//			return fmt.Sprintf("同步消耗报表慢队列数据失败, err: %s", err)
//		}
//	}
//	return "同步消耗报表慢队列数据成功"
//}
//
///*
//	执行参数：
//	{
//		"is_history":1,
//		"is_fast":0
//	}
//*/
//// SyncReportLimitHistory 拉取头条消耗数据 历史数据
//func SyncReportLimitHistory(ctx context.Context, param *xxl.RunReq) (msg string) {
//	params := report.AccountReportSyncExecutorParams{}
//	if param.ExecutorParams != "" {
//		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
//		if err != nil {
//			return fmt.Sprintf("消耗历史报表参数解析错误, err: %s", err)
//		}
//	}
//
//	crontabDateList, err := params.CrontabDateList()
//	if err != nil {
//		return fmt.Sprintf("同步消耗历史报表数据时间错误, err: %s", err)
//	}
//	//
//	reportHourService := mediaRepo.NewReportHourService(ctx)
//	for _, crontabDate := range crontabDateList {
//		err = reportHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
//		if err != nil {
//			return fmt.Sprintf("同步消耗历史报表数据失败, err: %s", err)
//		}
//	}
//	return "同步消耗历史报表数据成功"
//}

/***********************         新授权逻辑 令牌桶方式获取消耗  end       ***********************/

/**
{
	"is_history":0,
	"is_fast":2
}
*/

// SyncReportPromotionLimitTodaySubscribe 按照订阅消息拉取广告维度账号消耗 当日
func SyncReportPromotionLimitTodaySubscribe(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("广告级消耗参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("按照订阅消息拉取广告维度账号消耗时间错误, err: %s", err)
	}
	//
	reportHourService := mediaRepo.NewReportHourService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("按照订阅消息拉取广告维度账号消耗失败, err: %s", err)
		}
	}
	return "按照订阅消息拉取广告维度账号消耗成功"
}

/**
{
	"is_history":1,
	"is_fast":1
}
*/

// SyncReportPromotionLimitBeforeSubscribe 按照订阅消息拉取广告维度账号消耗 当日
func SyncReportPromotionLimitBeforeSubscribe(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("广告级消耗参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("按照订阅消息拉取广告维度账号消耗时间错误, err: %s", err)
	}
	//
	reportHourService := mediaRepo.NewReportHourService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportHourService.DistributeReportAccounts(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("按照订阅消息拉取广告维度账号消耗失败, err: %s", err)
		}
	}
	return "按照订阅消息拉取广告维度账号消耗成功"
}

// SyncReportPromotionLimitReplenish 按照订阅消息拉取广告维度账号消耗 当日
func SyncReportPromotionLimitReplenish(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("广告级消耗参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("按照订阅消息拉取广告维度账号消耗时间错误, err: %s", err)
	}
	//
	reportHourService := mediaRepo.NewReportHourService(ctx)
	for _, crontabDate := range crontabDateList {
		err = reportHourService.DistributeReportAccountsRe(crontabDate, ctx, params.IsFast)
		if err != nil {
			return fmt.Sprintf("按照订阅消息拉取广告维度账号消耗失败, err: %s", err)
		}
	}
	return "按照订阅消息拉取广告维度账号消耗成功"
}
