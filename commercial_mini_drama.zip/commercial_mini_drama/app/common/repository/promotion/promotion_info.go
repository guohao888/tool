package promotion

import (
	"goserver/app/common/repository"
	"time"
)

const PromotionInfoTable = "promotion_info"

const CreatePromotionDefault = 0      // state_code 默认
const CreatePromotionSuccess = 1      // state_code 成功
const CreatePromotionFanqieFailed = 2 // state_code 番茄推送失败
const CreatePromotionOceanFailed = 3  // state_code 巨量推送失败

// PromotionInfoEntity 定义 PromotionInfo 表的结构体
type PromotionInfoEntity struct {
	RequestID            string    `json:"request_id" gorm:"primaryKey;column:request_id;type:varchar(256)"`
	PromotionID          string    `json:"promotion_id" gorm:"column:promotion_id;type:varchar(256)"`
	PromotionURL         string    `json:"promotion_url" gorm:"column:promotion_url;type:varchar(256)"`
	PromotionName        string    `json:"promotion_name" gorm:"column:promotion_name;type:varchar(256)"`
	BookID               string    `json:"book_id" gorm:"column:book_id;type:varchar(256)"`
	BookName             string    `json:"book_name" gorm:"column:book_name;type:varchar(256)"`
	BookIndex            int64     `json:"book_index" gorm:"column:book_index;type:int(11)"`
	MediaSource          int64     `json:"media_source" gorm:"column:media_source;type:int(11)"`
	AdCallbackConfigID   int64     `json:"ad_callback_config_id" gorm:"column:ad_callback_config_id;type:bigint(20)"`
	AdCallbackConfigName string    `json:"ad_callback_config_name" gorm:"column:ad_callback_config_name;type:varchar(256)"`
	AdEpisode            int64     `json:"ad_episode" gorm:"column:ad_episode;type:int(11)"`
	CustomizeParams      string    `json:"customize_params" gorm:"column:customize_params;type:varchar(256)"`
	AppType              int64     `json:"app_type" gorm:"column:app_type;type:int(11)"`
	AppName              string    `json:"app_name" gorm:"column:app_name;type:varchar(256)"`
	InstanceID           int64     `json:"instance_id" gorm:"column:instance_id;type:bigint(20)"`
	AdvertiserID         int64     `json:"advertiser_id" gorm:"column:advertiser_id;type:bigint(20)"`
	AdvertiserName       string    `json:"advertiser_name" gorm:"column:advertiser_name;type:varchar(256)"`
	PackageID            int64     `json:"package_id" gorm:"column:package_id;type:int(11)"`
	PackageName          string    `json:"package_name" gorm:"column:package_name;type:varchar(256)"`
	BoundPackageID       int64     `json:"bound_package_id" gorm:"column:bound_package_id;type:bigint(20)"`
	BoundPackageName     string    `json:"bound_package_name" gorm:"column:bound_package_name;type:varchar(256)"`
	UserName             string    `json:"user_name" gorm:"column:user_name;type:varchar(256)"`
	StateCode            int64     `json:"state_code" gorm:"column:state_code;type:tinyint(4)"`
	Distributor          string    `json:"distributor" gorm:"column:distributor;type:varchar(256)"`
	DistributorID        int64     `json:"distributor_id" gorm:"column:distributor_id;type:bigint(20)"`
	PromotionNameFormat  string    `json:"promotion_name_format" gorm:"column:promotion_name_format;type:varchar(256)"`
	FailedReason         string    `json:"failed_reason" gorm:"column:failed_reason;type:varchar(100)"`
	AdvIDs               string    `json:"adv_ids" gorm:"column:adv_ids;type:varchar(2000)"`
	CreatedAt            time.Time `json:"created_at" gorm:"column:created_at;type:datetime;autoCreateTime"`
	UpdatedAt            time.Time `json:"updated_at" gorm:"column:updated_at;type:datetime;autoUpdateTime"`
}

func (*PromotionInfoEntity) TableName() string {
	return PromotionInfoTableName()
}

func PromotionInfoTableName() string {
	if repository.IsDebugTable(PromotionInfoTable) {
		return PromotionInfoTable + "_dev"
	} else {
		return PromotionInfoTable
	}
}
