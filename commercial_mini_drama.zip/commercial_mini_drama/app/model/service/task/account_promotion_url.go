package task

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/spf13/viper"
	"github.com/xxl-job/xxl-job-executor-go"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/library/playlet/xxljob"
	"goserver/app/model/service/accounts"
)

func AccountPromotionUrlSyncToutiao(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.AccountPromotionUrlSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
	}

	params.Media = repository.MediaToutiao
	if params.PoolWorkers <= 0 {
		params.PoolWorkers = 5
	}
	if params.InsertBatchSize <= 0 {
		params.InsertBatchSize = 200
	}

	accountPromotionUrlService := accounts.NewAccountPromotionUrlService(ctx)
	err := accountPromotionUrlService.SyncToutiao(params)
	if err != nil {
		log.Errorf("同步头条广告主推广链数据失败, err: %s", err)
		panic(fmt.Errorf("同步头条广告主推广链数据失败, err: %w", err))
	}
	return "同步头条广告主推广链数据成功"
}

func AccountPromotionUrlSyncToutiaoJobInfoAdd(index int, appId string, appType string, priority string) error {

	jobGroup := viper.GetInt("xxl_job_admin.job_group")
	executorHandler := fmt.Sprintf("account_promotion_url_sync_toutiao_%s_%s_%s", appType, priority, appId)
	jobDesc := fmt.Sprintf("同步头条广告主的推广链数据_%s_%s_%s", accountrepo.AppTypeDesc[appType], priority, appId)
	author := "dengcao"
	alarmEmail := "dengcao@360.cn"

	jobInfoPageListResp, err := xxljob.JobInfoPageList(xxljob.JobInfoPageListReq{
		JobGroup:        jobGroup,
		TriggerStatus:   -1,
		JobDesc:         "",
		ExecutorHandler: executorHandler,
		Author:          author,
		Start:           0,
		Length:          10,
	})
	if err != nil {
		return err
	}
	if len(jobInfoPageListResp.Data) > 0 {
		for _, v := range jobInfoPageListResp.Data {
			if v.ExecutorHandler == executorHandler {
				return nil // 存在就直接返回，不在新增
			}
		}
	}

	var executorParamDefault string
	switch appType {
	case accountrepo.AppTypeWechatApplet:
		executorParamDefault = `
{
	"advertiser_ids": [],
	"is_sync_all": true,
	"prev_days": 0,
	"pool_workers": 1,
	"app_ids": [],
	"insert_batch_size": 100
}
`
	case accountrepo.AppTypeByteMicroApp:
		executorParamDefault = `
{
	"advertiser_ids": [],
	"is_sync_all": true,
	"prev_days": 0,
	"pool_workers": 1,
	"app_ids": [],
	"insert_batch_size": 100
}
`
	}

	var scheduleConfDefault string
	var executorTimeoutDefault int
	switch priority {
	case accountrepo.PriorityHigh:
		scheduleConfDefault = fmt.Sprintf("0 %d/10 * * * ?", index%60)
		executorTimeoutDefault = 10 * 60 // 每10分钟
	case accountrepo.PriorityLow:
		scheduleConfDefault = fmt.Sprintf("0 %d 0/4 * * ?", index%60)
		executorTimeoutDefault = 4 * 60 * 60 // 每4小时
	default:
		scheduleConfDefault = fmt.Sprintf("0 %d 0/5 * * ?", index%60)
		executorTimeoutDefault = 6 * 60 * 60 // 每6小时
	}

	// 新建
	JobInfoAddResp, err := xxljob.JobInfoAdd(xxljob.JobInfoAddReq{
		JobGroup:               jobGroup,
		JobDesc:                jobDesc,
		Author:                 author,
		AlarmEmail:             alarmEmail,
		ScheduleType:           "CRON",
		ScheduleConf:           scheduleConfDefault,
		CronGenDisplay:         scheduleConfDefault,
		ScheduleConfCRON:       "",
		ScheduleConfFixRate:    "",
		ScheduleConfFixDelay:   "",
		GlueType:               "BEAN",
		ExecutorHandler:        executorHandler,
		ExecutorParam:          executorParamDefault,
		ExecutorRouteStrategy:  "FIRST",
		ChildJobID:             "",
		MisfireStrategy:        "DO_NOTHING",
		ExecutorBlockStrategy:  "SERIAL_EXECUTION",
		ExecutorTimeout:        executorTimeoutDefault,
		ExecutorFailRetryCount: 1,
		GlueRemark:             "",
		GlueSource:             "",
		TriggerStatus:          1,
	})
	if err != nil {
		return err
	}

	if JobInfoAddResp.Code != 200 {
		return errors.New("code error")
	}

	return nil
}
