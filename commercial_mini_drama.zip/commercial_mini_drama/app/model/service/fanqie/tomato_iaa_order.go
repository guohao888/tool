package fanqie

import (
	"context"
	dto "goserver/app/common/dto/fanqie"
	"goserver/app/model/dao/fanqie"
)

// TomatoIAAOrderService 番茄IAA订单Service
type TomatoIAAOrderService struct {
	Ctx context.Context
}

// NewTomatoIAAOrderService 创建上下文IAA订单Service
func NewTomatoIAAOrderService(ctx context.Context) *TomatoIAAOrderService {
	return &TomatoIAAOrderService{Ctx: ctx}
}

// SaveIAAOrderInfos 保存IAA订单数据
func (t *TomatoIAAOrderService) SaveIAAOrderInfos(req []dto.TomatoIAAOrderReq) error {
	tomatoIAAOrderDao := fanqie.NewTomatoIAAOrderDao(t.Ctx)
	err := tomatoIAAOrderDao.Req2Entity(req)
	return err
}
