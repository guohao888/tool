package fanqie

import (
	"github.com/gin-gonic/gin"
	fanqie2 "goserver/app/common/dto/fanqie"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/fanqie"
)

// TomatoAddCoefficient 新增/修改番茄IAA系数
func TomatoAddCoefficient(c *gin.Context) {
	r := response.Gin{Ctx: c}
	// 解析参数
	req := fanqie2.NewIAACoefficientReq(c)
	coefficientService := fanqie.NewTomatoIAACoefficientService(c)
	err := coefficientService.SaveIAACoefficientInfo(req.SearchDate, req.Coefficient)
	if err != nil {
		r.Response(myerror.SaveCoefficientError.Code, myerror.SaveCoefficientError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

// GetTomatoCoefficientList 番茄IAA系数列表
func GetTomatoCoefficientList(c *gin.Context) {
	r := response.Gin{Ctx: c}
	// 解析参数
	req := fanqie2.NewIAACoefficientQuery(c)
	coefficientService := fanqie.NewTomatoIAACoefficientService(c)
	res, err := coefficientService.GetIAACoefficientList(req)
	if err != nil {
		r.Response(myerror.CoefficientListError.Code, myerror.CoefficientListError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, res)
}
