package spidto

import (
	"encoding/json"
	"goserver/app/library/log"
)

// VerifyRequest 订阅验证请求结构
type VerifyRequest struct {
	Challenge int    `json:"challenge"`
	Event     string `json:"event"`
}

// BaseRequest 目标结构体  该结构获取推送数据时的结构
// 文档地址 https://open.oceanengine.com/labels/7/docs/1725097846184964?origin=left_nav
type BaseRequest struct {
	TaskID          int64   `json:"task_id"`
	MessageID       string  `json:"message_id"`
	SubscribeTaskID int64   `json:"subscribe_task_id"`
	AdvertiserIDs   []int64 `json:"advertiser_ids"`
	AccountRelation struct {
		CoreUserIDs map[string][]int64 `json:"core_user_ids"`
	} `json:"account_relation"`
	ServiceLabel string `json:"service_label"`
	PublishTime  int64  `json:"publish_time"`
	Data         struct {
		AppID       int64   `json:"app_id"`
		CoreUserID  int64   `json:"core_user_id"`
		MaterialIDs []int64 `json:"material_ids"`
	} `json:"data"`
	Timestamp int64 `json:"timestamp"`
	Nonce     int64 `json:"nonce"`
}

// BaseResp 基础响应结构
type BaseResp struct {
	StatusCode    int    `json:"StatusCode"`
	StatusMessage string `json:"StatusMessage"`
}

// VerifyResponse 订阅验证响应结构
type VerifyResponse struct {
	BaseResp  BaseResp `json:"BaseResp"`
	Challenge int64    `json:"challenge"`
}

func NewBaseResp(code int, msg string) BaseResp {
	return BaseResp{
		StatusCode:    code,
		StatusMessage: msg,
	}
}

// SpiMaterialRequest SPI素材请求结构体
type SpiMaterialRequest struct {
	MessageID       string          `json:"message_id"`
	AdvertiserIDs   []int64         `json:"advertiser_ids"`
	AccountRelation json.RawMessage `json:"account_relation"`
	ServiceLabel    string          `json:"service_label"`
	Data            json.RawMessage `json:"data"` // 改回 json.RawMessage 类型
	PublishTime     int64           `json:"publish_time"`
	Timestamp       int64           `json:"timestamp"`
	Nonce           int64           `json:"nonce"`
	SubscribeTaskID int64           `json:"subscribe_task_id"`
}

// ParseData 解析 Data 字段
func (r *SpiMaterialRequest) ParseData() (*MaterialData, error) {
	var data MaterialData

	// 首先将 Data 字段解析为字符串
	var dataStr string
	if err := json.Unmarshal(r.Data, &dataStr); err != nil {
		log.Errorf("oceanengine spi ParseData error: %v,  data: %s", err, r.Data)
		return nil, err
	}

	// 将字符串解析为 MaterialData 结构体
	if err := json.Unmarshal([]byte(dataStr), &data); err != nil {
		log.Errorf("oceanengine spi ParseData error: %v,  data: %s", err, r.Data)
		return nil, err
	}

	return &data, nil
}

// ParseAccountRelation 解析 AccountRelation 字段
func (r *SpiMaterialRequest) ParseAccountRelation() (*AccountRelation, error) {
	var relation AccountRelation
	if err := json.Unmarshal(r.AccountRelation, &relation); err != nil {
		return nil, err
	}
	return &relation, nil
}

// MaterialData 素材数据
type MaterialData struct {
	AppID       int64   `json:"app_id"`
	CoreUserID  int64   `json:"core_user_id"`
	MaterialIDs []int64 `json:"material_ids"`
}

// AccountRelation 账户关系
type AccountRelation struct {
	CoreUserIDs map[string][]int64 `json:"core_user_ids"`
}
