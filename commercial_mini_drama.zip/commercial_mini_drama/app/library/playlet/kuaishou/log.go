package kuaishou

import (
	"goserver/app/library/log"
	"resty.dev/v3"
)

var _ resty.Logger = (*Logger)(nil)

type Logger struct{}

func (l *Logger) Errorf(format string, v ...any) {
	if log.LogrusLog != nil {
		log.LogrusLog.Errorf(format, v...)
	}
}

func (l *Logger) Warnf(format string, v ...any) {
	if log.LogrusLog != nil {
		log.LogrusLog.Warnf(format, v...)
	}
}

func (l *Logger) Debugf(format string, v ...any) {
	if log.LogrusLog != nil {
		log.LogrusLog.Debugf(format, v...)
	}
}

var _ resty.Logger = (*NoneLogger)(nil)

type NoneLogger struct{}

func (n *NoneLogger) Errorf(format string, v ...any) {
}

func (n *NoneLogger) Warnf(format string, v ...any) {
}

func (n *NoneLogger) Debugf(format string, v ...any) {
}
