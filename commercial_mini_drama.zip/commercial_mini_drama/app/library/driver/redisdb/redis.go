package redisdb

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/spf13/viper"
	"time"

	"github.com/gomodule/redigo/redis"
)

var RedisPool *redis.Pool

var ErrNil = fmt.Errorf("redigo: nil returned")

type redisConfig struct {
	addr           string
	maxIdle        int
	idleTimeoutSec int
	password       string
}

func initRedisConfig() *redisConfig {
	env := viper.GetString("runmode")
	addr := viper.GetString("redis.addr")
	if addr == "" {
		panic(errors.New(env + " redis config empty"))
	}
	maxIdle := viper.GetInt("redis.max_idle")
	idleTimeoutSec := viper.GetInt("redis.idle_timeout_sec")
	password := viper.GetString("redis.password")

	return &redisConfig{
		addr:           addr,
		maxIdle:        maxIdle,
		idleTimeoutSec: idleTimeoutSec,
		password:       password,
	}
}

// NewRedisPool 返回redis连接池
func NewRedisPool() {
	config := initRedisConfig()

	RedisPool = &redis.Pool{
		MaxIdle:     config.maxIdle,
		IdleTimeout: time.Duration(config.idleTimeoutSec) * time.Second,
		Dial: func() (redis.Conn, error) {
			c, err := redis.DialURL(config.addr)
			if err != nil {
				return nil, fmt.Errorf("redis connection error: %s", err)
			}
			//验证redis密码
			if _, authErr := c.Do("AUTH", config.password); authErr != nil {
				return nil, fmt.Errorf("redis auth password error: %s", authErr)
			}
			return c, err
		},
		TestOnBorrow: func(c redis.Conn, t time.Time) error {
			_, err := c.Do("PING")
			if err != nil {
				return fmt.Errorf("ping redis error: %s", err)
			}
			return nil
		},
	}
}

func Test() {
	c := RedisPool.Get()
	defer c.Close()

	_, err := redis.String(c.Do("Ping"))
	if err != nil {
		panic(err)
	}
}

func Set(k, v string) error {
	c := RedisPool.Get()
	defer c.Close()

	_, err := c.Do("SET", k, v)

	return err
}

func Incr(k string) error {
	c := RedisPool.Get()
	defer c.Close()

	_, err := redis.Int64(c.Do("INCR", k))

	return err
}

func GetIncrValue(k string) (int64, error) {
	c := RedisPool.Get()
	defer c.Close()
	val, err := redis.Int64(c.Do("INCR", k))
	return val, err
}

func GetStringValue(k string) (string, error) {
	c := RedisPool.Get()
	defer c.Close()

	return redis.String(c.Do("GET", k))
}

func GetIntValue(k string) (int, error) {
	c := RedisPool.Get()
	defer c.Close()

	return redis.Int(c.Do("GET", k))
}

func SetKeyExpire(k string, ex int) error {
	c := RedisPool.Get()
	defer c.Close()

	_, err := c.Do("EXPIRE", k, ex)
	return err
}

func SetKeyExpireAt(k string, ex int64) error {
	c := RedisPool.Get()
	defer c.Close()

	_, err := c.Do("EXPIREAT", k, ex)
	return err
}

func CheckKey(k string) (bool, error) {
	c := RedisPool.Get()
	defer c.Close()

	return redis.Bool(c.Do("EXISTS", k))
}

func GetKeyTTL(k string) (int, error) {
	c := RedisPool.Get()
	defer c.Close()

	return redis.Int(c.Do("TTL", k))
}

func DelKey(k string) error {
	c := RedisPool.Get()
	defer c.Close()

	_, err := c.Do("DEL", k)
	if err != nil {
		return err
	}
	return nil
}

func SetJson(k string, data interface{}) error {
	c := RedisPool.Get()
	defer c.Close()

	value, _ := json.Marshal(data)
	n, _ := c.Do("SETNX", k, value)
	if n != int64(1) {
		return errors.New("set failed")
	}
	return nil
}

func GetJsonByte(k string) ([]byte, error) {
	c := RedisPool.Get()
	defer c.Close()

	jsonGet, err := redis.Bytes(c.Do("GET", k))
	if err != nil {
		return nil, err
	}
	return jsonGet, nil
}

func SetWithExpire(k, v string, seconds int64) (string, error) {
	c := RedisPool.Get()
	defer c.Close()

	reply, err := c.Do("SET", k, v, "EX", seconds)
	replyStr, _ := reply.(string)

	return replyStr, err
}
