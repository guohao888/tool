package tuitui

import (
	"bytes"
	"encoding/json"
	"goserver/app/library/log"
	"io"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"os"
)

type UploadReq struct {
	FileName string
}

type UploadRes struct {
	TransId   string `json:"trans_id"`
	ErrCode   string `json:"err_code"`
	ErrMsg    string `json:"err_msg"`
	Timestamp string `json:"timestamp"`
	TimeCost  string `json:"time_cost"`
	MediaId   string `json:"media_id"`
	Url       string `json:"url"`
}

func (c *client) DoUpload(req *UploadReq) (*UploadRes, error) {
	bodyBuf := &bytes.Buffer{}
	bodyWriter := multipart.NewWriter(bodyBuf)

	//关键的一步操作
	fileWriter, err := bodyWriter.CreateFormFile("media", req.FileName)
	if err != nil {
		log.Error("error writing to buffer")
		return nil, err
	}
	//打开文件句柄操作
	fh, err := os.Open(req.FileName)
	if err != nil {
		log.Error("error opening file")
		return nil, err
	}
	defer fh.Close()

	//iocopy
	_, err = io.Copy(fileWriter, fh)
	if err != nil {
		return nil, err
	}

	contentType := bodyWriter.FormDataContentType()
	bodyWriter.Close()

	resp, err := http.Post(GetFieldUrl, contentType, bodyBuf)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	resp_body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Errorf("[tuitui] upload file to tuitui error, err: %s", err)
		return nil, err
	}

	log.Debugf("[tuitui] upload file: %s to server, response: %s", req.FileName, string(resp_body))

	response := &UploadRes{}
	err = json.Unmarshal(resp_body, response)
	if err != nil {
		log.Errorf("[tuitui] upload file to tuitui json parse error, err: %s", err)
		return nil, err
	}

	if response.ErrCode != "0" {
		log.Errorf("[tuitui] upload file to tuitui error, err: %s", err)
		return nil, err
	}

	return response, nil
}
