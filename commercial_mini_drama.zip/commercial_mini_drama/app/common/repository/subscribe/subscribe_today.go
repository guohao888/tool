package subscribe

import "goserver/app/common/repository"

const TodaySubscribeEntityTable = "subscribe_today"

type TodaySubscribeEntity struct {
	MessageId       string `gorm:"column:message_id"`        // 消息ID，唯一标识
	SubscribeTaskId int64  `gorm:"column:subscribe_task_id"` // 订阅任务ID
	AdvertiserId    string `gorm:"column:advertiser_id"`     // 消息对应的广告主账号
	Status          int    `gorm:"column:status"`            // 拉取状态 0 未拉取  1 已拉取
}

func (*TodaySubscribeEntity) TableName() string {
	return TodaySubscribeEntityTable
}

func TodaySubscribeEntityTableName() string {
	if repository.IsDebugTable(TodaySubscribeEntityTable) {
		return TodaySubscribeEntityTable + "_dev"
	} else {
		return TodaySubscribeEntityTable
	}
}
