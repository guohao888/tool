package kuaishou

import "errors"

const (
	CodeSuccess = 0
)

type CommonRespField struct {
	Code      int    `json:"code"`
	Message   string `json:"message"`
	RequestId string `json:"request_id"`
}

var (
	RespCodeErrorAccessToken = errors.New("access token error")
)
