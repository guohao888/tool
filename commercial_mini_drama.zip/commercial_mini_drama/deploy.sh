#!/bin/sh

################ Version Info ##################
# Create Date: 2019-08-05
# Author:      hanyan
# Mail:        hanyan3@360.cn
# Version:     1.0
# Attention:   微服务编译和发布脚本
################################################

projectname=$(basename `pwd`)
exefile="mini-drama"

#shell command e.g. sh deploy.sh -d 20201225testv1 -e test delete

main() {
    if [ "$1" == "-d" ]; then
        if [ $# != 4 ] && [ $# != 5 ]; then
            echo "Usage: $0 -d versionCode -e test/online, versionCode is publish version, -e is test's env or online env's"
            exit 1
        fi
    fi

    delflag=${@: -1}
	echo "project name:$projectname"
	rm -rf $exefile
	if [ "$1" == "-b" ]; then 
		build
        if [ "$delflag" == "delete" ]; then
            delete
        fi
    elif [ "$1" == "-d" ]; then
        build  "$4"
        if [ $? == 0 ]; then
            echo "docker is packaging and upload ......"
            deploy "$@"
        fi
        if [ "$delflag" == "delete" ]; then
            delete
        fi
    else 
        echo "Usage: $0 -b"
        echo "-b indicates only build, -d indicate build and deploy"
	fi
}

build() {
    go clean
    GOOS=linux
    GOARCH=amd64
    rm -rf ./docker/release

    export GO111MODULE=on
    export GOPROXY=http://goproxy.cn

    go build -tags=jsoniter -o $exefile
    returnCode=$?
    if [ ! -d "./release/conf" ];then
        mkdir -p ./release/conf
    fi
    if [ ! -d "./release/lib" ];then
        mkdir -p ./release/lib
    fi
    mv $exefile ./release

    if [ "$1" == "online" ];then
        cp -rf ./conf/release/config.yml ./release/conf/config.yml
    elif [ "$1" == "regress" ];then
        cp -rf ./conf/debug/config.yml ./release/conf/config.yml
    else
        cp -rf ./conf/debug/config.yml ./release/conf/config.yml
    fi

    cp -rf ./cacrt ./release
    cp -rf ./conf/fonts ./release/conf

    mv release ./docker

	cp -rf ./docker/start.sh ./docker/release/start.sh
	chmod 755 ./docker/release/start.sh

    if [ "$returnCode" == 0 ] 
    then
        echo "$exefile build success !"
        return 0
    else
        echo "$exefile build fail !"
        return 1
    fi
}

deploy() {
    dockerfile="docker"
    cd $dockerfile
    if [ "$4" == "online" ];then
        output=`docker build -t $exefile:$2 .`
        output=`docker tag $exefile:$2 harbor.qihoo.net/sjwssyh-mini-drama/$exefile:$2`
        output=`docker login -u sjwssyh-mini-drama -p jylATmz5qDaf2m0JdZ harbor.qihoo.net`
        output=`docker push harbor.qihoo.net/sjwssyh-mini-drama/$exefile:$2`
        output=`docker logout harbor.qihoo.net`
    else
        output=`docker build -t $exefile"-test":$2 .`
        output=`docker tag $exefile"-test":$2 harbor.qihoo.net/sjwssyh-mini-drama/$exefile"-test":$2`
        output=`docker login -u sjwssyh-mini-drama -p jylATmz5qDaf2m0JdZ harbor.qihoo.net`
        output=`docker push harbor.qihoo.net/sjwssyh-mini-drama/$exefile"-test":$2`
        output=`docker logout harbor.qihoo.net`
    fi
}

delete() {
    rm -rf docker/release
}

main "$@"
