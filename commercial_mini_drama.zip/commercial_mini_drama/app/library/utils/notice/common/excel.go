package common

import (
	"github.com/spf13/viper"
	"os"
	"time"
)

func InitTuiTuiClient() *Client {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := NewClient(appID, secret, host)
	return client

}

func SendExcelRepostMsg(result *QueryResult, file *os.File) {
	client := InitTuiTuiClient()
	filePath := "/drama/" + result.ExcelName + "(" + time.Now().Format(time.DateOnly) + ").xlsx"
	res, err := client.UploadMediaFile(file, &MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return
	}
	msg := &GroupMessage{
		Togroups:   []string{result.GroupNum},
		Msgtype:    "attachment",
		Attachment: &Attachment{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return
	}
	return
}
