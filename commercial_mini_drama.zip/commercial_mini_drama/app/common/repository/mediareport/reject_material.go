package mediareport

import (
	"goserver/app/common/repository"
	"time"
)

const RejectMaterialEntityTable = "reject_material"

type RejectMaterialEntity struct {
	AdvertiserId  string    `gorm:"column:advertiser_id"`
	PromotionId   string    `gorm:"column:promotion_id"`
	Type          string    `gorm:"column:type"`
	Item          string    `gorm:"column:item"`
	RejectReason  string    `gorm:"column:reject_reason"`
	Suggestion    string    `gorm:"column:suggestion"`
	AuditPlatform string    `gorm:"column:audit_platform"`
	CreatedAt     time.Time `gorm:"column:created_at"`
	UpdatedAt     time.Time `gorm:"column:updated_at"`
}

func (*RejectMaterialEntity) TableName() string {
	return RejectMaterialEntityTable
}

func RejectMaterialEntityTableName() string {
	if repository.IsDebugTable(RejectMaterialEntityTable) {
		return RejectMaterialEntityTable + "_dev"
	} else {
		return RejectMaterialEntityTable
	}
}
