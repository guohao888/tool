package promotion

import (
	"github.com/gin-gonic/gin"
	promotionDto "goserver/app/common/dto/promotion"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/promotion"
)

func PackageList(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := promotionDto.NewPackageListReq(c)
	promotionService := promotion.NewNovelSaleService(c)
	pkgList, err := promotionService.GetPackageList(req)
	if err == nil {
		r.Response(myerror.OK.Code, myerror.OK.Message, pkgList)
		return
	}
	r.Response(myerror.BusinessFailure.Code, myerror.BusinessFailure.Message+err.Error(), nil)
}

func BoundPackageList(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := promotionDto.NewBoundPackageListReq(c)
	promotionService := promotion.NewNovelSaleService(c)
	pkgList, err := promotionService.GetBoundPackageList(req)
	if err == nil {
		r.Response(myerror.OK.Code, myerror.OK.Message, pkgList)
		return
	}
	r.Response(myerror.BusinessFailure.Code, myerror.BusinessFailure.Message+err.Error(), nil)
}

func BookMeta(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := promotionDto.NewBookMeatReq(c)
	promotionService := promotion.NewNovelSaleService(c)
	bookMeat, err := promotionService.GetBookMeta(req)
	if err == nil {
		r.Response(myerror.OK.Code, myerror.OK.Message, bookMeat)
		return
	}
	r.Response(myerror.BusinessFailure.Code, myerror.BusinessFailure.Message+err.Error(), nil)
}

func CallbackConfigList(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := promotionDto.NewAdCallbackConfigReq(c)
	promotionService := promotion.NewNovelSaleService(c)
	bookMeat, err := promotionService.GetAdCallbackConfigList(req)
	if err == nil {
		r.Response(myerror.OK.Code, myerror.OK.Message, bookMeat)
		return
	}
	r.Response(myerror.BusinessFailure.Code, myerror.BusinessFailure.Message+err.Error(), nil)
}

func Create(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := promotionDto.NewCreateReqReq(c)
	promotionService := promotion.NewNovelSaleService(c)
	err := promotionService.Create(req)
	if err == nil {
		r.Response(myerror.OK.Code, myerror.OK.Message, nil)
		return
	}
	r.Response(myerror.BusinessFailure.Code, myerror.BusinessFailure.Message+err.Error(), nil)
}

func Retry(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := promotionDto.NewRetryReqReq(c)
	promotionService := promotion.NewNovelSaleService(c)
	err := promotionService.Retry(req)
	if err == nil {
		r.Response(myerror.OK.Code, myerror.OK.Message, nil)
		return
	}
	r.Response(myerror.BusinessFailure.Code, myerror.BusinessFailure.Message+err.Error(), nil)
}

func ListOptions(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := promotionDto.NewListOptionsReq(c)
	promotionService := promotion.NewNovelSaleService(c)
	bookMeat, err := promotionService.ListOptions(req)
	if err == nil {
		r.Response(myerror.OK.Code, myerror.OK.Message, bookMeat)
		return
	}
	r.Response(myerror.BusinessFailure.Code, myerror.BusinessFailure.Message+err.Error(), nil)
}

func List(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := promotionDto.NewListReq(c)
	infoService := promotion.NewInfoService(c)
	filters, err := infoService.List(req)
	if err == nil {
		r.Response(myerror.OK.Code, myerror.OK.Message, filters)
		return
	}
	r.Response(myerror.BusinessFailure.Code, myerror.BusinessFailure.Message+err.Error(), nil)
}
