package product

import (
	"context"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"github.com/panjf2000/ants/v2"
	repo "goserver/app/common/repository"
	"goserver/app/common/repository/product"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
	productdao "goserver/app/model/dao/product"
	projectdao "goserver/app/model/dao/project"
	"strconv"
	"sync"
	"time"
)

// InfoProductService 账号项目Service
type InfoProductService struct {
	Ctx context.Context
}

func NewInfoProductService(ctx context.Context) *InfoProductService {
	return &InfoProductService{Ctx: ctx}
}

// SyncProductInfos 查询商品信息
func (ip *InfoProductService) SyncProductInfos(crontabTime time.Time, ctx context.Context) error {
	projectDao := projectdao.NewInfoProjectDao(ctx)
	activeList, err := projectDao.GetProductList(crontabTime.Format(time.DateOnly))
	if err != nil {
		return fmt.Errorf("查询活跃账号失败, err: %v", err)
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return fmt.Errorf("查询活跃账号为空")
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0

	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			LimitProductInfos(activeList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func LimitProductInfos(activeList []projectdao.OauthProductInfos, oauth map[string]string, appId string) {
	resChan := make(chan *product.InfoProductEntity)
	errChan := make(chan error)

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)
	once.Do(func() {
		go func() {
			insertErr := execProductInfoDB(context.Background(), resChan)
			if insertErr != nil {
				errChan <- fmt.Errorf("execProductInfoDB error: %v", insertErr)
			}
		}()
	})
	// 获取所有活跃账号及token 请求接口数据
	for _, v := range activeList {
		currentItem := v
		wg.Add(1)
		task := func() {
			defer wg.Done()
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("panic recovered: %v", x)
				}
			}()
			advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
			advertiserIdStr := currentItem.AdvertiserId
			userId := currentItem.UserId
			productPlatformId := currentItem.ProductPlatformId
			productId := currentItem.ProductId
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			// 获取MATERIAL_DATA数据
			allProductInfos, getErr := toutiao.AllProductDetail(context.Background(), toutiao.AllProductDetailReq{
				AccessToken:       oauth[userId],
				AdvertiserId:      int64(advertiserId),
				ProductPlatformId: productPlatformId,
				Filtering:         models.DpaDetailGetV2Filtering{ProductId: &productId},
			}, appId)
			if getErr != nil {
				errChan <- fmt.Errorf("执行查询失败 advertiser_id: %s, token: %s, appId: %s, error: %s", advertiserIdStr, oauth[userId], appId, getErr.Error())
			}
			// 查询无数据直接返回
			if allProductInfos == nil {
				return
			}
			for _, row := range allProductInfos {
				info := &product.InfoProductEntity{
					AdvertiserId: advertiserIdStr,
					PlatformId:   *row.PlatformId,
					ProductId:    *row.ProductId,
					Name: func() string {
						if row.Name == nil {
							return ""
						}
						return *row.Name
					}(),
					Description: func() string {
						if row.Description == nil {
							return ""
						}
						return *row.Description
					}(),
					ImageUrl: func() string {
						if row.ImageUrl == nil {
							return ""
						}
						return *row.ImageUrl
					}(),
					OnlineTime:  *row.OnlineTime,
					OfflineTime: *row.OfflineTime,
					Status:      *row.Status,
					Title: func() string {
						if row.Title == nil {
							return ""
						}
						return *row.Title
					}(),
					Video: func() string {
						if row.Video == nil {
							return ""
						}
						return *row.Video
					}(),
					CopyRightOwner: func() string {
						if row.Profession == nil {
							return ""
						}
						return (*row.Profession)["copyright_owner"]
					}(),
				}
				resChan <- info
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done() // 提交失败，减少计数器
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待所有任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan) // 确保所有任务完成后关闭通道
	}()
	// 收集所有错误
	var errs []error
	for errL := range errChan {
		errs = append(errs, errL)
	}
	return
}

// execProductInfoDB 保存项目列表
func execProductInfoDB(ctx context.Context, resChan <-chan *product.InfoProductEntity) (err error) {
	infoProductDao := productdao.NewInfoProductDao(ctx)
	// 2.3 将数据写入 report_hour
	var data = make([]*product.InfoProductEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			if dbErr := infoProductDao.InsertBatchSize(data, 5000); dbErr != nil {
				errs = append(errs, dbErr) // 收集错误，不退出
			}
			data = data[:0]
		}

	}
	if len(data) > 0 {
		dbErr := infoProductDao.InsertBatchSize(data, 5000)
		if dbErr != nil {
			errs = append(errs, dbErr)
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execProductInfoDB errors: %v", errs)
	}
	return nil
}
