package task

import (
	"context"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	"goserver/app/common/repository"
	accountsvc "goserver/app/model/service/accounts"
)

func OauthBalanceAccountSyncToutiao(ctx context.Context, param *xxl.RunReq) (msg string) {
	media := repository.MediaToutiao

	oauthBalanceAccountService := accountsvc.NewOauthBalanceAccountService(ctx)
	err := oauthBalanceAccountService.OauthBalanceAccountSyncToutiao(media)
	if err != nil {
		panic(fmt.Errorf("均衡头条管家账号下的广告主到应用失败, %w", err))
	}
	return "均衡头条管家账号下的广告主到应用"
}
