package dorisdb

import (
	"fmt"
	"github.com/jinzhu/gorm"
	"github.com/spf13/viper"
	"goserver/app/library/log"
	"time"
)

var MySQLMaxOpenConns = 20
var MySQLMaxIdleConns = 20
var MySQLConnMaxIdleTime = time.Second * 5

var dorisDB *gorm.DB

func InitDoris() error {
	MySQLConnMaxIdleTime = time.Duration(viper.GetInt("mysql_conn_max_idle_time")) * time.Second
	dbPrefix := "doris"

	host := viper.GetString(dbPrefix + ".host")
	port := viper.GetInt(dbPrefix + ".port")
	uname := viper.GetString(dbPrefix + ".uname")
	passwd := viper.GetString(dbPrefix + ".passwd")
	charset := viper.GetString(dbPrefix + ".charset")
	dbname := viper.GetString(dbPrefix + ".dbname")

	log.Debugf("connecting to doris instance, host = '%s', port = %d, uname = '%s', db = '%s', charset = '%s'. \n",
		host, port, uname, dbname, charset)

	dbConf := fmt.Sprintf("%s:%s@(%s:%d)/%s?charset=utf8&parseTime=True&loc=Local&interpolateParams=true&timeout=100s&readTimeout=100s&writeTimeout=100s", uname, passwd, host, port, dbname)
	tempDb, err := gorm.Open("mysql", dbConf)
	if nil != err {
		return err
	}

	tempDb.DB().SetMaxOpenConns(MySQLMaxOpenConns)
	tempDb.DB().SetMaxIdleConns(MySQLMaxIdleConns)
	tempDb.DB().SetConnMaxLifetime(MySQLConnMaxIdleTime)
	// 全局禁用表名复数
	tempDb.SingularTable(true) // 如果设置为true,`User`的默认表名为`user`,使用`TableName`设置的表名不受影响
	enableLog := viper.GetBool(dbPrefix + ".enable_log")
	if enableLog {
		tempDb.SetLogger(log.MysqlLog)
		tempDb.LogMode(true)
	}
	tempDb.DB().Exec("SET SESSION group_concat_max_len=-1;")

	dorisDB = tempDb

	return nil
}

func DorisClient() *gorm.DB {
	return dorisDB
}
