package tuitui

import (
	"bytes"
	"encoding/json"
	"fmt"
	"goserver/app/library/driver/rbac/rbacRedisDb"
	"goserver/app/library/log"
	"goserver/app/library/utils/httplib"
)

type AccessTokenReq struct {
	AppId  string `json:"app_id"`
	AppKey string `json:"app_key"`
	Iss    string `json:"iss"`
}

type AccessTokenRes struct {
	ErrCode string             `json:"err_code"`
	ErrMsg  string             `json:"err_msg"`
	Datas   []*AccessTokenData `json:"datas"`
}

type AccessTokenData struct {
	AccessToken string `json:"access_token"`
}

/**
@desc 获取凭证token
*/
func (c *client) GetAccessToken(refresh bool) (string, error) {
	//1.强制刷新，直接获取
	if refresh {
		return c.RemoteAccessTokenRequest()
	}
	//2.cache获取,失败强制更新
	token, err := c.getAccessTokenFromCache()
	if err != nil || len(token) == 0 {
		return c.RemoteAccessTokenRequest()
	}

	return token, err
}

/**
@desc 远程请求access token
*/
func (c *client) RemoteAccessTokenRequest() (string, error) {
	request := &AccessTokenReq{
		AppKey: c.appKey,
		AppId:  c.appId,
		Iss:    c.iss,
	}
	req, err := json.Marshal(request)
	if err != nil {
		log.Error("[tuitui] get token, json encode error, err: " + err.Error())
		return "", err
	}

	cli := httplib.NewHttpRequest(GetAccessTokenUrl)
	bodybuffer := bytes.NewBuffer(req)
	cli.SetBody(bodybuffer)
	res, err := cli.Post()
	if err != nil {
		log.Error("[tuitui] get token error, str: " + res + ", err: " + err.Error())
		return "", err
	}

	response := &AccessTokenRes{}
	err = json.Unmarshal([]byte(res), response)
	if err != nil {
		log.Error("[tuitui] get token json parse error, str: " + res + ", err: " + err.Error())
		return "", err
	}

	if response.ErrCode != "0" || response.Datas == nil || len(response.Datas) == 0 {
		log.Error("[tuitui] get token error, str: " + res + ", err: " + err.Error())
		return "", err
	}

	token := response.Datas[0].AccessToken
	c.setAccessTokenToCache(token)

	return token, nil
}

/**
@desc 获取缓存凭证token
*/
func (c *client) getAccessTokenFromCache() (string, error) {
	key := c.getAccessTokenKey()
	v, err := rbacRedisDb.GetStringValue(key)
	return v, err
}

/**
@desc 设置缓存凭证token
*/
func (c *client) setAccessTokenToCache(token string) error {
	key := c.getAccessTokenKey()
	err := rbacRedisDb.Set(key, token)
	if err != nil {
		return err
	}
	err = rbacRedisDb.SetKeyExpire(key, 2*3600-300)
	return err
}

/**
@desc token redis key
*/
func (c *client) getAccessTokenKey() string {
	key := fmt.Sprintf("tuitui:app_id:%s:access_token", c.appId)
	return key
}
