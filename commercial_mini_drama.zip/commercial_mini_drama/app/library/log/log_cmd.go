package log

import (
	"fmt"
	"github.com/natefinch/lumberjack"
	"github.com/rifflock/lfshook"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
	"path"
)

var LogCmdLog *logrus.Logger

//打点日志记录
func InitLogrusCmdLog() {
	basePath := viper.GetString("log.basedir")
	fileName := path.Join(basePath, "cmd")

	LogCmdLog = logrus.New()
	LogCmdLog.SetLevel(logrus.InfoLevel)

	LogCmdLog.SetOutput(&lumberjack.Logger{
		Filename:   fmt.Sprintf("%s.log", fileName), // 日志文件路径
		MaxSize:    viper.GetInt("log.max_size"),    // 每个日志文件保存的最大尺寸 单位：M
		MaxBackups: viper.GetInt("log.max_backups"), // 日志文件最多保存多少个备份
		MaxAge:     viper.GetInt("log.max_age"),     // 文件最多保存多少天
		Compress:   true,                            // 是否压缩
	})

	eventLogWriter, _ := getLogWriter(fileName)
	writeMap := lfshook.WriterMap{
		logrus.InfoLevel: eventLogWriter,
	}
	lfHook := lfshook.NewHook(writeMap, &logrus.JSONFormatter{
		TimestampFormat: "2006-01-02 15:04:05",
	})

	LogCmdLog.AddHook(lfHook)
}
