package warning

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common/dto/page"
	"goserver/app/common/dto/warningdto"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/optimizer"
	"goserver/app/model/service/warning"
)

// SaveOrUpdateMonitor 保存或修改盯盘任务
func SaveOrUpdateMonitor(c *gin.Context) {
	r := response.Gin{Ctx: c}

	monitorService := warning.NewMonitorService(c)
	monitorInfo := warningdto.NewMonitorInfoReq(c)
	// 增加参数校验
	if monitorInfo.Interval.IntervalValue == "" {
		r.Response(myerror.ParamsError.Code, myerror.ParamsError.Message, nil)
		return
	}
	err := monitorService.SaveOrUpdateMonitorInfo(monitorInfo)
	if err != nil { //保存数据失败
		r.Response(myerror.SaveOrUpdateMonitorError.Code, myerror.SaveOrUpdateMonitorError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

// FindMonitorList 获取盯盘任务列表
func FindMonitorList(c *gin.Context) {
	r := response.Gin{Ctx: c}

	monitorService := warning.NewMonitorService(c)
	params := warningdto.NewMonitorListReq(c)
	data, err := monitorService.GetMonitorList(params)
	if err != nil {
		r.Response(myerror.FindMonitorError.Code, myerror.FindMonitorError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, data)
}

// DeleteMonitorInfo 删除盯盘任务
func DeleteMonitorInfo(c *gin.Context) {
	r := response.Gin{Ctx: c}

	monitorService := warning.NewMonitorService(c)
	params := warningdto.NewMonitorInfoReq(c)
	err := monitorService.DeleteMonitorInfo(params)
	if err != nil {
		r.Response(myerror.DeleteMonitorError.Code, myerror.DeleteMonitorError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

func VerityAccountList(c *gin.Context) {
	r := response.Gin{Ctx: c}

	monitorService := warning.NewMonitorService(c)
	params := warningdto.NewAdvertiserVerify(c)
	list, err := monitorService.AccountVerify(params)
	if err != nil {
		r.Response(myerror.GetOptimizerAccountError.Code, myerror.GetOptimizerAccountError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, page.Paginator{List: list})
}

func GetOptimizerAccountList(c *gin.Context) {
	r := response.Gin{Ctx: c}

	optimizerService := optimizer.NewOptimizerService(c)
	list, err := optimizerService.OptimizerInfoList(nil)
	if err != nil {
		r.Response(myerror.GetOptimizerAccountError.Code, myerror.GetOptimizerAccountError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, page.Paginator{List: list})
}
