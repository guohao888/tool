package accounts

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

type OauthBalanceAccountDao struct {
	Ctx context.Context
}

func NewOauthBalanceAccountDao(ctx context.Context) *OauthBalanceAccountDao {
	return &OauthBalanceAccountDao{Ctx: ctx}
}

func (d *OauthBalanceAccountDao) InsertBatchSize(data []accountrepo.OauthBalanceAccountEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsert(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		// 如果出现错误，回滚事务
		tx.Rollback()
		return err
	}

	tx.Commit()

	return nil
}

func (d *OauthBalanceAccountDao) batchInsert(tx *gorm.DB, data []accountrepo.OauthBalanceAccountEntity) error {
	insertColumns := []string{"media", "advertiser_id", "advertiser_name", "oauth_id", "app_id", "user_id"}
	sqlStr := fmt.Sprintf("INSERT INTO "+accountrepo.OauthBalanceAccountTableName()+" (%s) VALUES ", strings.Join(insertColumns, ","))
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?),"
		vals = append(vals,
			v.Media,
			v.AdvertiserId,
			v.AdvertiserName,
			v.OauthId,
			v.AppId,
			v.UserId,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
