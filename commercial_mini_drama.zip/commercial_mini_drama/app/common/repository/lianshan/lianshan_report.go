package lianshan

import (
	"github.com/mitchellh/mapstructure"
	"goserver/app/common/repository"
)

const ReportLianshanEntityTable = "lianshan_report"

// ReportLianshanHourEntity 巨量小时项目维度消耗
type ReportLianshanHourEntity struct {
	ID                                        int64   `gorm:"column:id" json:"id"`                                                                                         // 主键id
	CreateTime                                string  `gorm:"column:create_time" json:"create_time"`                                                                       // 记录创建时间
	AdvertiserID                              int64   `gorm:"column:advertiser_id" json:"advertiser_id"`                                                                   // 账户ID
	CdpProjectID                              int64   `gorm:"column:cdp_project_id" json:"cdp_project_id"`                                                                 // 项目ID
	CdpPromotionID                            int64   `gorm:"column:cdp_promotion_id" json:"cdp_promotion_id"`                                                             // 广告ID
	StatTimeHour                              int64   `gorm:"column:stat_time_hour" json:"stat_time_hour"`                                                                 // 时间-小时
	StatCost                                  float64 `gorm:"column:stat_cost" json:"stat_cost"`                                                                           // 消耗
	ShowCnt                                   int64   `gorm:"column:show_cnt" json:"show_cnt"`                                                                             // 展示数
	ClickCnt                                  int64   `gorm:"column:click_cnt" json:"click_cnt"`                                                                           // 点击数
	ConvertCnt                                int64   `gorm:"column:convert_cnt" json:"convert_cnt"`                                                                       // 转化数
	CpmPlatform                               float64 `gorm:"column:cpm_platform" json:"cpm_platform"`                                                                     // 平均千次展现费用(元)
	Ctr                                       float64 `gorm:"column:ctr" json:"ctr"`                                                                                       // 点击率
	CpcPlatform                               float64 `gorm:"column:cpc_platform" json:"cpc_platform"`                                                                     // 平均点击单价(元)
	AttributionConvertCnt                     float64 `gorm:"column:attribution_convert_cnt" json:"attribution_convert_cnt"`                                               // 转化数(计费时间)
	AttributionConvertCost                    float64 `gorm:"column:attribution_convert_cost" json:"attribution_convert_cost"`                                             // 转化成本(计费时间)
	ConversionCost                            float64 `gorm:"column:conversion_cost" json:"conversion_cost"`                                                               // 平均转化成本
	Active                                    float64 `gorm:"column:active" json:"active"`                                                                                 // 激活数
	ActiveCost                                float64 `gorm:"column:active_cost" json:"active_cost"`                                                                       // 激活成本
	StatAttributionMicroGame24hAmount         float64 `gorm:"column:stat_attribution_micro_game_24h_amount" json:"stat_attribution_micro_game_24h_amount"`                 // 24小时变现金额（激活时间）
	AttributionMicroGame24hRoi                float64 `gorm:"column:attribution_micro_game_24h_roi" json:"attribution_micro_game_24h_roi"`                                 // 激活后24小时变现ROI
	StatMicroGame0dAmount                     float64 `gorm:"column:stat_micro_game_0d_amount" json:"stat_micro_game_0d_amount"`                                           // 原生短剧当日变现（结算）
	LandingType                               int64   `gorm:"column:landing_type" json:"landing_type"`                                                                     // 推广目的
	ExternalAction                            int64   `gorm:"column:external_action" json:"external_action"`                                                               // 转化目标
	Pricing                                   int64   `gorm:"column:pricing" json:"pricing"`                                                                               // 计费类型
	DeliveryMode                              int64   `gorm:"column:delivery_mode" json:"delivery_mode"`                                                                   // 投放模式
	AppCode                                   int64   `gorm:"column:app_code" json:"app_code"`                                                                             // 首选位置
	CampaignType                              int64   `gorm:"column:campaign_type" json:"campaign_type"`                                                                   // 广告类型
	CdpMarketingGoal                          int64   `gorm:"column:cdp_marketing_goal" json:"cdp_marketing_goal"`                                                         // 营销场景
	AttributionConversionRate                 float64 `gorm:"column:attribution_conversion_rate" json:"attribution_conversion_rate"`                                       // 转化率(计费时间)
	AttributionDeepConvertCnt                 float64 `gorm:"column:attribution_deep_convert_cnt" json:"attribution_deep_convert_cnt"`                                     // 深度转化数(计费时间)
	AttributionDeepConvertCost                float64 `gorm:"column:attribution_deep_convert_cost" json:"attribution_deep_convert_cost"`                                   // 深度转化成本(计费时间)
	AttributionDeepConvertRate                float64 `gorm:"column:attribution_deep_convert_rate" json:"attribution_deep_convert_rate"`                                   // 深度转化率(计费时间)
	ConversionRate                            float64 `gorm:"column:conversion_rate" json:"conversion_rate"`                                                               // 转化率
	DeepConvertCnt                            float64 `gorm:"column:deep_convert_cnt" json:"deep_convert_cnt"`                                                             // 深度转化数
	DeepConvertCost                           float64 `gorm:"column:deep_convert_cost" json:"deep_convert_cost"`                                                           // 深度转化成本
	DeepConvertRate                           float64 `gorm:"column:deep_convert_rate" json:"deep_convert_rate"`                                                           // 深度转化率
	ActiveRate                                float64 `gorm:"column:active_rate" json:"active_rate"`                                                                       // 激活率
	GameAddictionCost                         float64 `gorm:"column:game_addiction_cost" json:"game_addiction_cost"`                                                       // 关键行为成本
	GameAddiction                             float64 `gorm:"column:game_addiction" json:"game_addiction"`                                                                 // 关键行为数
	GameAddictionRate                         float64 `gorm:"column:game_addiction_rate" json:"game_addiction_rate"`                                                       // 关键行为率
	ActivePay                                 float64 `gorm:"column:active_pay" json:"active_pay"`                                                                         // 首次付费数
	ActivePayCost                             float64 `gorm:"column:active_pay_cost" json:"active_pay_cost"`                                                               // 首次付费成本
	ActivePayRate                             float64 `gorm:"column:active_pay_rate" json:"active_pay_rate"`                                                               // 首次付费率
	GamePayCost                               float64 `gorm:"column:game_pay_cost" json:"game_pay_cost"`                                                                   // 付费成本
	GamePayCount                              float64 `gorm:"column:game_pay_count" json:"game_pay_count"`                                                                 // 付费次数
	AttributionGamePay7dCount                 float64 `gorm:"column:attribution_game_pay_7d_count" json:"attribution_game_pay_7d_count"`                                   // 7日付费次数(激活时间)
	AttributionGamePay7dCost                  float64 `gorm:"column:attribution_game_pay_7d_cost" json:"attribution_game_pay_7d_cost"`                                     // 7日付费成本(激活时间)
	AttributionActivePay7dPerCount            float64 `gorm:"column:attribution_active_pay_7d_per_count" json:"attribution_active_pay_7d_per_count"`                       // 7日人均付费次数(激活时间)
	AttributionBillingGameInAppLtv1day        float64 `gorm:"column:attribution_billing_game_in_app_ltv_1day" json:"attribution_billing_game_in_app_ltv_1day"`             // 计费当日付费金额
	AttributionBillingGameInAppLtv2days       float64 `gorm:"column:attribution_billing_game_in_app_ltv_2days" json:"attribution_billing_game_in_app_ltv_2days"`           // 计费二日内付费金额
	AttributionBillingGameInAppLtv3days       float64 `gorm:"column:attribution_billing_game_in_app_ltv_3days" json:"attribution_billing_game_in_app_ltv_3days"`           // 计费三日内付费金额
	AttributionBillingGameInAppLtv4days       float64 `gorm:"column:attribution_billing_game_in_app_ltv_4days" json:"attribution_billing_game_in_app_ltv_4days"`           // 计费四日内付费金额
	AttributionBillingGameInAppLtv5days       float64 `gorm:"column:attribution_billing_game_in_app_ltv_5days" json:"attribution_billing_game_in_app_ltv_5days"`           // 计费五日内付费金额
	AttributionBillingGameInAppLtv6days       float64 `gorm:"column:attribution_billing_game_in_app_ltv_6days" json:"attribution_billing_game_in_app_ltv_6days"`           // 计费六日内付费金额
	AttributionBillingGameInAppLtv7days       float64 `gorm:"column:attribution_billing_game_in_app_ltv_7days" json:"attribution_billing_game_in_app_ltv_7days"`           // 计费七日内付费金额
	AttributionBillingGameInAppRoi1day        float64 `gorm:"column:attribution_billing_game_in_app_roi_1day" json:"attribution_billing_game_in_app_roi_1day"`             // 计费当日付费ROI
	AttributionBillingGameInAppRoi2days       float64 `gorm:"column:attribution_billing_game_in_app_roi_2days" json:"attribution_billing_game_in_app_roi_2days"`           // 计费二日内付费ROI
	AttributionBillingGameInAppRoi3days       float64 `gorm:"column:attribution_billing_game_in_app_roi_3days" json:"attribution_billing_game_in_app_roi_3days"`           // 计费三日内付费ROI
	AttributionBillingGameInAppRoi4days       float64 `gorm:"column:attribution_billing_game_in_app_roi_4days" json:"attribution_billing_game_in_app_roi_4days"`           // 计费四日内付费ROI
	AttributionBillingGameInAppRoi5days       float64 `gorm:"column:attribution_billing_game_in_app_roi_5days" json:"attribution_billing_game_in_app_roi_5days"`           // 计费五日内付费ROI
	AttributionBillingGameInAppRoi6days       float64 `gorm:"column:attribution_billing_game_in_app_roi_6days" json:"attribution_billing_game_in_app_roi_6days"`           // 计费六日内付费ROI
	AttributionBillingGameInAppRoi7days       float64 `gorm:"column:attribution_billing_game_in_app_roi_7days" json:"attribution_billing_game_in_app_roi_7days"`           // 计费七日内付费ROI
	AttributionActivePayCost                  float64 `gorm:"column:attribution_active_pay_cost" json:"attribution_active_pay_cost"`                                       // 首次付费成本(计费时间)
	AttributionActivePayRate                  float64 `gorm:"column:attribution_active_pay_rate" json:"attribution_active_pay_rate"`                                       // 首次付费率(计费时间)
	StatPayAmount                             float64 `gorm:"column:stat_pay_amount" json:"stat_pay_amount"`                                                               // 付费金额(回传时间)
	PayAmountRoi                              float64 `gorm:"column:pay_amount_roi" json:"pay_amount_roi"`                                                                 // 付费ROI(回传时间)
	AttributionGameAddictionPayConversionRate float64 `gorm:"column:attribution_game_addiction_pay_conversion_rate" json:"attribution_game_addiction_pay_conversion_rate"` // 行为付费率（计费时间）
	AttributionMicroGame0dLtv                 float64 `gorm:"column:attribution_micro_game_0d_ltv" json:"attribution_micro_game_0d_ltv"`                                   // 小程序/小游戏当日LTV
	AttributionMicroGame3dLtv                 float64 `gorm:"column:attribution_micro_game_3d_ltv" json:"attribution_micro_game_3d_ltv"`                                   // 小程序/小游戏激活后三日LTV
	AttributionMicroGame7dLtv                 float64 `gorm:"column:attribution_micro_game_7d_ltv" json:"attribution_micro_game_7d_ltv"`                                   // 小程序/小游戏激活后七日LTV
	AttributionMicroGame0dRoi                 float64 `gorm:"column:attribution_micro_game_0d_roi" json:"attribution_micro_game_0d_roi"`                                   // 小程序/小游戏当日广告变现ROI
	AttributionMicroGame3dRoi                 float64 `gorm:"column:attribution_micro_game_3d_roi" json:"attribution_micro_game_3d_roi"`                                   // 小程序/小游戏激活后三日广告变现ROI
	AttributionMicroGame7dRoi                 float64 `gorm:"column:attribution_micro_game_7d_roi" json:"attribution_micro_game_7d_roi"`                                   // 小程序/小游戏激活后七日广告变现ROI
	AttributionMicroGameIaapLtv1day           float64 `gorm:"column:attribution_micro_game_iaap_ltv_1day" json:"attribution_micro_game_iaap_ltv_1day"`                     // 小程序/小游戏当日内购&变现收入（激活时间）
	AttributionMicroGameIaapRoi1day           float64 `gorm:"column:attribution_micro_game_iaap_roi_1day" json:"attribution_micro_game_iaap_roi_1day"`                     // 小程序/小游戏当日内购&变现ROI（激活时间）
	AttributionEffectActive30dCount           float64 `gorm:"column:attribution_effect_active_30d_count" json:"attribution_effect_active_30d_count"`                       // 有效激活数
	AttributionEffectActive30dCost            float64 `gorm:"column:attribution_effect_active_30d_cost" json:"attribution_effect_active_30d_cost"`                         // 有效激活成本
	AttributionMicroGameIaapLtv24h            float64 `gorm:"column:attribution_micro_game_iaap_ltv_24h" json:"attribution_micro_game_iaap_ltv_24h"`                       // 24小时综合流水（激活时间）
	AttributionMicroGameIaapLtv24hRoi         float64 `gorm:"column:attribution_micro_game_iaap_ltv_24h_roi" json:"attribution_micro_game_iaap_ltv_24h_roi"`               // 24小时综合ROI（激活时间）
	AttributionMicroGameIaapLtv7d             float64 `gorm:"column:attribution_micro_game_iaap_ltv_7d" json:"attribution_micro_game_iaap_ltv_7d"`                         // 7日综合流水（激活时间）
	AttributionMicroGameIaapLtv7dRoi          float64 `gorm:"column:attribution_micro_game_iaap_ltv_7d_roi" json:"attribution_micro_game_iaap_ltv_7d_roi"`                 // 7日综合ROI（激活时间）
	StatAttributionMicroGame7dAmount          float64 `gorm:"column:stat_attribution_micro_game_7d_amount" json:"stat_attribution_micro_game_7d_amount"`                   // 7日变现金额（激活时间）
	StatMicroGameIaapIaaCost                  float64 `gorm:"column:stat_micro_game_iaap_iaa_cost" json:"stat_micro_game_iaap_iaa_cost"`                                   // 消耗（混变广告变现部分）（元）
	AttributionMicroGameIaapIaa7dRoi          float64 `gorm:"column:attribution_micro_game_iaap_iaa_7d_roi" json:"attribution_micro_game_iaap_iaa_7d_roi"`                 // 混变-7日广告变现roi（激活时间）
	StatMicroGameIaapIapCost                  float64 `gorm:"column:stat_micro_game_iaap_iap_cost" json:"stat_micro_game_iaap_iap_cost"`                                   // 消耗（混变付费部分）（元）
	AttributionMicroGameIaapIapRoi8days       float64 `gorm:"column:attribution_micro_game_iaap_iap_roi_8days" json:"attribution_micro_game_iaap_iap_roi_8days"`           // 混变-7日付费roi（激活时间）
	AttributionBillingMicroGame0dLtv          float64 `gorm:"column:attribution_billing_micro_game_0d_ltv" json:"attribution_billing_micro_game_0d_ltv"`                   // 小程序/小游戏当日LTV(计费时间）
	AttributionBillingMicroGame7dLtv          float64 `gorm:"column:attribution_billing_micro_game_7d_ltv" json:"attribution_billing_micro_game_7d_ltv"`                   // 小程序/小游戏七日LTV（计费时间）
	AttributionBillingMicroGame0dRoi          float64 `gorm:"column:attribution_billing_micro_game_0d_roi" json:"attribution_billing_micro_game_0d_roi"`                   // 小程序/小游戏当日变现ROI（计费时间）
	StatAttributionBillingMicroGame24hAmount  float64 `gorm:"column:stat_attribution_billing_micro_game_24h_amount" json:"stat_attribution_billing_micro_game_24h_amount"` // 小程序/小游戏24小时变现金额（计费时间）
	StatAttributionBillingMicroGame3dAmount   float64 `gorm:"column:stat_attribution_billing_micro_game_3d_amount" json:"stat_attribution_billing_micro_game_3d_amount"`   // 小程序/小游戏三日变现金额（计费时间）
	StatAttributionBillingMicroGame7dAmount   float64 `gorm:"column:stat_attribution_billing_micro_game_7d_amount" json:"stat_attribution_billing_micro_game_7d_amount"`   // 小程序/小游戏七日变现金额（计费时间）
	AttributionBillingMicroGame24hRoi         float64 `gorm:"column:attribution_billing_micro_game_24h_roi" json:"attribution_billing_micro_game_24h_roi"`                 // 小程序/小游戏24小时ROI（计费时间）
	AttributionBillingMicroGame3dRoi          float64 `gorm:"column:attribution_billing_micro_game_3d_roi" json:"attribution_billing_micro_game_3d_roi"`                   // 小程序/小游戏三日变现ROI（计费时间）
	AttributionBillingMicroGame7dRoi          float64 `gorm:"column:attribution_billing_micro_game_7d_roi" json:"attribution_billing_micro_game_7d_roi"`                   // 小程序/小游戏七日变现ROI（计费时间）
	AttributionGameInAppLtv1day               float64 `gorm:"column:attribution_game_in_app_ltv_1day" json:"attribution_game_in_app_ltv_1day"`                             // 当日付费金额
	AttributionGameInAppLtv2days              float64 `gorm:"column:attribution_game_in_app_ltv_2days" json:"attribution_game_in_app_ltv_2days"`                           // 激活后一日付费金额
	AttributionGameInAppLtv3days              float64 `gorm:"column:attribution_game_in_app_ltv_3days" json:"attribution_game_in_app_ltv_3days"`                           // 激活后二日付费金额
	AttributionGameInAppLtv4days              float64 `gorm:"column:attribution_game_in_app_ltv_4days" json:"attribution_game_in_app_ltv_4days"`                           // 激活后三日付费金额
	AttributionGameInAppLtv5days              float64 `gorm:"column:attribution_game_in_app_ltv_5days" json:"attribution_game_in_app_ltv_5days"`                           // 激活后四日付费金额
	AttributionGameInAppLtv6days              float64 `gorm:"column:attribution_game_in_app_ltv_6days" json:"attribution_game_in_app_ltv_6days"`                           // 激活后五日付费金额
	AttributionGameInAppLtv7days              float64 `gorm:"column:attribution_game_in_app_ltv_7days" json:"attribution_game_in_app_ltv_7days"`                           // 激活后六日付费金额
	AttributionGameInAppLtv8days              float64 `gorm:"column:attribution_game_in_app_ltv_8days" json:"attribution_game_in_app_ltv_8days"`                           // 激活后七日付费金额
	AttributionActivePayIntraOneDayCount      float64 `gorm:"column:attribution_active_pay_intra_one_day_count" json:"attribution_active_pay_intra_one_day_count"`         // 激活后24h首次付费数
	ActivePayIntraDayCost                     float64 `gorm:"column:active_pay_intra_day_cost" json:"active_pay_intra_day_cost"`                                           // 激活当日首次付费成本
	AttributionActivePayIntraOneDayCost       float64 `gorm:"column:attribution_active_pay_intra_one_day_cost" json:"attribution_active_pay_intra_one_day_cost"`           // 激活后24h首次付费成本
	AttributionActivePayIntraOneDayAmount     float64 `gorm:"column:attribution_active_pay_intra_one_day_amount" json:"attribution_active_pay_intra_one_day_amount"`       // 激活后24h付费金额
	FirstPayIntra24hourAmount                 float64 `gorm:"column:first_pay_intra_24hour_amount" json:"first_pay_intra_24hour_amount"`                                   // 首次付费后24h内付费金额
	StatTime                                  string  `gorm:"column:stat_time" json:"stat_time"`                                                                           // 数据产生时间
	UID                                       string  `gorm:"column:uid" json:"uid"`                                                                                       // 对应docId
	UpdateTime                                string  `gorm:"column:update_time" json:"update_time"`                                                                       // 记录修改时间
}

func (*ReportLianshanHourEntity) TableName() string {
	return ReportLianshanEntityTable
}

func ReportLianshanHourTableName() string {
	if repository.IsDebugTable(ReportLianshanEntityTable) {
		return ReportLianshanEntityTable + "_dev"
	} else {
		return ReportLianshanEntityTable
	}
}

func ConvertToStruct(listMap []map[string]interface{}) (list []ReportLianshanHourEntity) {
	for _, data := range listMap {
		var p ReportLianshanHourEntity
		config := &mapstructure.DecoderConfig{
			TagName:          "json", // 使用标签匹配
			Result:           &p,     // 结果指针
			WeaklyTypedInput: true,   // 允许弱类型转换
		}
		decoder, _ := mapstructure.NewDecoder(config)
		decoder.Decode(data)
		list = append(list, p)
	}
	return
}
