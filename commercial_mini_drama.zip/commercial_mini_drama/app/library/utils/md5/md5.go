package md5

import (
	"crypto/md5"
	"encoding/hex"
)

func GetStringMd5(s string) string {
	md5util := md5.New()
	md5util.Write([]byte(s))
	md5Str := hex.EncodeToString(md5util.Sum(nil))
	return md5Str
}
