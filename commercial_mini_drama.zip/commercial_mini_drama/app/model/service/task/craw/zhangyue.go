package craw

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"github.com/PuerkitoBio/goquery"
	"github.com/xuri/excelize/v2"
	"github.com/xxl-job/xxl-job-executor-go"
	"goserver/app/library/utils/notice/common"
	"io"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"regexp"
	"strings"
	"time"
)

const BusinessTypeZhangYue = 3

func SyncCrawZhangYueData(ctx context.Context, param *xxl.RunReq) (msg string) {

	config, err := getCrawConfig(BusinessTypeZhangYue)
	if err != nil {
		return fmt.Sprintf("获取配置失败: %v", err)
	}
	cookies := ParseCookie(config.ReqCurl)
	// 2. 设置 Headers
	headers := http.Header{
		"accept":                    {"text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"},
		"accept-language":           {"zh-CN,zh;q=0.9"},
		"cache-control":             {"max-age=0"},
		"priority":                  {"u=0, i"},
		"referer":                   {"https://docs.qq.com/sheet/DUGxxR3ZMS2ZZQm9r?tab=BB08J2"},
		"sec-ch-ua":                 {"\"Not;A=Brand\";v=\"99\", \"Google Chrome\";v=\"139\", \"Chromium\";v=\"139\""},
		"sec-ch-ua-mobile":          {"?0"},
		"sec-ch-ua-platform":        {"\"Windows\""},
		"sec-fetch-dest":            {"document"},
		"sec-fetch-mode":            {"navigate"},
		"sec-fetch-site":            {"same-origin"},
		"sec-fetch-user":            {"?1"},
		"upgrade-insecure-requests": {"1"},
		"user-agent":                {"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36"},
	}

	// 3. 创建 CookieJar
	jar, err := cookiejar.New(nil)
	if err != nil {
		return fmt.Sprintf("创建 CookieJar 失败: %v", err)
	}

	// 4. 解析基础 URL
	baseURL, err := url.Parse("https://docs.qq.com")
	if err != nil {
		return fmt.Sprintf("解析基础 URL 失败: %v", err)
	}

	// 5. 构建 Cookies 列表
	cookiesList := []*http.Cookie{}
	for name, value := range cookies {
		// 特殊处理 RT Cookie，因为它包含特殊字符和空格
		if name == "RT" {
			// 直接使用原始值，包括双引号
			cookie := &http.Cookie{
				Name:     name,
				Value:    value,
				Domain:   baseURL.Host,
				Path:     "/",
				HttpOnly: false,
			}
			cookiesList = append(cookiesList, cookie)
		} else {
			cookie := &http.Cookie{
				Name:     name,
				Value:    value,
				Domain:   baseURL.Host,
				Path:     "/",
				HttpOnly: false,
			}
			cookiesList = append(cookiesList, cookie)
		}
	}

	// 6. 设置 Cookies 到 CookieJar
	jar.SetCookies(baseURL, cookiesList)

	// 7. 创建 HTTP 客户端
	client := &http.Client{
		Jar: jar,
	}

	// 8. 第一次 GET 请求：获取表格页面
	firstURL := "https://docs.qq.com/sheet/DUGxxR3ZMS2ZZQm9r?tab=BB08J2&_t=1755767983898&nlc=1"
	req, err := http.NewRequest("GET", firstURL, nil)
	if err != nil {
		return fmt.Sprintf("创建 GET 请求失败: %v", err)
	}
	req.Header = headers

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Sprintf("发送 GET 请求失败: %v", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		bodyBytes, _ := io.ReadAll(resp.Body)
		return fmt.Sprintf("GET 请求失败，状态码: %d, 响应内容: %s", resp.StatusCode, bodyBytes)
	}

	htmlContent, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Sprintf("读取响应内容失败: %v", err)
	}

	// 9. 使用 goquery 解析 HTML 并提取 src
	doc, err := goquery.NewDocumentFromReader(bytes.NewReader(htmlContent))
	if err != nil {
		return fmt.Sprintf("使用 goquery 解析 HTML 失败: %v", err)
	}

	var src string
	// 尝试通过 ID 选择器提取 src
	doc.Find("#opendoc-jsonp").Each(func(i int, s *goquery.Selection) {
		srcAttr, exists := s.Attr("src")
		if exists {
			src = srcAttr
		}
	})

	if src == "" {
		// 如果通过 ID 选择器未找到，尝试通过属性选择器
		doc.Find("script[src*='opendoc-jsonp']").Each(func(i int, s *goquery.Selection) {
			srcAttr, exists := s.Attr("src")
			if exists {
				src = srcAttr
				return // 找到第一个匹配项后退出
			}
		})
	}

	if src == "" {
		return "未找到 src URL"
	}

	// 确保 src 以 http 或 https 开头
	if !strings.HasPrefix(src, "http") {
		if strings.HasPrefix(src, "//") {
			src = "https:" + src
		} else {
			src = "https:" + src
		}
	} else if strings.HasPrefix(src, "//") {
		src = "https:" + src
	}

	// 10. 第二次 GET 请求：获取 src URL 的内容
	req2, err := http.NewRequest("GET", src, nil)
	if err != nil {
		return fmt.Sprintf("创建 GET 请求失败: %v", err)
	}
	req2.Header = headers

	resp2, err := client.Do(req2)
	if err != nil {
		return fmt.Sprintf("发送 GET 请求失败: %v", err)
	}
	defer resp2.Body.Close()

	if resp2.StatusCode != http.StatusOK {
		bodyBytes, _ := io.ReadAll(resp2.Body)
		return fmt.Sprintf("GET 请求失败，状态码: %d, 响应内容: %s", resp2.StatusCode, bodyBytes)
	}

	htmlContent2, err := io.ReadAll(resp2.Body)
	if err != nil {
		return fmt.Sprintf("读取响应内容失败: %v", err)
	}

	// 11. 使用正则表达式提取 globalPadId
	// 假设响应中包含类似 clientVarsCallback({...}) 的内容
	re := regexp.MustCompile(`clientVarsCallback\((.*?)\)`)
	matches := re.FindStringSubmatch(string(htmlContent2))
	if len(matches) < 2 {
		return fmt.Sprintf("未找到 globalPadId")
	}

	clientVarsJSON := matches[1]

	// 12. 解析 clientVars JSON
	var clientVars map[string]interface{}
	if err := json.Unmarshal([]byte(clientVarsJSON), &clientVars); err != nil {

		return fmt.Sprintf("解析 clientVars JSON 失败: %v", err)
	}

	// 假设 clientVars 结构为 {"clientVars": {"globalPadId": "someValue"}}
	globalPadIdInterface, ok := clientVars["clientVars"]
	if !ok {
		return fmt.Sprintf("未能找到 'clientVars' 字段")
	}

	clientVarsMap, ok := globalPadIdInterface.(map[string]interface{})
	if !ok {

		return fmt.Sprintf("'clientVars' 不是一个 map")
	}

	globalPadId, ok := clientVarsMap["globalPadId"].(string)
	if !ok {
		// cookie可能失效导致不存在，推推提醒
		content := "日期" + time.Now().Format("2006-01-02 15:04:05") + "\n【掌阅】Cookie已过期，请更换cookie信息"

		err := common.SendTuituiTextMsg(content, GroupNum, strings.Split(AtPersonOfCookie, ",")...)
		if err != nil {
			return fmt.Sprintf("发送提醒失败: %v", err)
		}
		return fmt.Sprintf("'globalPadId' 不是一个字符串")
	}

	// 13. 准备 POST 请求的数据
	// 根据你的 Python 代码，数据是以 x-www-form-urlencoded 形式发送的
	data := url.Values{}
	data.Add("exportType", "0")
	data.Add("switches", `{"embedFonts":false}`)
	data.Add("exportSource", "client")
	data.Add("docId", globalPadId)
	data.Add("version", "2")

	// 14. 发送 POST 请求到导出接口
	exportURL := "https://docs.qq.com/v1/export/export_office"
	req3, err := http.NewRequest("POST", exportURL, strings.NewReader(data.Encode()))
	if err != nil {
		return fmt.Sprintf("创建 POST 请求失败: %v", err)

	}
	req3.Header = headers
	req3.Header.Set("Content-Type", "application/x-www-form-urlencoded")

	resp3, err := client.Do(req3)
	if err != nil {
		return fmt.Sprintf("发送 POST 请求失败: %v", err)

	}
	defer resp3.Body.Close()

	if resp3.StatusCode != http.StatusOK {
		bodyBytes, _ := io.ReadAll(resp3.Body)
		return fmt.Sprintf("POST 请求失败，状态码: %d, 响应内容: %s", resp3.StatusCode, bodyBytes)
	}

	// 15. 解析 POST 响应的 JSON
	var exportResponse map[string]interface{}
	if err := json.NewDecoder(resp3.Body).Decode(&exportResponse); err != nil {
		return fmt.Sprintf("解析 POST 响应 JSON 失败: %v", err)
	}

	operationId, ok := exportResponse["operationId"].(string)
	if !ok {
		return fmt.Sprintf("未找到 'operationId'")
	}

	// 16. 等待 3 秒
	time.Sleep(3 * time.Second)

	// 17. 发送 GET 请求查询进度
	progressURL := "https://docs.qq.com/v1/export/query_progress"
	params := url.Values{}
	params.Add("operationId", operationId)
	progressReq, err := http.NewRequest("GET", progressURL+"?"+params.Encode(), nil)
	if err != nil {
		return fmt.Sprintf("创建进度查询请求失败: %v", err)
	}
	progressReq.Header = headers

	progressResp, err := client.Do(progressReq)
	if err != nil {
		return fmt.Sprintf("发送进度查询请求失败: %v", err)
	}
	defer progressResp.Body.Close()

	if progressResp.StatusCode != http.StatusOK {
		bodyBytes, _ := io.ReadAll(progressResp.Body)
		return fmt.Sprintf("进度查询请求失败，状态码: %d, 响应内容: %s", progressResp.StatusCode, bodyBytes)
	}

	// 18. 解析进度响应的 JSON
	var progressResponse map[string]interface{}
	if err := json.NewDecoder(progressResp.Body).Decode(&progressResponse); err != nil {
		return fmt.Sprintf("解析进度响应 JSON 失败: %v", err)
	}

	fileURL, ok := progressResponse["file_url"].(string)
	if !ok {
		return fmt.Sprintf("未找到 'file_url'")
	}

	// 19. 发送 GET 请求下载文件
	downloadReq, err := http.NewRequest("GET", fileURL, nil)
	if err != nil {
		return fmt.Sprintf("创建下载请求失败: %v", err)
	}
	downloadReq.Header = headers

	downloadResp, err := client.Do(downloadReq)
	if err != nil {
		return fmt.Sprintf("发送下载请求失败: %v", err)

	}
	defer downloadResp.Body.Close()

	if downloadResp.StatusCode != http.StatusOK {
		bodyBytes, _ := io.ReadAll(downloadResp.Body)
		return fmt.Sprintf("下载请求失败，状态码: %d, 响应内容: %s", downloadResp.StatusCode, bodyBytes)

	}

	file, err := excelize.OpenReader(downloadResp.Body)
	if err != nil {
		return fmt.Sprintf("打开文件失败: %v", err)
	}
	defer file.Close()

	var zhangYue []*ResultData
	for key, sheet := range file.GetSheetList() {
		// 获取sheet1 的数据
		if key > 0 {
			continue
		}
		rows, err := file.GetRows(sheet)
		if err != nil {
			return fmt.Sprintf("获取行数据失败: %v", err)
		}
		//     1. 【工作表1】中的C列和J列数据，每次文档更新时只抓取增量数据
		for k, row := range rows {
			if k == 0 {
				continue
			}
			var zhangyue = &ResultData{
				BookName:       row[2],
				ReferralUrl:    row[9],
				CopyrightOwner: "掌阅",
				CreatedTime:    time.Now(),
				HashID:         ParseUrl(row[9]),
			}
			if zhangyue.ReferralUrl == "" {
				continue
			}
			zhangYue = append(zhangYue, zhangyue)

		}
		// 保存入库
		err = saveToDatabase(ctx, zhangYue)
		if err != nil {
			return fmt.Sprintf("保存数据失败: %v", err)
		}
	}
	return "success"
}
