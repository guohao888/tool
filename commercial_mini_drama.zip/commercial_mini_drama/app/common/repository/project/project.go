package project

import (
	"goserver/app/common/repository"
)

const InfoProjectEntityTable = "project_info"

type InfoProjectEntity struct {
	AdvertiserId        int64   `gorm:"column:advertiser_id"`         // 广告账户id
	ProjectId           int64   `gorm:"column:project_id"`            // 项目ID
	DeliveryMode        string  `gorm:"column:delivery_mode"`         // 投放模式，允许值：MANUAL手动投放、PROCEDURAL自动投放
	DeliveryType        string  `gorm:"column:delivery_type"`         // 投放类型，允许值 NORMAL 常规投放（默认） DURATION 周期稳投（搜索场景下为极速智投）
	LandingType         string  `gorm:"column:landing_type"`          // 推广目的，枚举值：APP 应用推广、LINK 销售线索推广、MICRO_GAME小程序、QUICK_APP快应用
	AppPromotionType    string  `gorm:"column:app_promotion_type"`    // 子目标，枚举值：DOWNLOAD 应用下载、LAUNCH 应用调用、RESERVE 预约下载
	MarketingGoal       string  `gorm:"column:marketing_goal"`        // 营销场景，枚举值：VIDEO_AND_IMAGE 短视频/图片、LIVE直播
	AdType              string  `gorm:"column:ad_type"`               // 广告类型，枚举值：ALL所有广告，SEARCH 搜索广告
	OptStatus           string  `gorm:"column:opt_status"`            // 目标操作，枚举值：ENABLE 启用项目、DISABLE暂停项目
	Name                string  `gorm:"column:name"`                  // 项目名称
	ProjectCreateTime   string  `gorm:"column:project_create_time"`   // 项目创建时间，格式yyyy-MM-dd HH:mm:ss
	ProjectModifyTime   string  `gorm:"column:project_modify_time"`   // 项目更新时间，格式yyyy-MM-dd HH:mm:ss
	Status              string  `gorm:"column:status"`                // 项目状态
	Pricing             string  `gorm:"column:pricing"`               // 出价方式
	PackageName         string  `gorm:"column:package_name"`          // 应用包名
	AppName             string  `gorm:"column:app_name"`              // 应用名
	FeedDeliverySearch  string  `gorm:"column:feed_delivery_search"`  // 搜索快投关键词功能，HAS_OPEN:启用，DISABLED:未启用
	SearchBidRatio      float64 `gorm:"column:search_bid_ratio"`      // 出价系数
	AudienceExtend      string  `gorm:"column:audience_extend"`       // 定向拓展
	Keywords            string  `gorm:"column:keywords"`              // 搜索关键词列表
	RelatedProduct      string  `gorm:"column:related_product"`       // 关联产品投放相关
	DeliveryProduct     string  `gorm:"column:delivery_product"`      // 推广产品，枚举值 NONE：无产品 APP ：应用 PRODUCT：商品 WECHAT_GAME：微信小游戏 WECHAT_APP：微信小程序 BYTE_GAME：字节小游戏 BYTE_APP：字节小程序 QUICK_APP：快应用 AWEME：抖音号
	DeliveryMedium      string  `gorm:"column:delivery_medium"`       // 单投放载体，枚举值 WECHAT_GAME：微信小游戏 WECHAT_APP：微信小程序 BYTE_GAME：字节小游戏 BYTE_APP：字节小程序 PRODUCT：商品 ORANGE： 橙子落地页 THIRDPARTY ：自研落地页 ENTERPRISE ：企业号落地页 AWEME： 抖音号 QUICK_APP：快应用 APP：应用 LANDING_PAGE_LINK：落地页
	MultiDeliveryMedium string  `gorm:"column:multi_delivery_medium"` // 多投放载体，仅当landing_type = LINK 销售线索推广目的下会返回 对应创建项目时的参数multi_asset_type多投放载体 枚举值： ORANGE_AND_AWEME优选投放橙子落地页和抖音主页
	DownloadUrl         string  `gorm:"column:download_url"`          // 下载链接
	DownloadType        string  `gorm:"column:download_type"`         // 下载方式，枚举值：DOWNLOAD_URL 直接下载、EXTERNAL_URL 落地页下载
	DownloadMode        string  `gorm:"column:download_mode"`         // 优先从系统应用商店下载（下载模式），枚举值：APP_STORE_DELIVERY 优先商店下载、 DEFAULT 默认下载
	LaunchType          string  `gorm:"column:launch_type"`           // 调起方式，枚举值： DIRECT_OPEN 直接调起、EXTERNAL_OPEN 落地页调起
	PromotionType       string  `gorm:"column:promotion_type"`        // 投放内容，允许值：AWEME_HOME_PAGE抖音主页、LANDING_PAGE_LINK落地页
	AssetType           string  `gorm:"column:asset_type"`            // 资产类型，允许值： ORANGE 橙子落地页、THIRDPARTY自研落地页、ENTERPRISE 企业号落地页、AWEME_HOME_PAGE 抖音主页、MICRO_APP字节小程序、WECHAT_APPLET微信小程序
	MicroPromotionType  string  `gorm:"column:micro_promotion_type"`  // 小程序类型，允许值： BYTE_APP 字节小程序、BYTE_GAME字节小游戏、WECHAT_APP 微信小程序、WECHAT_GAME 微信小游戏、AWEME抖音号
	MicroAppInstanceId  int64   `gorm:"column:micro_app_instance_id"` // 字节小程序/小游戏资产id
	OptimizeGoal        string  `gorm:"column:optimize_goal"`         // 优化目标
	ValueOptimizedType  string  `gorm:"column:value_optimized_type"`  // 目标优化类型
	DeliveryRange       string  `gorm:"column:delivery_range"`        // 广告版位
	Audience            string  `gorm:"column:audience"`              // 定向设置
	Bid                 float64 `gorm:"column:bid"`                   // 出价
}

func (InfoProjectEntity) TableName() string {
	return InfoProjectEntityTable
}

func InfoProjectEntityTableName() string {
	if repository.IsDebugTable(InfoProjectEntityTable) {
		return InfoProjectEntityTable + "_dev"
	} else {
		return InfoProjectEntityTable
	}
}

type Keywords struct {
	BidType   string `json:"bid_type,omitempty"`   // 出价类型。 允许值:FEED_TO_SEARCH 搜索快投
	MatchType string `json:"match_type,omitempty"` // 匹配类型，允许值: PHRASE短语匹配，EXTENSIVE广泛匹配，PRECISION精准匹配
	Word      string `json:"word,omitempty"`       // 关键词
}

type RelatedProduct struct {
	ProductId         string     `json:"product_id,omitempty"`          // 产品ID
	ProductPlatformId int64      `json:"product_platform_id,omitempty"` // 产品ID列表
	ProductSetting    string     `json:"product_setting,omitempty"`     // 商品库设置，枚举值：SINGLE 启用SDPA、NO_MAP不启用、MULTI_PRODUCTS多品投放
	Products          []Products `json:"products,omitempty"`            // 产品ID列表
	UniqueProductId   int64      `json:"unique_product_id,omitempty"`   // 线索版产品ID，此ID也是【商品广告-获取线索商品列表】获取到的product_id
}

type Products struct {
	AssetId           int64  `json:"asset_id,omitempty"`            // 投放条件ID
	ProductId         string `json:"product_id,omitempty"`          // 产品ID
	ProductPlatformId int64  `json:"product_platform_id,omitempty"` // 产品库ID
	UniqueProductId   int64  `json:"unique_product_id,omitempty"`   // 线索版产品ID，此ID也是【商品广告-获取线索商品列表】获取到的product_id
}

type DeliverySetting struct {
	Bid               float64             `json:"bid,omitempty"`                 // 点击出价/展示出价
	FilterNightSwitch string              `json:"filter_night_switch,omitempty"` // 过滤夜间投放
	CpaBid            float64             `json:"cpa_bid,omitempty"`             // 目标转化出价/预期成本
	DeepCpabid        float64             `json:"deep_cpabid,omitempty"`         // 深度优化出价
	RoiGoal           float64             `json:"roi_goal,omitempty"`            // 深度转化ROI系数
	ScheduleTime      string              `json:"schedule_time,omitempty"`       // 投放时段
	ScheduleType      string              `json:"schedule_type,omitempty"`       // 投放时间类型，枚举值： SCHEDULE_FROM_NOW 从今天起长期投放 SCHEDULE_START_END 设置开始和结束日期 SCHEDULE_7_DAYS 7日稳投（仅搜索极速智投场景）
	BidType           string              `json:"bid_type,omitempty"`            // 竞价策略，枚举值：CUSTOM 稳定成本、NO_BID 最大转化投放、UPPER_CONTROL最优成本 EXPLORE_UPGRADE广告潜力探索-升级版
	BidSpeed          string              `json:"bid_speed,omitempty"`           // 投放速度，允许值：BALANCE 匀速,FAST 加速
	DeepBidType       string              `json:"deep_bid_type,omitempty"`       // 深度优化方式
	Budget            float64             `json:"budget,omitempty"`              // 项目预算
	BudgetMode        string              `json:"budget_mode,omitempty"`         // 项目预算类型， 枚举值：BUDGET_MODE_INFINITE 不限、BUDGET_MODE_DAY 日预算、BUDGET_MODE_TOTAL 总预算
	FirstRoiGoal      float64             `json:"first_roi_goal,omitempty"`      // 首日roi系数
	ShopMultiRoiGoals []ShopMultiRoiGoals `json:"shop_multi_roi_goals,omitempty"`
}

type ShopMultiRoiGoals struct {
	RoiGoal      float64 `json:"roi_goal,omitempty"`      // ROI系数，范围[0.01,100]，精度：最多保留小数点后四位
	ShopPlatform string  `json:"shop_platform,omitempty"` // ROI系数所属平台，允许值： PDD 拼多多 TB 淘宝 JD 京东 OTHER 其他
}

type Audience struct {
	DeviceType            []string `json:"device_type,omitempty"`
	ConvertedTimeDuration string   `json:"converted_time_duration,omitempty"`
}

type DeliveryRange struct {
	InventoryCatalog string   `json:"inventory_catalog,omitempty"` // 广告位大类，枚举值： MANUAL 首选媒体，UNIVERSAL_SMART 通投智选
	InventoryType    []string `json:"inventory_type,omitempty"`    // 广告投放位置（首选媒体）
	UnionVideoType   string   `json:"union_video_type,omitempty"`  // 投放形式（穿山甲视频创意类型），枚举值：ORIGINAL_VIDEO 原生视频、REWARDED_VIDEO 激励视频、SPLASH_VIDEO 开屏视频
}

type OptimizeGoal struct {
	AssetIds           []int64 `json:"asset_ids,omitempty"`            // 事件管理资产id
	ConvertId          int64   `json:"convert_id,omitempty"`           // 转化跟踪id
	DeepExternalAction string  `json:"deep_external_action,omitempty"` // 深度转化目标
	ExternalAction     string  `json:"external_action,omitempty"`      // 优化目标
	GameAddictionId    string  `json:"game_addiction_id,omitempty"`    // 关键行为ID
	PaidSwitch         int64   `json:"paid_switch,omitempty"`          // 字节提供的归因方式，返回值： 1启用；2 不启用
}
