package accounts

import (
	"context"
	"fmt"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"strings"
)

type OauthActiveAccountDao struct {
	Ctx context.Context
}

func NewOauthActiveAccountDao(ctx context.Context) *OauthActiveAccountDao {
	return &OauthActiveAccountDao{Ctx: ctx}
}

func (d *OauthActiveAccountDao) ListByMedia(media string, advertiserIds []string) ([]accountrepo.OauthActiveAccountEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.OauthActiveAccountTableName()).Select("advertiser_id,oauth_id,advertiser_name")
	q = q.Where("media = ?", media)
	if len(advertiserIds) > 0 {
		q = q.Where("advertiser_id in (?)", advertiserIds)
	}

	var res []accountrepo.OauthActiveAccountEntity
	err := q.Find(&res).Error
	return res, err
}

func (d *OauthActiveAccountDao) ListByMediaAndAppIds(media string, appIds []string, advertiserIds []string) ([]accountrepo.OauthActiveAccountEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.OauthActiveAccountTableName()).Select("advertiser_id,oauth_id,advertiser_name")
	if len(appIds) > 0 {
		subQuery := db.Table(accountrepo.OauthTableName()).Select("oauth_id").Where("app_id in (?)", appIds).QueryExpr()
		q = q.Where("media = ? and oauth_id in (?)", media, subQuery)
	} else {
		q = q.Where("media = ?", media)
	}
	if len(advertiserIds) > 0 {
		q = q.Where("advertiser_id in (?)", advertiserIds)
	}

	var res []accountrepo.OauthActiveAccountEntity
	err := q.Find(&res).Error
	return res, err
}

func (d *OauthActiveAccountDao) ListTodayQueen() ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT advertiser_id FROM report_hour WHERE date(search_date) = CURRENT_DATE GROUP BY advertiser_id ) has LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) ac ON has.advertiser_id = ac.advertiser_id"
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

// ListReplenishQueen 获取消耗表历史账号信息  --- 改版
func (d *OauthActiveAccountDao) ListReplenishQueen(searchTime string) ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT advertiser_id FROM ( SELECT advertiser_id FROM subscribe_today WHERE date(created_at) = '" + searchTime + "' UNION SELECT advertiser_id FROM subscribe_before WHERE date(created_at) = '" + searchTime + "' ) a GROUP BY advertiser_id ) has LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) ac ON has.advertiser_id = ac.advertiser_id"
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

// ListFastQueen 获取快队列数据  --- 改版
func (d *OauthActiveAccountDao) ListFastQueen() ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT advertiser_id FROM ( SELECT advertiser_id FROM ( SELECT promotion_id FROM tomato_iaa_award WHERE date(event_date) = CURRENT_DATE  GROUP BY promotion_id ) o LEFT JOIN ( SELECT advertiser_id, promotion_id FROM account_distributor_promotion_url ) l ON o.promotion_id = l.promotion_id UNION SELECT advertiser_id FROM report_hour WHERE date(search_date) = CURRENT_DATE AND cost  > 0 GROUP BY advertiser_id ) t GROUP BY t.advertiser_id ) has LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) ac ON has.advertiser_id = ac.advertiser_id"
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

// ListSlowQueen 获取慢队列数据   --- 改版
func (d *OauthActiveAccountDao) ListSlowQueen() ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT t1.advertiser_id FROM oauth_active_account_view t1 LEFT JOIN ( SELECT advertiser_id FROM ( SELECT advertiser_id FROM ( SELECT promotion_id FROM tomato_iaa_award WHERE date(event_date) = CURRENT_DATE  GROUP BY promotion_id ) o LEFT JOIN ( SELECT advertiser_id, promotion_id FROM account_distributor_promotion_url ) l ON o.promotion_id = l.promotion_id UNION SELECT advertiser_id FROM report_hour WHERE date(search_date) = CURRENT_DATE AND cost  > 0 GROUP BY advertiser_id ) t GROUP BY t.advertiser_id ) t2 ON t1.advertiser_id = t2.advertiser_id WHERE t2.advertiser_id IS NULL ) has LEFT JOIN ( SELECT advertiser_id, min(user_id) as user_id FROM oauth_account GROUP BY advertiser_id ) ac ON has.advertiser_id = ac.advertiser_id"
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

// ListQueenAll 获取慢队列数据   --- 改版
func (d *OauthActiveAccountDao) ListQueenAll() ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM oauth_active_account_view has LEFT JOIN ( SELECT advertiser_id, min(user_id) as user_id FROM oauth_account GROUP BY advertiser_id ) ac ON has.advertiser_id = ac.advertiser_id"
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

// ListFastQueenByAppId 获取快队列数据
func (d *OauthActiveAccountDao) ListFastQueenByAppId(appIds []string) ([]accountrepo.OauthActiveAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthActiveAccountEntity
	sql := "SELECT t.advertiser_id as advertiser_id, vie.oauth_id as oauth_id FROM ( SELECT advertiser_id FROM ( SELECT advertiser_id FROM ( SELECT promotion_id FROM tomato_iaa_award WHERE date(event_date) = CURRENT_DATE  GROUP BY promotion_id ) o LEFT JOIN ( SELECT advertiser_id, promotion_id FROM account_distributor_promotion_url ) l ON o.promotion_id = l.promotion_id UNION SELECT advertiser_id FROM report_hour WHERE date(search_date) = CURRENT_DATE AND cost  > 0 GROUP BY advertiser_id ) a GROUP BY a.advertiser_id ) t LEFT JOIN ( SELECT advertiser_id, oauth_id FROM oauth_active_account_view WHERE oauth_id in ( SELECT oauth_id FROM oauth WHERE app_id = '" + appIds[0] + "' ) ) vie ON t.advertiser_id = vie.advertiser_id WHERE vie.oauth_id is not null"
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

// ListSlowQueenByAppId 获取慢队列数据
func (d *OauthActiveAccountDao) ListSlowQueenByAppId(appIds []string) ([]accountrepo.OauthActiveAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthActiveAccountEntity
	sql := "SELECT advertiser_id, oauth_id FROM oauth_active_account_view WHERE oauth_id in ( SELECT oauth_id FROM oauth WHERE app_id = '" + appIds[0] + "' ) AND advertiser_id NOT IN ( SELECT t.advertiser_id as advertiser_id FROM ( SELECT advertiser_id FROM ( SELECT advertiser_id FROM ( SELECT promotion_id FROM tomato_iaa_award WHERE date(event_date) = CURRENT_DATE  GROUP BY promotion_id ) o LEFT JOIN ( SELECT advertiser_id, promotion_id FROM account_distributor_promotion_url ) l ON o.promotion_id = l.promotion_id UNION SELECT advertiser_id FROM report_hour WHERE date(search_date) = CURRENT_DATE AND cost  > 0 GROUP BY advertiser_id ) a GROUP BY a.advertiser_id ) t LEFT JOIN ( SELECT advertiser_id, oauth_id FROM oauth_active_account_view WHERE oauth_id in ( SELECT oauth_id FROM oauth WHERE app_id = '" + appIds[0] + "' ) ) vie ON t.advertiser_id = vie.advertiser_id WHERE vie.oauth_id is not null )"
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

// ListSpiQueen 获取spi订阅信息
func (d *OauthActiveAccountDao) ListSpiQueen(date string) ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT advertiser_id FROM spi_material_modification_log WHERE date(created_at) = '" + date + "' GROUP BY advertiser_id ) has LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) ac ON has.advertiser_id = ac.advertiser_id"
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}

// ListHighHasReportData 主应用下的管家下的所有广告主，关联状态是活跃的，且当日，有报表数据的广告主均衡到应用
func (d *OauthActiveAccountDao) ListHighHasReportData(media string, appIds []string, advertiserIds []string) ([]accountrepo.OauthActiveAccountEntity, error) {
	db := dorisdb.DorisClient()

	// 先查询oauth授权里面授权的应用数量
	var bucketCount int64
	err := db.Table(accountrepo.OauthTableName()).Select("COUNT(DISTINCT app_id)").Count(&bucketCount).Error
	if err != nil {
		return nil, err
	}
	if bucketCount == 0 {
		return nil, nil
	}

	d1 := db.Table(accountrepo.OauthMasterAppIdActiveAccountHasReportDataViewName())
	columns1 := []string{
		"media",
		"advertiser_id",
		"advertiser_name",
		"user_id",
		fmt.Sprintf("NTILE(%d) OVER(PARTITION BY user_id ORDER BY advertiser_id ) AS app_id_index", bucketCount),
	}
	sq1 := d1.Select(strings.Join(columns1, ",")).Where("media = ?", media).SubQuery()

	d2 := db.Table(accountrepo.OauthTableName())
	columns2 := []string{
		"media",
		"oauth_id",
		"app_id",
		"user_id",
		"ROW_NUMBER() OVER(PARTITION BY user_id ORDER BY app_id DESC) AS app_id_index",
	}
	sq2 := d2.Select(strings.Join(columns2, ",")).Where("media = ?", media).SubQuery()

	columns := []string{
		"t1.media AS media",
		"t1.advertiser_id AS advertiser_id",
		"t1.advertiser_name AS advertiser_name",
		"t1.user_id AS user_id",
		"t2.oauth_id AS oauth_id",

		"t1.app_id_index AS app_id_index",
		"t2.media AS t2_media",
		"t2.app_id AS t2_app_id",
		"t2.user_id AS t2_user_id",
		"t2.app_id_index AS t2_app_id_index",
	}

	var res []accountrepo.OauthActiveAccountEntity

	var vars []interface{}
	sql1 := fmt.Sprintf("SELECT %s FROM ? AS t1 LEFT JOIN ? AS t2 ON t1.user_id = t2.user_id and t1.app_id_index = t2.app_id_index", strings.Join(columns, ","))
	vars = append(vars, sq1, sq2)
	var whereSlice []string
	if media != "" {
		whereSlice = append(whereSlice, "t1.media = ?")
		vars = append(vars, media)
	}
	if len(appIds) > 0 {
		whereSlice = append(whereSlice, "t2.app_id in (?)")
		vars = append(vars, appIds)
	}
	if len(advertiserIds) > 0 {
		whereSlice = append(whereSlice, "t1.advertiser_id in (?)")
		vars = append(vars, advertiserIds)
	}

	sql := fmt.Sprintf("%s where %s", sql1, strings.Join(whereSlice, " and "))
	q := db.Raw(sql, vars...)
	err = q.Scan(&res).Error
	if err != nil {
		return nil, err
	}

	return res, err
}

// ListLowNoReportData 主应用下的管家下的所有广告主，关联状态是活跃的，且当日，没有报表数据的广告主均衡到应用
func (d *OauthActiveAccountDao) ListLowNoReportData(media string, appIds []string, advertiserIds []string) ([]accountrepo.OauthActiveAccountEntity, error) {
	db := dorisdb.DorisClient()

	// 先查询oauth授权里面授权的应用数量
	var bucketCount int64
	err := db.Table(accountrepo.OauthTableName()).Select("COUNT(DISTINCT app_id)").Count(&bucketCount).Error
	if err != nil {
		return nil, err
	}
	if bucketCount == 0 {
		return nil, nil
	}

	d1 := db.Table(accountrepo.OauthMasterAppIdActiveAccountNoReportDataViewName())
	columns1 := []string{
		"media",
		"advertiser_id",
		"advertiser_name",
		"user_id",
		fmt.Sprintf("NTILE(%d) OVER(PARTITION BY user_id ORDER BY advertiser_id ) AS app_id_index", bucketCount),
	}
	sq1 := d1.Select(strings.Join(columns1, ",")).Where("media = ?", media).SubQuery()

	d2 := db.Table(accountrepo.OauthTableName())
	columns2 := []string{
		"media",
		"oauth_id",
		"app_id",
		"user_id",
		"ROW_NUMBER() OVER(PARTITION BY user_id ORDER BY app_id DESC) AS app_id_index",
	}
	sq2 := d2.Select(strings.Join(columns2, ",")).Where("media = ?", media).SubQuery()

	columns := []string{
		"t1.media AS media",
		"t1.advertiser_id AS advertiser_id",
		"t1.advertiser_name AS advertiser_name",
		"t1.user_id AS user_id",
		"t2.oauth_id AS oauth_id",

		"t1.app_id_index AS app_id_index",
		"t2.media AS t2_media",
		"t2.app_id AS t2_app_id",
		"t2.user_id AS t2_user_id",
		"t2.app_id_index AS t2_app_id_index",
	}

	var res []accountrepo.OauthActiveAccountEntity

	var vars []interface{}
	sql1 := fmt.Sprintf("SELECT %s FROM ? AS t1 LEFT JOIN ? AS t2 ON t1.user_id = t2.user_id and t1.app_id_index = t2.app_id_index", strings.Join(columns, ","))
	vars = append(vars, sq1, sq2)
	var whereSlice []string
	if media != "" {
		whereSlice = append(whereSlice, "t1.media = ?")
		vars = append(vars, media)
	}
	if len(appIds) > 0 {
		whereSlice = append(whereSlice, "t2.app_id in (?)")
		vars = append(vars, appIds)
	}
	if len(advertiserIds) > 0 {
		whereSlice = append(whereSlice, "t1.advertiser_id in (?)")
		vars = append(vars, advertiserIds)
	}

	sql := fmt.Sprintf("%s where %s", sql1, strings.Join(whereSlice, " and "))
	q := db.Raw(sql, vars...)
	err = q.Scan(&res).Error
	if err != nil {
		return nil, err
	}

	return res, err
}
