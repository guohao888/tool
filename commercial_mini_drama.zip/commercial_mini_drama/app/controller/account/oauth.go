package account

import (
	"github.com/gin-gonic/gin"
	accountdto "goserver/app/common/dto/accounts"
	repo "goserver/app/common/repository"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	account "goserver/app/model/service/accounts"
)

func CallbackToutiao(c *gin.Context) {
	r := response.Gin{Ctx: c}

	var req accountdto.CallbackToutiaoReq
	err := c.ShouldBindQuery(&req)
	if err != nil {
		panic(myerror.ParamsError)
	}

	// 根据auth_code获取token
	oauthService := account.NewOauthService(c)
	err = oauthService.CallbackToutiao(repo.MediaToutiao, req)

	if err != nil {
		r.Response(myerror.OauthAccessTokenError.Code, myerror.OauthAccessTokenError.Message, gin.H{
			"error": err.Error(),
		})
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

func CallbackKuaishou(c *gin.Context) {
	r := response.Gin{Ctx: c}

	var req accountdto.CallbackKuaishouReq
	err := c.ShouldBindQuery(&req)
	if err != nil {
		panic(myerror.ParamsError)
	}

	// 根据auth_code获取token
	oauthService := account.NewOauthService(c)
	err = oauthService.CallbackKuaishou(repo.MediaKuaishou, req)

	if err != nil {
		r.Response(myerror.OauthAccessTokenError.Code, myerror.OauthAccessTokenError.Message, gin.H{
			"error": err.Error(),
		})
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

func CallbackKuaishouMagnet(c *gin.Context) {
	r := response.Gin{Ctx: c}

	var req accountdto.CallbackKuaishouReq
	err := c.ShouldBindQuery(&req)
	if err != nil {
		panic(myerror.ParamsError)
	}

	// 根据auth_code获取token
	oauthService := account.NewOauthService(c)
	err = oauthService.CallbackKuaishou(repo.MediaKuaishouMagnet, req)

	if err != nil {
		r.Response(myerror.OauthAccessTokenError.Code, myerror.OauthAccessTokenError.Message, gin.H{
			"error": err.Error(),
		})
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

func CallbackToutiaoPush(c *gin.Context) {
	r := response.Gin{Ctx: c}

	var req accountdto.CallbackToutiaoReq
	err := c.ShouldBindQuery(&req)
	if err != nil {
		panic(myerror.ParamsError)
	}

	// 根据auth_code获取token
	oauthService := account.NewOauthService(c)
	err = oauthService.CallbackToutiaoPush(repo.MediaToutiao, req)

	if err != nil {
		r.Response(myerror.OauthAccessTokenError.Code, myerror.OauthAccessTokenError.Message, gin.H{
			"error": err.Error(),
		})
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}
