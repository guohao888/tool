package material

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	errgroup "golang.org/x/sync/errgroup"
	"goserver/app/common"
	"goserver/app/common/dto/materialdto"
	"goserver/app/common/dto/mediareport"
	"goserver/app/common/repository/accounts"
	repo "goserver/app/common/repository/material"
	"goserver/app/common/repository/warning"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/library/utils"
	"goserver/app/model/dao"
	"strconv"
	"strings"
	"time"
)

type ReportDataDao struct {
	Ctx context.Context
}

func NewReportDataDao(ctx context.Context) *ReportDataDao {
	return &ReportDataDao{Ctx: ctx}
}

// MediaAry 获取ROI报表媒体筛选项列表
func (d *ReportDataDao) MediaAry() (result []materialdto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.OauthActiveAccountTableName())
	q = q.Select("media")
	q = q.Where("media<>''")
	q = q.Group("media")
	q = q.Order("media ASC")
	type Row struct {
		Name string `gorm:"column:media"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, materialdto.IDLabel{
			ID:    row.Name,
			Label: row.Name,
		})
	}
	return
}

// BookAry 获取ROI报表剧目筛选项列表
func (d *ReportDataDao) BookAry(keywords string, limit int) (result []materialdto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.AccountDistributorTableName())
	q = q.Select("book_id,book_name")
	q = q.Where("book_name<>''")
	if keywords != "" {
		q = q.Where("book_name LIKE ?", "%"+keywords+"%")
	}
	q = q.Group("book_id,book_name")
	q = q.Order("book_name ASC")
	if limit > 0 {
		q = q.Offset(0).Limit(limit)
	}
	type Row struct {
		ID   string `gorm:"column:book_id"`
		Name string `gorm:"column:book_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, materialdto.IDLabel{
			ID:    row.ID,
			Label: row.Name,
		})
	}
	return
}

// AppAry 获取ROI报表应用筛选项列表
func (d *ReportDataDao) AppAry() (result []materialdto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.AccountDistributorTableName())
	q = q.Select("app_name")
	q = q.Where("app_name<>''")
	q = q.Group("app_name")
	q = q.Order("app_name ASC")
	type Row struct {
		Name string `gorm:"column:app_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, materialdto.IDLabel{
			ID:    row.Name,
			Label: row.Name,
		})
	}
	return
}

// MaterialNameAry 获取素材表素材名称筛选项列表
func (d *ReportDataDao) MaterialAry(keywords string, limit int) (result []materialdto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(repo.ReportHourlyMaterialTableName())
	q = q.Select("material_name")
	q = q.Where("material_name<>''")
	if keywords != "" {
		q = q.Where("material_name LIKE ?", "%"+keywords+"%")
	}
	q = q.Group("material_name")
	q = q.Order("material_name DESC")
	if limit > 0 {
		q = q.Offset(0).Limit(limit)
	}
	type Row struct {
		MaterialName string `gorm:"column:material_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, materialdto.IDLabel{
			ID:    row.MaterialName,
			Label: row.MaterialName,
		})
	}
	return
}

// OptimizerAry 获取ROI报表投放人员筛选项列表
func (d *ReportDataDao) OptimizerAry() (result []materialdto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.OptimizerInfoTableName())
	q = q.Select("nick_name")
	q = q.Where("nick_name<>''")
	q = q.Group("nick_name")
	q = q.Order("nick_name ASC")
	type Row struct {
		Name string `gorm:"column:nick_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, materialdto.IDLabel{
			ID:    row.Name,
			Label: row.Name,
		})
	}
	return
}

// EditorAry 获取素材表剪辑师筛选项列表
func (d *ReportDataDao) EditorAry() (result []materialdto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(repo.CutterRegionsTableName())
	q = q.Select("file_cutter")
	q = q.Where("file_cutter<>''")
	q = q.Group("file_cutter")
	q = q.Order("file_cutter ASC")
	type Row struct {
		EditorName string `gorm:"column:file_cutter"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, materialdto.IDLabel{
			ID:    row.EditorName,
			Label: row.EditorName,
		})
	}
	return
}

// EditorRegionAry 获取素材表剪辑师地域筛选项列表
func (d *ReportDataDao) EditorRegionAry() (result []materialdto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(repo.CutterRegionsTableName())
	q = q.Select("cutter_region")
	q = q.Where("cutter_region<>''")
	q = q.Group("cutter_region")
	q = q.Order("cutter_region ASC")
	type Row struct {
		EditorRegion string `gorm:"column:cutter_region"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, materialdto.IDLabel{
			ID:    row.EditorRegion,
			Label: row.EditorRegion,
		})
	}
	return
}

// AccountAry 获取ROI报表账户筛选项列表
func (d *ReportDataDao) AccountAry(keywords string, limit int) (result []materialdto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.OauthActiveAccountTableName())
	q = q.Select("advertiser_id,advertiser_name")
	q = q.Where("advertiser_name<>''")
	if keywords != "" {
		q = q.Where("advertiser_name LIKE ?", "%"+keywords+"%")
	}
	q = q.Group("advertiser_id,advertiser_name")
	q = q.Order("advertiser_name ASC")
	if limit > 0 {
		q = q.Offset(0).Limit(limit)
	}
	type Row struct {
		ID   string `gorm:"column:advertiser_id"`
		Name string `gorm:"column:advertiser_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, materialdto.IDLabel{
			ID:    row.ID,
			Label: row.Name,
		})
	}
	return
}

func (d *ReportDataDao) ReportData(params *materialdto.ReportDataReq) (*common.Paginator, error) {
	db := dorisdb.DorisClient()
	roiTable := repo.ReportHourlyMaterialTableName()
	pagination := params.Pagination
	limit := pagination.GetLimit()
	offset := pagination.GetOffset()
	var sql string
	var columns, columnsHb, columnsAccumulateInner, columnsOuterLayer, columnsTotal []string
	var kpis, kpisHb, kpisAccumulate, kpisAccumulateInner, kpisOuterLayer, kpisHourTotal []string
	var where, whereHb []string
	var groups, groupsHb, groupsAccumulateInner, groupsOuterLayer []string
	var sorts []string
	columnsAccumulateArr := []string{"account_id", "mid_id",
		"media", "book_name", "pay_type", "app_name", "optimizer_nickname",
		"editor_name", "editor_region", "account_name", "material_name",
		"promotion_id", "promotion_name"}

	/* 查询示例
	-- 子查询sql
	SELECT DATE,material_name,mid_id,MAX(material_cover) AS material_cover -- columns
		,sum(income) AS income,0 AS income_hb,0 AS income2 -- kpis
	FROM material_report_hourly
	WHERE DATE>='2025-03-03' AND DATE<='2025-03-09' AND mid_id='7477774521400147978' -- where
	GROUP BY DATE,material_name,mid_id -- groups
	UNION ALL
	SELECT DATE_ADD(DATE,INTERVAL 7 DAY) AS DATE,material_name,mid_id,MAX(material_cover) AS material_cover -- columnsHb
		,0 AS income,sum(income) AS income_hb,0 AS income2 -- kpisHb
	FROM material_report_hourly
	WHERE DATE>='2025-02-24' AND DATE<='2025-03-02' AND mid_id='7477774521400147978' -- whereHb
	GROUP BY DATE,material_name,mid_id -- groupsHb
	UNION ALL
	SELECT DATE,material_name,mid_id,MAX(material_cover) AS material_cover -- columnsOuterLayer
		,0 AS income,SUM(income2) AS income2 -- kpisAccumulate
	FROM (
		SELECT DATE,account_id,mid_id
			,media,book_name,pay_type,app_name,optimizer_nickname
			,editor_name,editor_region,account_name,material_name
			,promotion_id,promotion_name,MAX(material_cover) AS material_cover -- columnsAccumulateInner
			,MAX(new_sum_income) AS new_sum_income,MAX(income2) AS income2
			,MAX(income3) AS income3,MAX(income4) AS income4,MAX(income5) AS income5
			,MAX(income6) AS income6,MAX(income7) AS income7 -- kpisAccumulateInner
		FROM material_report_hourly
		WHERE DATE>='2025-03-03' AND DATE<='2025-03-09' AND mid_id='7477774521400147978' -- where
		GROUP BY DATE,account_id,mid_id
			,media,book_name,pay_type,app_name,optimizer_nickname
			,editor_name,editor_region,account_name,material_name
			,promotion_id,promotion_name  -- groupsAccumulateInner
	) AS tt
	GROUP BY DATE,material_name,mid_id -- groupsOuterLayer
	-- 分页明细数据查询
	SELECT DATE,material_name,mid_id,MAX(material_cover) AS material_cover -- columnsOuterLayer
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t
	GROUP BY DATE,material_name,mid_id -- groupsOuterLayer
	ORDER BY DATE ASC,income DESC -- sorts
	LIMIT 19 OFFSET 0; -- limit offset
	-- 汇总行数据查询
	SELECT '汇总' AS DATE -- columnTotal
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t;
	-- 总行数查询
	SELECT COUNT(DISTINCT DATE,material_name,mid_id) AS cnt -- groupsOuterLayer
	FROM (子查询sql) AS t;
	*/

	// 时间聚合维度
	columnsTotal = append(columnsTotal, "'汇总' as date")
	hbStr := "DATE(DATE_ADD(date,INTERVAL " + strconv.Itoa(params.DaysOfHb) + " DAY))"
	if params.GroupType == "w" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%xW%v') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%xW%v') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%xW%v') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%xW%v')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%xW%v')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%xW%v')")
	} else if params.GroupType == "m" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%Y-%m') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%Y-%m') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%Y-%m') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%Y-%m')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%Y-%m')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%Y-%m')")
	} else if params.GroupType == "h" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		columnsHb = append(columnsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groups = append(groups, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00')")
		groupsHb = append(groupsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")
		// 分小时的汇总行计算需要特殊逻辑
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	} else {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "date")
		columnsHb = append(columnsHb, hbStr+" AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groups = append(groups, "date")
		groupsHb = append(groupsHb, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	}
	groupsOuterLayer = append(groupsOuterLayer, "date")
	columnsAccumulateInner = append(columnsAccumulateInner, columnsAccumulateArr...)
	groupsAccumulateInner = append(groupsAccumulateInner, columnsAccumulateArr...)

	// 用户定制聚合维度 (group by)
	columns = append(columns, params.GroupBy...)
	columnsHb = append(columnsHb, params.GroupBy...)
	columnsOuterLayer = append(columnsOuterLayer, params.GroupBy...)
	groups = append(groups, params.GroupBy...)
	groupsHb = append(groupsHb, params.GroupBy...)
	groupsOuterLayer = append(groupsOuterLayer, params.GroupBy...)

	//素材封面URL去重处理
	columns = append(columns, "MAX(material_cover) AS material_cover")
	columnsHb = append(columnsHb, "MAX(material_cover) AS material_cover")
	columnsOuterLayer = append(columnsOuterLayer, "MAX(material_cover) AS material_cover")
	columnsAccumulateInner = append(columnsAccumulateInner, "MAX(material_cover) AS material_cover")

	// 普通指标
	kpiArr := []string{"media_cost", "show_count", "click_count",
		"media_active_count", "media_convert_count", "media_first_pay_count",
		"active_count", "new_pay_count", "active_pay_count", "first_income"}
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
		if kpi == "media_cost" || kpi == "first_income" {
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0.0 AS "+kpi)
		} else {
			kpisHb = append(kpisHb, "0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0 AS "+kpi)
		}
	}

	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost) as cost")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_hb) as cost_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income) as income")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(spending_campaigns_count) as spending_campaigns_count")
	//实际消耗= 媒体消耗/(1+返点比例2%)
	kpis = append(kpis, "SUM(media_cost)/1.02 as cost")
	kpis = append(kpis, "0.0 as cost_hb")
	kpisHb = append(kpisHb, "0.0 as cost")
	kpisHb = append(kpisHb, "SUM(media_cost)/1.02 as cost_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_hb")
	//实际收入
	kpis = append(kpis, "SUM(income) as income")
	kpisHb = append(kpisHb, "0.0 as income")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income")
	//关联有消耗计划数(素材ID维度）
	kpis = append(kpis, "COUNT(DISTINCT promotion_id) as spending_campaigns_count")
	kpisHb = append(kpisHb, "0 as spending_campaigns_count")
	kpisAccumulate = append(kpisAccumulate, "0 as spending_campaigns_count")

	//累计指标的, 小时的直接取, 日周天 的 要取当天的最早有消费的小时的数据
	kpiArr = []string{"new_sum_income", "income2", "income3", "income4", "income5", "income6", "income7"}
	kpisHourTotal = append(kpisHourTotal, kpis...)
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		if params.GroupType == "h" {
			kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisHourTotal = append(kpisHourTotal, "0.0 AS "+kpi) //分小时汇总行的累计指标需要特殊处理
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		} else { //非小时的日周天独立查询
			kpis = append(kpis, "0.0 AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		}
	}

	// 最外层计算指标排序的，需要特殊处理
	var kpi string
	//{Label: "点击率", Prop: "click_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(click_count)/SUM(show_count), 0) AS click_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "点击成本", Prop: "click_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(cost)/SUM(click_count), 0) AS click_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "千展成本", Prop: "show_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(cost)/SUM(show_count), 0) AS show_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活成本", Prop: "media_active_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(media_active_count)>0, SUM(cost)/SUM(media_active_count), 0) AS media_active_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活率", Prop: "media_active_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(media_active_count)/SUM(click_count), 0) AS media_active_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "实际ROI", Prop: "roi", Format: "rate", SortAble: true, IsDefault: true},
	kpi = "IF(SUM(cost)>0, SUM(income)/SUM(cost), 0) AS roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "首日新增ROI", Prop: "first_roi", Format: "rate", SortAble: true},
	kpi = "IF(SUM(cost)>0, SUM(first_income)/SUM(cost), 0) AS first_roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)

	// 查询条件 (where)
	var filterStr string
	if len(params.Media) > 0 {
		filterStr = "media IN ('" + strings.Join(params.Media, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.BookID) > 0 {
		filterStr = "book_id IN (" + utils.Join(params.BookID, ",") + ")"
		where = append(where, filterStr)
	}
	if len(params.PayType) > 0 {
		filterStr = "pay_type IN ('" + strings.Join(params.PayType, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AppName) > 0 {
		filterStr = "app_name IN ('" + strings.Join(params.AppName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.MidID) > 0 {
		filterStr = "mid_id='" + params.MidID + "'"
		where = append(where, filterStr)
	}
	if len(params.MaterialName) > 0 {
		filterStr = "material_name IN ('" + strings.Join(params.MaterialName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.OptimizerName) > 0 {
		filterStr = "optimizer_nickname IN ('" + strings.Join(params.OptimizerName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.EditorName) > 0 {
		filterStr = "editor_name IN ('" + utils.Join(params.EditorName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.EditorRegion) > 0 {
		filterStr = "editor_region IN ('" + utils.Join(params.EditorRegion, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AccountID) > 0 {
		filterStr = "account_id IN ('" + strings.Join(params.AccountID, "','") + "')"
		where = append(where, filterStr)
	}

	whereHb = append(whereHb, where...)

	if params.StartDate == params.EndDate {
		where = append(where, "date='"+params.StartDate+"'")
		whereHb = append(whereHb, "date='"+params.StartDateHb+"'")
	} else {
		where = append(where, "date>='"+params.StartDate+"' AND date<='"+params.EndDate+"'")
		whereHb = append(whereHb, "date>='"+params.StartDateHb+"' AND date<='"+params.EndDateHb+"'")
	}

	// 排序 (sort)
	if len(params.Sorts) == 0 {
		params.Sorts = append(params.Sorts,
			common.Sort{Key: "date", Order: "asc"},
			common.Sort{Key: "cost", Order: "desc"},
		)
	}
	for _, sort := range params.Sorts {
		sorts = append(sorts, fmt.Sprintf("%s %s", sort.Key, sort.Order))
	}

	//子查询构造
	subSql := "SELECT " + strings.Join(columns, ",") + "," + strings.Join(kpis, ",") +
		" FROM " + roiTable +
		" WHERE " + strings.Join(where, " AND ") +
		" GROUP BY " + strings.Join(groups, ",") +
		" UNION ALL" +
		" SELECT " + strings.Join(columnsHb, ",") + "," + strings.Join(kpisHb, ",") +
		" FROM " + roiTable +
		" WHERE " + strings.Join(whereHb, " AND ") +
		" GROUP BY " + strings.Join(groupsHb, ",")
	if params.GroupType != "h" {
		subSql += " UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			" SELECT " + strings.Join(columnsAccumulateInner, ",") + "," + strings.Join(kpisAccumulateInner, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(where, " AND ") +
			" GROUP BY " + strings.Join(groupsAccumulateInner, ",") +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}

	// 总行数查询
	var total int64
	type Dist struct {
		Cnt int64 `gorm:"column:cnt"`
	}
	var dist Dist
	sql = "SELECT COUNT(DISTINCT " + strings.Join(groupsOuterLayer, ",") + ") AS cnt " +
		" FROM (" + subSql + ") AS t"
	err := db.Raw(sql).Scan(&dist).Error
	if err != nil {
		return nil, err
	}
	total = dist.Cnt

	// 分页明细数据查询
	var res []repo.ReportHourlyMaterialEntity
	sql = "SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t" +
		" GROUP BY " + strings.Join(groupsOuterLayer, ",") +
		" ORDER BY " + strings.Join(sorts, ",") +
		" LIMIT " + strconv.FormatInt(limit, 10) + " OFFSET " + strconv.FormatInt(offset, 10)
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	// 计算指标处理
	for i, row := range res {
		res[i] = *row.Calculate()
		if params.GroupType == "h" {
			res[i].Date = row.Date[0:10] + " " + row.Date[11:19]
		} else if params.GroupType == "d" {
			res[i].Date = row.Date[0:10]
		}
	}

	// 汇总行数据查询
	if params.GroupType == "h" {
		//子查询构造 - 小时维度特殊处理
		subSql = "SELECT " + strings.Join(columns, ",") + "," + strings.Join(kpisHourTotal, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(where, " AND ") +
			" GROUP BY " + strings.Join(groups, ",") +
			" UNION ALL" +
			" SELECT " + strings.Join(columnsHb, ",") + "," + strings.Join(kpisHb, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(whereHb, " AND ") +
			" GROUP BY " + strings.Join(groupsHb, ",") +
			" UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			" SELECT " + strings.Join(columnsAccumulateInner, ",") + "," + strings.Join(kpisAccumulateInner, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(where, " AND ") +
			" GROUP BY " + strings.Join(groupsAccumulateInner, ",") +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}
	var countRow repo.ReportHourlyMaterialEntity
	sql = "SELECT " + strings.Join(columnsTotal, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t"
	err = db.Raw(sql).Scan(&countRow).Error
	if err != nil {
		return nil, err
	}
	//拼接返回列表行
	var list []repo.ReportHourlyMaterialEntity
	if countRow.Date != "" {
		// 计算指标处理
		countRow.Calculate()
		list = append(list, countRow)
	}
	list = append(list, res...)

	// 格式化数据
	for i, row := range list {
		list[i].Media = utils.HtmlEncode(row.Media)
		if val, ok := materialdto.PayTypeMapping[row.PayType]; ok {
			list[i].PayType = val
		}
		list[i].BookName = utils.HtmlEncode(row.BookName)
		list[i].AppID = utils.HtmlEncode(row.AppID)
		list[i].AppName = utils.HtmlEncode(row.AppName)
		list[i].MidID = utils.HtmlEncode(row.MidID)
		list[i].MidType = utils.HtmlEncode(row.MidType)
		list[i].MaterialName = utils.HtmlEncode(row.MaterialName)
		list[i].OptimizerNickname = utils.HtmlEncode(row.OptimizerNickname)
		list[i].EditorName = utils.HtmlEncode(row.EditorName)
		list[i].EditorRegion = utils.HtmlEncode(row.EditorRegion)
		list[i].AccountID = utils.HtmlEncode(row.AccountID)
		list[i].AccountName = utils.HtmlEncode(row.AccountName)
		list[i].PromotionID = utils.HtmlEncode(row.PromotionID)
		list[i].PromotionName = utils.HtmlEncode(row.PromotionName)
	}

	paginator := common.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, list)
	return &paginator, nil
}

func (d *ReportDataDao) ExportData(params *materialdto.ReportDataReq) (result *[]repo.ReportHourlyMaterialEntity, err error) {
	db := dorisdb.DorisClient()
	roiTable := repo.ReportHourlyMaterialTableName()
	var sql string
	var columns, columnsHb, columnsAccumulateInner, columnsOuterLayer, columnsTotal []string
	var kpis, kpisHb, kpisAccumulate, kpisAccumulateInner, kpisOuterLayer, kpisHourTotal []string
	var where, whereHb []string
	var groups, groupsHb, groupsAccumulateInner, groupsOuterLayer []string
	var sorts []string
	columnsAccumulateArr := []string{"account_id", "mid_id",
		"media", "book_name", "pay_type", "app_name", "optimizer_nickname",
		"editor_name", "editor_region", "account_name", "material_name",
		"promotion_id", "promotion_name"}

	/* 查询示例
	-- 子查询sql
	SELECT DATE,material_name,mid_id,MAX(material_cover) AS material_cover -- columns
		,sum(income) AS income,0 AS income_hb,0 AS income2 -- kpis
	FROM material_report_hourly
	WHERE DATE>='2025-03-03' AND DATE<='2025-03-09' AND mid_id='7477774521400147978' -- where
	GROUP BY DATE,material_name,mid_id -- groups
	UNION ALL
	SELECT DATE_ADD(DATE,INTERVAL 7 DAY) AS DATE,material_name,mid_id,MAX(material_cover) AS material_cover -- columnsHb
		,0 AS income,sum(income) AS income_hb,0 AS income2 -- kpisHb
	FROM material_report_hourly
	WHERE DATE>='2025-02-24' AND DATE<='2025-03-02' AND mid_id='7477774521400147978' -- whereHb
	GROUP BY DATE,material_name,mid_id -- groupsHb
	UNION ALL
	SELECT DATE,material_name,mid_id,MAX(material_cover) AS material_cover -- columnsOuterLayer
		,0 AS income,SUM(income2) AS income2 -- kpisAccumulate
	FROM (
		SELECT DATE,account_id,mid_id
			,media,book_name,pay_type,app_name,optimizer_nickname
			,editor_name,editor_region,account_name,material_name
			,promotion_id,promotion_name,MAX(material_cover) AS material_cover -- columnsAccumulateInner
			,MAX(new_sum_income) AS new_sum_income,MAX(income2) AS income2
			,MAX(income3) AS income3,MAX(income4) AS income4,MAX(income5) AS income5
			,MAX(income6) AS income6,MAX(income7) AS income7 -- kpisAccumulateInner
		FROM material_report_hourly
		WHERE DATE>='2025-03-03' AND DATE<='2025-03-09' AND mid_id='7477774521400147978' -- where
		GROUP BY DATE,account_id,mid_id
			,media,book_name,pay_type,app_name,optimizer_nickname
			,editor_name,editor_region,account_name,material_name
			,promotion_id,promotion_name  -- groupsAccumulateInner
	) AS tt
	GROUP BY DATE,material_name,mid_id -- groupsOuterLayer
	-- 分页明细数据查询
	SELECT DATE,material_name,mid_id,MAX(material_cover) AS material_cover -- columnsOuterLayer
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t
	GROUP BY DATE,material_name,mid_id -- groupsOuterLayer
	ORDER BY DATE ASC,income DESC -- sorts
	LIMIT 19 OFFSET 0; -- limit offset
	-- 汇总行数据查询
	SELECT '汇总' AS DATE -- columnTotal
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t;
	*/

	// 时间聚合维度
	columnsTotal = append(columnsTotal, "'汇总' as date")
	hbStr := "DATE(DATE_ADD(date,INTERVAL " + strconv.Itoa(params.DaysOfHb) + " DAY))"
	if params.GroupType == "w" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%xW%v') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%xW%v') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%xW%v') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%xW%v')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%xW%v')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%xW%v')")
	} else if params.GroupType == "m" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%Y-%m') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%Y-%m') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%Y-%m') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%Y-%m')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%Y-%m')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%Y-%m')")
	} else if params.GroupType == "h" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		columnsHb = append(columnsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groups = append(groups, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00')")
		groupsHb = append(groupsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")
		// 分小时的汇总行计算需要特殊逻辑
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	} else {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "date")
		columnsHb = append(columnsHb, hbStr+" AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groups = append(groups, "date")
		groupsHb = append(groupsHb, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	}
	groupsOuterLayer = append(groupsOuterLayer, "date")
	columnsAccumulateInner = append(columnsAccumulateInner, columnsAccumulateArr...)
	groupsAccumulateInner = append(groupsAccumulateInner, columnsAccumulateArr...)

	// 用户定制聚合维度 (group by)
	columns = append(columns, params.GroupBy...)
	columnsHb = append(columnsHb, params.GroupBy...)
	columnsOuterLayer = append(columnsOuterLayer, params.GroupBy...)
	groups = append(groups, params.GroupBy...)
	groupsHb = append(groupsHb, params.GroupBy...)
	groupsOuterLayer = append(groupsOuterLayer, params.GroupBy...)

	//素材封面URL去重处理
	columns = append(columns, "MAX(material_cover) AS material_cover")
	columnsHb = append(columnsHb, "MAX(material_cover) AS material_cover")
	columnsOuterLayer = append(columnsOuterLayer, "MAX(material_cover) AS material_cover")
	columnsAccumulateInner = append(columnsAccumulateInner, "MAX(material_cover) AS material_cover")

	// 普通指标
	kpiArr := []string{"media_cost", "show_count", "click_count",
		"media_active_count", "media_convert_count", "media_first_pay_count",
		"active_count", "new_pay_count", "active_pay_count", "first_income"}
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
		if kpi == "media_cost" || kpi == "first_income" {
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0.0 AS "+kpi)
		} else {
			kpisHb = append(kpisHb, "0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0 AS "+kpi)
		}
	}

	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost) as cost")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_hb) as cost_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income) as income")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(spending_campaigns_count) as spending_campaigns_count")
	//实际消耗= 媒体消耗/(1+返点比例2%)
	kpis = append(kpis, "SUM(media_cost)/1.02 as cost")
	kpis = append(kpis, "0.0 as cost_hb")
	kpisHb = append(kpisHb, "0.0 as cost")
	kpisHb = append(kpisHb, "SUM(media_cost)/1.02 as cost_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_hb")
	//实际收入
	kpis = append(kpis, "SUM(income) as income")
	kpisHb = append(kpisHb, "0.0 as income")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income")
	//关联有消耗计划数(素材ID维度）
	kpis = append(kpis, "COUNT(DISTINCT promotion_id) as spending_campaigns_count")
	kpisHb = append(kpisHb, "0 as spending_campaigns_count")
	kpisAccumulate = append(kpisAccumulate, "0 as spending_campaigns_count")

	//累计指标的, 小时的直接取, 日周天 的 要取当天的最早有消费的小时的数据
	kpiArr = []string{"new_sum_income", "income2", "income3", "income4", "income5", "income6", "income7"}
	kpisHourTotal = append(kpisHourTotal, kpis...)
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		if params.GroupType == "h" {
			kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisHourTotal = append(kpisHourTotal, "0.0 AS "+kpi) //分小时汇总行的累计指标需要特殊处理
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		} else { //非小时的日周天独立查询
			kpis = append(kpis, "0.0 AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		}
	}

	// 最外层计算指标排序的，需要特殊处理
	var kpi string
	//{Label: "点击率", Prop: "click_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(click_count)/SUM(show_count), 0) AS click_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "点击成本", Prop: "click_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(cost)/SUM(click_count), 0) AS click_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "千展成本", Prop: "show_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(cost)/SUM(show_count), 0) AS show_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活成本", Prop: "media_active_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(media_active_count)>0, SUM(cost)/SUM(media_active_count), 0) AS media_active_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活率", Prop: "media_active_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(media_active_count)/SUM(click_count), 0) AS media_active_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "实际ROI", Prop: "roi", Format: "rate", SortAble: true, IsDefault: true},
	kpi = "IF(SUM(cost)>0, SUM(income)/SUM(cost), 0) AS roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "首日新增ROI", Prop: "first_roi", Format: "rate", SortAble: true},
	kpi = "IF(SUM(cost)>0, SUM(first_income)/SUM(cost), 0) AS first_roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)

	// 查询条件 (where)
	var filterStr string
	if len(params.Media) > 0 {
		filterStr = "media IN ('" + strings.Join(params.Media, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.BookID) > 0 {
		filterStr = "book_id IN (" + utils.Join(params.BookID, ",") + ")"
		where = append(where, filterStr)
	}
	if len(params.PayType) > 0 {
		filterStr = "pay_type IN ('" + strings.Join(params.PayType, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AppName) > 0 {
		filterStr = "app_name IN ('" + strings.Join(params.AppName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.MidID) > 0 {
		filterStr = "mid_id='" + params.MidID + "'"
		where = append(where, filterStr)
	}
	if len(params.MaterialName) > 0 {
		filterStr = "material_name IN ('" + strings.Join(params.MaterialName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.OptimizerName) > 0 {
		filterStr = "optimizer_nickname IN ('" + strings.Join(params.OptimizerName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.EditorName) > 0 {
		filterStr = "editor_name IN ('" + utils.Join(params.EditorName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.EditorRegion) > 0 {
		filterStr = "editor_region IN ('" + utils.Join(params.EditorRegion, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AccountID) > 0 {
		filterStr = "account_id IN ('" + strings.Join(params.AccountID, "','") + "')"
		where = append(where, filterStr)
	}

	whereHb = append(whereHb, where...)

	if params.StartDate == params.EndDate {
		where = append(where, "date='"+params.StartDate+"'")
		whereHb = append(whereHb, "date='"+params.StartDateHb+"'")
	} else {
		where = append(where, "date>='"+params.StartDate+"' AND date<='"+params.EndDate+"'")
		whereHb = append(whereHb, "date>='"+params.StartDateHb+"' AND date<='"+params.EndDateHb+"'")
	}

	// 排序 (sort)
	if len(params.Sorts) == 0 {
		params.Sorts = append(params.Sorts,
			common.Sort{Key: "date", Order: "asc"},
			common.Sort{Key: "cost", Order: "desc"},
		)
	}
	for _, sort := range params.Sorts {
		sorts = append(sorts, fmt.Sprintf("%s %s", sort.Key, sort.Order))
	}

	//子查询构造
	subSql := "SELECT " + strings.Join(columns, ",") + "," + strings.Join(kpis, ",") +
		" FROM " + roiTable +
		" WHERE " + strings.Join(where, " AND ") +
		" GROUP BY " + strings.Join(groups, ",") +
		" UNION ALL" +
		" SELECT " + strings.Join(columnsHb, ",") + "," + strings.Join(kpisHb, ",") +
		" FROM " + roiTable +
		" WHERE " + strings.Join(whereHb, " AND ") +
		" GROUP BY " + strings.Join(groupsHb, ",")
	if params.GroupType != "h" {
		subSql += " UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			" SELECT " + strings.Join(columnsAccumulateInner, ",") + "," + strings.Join(kpisAccumulateInner, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(where, " AND ") +
			" GROUP BY " + strings.Join(groupsAccumulateInner, ",") +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}

	// 分页明细数据查询
	var res []repo.ReportHourlyMaterialEntity
	sql = "SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t" +
		" GROUP BY " + strings.Join(groupsOuterLayer, ",") +
		" ORDER BY " + strings.Join(sorts, ",")
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	// 计算指标处理
	for i, row := range res {
		res[i] = *row.Calculate()
		if params.GroupType == "h" {
			res[i].Date = row.Date[0:10] + " " + row.Date[11:19]
		} else if params.GroupType == "d" {
			res[i].Date = row.Date[0:10]
		}
	}

	// 汇总行数据查询
	if params.GroupType == "h" {
		//子查询构造 - 小时维度特殊处理
		subSql = "SELECT " + strings.Join(columns, ",") + "," + strings.Join(kpisHourTotal, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(where, " AND ") +
			" GROUP BY " + strings.Join(groups, ",") +
			" UNION ALL" +
			" SELECT " + strings.Join(columnsHb, ",") + "," + strings.Join(kpisHb, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(whereHb, " AND ") +
			" GROUP BY " + strings.Join(groupsHb, ",") +
			" UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			" SELECT " + strings.Join(columnsAccumulateInner, ",") + "," + strings.Join(kpisAccumulateInner, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(where, " AND ") +
			" GROUP BY " + strings.Join(groupsAccumulateInner, ",") +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}
	var countRow repo.ReportHourlyMaterialEntity
	sql = "SELECT " + strings.Join(columnsTotal, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t"
	err = db.Raw(sql).Scan(&countRow).Error
	if err != nil {
		return nil, err
	}
	//拼接返回列表行
	var list []repo.ReportHourlyMaterialEntity
	if countRow.Date != "" {
		// 计算指标处理
		countRow.Calculate()
		list = append(list, countRow)
	}
	list = append(list, res...)

	// 格式化数据
	for i, row := range list {
		list[i].Media = utils.HtmlEncode(row.Media)
		if val, ok := materialdto.PayTypeMapping[row.PayType]; ok {
			list[i].PayType = val
		}
		list[i].BookName = utils.HtmlEncode(row.BookName)
		list[i].AppID = utils.HtmlEncode(row.AppID)
		list[i].AppName = utils.HtmlEncode(row.AppName)
		list[i].MidID = utils.HtmlEncode(row.MidID)
		list[i].MidType = utils.HtmlEncode(row.MidType)
		list[i].MaterialName = utils.HtmlEncode(row.MaterialName)
		list[i].OptimizerNickname = utils.HtmlEncode(row.OptimizerNickname)
		list[i].EditorName = utils.HtmlEncode(row.EditorName)
		list[i].EditorRegion = utils.HtmlEncode(row.EditorRegion)
		list[i].AccountID = utils.HtmlEncode(row.AccountID)
		list[i].AccountName = utils.HtmlEncode(row.AccountName)
		list[i].PromotionID = utils.HtmlEncode(row.PromotionID)
		list[i].PromotionName = utils.HtmlEncode(row.PromotionName)
	}

	result = &list
	return
}

// GetMediaCostByAdvertiserId 获取媒体花费大于0的账户id列表
func (d *ReportDataDao) GetMediaCostByAdvertiserId(startTime, endTime string, advertiserId []string) ([]string, error) {
	advertiserIdSlice := []string{}
	db := dorisdb.DorisClient()
	err := db.Table(repo.ReportHourlyMaterialTableName()).
		Where("date>=? AND date<=?", startTime, endTime).
		Where("account_id in (?)", advertiserId).
		Where("media_cost>?", 0).
		Pluck("distinct(account_id)", &advertiserIdSlice).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return advertiserIdSlice, err
	}
	return advertiserIdSlice, nil
}

// InsertBatchSizeFinalTable 插入更新最总报表数据
func (d *ReportDataDao) InsertBatchSizeFinalTable(data []repo.ReportHourlyMaterialEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsertFinalDate(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (d *ReportDataDao) batchInsertFinalDate(tx *gorm.DB, data []repo.ReportHourlyMaterialEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.ReportHourlyMaterialTableName() +
		" (`date`, `hour`, media, book_id, book_name, pay_type, app_id, app_name, optimizer_id, optimizer_nickname, " +
		"account_id, account_name, promotion_id, promotion_name, mid_id, mid_type, material_name, material_cover, " +
		"editor_name, editor_region, data_type, spending_campaigns_count, " +
		"media_cost, reward_cost, shared_wallet_cost, media_rebate_rate, " +
		"show_count, click_count, media_active_count, media_convert_count, media_first_pay_count, " +
		"income, active_count, new_pay_count, active_pay_count, first_income, new_sum_income, " +
		"income2, income3, income4, income5, income6, income7)  VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.Date, v.Hour, v.Media, v.BookID, v.BookName, v.PayType, v.AppID, v.AppName, v.OptimizerID, v.OptimizerNickname,
			v.AccountID, v.AccountName, v.PromotionID, v.PromotionName, v.MidID, v.MidType, v.MaterialName, v.MaterialCover,
			v.EditorName, v.EditorRegion, v.DataType, v.SpendingCampaignsCount,
			v.MediaCost, v.RewardCost, v.SharedWalletCost, v.MediaRebateRate,
			v.ShowCount, v.ClickCount, v.MediaActiveCount, v.MediaConvertCount, v.MediaFirstPayCount,
			v.Income, v.ActiveCount, v.NewPayCount, v.ActivePayCount, v.FirstIncome, v.NewSumIncome,
			v.Income2, v.Income3, v.Income4, v.Income5, v.Income6, v.Income7,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// BuildAggHasReferralFinalEntityData 按时间刷新数据 有推广链接
func (d *ReportDataDao) BuildAggHasReferralFinalEntityData(queryDate string) error {
	var data []repo.ReportHourlyMaterialEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	partition := "p" + strings.Replace(queryDate, "-", "", -1)
	ac := "SELECT module, media, ad.advertiser_id, advertiser_name, distributor, ad.promotion_id, app_name, book_id, book_name, region, optimizer_id, optimizer_name FROM ( SELECT advertiser_id, promotion_id, max(dpu_create_time) as max_created_at FROM account_distributor_promotion_url GROUP BY advertiser_id, distributor, promotion_id ) ad LEFT JOIN ( SELECT module, media, advertiser_id, advertiser_name, book_id, book_name, distributor, promotion_id, app_name, region, optimizer_id, optimizer_name, dpu_create_time FROM account_distributor_promotion_url ) adl ON ad.advertiser_id = adl.advertiser_id  AND ad.promotion_id = adl.promotion_id AND ad.max_created_at = adl.dpu_create_time "
	ad := "SELECT search_date, search_hour, material_id, filename, file_cutter, url, promotion_id, advertiser_id, promotion_name, referral_id, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM media_income_table " + adWhere + " AND referral_id != '' "
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, media AS media, book_id, book_name, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name,  optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, advertiser_name AS account_name, CASE WHEN (t.promotion_id = '' OR t.promotion_id = '__PROMOTION_ID__' ) THEN '0' ELSE t.promotion_id END AS promotion_id, promotion_name AS promotion_name, 1 AS data_type, material_id AS mid_id, 'video' AS mid_type, filename AS material_name, url AS material_cover, t.file_cutter AS editor_name, '' AS editor_region, cost AS media_cost, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count, active_pay AS media_first_pay_count, income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	region := "SELECT file_cutter, cutter_region FROM cutter_regions "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN (" + region + ") re ON t.file_cutter = re.file_cutter LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id AND t.referral_id = ac.promotion_id "
	db := dorisdb.DorisClient()
	q := db.Table(repo.ReportHourlyMaterialTableName())
	err := q.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	// 执行删除当日或历史数据
	deleteSql := "ALTER TABLE material_report_hourly DROP PARTITION IF EXISTS " + partition
	_ = db.Exec(deleteSql).Error
	err = d.InsertBatchSizeFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggNoReferralFinalEntityData 按时间刷新数据 无推广链接
func (d *ReportDataDao) BuildAggNoReferralFinalEntityData(queryDate string) error {
	var data []repo.ReportHourlyMaterialEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	ac := "SELECT module, media, ad.advertiser_id, advertiser_name, distributor, promotion_id, app_name, book_id, book_name, region, optimizer_id, optimizer_name FROM ( SELECT advertiser_id, max(promotion_id) as max_promotion_id FROM account_distributor_promotion_url GROUP BY advertiser_id ) ad LEFT JOIN ( SELECT module, media, advertiser_id, advertiser_name, book_id, book_name, distributor, promotion_id, app_name, region, optimizer_id, optimizer_name, dpu_create_time FROM account_distributor_promotion_url ) adl ON ad.advertiser_id = adl.advertiser_id AND ad.max_promotion_id = adl.promotion_id "
	ad := "SELECT search_date, search_hour, material_id, filename, file_cutter, url, promotion_id, advertiser_id, promotion_name, referral_id, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM media_income_table " + adWhere + " AND referral_id = '' "
	//ad := "SELECT search_date, search_hour, promotion_id, advertiser_id, promotion_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, referral_id, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM cost_income_table " + adWhere + " AND income = 0 "
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, media AS media, book_id, book_name, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name,  optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, advertiser_name AS account_name, CASE WHEN (t.promotion_id = '' OR t.promotion_id = '__PROMOTION_ID__' ) THEN '0' ELSE t.promotion_id END AS promotion_id, promotion_name AS promotion_name, 1 AS data_type, material_id AS mid_id, 'video' AS mid_type, filename AS material_name, url AS material_cover, t.file_cutter AS editor_name, '' AS editor_region, cost AS media_cost, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count, active_pay AS media_first_pay_count, income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	region := "SELECT file_cutter, cutter_region FROM cutter_regions "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN (" + region + ") re ON t.file_cutter = re.file_cutter LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id "
	db := dorisdb.DorisClient()
	q := db.Table(repo.ReportHourlyMaterialTableName())
	err := q.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

func (d *ReportDataDao) HourTuituiCostList() (res []mediareport.HourReport, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT search_date, search_hour, SUM(media_cost) OVER (PARTITION BY manager ORDER BY search_hour ASC) as media_cost, manager FROM ( SELECT cos.search_date, cos.search_hour, sum(cost) as media_cost, oa.manager  FROM ( SELECT date(search_date) as search_date, search_hour, advertiser_id, sum(cost) as cost FROM report_project_hour WHERE date(search_date) = CURRENT_DATE AND search_hour < HOUR(CURRENT_TIME) GROUP BY date(search_date), search_hour, advertiser_id ) cos LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) acc ON cos.advertiser_id = acc.advertiser_id LEFT JOIN ( SELECT user_id, cast(ext->'user_name' as CHAR) as manager  FROM oauth GROUP BY user_id, manager ) oa ON acc.user_id = oa.user_id GROUP BY cos.search_date, cos.search_hour, oa.manager ORDER BY oa.manager DESC, search_hour DESC ) a "
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

func (d *ReportDataDao) HourTuituiIncomeList() (res []mediareport.HourReport, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT search_date, search_hour, SUM(income) OVER (PARTITION BY search_date ORDER BY search_hour ASC) as income, SUM(real_income) OVER (PARTITION BY search_date ORDER BY search_hour ASC) as real_income FROM ( SELECT date(event_date) as search_date, case when hour(event_date) < 10 then CONCAT('0',hour(event_date)) else hour(event_date) END as search_hour, round(sum(ecpm_cost/100000)*1.28, 2) as income, round(sum(ecpm_cost/100000), 2) as real_income FROM tomato_iaa_award WHERE date(event_date) = CURRENT_DATE GROUP BY date(event_date), hour(event_date)) a "
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

func (d *ReportDataDao) DayTuituiCostList() (res []mediareport.HourReport, err error) {
	db := dorisdb.DorisClient()
	endDate := time.Now().AddDate(0, 0, -1).Format(time.DateOnly)
	sql := "SELECT cos.search_date, sum(cost) as media_cost, ma.manager  FROM ( SELECT date(search_date) as search_date, advertiser_id, sum(cost) as cost FROM report_project_hour WHERE date(search_date) BETWEEN '2025-05-01' AND '" + endDate + "' GROUP BY date(search_date), advertiser_id ) cos LEFT JOIN ( SELECT advertiser_id, manager FROM ( SELECT advertiser_id, oauth_id FROM oauth_account ) acc LEFT JOIN  ( SELECT oauth_id, cast(ext->'user_name' as CHAR) as manager  FROM oauth ) oa ON acc.oauth_id = oa.oauth_id ) ma ON cos.advertiser_id = ma.advertiser_id GROUP BY cos.search_date, ma.manager ORDER BY ma.manager DESC, search_date DESC "
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

func (d *ReportDataDao) DayTuituiIncomeList() (res []mediareport.HourReport, err error) {
	db := dorisdb.DorisClient()
	endDate := time.Now().AddDate(0, 0, -1).Format(time.DateOnly)
	sql := "SELECT date(event_date) as search_date,  round(sum(ecpm_cost/100000)*1.28, 2) as income, round(sum(ecpm_cost/100000), 2) as real_income FROM tomato_iaa_award WHERE date(event_date) BETWEEN '2025-05-01' AND '" + endDate + "' GROUP BY date(event_date)"
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

func (d *ReportDataDao) HourTuituiInfo() (res repo.ReportHourlyMaterialEntity, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT a.search_date as `date`, max(search_hour) as `hour`, round(sum(cost), 2) as media_cost, round(sum(income+raw_income), 2) as income , ROUND(sum(income+raw_income)/sum(cost), 2) as roi FROM (SELECT search_date, max(search_hour) as search_hour, sum(cost) as cost, sum(case when (delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then raw_income else 0 end) as raw_income FROM ( SELECT date(search_date) as search_date, max(search_hour) as search_hour, advertiser_id, project_id, sum(cost)/1.02 as cost, sum(stat_micro_game_0d_amount)*0.9*0.98 as raw_income FROM report_project_hour WHERE date(search_date) = CURRENT_DATE GROUP BY date(search_date), advertiser_id, project_id ) c LEFT JOIN ( SELECT advertiser_id, project_id, delivery_product, delivery_medium FROM project_info ) pro ON c.advertiser_id = pro.advertiser_id AND c.project_id = pro.project_id GROUP BY search_date ) a LEFT JOIN ( SELECT date(event_date) as event_date, sum(ecpm_cost/100000) * 1.28 as income  FROM tomato_iaa_award WHERE date(event_date) = CURRENT_DATE AND HOUR(event_date) < HOUR(CURRENT_TIME) GROUP BY date(event_date)) b ON a.search_date = b.event_date GROUP BY a.search_date"
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

func (d *ReportDataDao) DayTuituiInfo(endDate string) (res repo.ReportHourlyMaterialEntity, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT a.search_date as `date`, round(sum(cost), 2) as media_cost, round(sum(income+raw_income), 2) as income , ROUND(sum(income+raw_income)/sum(cost), 2) as roi FROM (SELECT search_date, max(search_hour) as search_hour, sum(cost) as cost, sum(case when (delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') or delivery_product = 'AWEME' then raw_income else 0 end) as raw_income FROM ( SELECT date(search_date) as search_date, max(search_hour) as search_hour, advertiser_id, project_id, sum(cost)/1.02 as cost, sum(stat_micro_game_0d_amount)*0.9*0.98 as raw_income FROM report_project_hour WHERE date(search_date) = '" + endDate + "' GROUP BY date(search_date), advertiser_id, project_id ) c LEFT JOIN ( SELECT advertiser_id, project_id, delivery_product, delivery_medium FROM project_info ) pro ON c.advertiser_id = pro.advertiser_id AND c.project_id = pro.project_id GROUP BY search_date ) a LEFT JOIN ( SELECT date(event_date) as event_date, sum(ecpm_cost/100000) * 1.28 as income  FROM tomato_iaa_award WHERE date(event_date) = '" + endDate + "' GROUP BY date(event_date)) b ON a.search_date = b.event_date GROUP BY a.search_date"
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

func (d *ReportDataDao) AccDayTuituiInfo(startDate, endDate string) (res repo.ReportHourlyMaterialEntity, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT round(sum(cost), 2) as media_cost, round(sum(income+raw_income), 2) as income , ROUND(sum(income+raw_income)/sum(cost), 2) as roi FROM ( SELECT sum(cost) as cost, sum(case when (delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then raw_income else 0 end) as raw_income FROM ( SELECT date(search_date) as search_date, max(search_hour) as search_hour, advertiser_id, project_id, sum(cost)/1.02 as cost, sum(stat_micro_game_0d_amount)*0.9*0.98 as raw_income FROM report_project_hour WHERE date(search_date) BETWEEN '" + startDate + "' AND '" + endDate + "' GROUP BY date(search_date), advertiser_id, project_id ) c LEFT JOIN ( SELECT advertiser_id, project_id, delivery_product, delivery_medium FROM project_info ) pro ON c.advertiser_id = pro.advertiser_id AND c.project_id = pro.project_id ) a, ( SELECT sum(ecpm_cost/100000) * 1.28 as income  FROM tomato_iaa_award WHERE date(event_date) BETWEEN '" + startDate + "' AND '" + endDate + "' ) b "
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

func (d *ReportDataDao) DaySubtractBillTuituiInfo(endDate string) (res repo.ReportHourlyMaterialEntity, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT a.search_date as `date`, round(sum((cost-reward_cost-shared_wallet_cost)/1.02), 2) as media_cost, round(sum(income+raw_income), 2) as income , ROUND(sum(income+raw_income)/sum((cost-reward_cost-shared_wallet_cost)/1.02), 2) as roi FROM ( SELECT search_date, sum(cost) as cost, sum(case when (delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then raw_income else 0 end) as raw_income FROM ( SELECT date(search_date) as search_date, advertiser_id, project_id, sum(cost) as cost, sum(stat_micro_game_0d_amount)*0.9*0.98 as raw_income FROM report_project_hour WHERE date(search_date) = '" + endDate + "' GROUP BY date(search_date), advertiser_id, project_id ) c LEFT JOIN ( SELECT advertiser_id, project_id, delivery_product, delivery_medium FROM project_info ) pro ON c.advertiser_id = pro.advertiser_id AND c.project_id = pro.project_id GROUP BY search_date ) a LEFT JOIN ( SELECT date(search_date) as date, sum(reward_cost) as reward_cost, sum(shared_wallet_cost) as shared_wallet_cost FROM bill_details WHERE date(search_date) = '" + endDate + "' GROUP BY date(search_date) ) c ON a.search_date = c.date LEFT JOIN ( SELECT date(event_date) as event_date, sum(ecpm_cost/100000) * 1.28 as income  FROM tomato_iaa_award WHERE date(event_date) = '" + endDate + "' GROUP BY date(event_date)) b ON a.search_date = b.event_date GROUP BY a.search_date "
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

func (d *ReportDataDao) AccDaySubtractBillTuituiInfo(startDate, endDate string) (res repo.ReportHourlyMaterialEntity, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT round(sum((cost-reward_cost-shared_wallet_cost)/1.02), 2) as media_cost, round(sum(income+raw_income), 2) as income , ROUND(sum(income+raw_income)/sum((cost-reward_cost-shared_wallet_cost)/1.02), 2) as roi FROM ( SELECT sum(cost) as cost, sum(case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then raw_income else 0 end) as raw_income FROM ( SELECT date(search_date) as search_date, max(search_hour) as search_hour, advertiser_id, project_id, sum(cost)/1.02 as cost, sum(stat_micro_game_0d_amount)*0.9*0.98 as raw_income FROM report_project_hour WHERE date(search_date) BETWEEN '" + startDate + "' AND '" + endDate + "' GROUP BY date(search_date), advertiser_id, project_id ) c LEFT JOIN ( SELECT advertiser_id, project_id, delivery_product, delivery_medium FROM project_info ) pro ON c.advertiser_id = pro.advertiser_id AND c.project_id = pro.project_id ) a, ( SELECT sum(ecpm_cost/100000) * 1.28 as income  FROM tomato_iaa_award WHERE date(event_date) BETWEEN '" + startDate + "' AND '" + endDate + "' ) b, ( SELECT sum(reward_cost) as reward_cost, sum(shared_wallet_cost) as shared_wallet_cost FROM bill_details WHERE date(search_date) BETWEEN '" + startDate + "' AND '" + endDate + "' ) c  "
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

type ROIStruct struct {
	Time     string `gorm:"column:time"`
	BookName string `gorm:"column:book_name"`
	//BookId    string  `gorm:"column:book_id"`
	MediaCost float64 `gorm:"column:media_cost"`
	HourCost  float64 `gorm:"column:hour_cost"`
	ROI       float64 `gorm:"column:roi"`
	Profit    float64 `gorm:"column:profit"`
}

func (d *ReportDataDao) ROITuituiInfo() (res []ROIStruct, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT CONCAT(CURRENT_DATE,\" \", HOUR(CURRENT_TIME)-1) as time, a.book_name, a.cost as media_cost, roi, a.income-a.cost as profit, b.cost as hour_cost FROM ( SELECT book_id, book_name, round(sum(media_cost), 2) as cost, round(sum(income), 2) as income, round(sum(income)/sum(media_cost), 2) as roi FROM roi_project_hourly_today WHERE date(date) = CURRENT_DATE AND media = '抖小' GROUP BY book_id, book_name HAVING cost > 500 AND roi < 0.5 ) a LEFT JOIN ( SELECT book_id, book_name, round(sum(media_cost), 2) as cost FROM roi_project_hourly_today WHERE date(date) = CURRENT_DATE AND `hour` =  HOUR(CURRENT_TIME)-1 GROUP BY book_id, book_name ) b ON a.book_id = b.book_id AND a.book_name = b.book_name" //a.book_id,
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}

func (d *ReportDataDao) FindAlbumSpeed() (res []warning.AlbumImage, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT t.`hour`, t.book_name, t.book_id, t.speed, t3.cost, round(t3.income/t3.cost, 2) as roi FROM ( SELECT HOUR(CURRENT_TIME) as `hour`, t1.book_name, t1.book_id, t1.cost1 - t2.cost2 as speed  FROM ( SELECT book_name, book_id, sum(media_cost) as cost1 FROM roi_project_hourly_today WHERE date(date) = CURRENT_DATE AND `hour` = HOUR(CURRENT_TIME)-1 GROUP BY book_name, book_id ) t1 LEFT JOIN ( SELECT book_name, book_id, sum(media_cost) as cost2 FROM roi_project_hourly_today WHERE date(date) = CURRENT_DATE AND `hour` = HOUR(CURRENT_TIME)-2 GROUP BY book_name, book_id ) t2 ON t1.book_id = t2.book_id AND t1.book_name = t2.book_name WHERE t1.cost1 - t2.cost2 > 500 AND t1.book_id != '0') t LEFT JOIN ( SELECT book_name, book_id, sum(media_cost) as cost, sum(income) as income FROM roi_project_hourly_today WHERE date(date) = CURRENT_DATE GROUP BY book_name, book_id ) t3 ON t.book_id = t3.book_id AND t.book_name = t3.book_name"
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}
