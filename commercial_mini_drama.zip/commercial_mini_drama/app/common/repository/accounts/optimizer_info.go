package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const OptimizerInfoTable = "optimizer_info_view"

type OptimizerInfoEntity struct {
	NickName  string    `gorm:"column:nick_name"`  // 优化师名称
	Phone     string    `gorm:"column:phone"`      // 手机号
	Region    string    `gorm:"column:region"`     // 城市
	Status    int64     `gorm:"column:status"`     // 账号状态 0: 正常 1: 停用
	CreatedAt time.Time `gorm:"column:created_at"` // 创建时间
	UpdatedAt time.Time `gorm:"column:updated_at"` // 更新时间
}

func (*OptimizerInfoEntity) TableName() string {
	return OptimizerInfoTableName()
}

func OptimizerInfoTableName() string {
	if repository.IsDebugTable(OptimizerInfoTable) {
		return OptimizerInfoTable + "_dev"
	} else {
		return OptimizerInfoTable
	}
}

/**
建立视图语句
CREATE VIEW commercial_mini_drama.optimizer_info_view
(
    nick_name COMMENT '优化师名字',
    phone COMMENT '手机号',
    region COMMENT '优化师区域名字',
    status COMMENT '状态 0=启用 1=停用',
    updated_at COMMENT '更新时间',
    created_at COMMENT '创建时间'
)
COMMENT '优化师信息视图表'
AS
SELECT
optimizer.optimizer_name,
optimizer.phone,
optimizer_city.optimizer_city_name,
(optimizer_city_relation.status - 1) as status,
optimizer_city_relation.updated_at,
optimizer_city_relation.created_at
FROM optimizer_city_relation
left join optimizer on optimizer_city_relation.optimizer_id = optimizer.optimizer_id
left join optimizer_city on optimizer_city_relation.optimizer_city_id = optimizer_city.optimizer_city_id;
**/
