package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const DistributorConfigTable = "distributor_config"

type DistributorConfigEntity struct {
	Distributor string    `gorm:"column:distributor"`
	ApiId       string    `gorm:"column:api_id"`
	ApiSecret   string    `gorm:"column:api_secret"`
	AppType     int       `gorm:"column:app_type"`
	ProfitModel string    `gorm:"column:profit_model"`
	CreatedAt   time.Time `gorm:"column:created_at"`
	UpdatedAt   time.Time `gorm:"column:updated_at"`
}

func (*DistributorConfigEntity) TableName() string {
	return DistributorConfigTableName()
}

func DistributorConfigTableName() string {
	if repository.IsDebugTable(DistributorConfigTable) {
		return DistributorConfigTable + "_dev"
	} else {
		return DistributorConfigTable
	}
}
