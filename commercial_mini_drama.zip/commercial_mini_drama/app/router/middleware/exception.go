package middleware

import (
	"github.com/gin-gonic/gin"
	"goserver/app/library/log"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
)

func ExceptionMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		defer func() {
			if err := recover(); err != nil {
				r := response.Gin{Ctx: c}
				log.Error(err)

				switch err.(type) {
				case *myerror.MyErr:
					e := err.(*myerror.MyErr)
					r.Response(e.Code, e.Message, nil)
				default:
					r.Response(myerror.InternalServerError.Code, myerror.InternalServerError.Message, nil)
				}
				c.Abort()
			}
		}()
		c.Next()
	}
}
