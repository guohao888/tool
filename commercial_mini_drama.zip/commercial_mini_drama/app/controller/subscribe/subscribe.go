package subscribe

import (
	"bytes"
	"fmt"
	"github.com/gin-gonic/gin"
	"goserver/app/common/dto/subscribedto"
	"goserver/app/library/kafka"
	"goserver/app/library/subscribe"
	"io"
	"net/http"
	"strconv"
)

func VerifyChallengeAndData(c *gin.Context) {
	// 解析参数
	event := c.Query("event")
	if event == "verify_webhook" {
		challenge := c.Query("challenge")
		iChallenge, _ := strconv.ParseInt(challenge, 10, 64)
		c.JSON(http.StatusOK, subscribedto.ChallengeResp{
			Challenge: iChallenge,
			BaseResp: subscribedto.BaseResp{
				StatusCode:    http.StatusOK,
				StatueMessage: "ok",
			},
		})
		return
	}
	// 验证签名数据
	body, bErr := c.GetRawData()
	if bErr != nil {
		c.JSON(http.StatusBadRequest, subscribedto.BaseResp{
			StatusCode:    http.StatusBadRequest,
			StatueMessage: fmt.Errorf("读取body失败").Error(),
		})
		return
	}
	if !subscribe.IsValidToken(body, []byte(c.GetHeader("X-Open-Signature"))) {
		c.JSON(http.StatusUnauthorized, subscribedto.BaseResp{
			StatusCode:    http.StatusUnauthorized,
			StatueMessage: fmt.Errorf("验签名失败").Error(),
		})
		return
	}
	// 重新注入 Body（关键步骤！）
	c.Request.Body = io.NopCloser(bytes.NewBuffer(body))

	req := subscribedto.NewPostInfoReq(c)
	// 推送数据到Kafka
	producer := kafka.SubscribeKafkaProducer()
	// 保存到Kafka
	err := producer.AddSubscribeInfo(*req)
	if err != nil {
		if err != nil {
			c.JSON(http.StatusInternalServerError, subscribedto.BaseResp{
				StatusCode:    http.StatusInternalServerError,
				StatueMessage: err.Error(),
			})
			return
		}
	}
	c.JSON(http.StatusOK, subscribedto.BaseResp{
		StatusCode:    http.StatusOK,
		StatueMessage: "ok",
	})
	return
}

// 直接入库
//taskService := subscribeService.NewSubscribedService(c)
//if req.ServiceLabel == "report.advertiser.activeprogram" {
//	todayErr := taskService.InsertTodayTask(req)
//	if todayErr != nil {
//		c.JSON(http.StatusOK, subscribedto.BaseResp{
//			StatusCode:    http.StatusInternalServerError,
//			StatueMessage: todayErr.Error(),
//		})
//		return
//	}
//} else if req.ServiceLabel == "report.advertiser.beforeday" {
//	beforeErr := taskService.InsertBeforeTask(req)
//	if beforeErr != nil {
//		c.JSON(http.StatusOK, subscribedto.BaseResp{
//			StatusCode:    http.StatusInternalServerError,
//			StatueMessage: beforeErr.Error(),
//		})
//		return
//	}
//}
