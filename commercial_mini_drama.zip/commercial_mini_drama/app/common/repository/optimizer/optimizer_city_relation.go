package optimizer

import (
	"goserver/app/common/repository"
	"time"
)

// OptimizerCityRelationEntityTable 优化师地区关联表
const OptimizerCityRelationEntityTable = "optimizer_city_relation"

type OptimizerCityRelationEntity struct {
	OptimizerCityRelationId int64     `gorm:"column:optimizer_city_relation_id"` // 优化师地区关联主键
	OptimizerId             int64     `gorm:"column:optimizer_id"`               // 优化师主键
	OptimizerCityId         int64     `gorm:"column:optimizer_city_id"`          // 优化师地区主键
	Status                  int64     `gorm:"column:status"`                     // 状态
	CreatedAt               time.Time `gorm:"column:created_at"`                 // 创建时间
	UpdatedAt               time.Time `gorm:"column:updated_at"`                 // 更新时间
}

// OptimizerCityRelationEntityTableName 表名称
func OptimizerCityRelationEntityTableName() string {
	if repository.IsDebugTable(OptimizerCityRelationEntityTable) {
		return OptimizerCityRelationEntityTable + "_dev"
	} else {
		return OptimizerCityRelationEntityTable
	}
}
