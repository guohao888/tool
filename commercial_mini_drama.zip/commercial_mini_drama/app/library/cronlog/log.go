package cronlog

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	"io"
	"os"
	"strings"
	"time"
)

func Info(ctx context.Context, args ...interface{}) {
	jobMap := ctx.Value("jobParam")
	if jobMap != nil {
		jobParamMap, ok := jobMap.(map[string]map[string]interface{})["logParam"]
		if ok {
			logId, ok := jobParamMap["logId"]
			if ok {
				nowTime := time.Now()

				var buffer bytes.Buffer
				buffer.WriteString(nowTime.Format(DateTimeFormat))
				buffer.WriteString("  [")

				jobName, ok := jobParamMap["jobName"]
				if ok {
					jobNameStr, _ := jobName.(string)
					buffer.WriteString(jobNameStr)
				}
				buffer.WriteString("#")
				jobFunc, ok := jobParamMap["jobFunc"]
				if ok {
					jobFuncStr, _ := jobFunc.(string)
					buffer.WriteString(jobFuncStr)
				}
				buffer.WriteString("]-[")

				jobId, ok := jobParamMap["jobId"]
				if ok {
					jobIdValue, _ := jobId.(int64)
					buffer.WriteString(fmt.Sprintf("jobId:%d", jobIdValue))
				}
				buffer.WriteString("]  ")
				if len(args) > 0 {
					for _, arg := range args {
						buffer.WriteString(fmt.Sprintf("%v", arg))
					}
				}
				buffer.WriteString("\r\n")

				logIdValue, _ := logId.(int64)
				writeLog(GetLogPath(nowTime), fmt.Sprintf("%d", logIdValue)+".log", buffer.String())
			}
		}
	}
}

func Error(ctx context.Context, args ...interface{}) {
	args = append(args, " err ")
	Info(ctx, args...)
}

/**
func LogEnd(ctx context.Context) {
	jobMap := ctx.Value("jobParam")
	if jobMap != nil {
		jobParamMap, ok := jobMap.(map[string]map[string]interface{})["logParam"]
		if ok {
			logid, ok := jobParamMap["logId"]
			if ok {
				nowTime := time.Now()
				var buffer bytes.Buffer
				buffer.WriteString("\r\n")
				logId := logid.(int64)
				writeLog(GetLogPath(nowTime), fmt.Sprintf("%d", logId)+".log", buffer.String())
			}
		}
	}
}
*/

// LogContext get log context
func LogContext(ctx context.Context, param *xxl.RunReq) context.Context {
	if ctx == nil {
		ctx = context.Background()
	}
	if param == nil {
		return ctx
	}
	jobMap := ctx.Value("jobParam")
	if jobMap == nil {
		logParam := make(map[string]interface{})
		logParam["logId"] = param.LogID
		logParam["jobId"] = param.JobID
		logParam["jobFunc"] = param.ExecutorHandler
		params := make(map[string]map[string]interface{})
		params["logParam"] = logParam
		ctx = context.WithValue(ctx, "jobParam", params)
	}
	return ctx
}

func GetLogPath(nowTime time.Time) string {
	return BasePath + nowTime.Format(DateFormat)
}

func InitLogPath() error {
	_, err := os.Stat(GetLogPath(time.Now()))
	if err != nil && os.IsNotExist(err) {
		err = os.MkdirAll(BasePath, os.ModePerm)
	}
	return err
}

func writeLog(logPath, logFile, log string) error {
	if strings.Trim(logFile, " ") != "" {
		fileFullPath := logPath + "/" + logFile
		file, err := os.OpenFile(fileFullPath, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0644)
		if err != nil && os.IsNotExist(err) {
			err = os.MkdirAll(logPath, os.ModePerm)
			if err == nil {
				file, err = os.OpenFile(fileFullPath, os.O_RDWR|os.O_CREATE|os.O_APPEND, 0644)
				if err != nil {
					return err
				}
			}
		}

		if file != nil {
			defer file.Close()
			res, err := file.Write([]byte(log))
			if err != nil {
				return err
			}
			if res <= 0 {
				return errors.New("write log failed")
			}
		}
	}
	return nil
}

func ReadLog(logDateTim, logId int64, fromLineNum, limit int32) (line int32, content string, isEnd bool) {
	now := time.Unix(logDateTim/1000, 0)
	fileName := GetLogPath(now) + "/" + fmt.Sprintf("%d", logId) + ".log"
	file, err := os.Open(fileName)
	totalLines := int32(1)
	var buffer bytes.Buffer
	if err == nil {
		defer file.Close()

		if fileState, err := file.Stat(); err == nil {
			fileSize := fileState.Size()
			if fromLineNum == 0 && fileSize > 100000 {
				file.Seek(-5000, io.SeekEnd)
			}
		}

		rd := bufio.NewReader(file)
		for {

			line, err := rd.ReadString('\n')
			if err == io.EOF {
				isEnd = true
				break
			}

			if err != nil {
				break
			}
			if totalLines >= fromLineNum {
				buffer.WriteString(line)
				limit--
			}
			totalLines++
			if limit == 0 {
				break
			}
		}
	}
	return totalLines, buffer.String(), isEnd
}
