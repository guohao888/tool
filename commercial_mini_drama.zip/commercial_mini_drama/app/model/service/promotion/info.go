package promotion

import (
	"context"
	"goserver/app/common/dto/page"
	promotionDto "goserver/app/common/dto/promotion"
	promotionRepo "goserver/app/common/repository/promotion"
	promotionDao "goserver/app/model/dao/promotion"
	"strconv"
	"time"
)

type InfoService struct {
	Ctx context.Context
}

func NewInfoService(ctx context.Context) *InfoService {
	return &InfoService{}
}

func (i *InfoService) List(req *promotionDto.ListReq) (*page.Paginator, error) {
	dao := promotionDao.NewPromotionInfoDao(i.Ctx)
	paginator, err := dao.PromotionList(req)
	if err != nil {
		return nil, err
	}

	list, _ := paginator.List.([]promotionRepo.PromotionInfoEntity)
	var res []promotionDto.ListInfo
	for _, v := range list {
		res = append(res, promotionDto.ListInfo{
			RequestId:           v.RequestID,
			PromotionId:         v.PromotionID,
			PromotionName:       v.PromotionName,
			PackageId:           v.PackageID,
			BoundPackageId:      strconv.FormatInt(v.BoundPackageID, 10),
			AdCallbackConfigId:  v.AdCallbackConfigID,
			PromotionNameFormat: v.PromotionNameFormat,
			BookId:              v.BookID,
			BookName:            v.BookName,
			AppName:             v.AppName,
			InstanceId:          strconv.FormatInt(v.InstanceID, 10),
			AdvertiserId:        strconv.FormatInt(v.AdvertiserID, 10),
			AdvertiserName:      v.AdvertiserName,
			CreateTime:          v.CreatedAt.Format(time.DateTime),
			UserName:            v.UserName,
			FailedReason:        v.FailedReason,
			StateCode:           v.StateCode,
		})
	}
	paginator.List = res

	return paginator, err
}
