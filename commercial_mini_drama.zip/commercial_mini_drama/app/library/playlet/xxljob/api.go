package xxljob

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/avast/retry-go"
	"github.com/go-playground/validator/v10"
	"github.com/gomodule/redigo/redis"
	"github.com/spf13/viper"
	"goserver/app/library/driver/redisdb"
	"goserver/app/library/utils/httplib"
	"io"
	"net/url"
	"strconv"
	"strings"
	"time"
)

const (
	ApiLogin           = "/login"            // 登录
	ApiJobInfoAdd      = "/jobinfo/add"      // 新增任务
	ApiJobInfoPageList = "/jobinfo/pageList" // 任务列表
	ApiJobInfoUpdate   = "/jobinfo/update"   // 编辑任务
	ApiJobInfoRemove   = "/jobinfo/remove"   // 删除
	ApiJobInfoStart    = "/jobinfo/start"    // 启动
	ApiJobInfoStop     = "/jobinfo/stop"     // 停止
)

const CacheXxlJobLoginIdentityKey = "commercial_mini_drama:xxl_job_login_identity"

var validate *validator.Validate

func init() {
	validate = validator.New()
}

type CommonResp struct {
	Code    int         `json:"code"`
	Msg     interface{} `json:"msg"`
	Content interface{} `json:"content"`
}

type LoginReq struct {
	UserName   string `validate:"required"`
	Password   string `validate:"required"`
	IfRemember string
}

type LoginResp struct {
	CommonResp
	XxlJobLoginIdentity string
	MaxAge              int
	Expires             time.Time
}

func GetXxlJobLoginIdentity() (string, error) {
	value, err := redisdb.GetStringValue(CacheXxlJobLoginIdentityKey)
	if err != nil && !errors.Is(err, redis.ErrNil) {
		return "", err
	}
	if value != "" {
		return value, nil
	}

	username := viper.GetString("xxl_job_admin.username")
	password := viper.GetString("xxl_job_admin.password")

	resp, err := Login(LoginReq{
		UserName:   username,
		Password:   password,
		IfRemember: "on",
	})
	if resp.XxlJobLoginIdentity != "" {
		_, err := redisdb.SetWithExpire(CacheXxlJobLoginIdentityKey, resp.XxlJobLoginIdentity, 60*60*24)
		if err != nil {
			return "", err
		}
		value = resp.XxlJobLoginIdentity
	}

	if value == "" {
		return "", errors.New("xxl job login identity key is empty")
	}

	return value, nil
}

// Login 登录
func Login(req LoginReq) (resp *LoginResp, err error) {
	err = validate.Struct(req)
	if err != nil {
		return nil, err
	}
	host := viper.GetString("xxl_job_admin.host")
	request := httplib.NewHttpRequest(host + ApiLogin)

	values := url.Values{}
	values.Set("userName", req.UserName)
	values.Set("password", req.Password)
	if req.IfRemember != "" {
		values.Set("ifRemember", "on")
	}

	params := values.Encode()
	request.SetBody(strings.NewReader(params))

	request.SetHeader(map[string]string{
		"Content-Type": "application/x-www-form-urlencoded",
	})

	resp = new(LoginResp)
	err = retry.Do(func() error {
		response, err := request.PostReturnResp()
		if err != nil {
			return err
		}

		if response.StatusCode != 200 {
			return errors.New(response.Status)
		}

		content, err := io.ReadAll(response.Body)
		defer response.Body.Close()
		if err != nil {
			return err
		}

		err = json.Unmarshal(content, resp)
		if err != nil {
			return err
		}

		if cookies := response.Cookies(); len(cookies) > 0 {
			for _, cookie := range cookies {
				if cookie.Name == "XXL_JOB_LOGIN_IDENTITY" {
					resp.XxlJobLoginIdentity = cookie.Value
					resp.Expires = cookie.Expires
					resp.MaxAge = cookie.MaxAge
				}
			}
		}

		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return resp, nil
}

type JobInfoPageListReq struct {
	JobGroup        int `validate:"required"` // 必填
	TriggerStatus   int `validate:"required"` // 必填
	JobDesc         string
	ExecutorHandler string
	Author          string
	Start           int
	Length          int
}

type JobInfoPageListRespData struct {
	Id                     int       `json:"id"`
	JobGroup               int       `json:"jobGroup"`
	JobDesc                string    `json:"jobDesc"`
	AddTime                time.Time `json:"addTime"`
	UpdateTime             time.Time `json:"updateTime"`
	Author                 string    `json:"author"`
	AlarmEmail             string    `json:"alarmEmail"`
	ScheduleType           string    `json:"scheduleType"`
	ScheduleConf           string    `json:"scheduleConf"`
	MisfireStrategy        string    `json:"misfireStrategy"`
	ExecutorRouteStrategy  string    `json:"executorRouteStrategy"`
	ExecutorHandler        string    `json:"executorHandler"`
	ExecutorParam          string    `json:"executorParam"`
	ExecutorBlockStrategy  string    `json:"executorBlockStrategy"`
	ExecutorTimeout        int       `json:"executorTimeout"`
	ExecutorFailRetryCount int       `json:"executorFailRetryCount"`
	GlueType               string    `json:"glueType"`
	GlueSource             string    `json:"glueSource"`
	GlueRemark             string    `json:"glueRemark"`
	GlueUpdatetime         time.Time `json:"glueUpdatetime"`
	ChildJobId             string    `json:"childJobId"`
	TriggerStatus          int       `json:"triggerStatus"`
	TriggerLastTime        int       `json:"triggerLastTime"`
	TriggerNextTime        int       `json:"triggerNextTime"`
}

type JobInfoPageListResp struct {
	CommonResp
	RecordsFiltered int                       `json:"recordsFiltered"`
	Data            []JobInfoPageListRespData `json:"data"`
	RecordsTotal    int                       `json:"recordsTotal"`
}

// JobInfoPageList 任务列表
func JobInfoPageList(req JobInfoPageListReq) (resp *JobInfoPageListResp, err error) {
	err = validate.Struct(req)
	if err != nil {
		return nil, err
	}

	host := viper.GetString("xxl_job_admin.host")
	request := httplib.NewHttpRequest(host + ApiJobInfoPageList)

	values := url.Values{}
	strconv.Itoa(req.JobGroup)
	values.Set("jobGroup", strconv.Itoa(req.JobGroup))
	values.Set("triggerStatus", strconv.Itoa(req.TriggerStatus))
	if req.JobDesc != "" {
		values.Set("jobDesc", req.JobDesc)
	}
	if req.ExecutorHandler != "" {
		values.Set("executorHandler", req.ExecutorHandler)
	}
	if req.Author != "" {
		values.Set("author", req.Author)
	}
	if req.Start > 0 {
		values.Set("start", strconv.Itoa(req.Start))
	}
	if req.Length > 0 {
		values.Set("length", strconv.Itoa(req.Length))
	}

	params := values.Encode()
	request.SetBody(strings.NewReader(params))

	resp = new(JobInfoPageListResp)
	err = retry.Do(func() error {

		xxlJobLoginIdentity, err := GetXxlJobLoginIdentity()
		if err != nil {
			return err
		}
		request.SetHeader(map[string]string{
			"Content-Type": "application/x-www-form-urlencoded",
			"Cookie":       fmt.Sprintf("%s=%s", "XXL_JOB_LOGIN_IDENTITY", xxlJobLoginIdentity),
		})

		respContent, err := request.Post()
		if err != nil {
			return err
		}

		err = json.Unmarshal([]byte(respContent), resp)
		if err != nil {
			return err
		}

		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return resp, nil
}

type JobInfoAddReq struct {
	JobGroup               int    `validate:"required"` // 必填 执行器id
	JobDesc                string `validate:"required"` // 必填 任务描述
	Author                 string `validate:"required"` // 必填 负责人
	AlarmEmail             string // 报警邮箱
	ScheduleType           string `validate:"required"`                      // 必填 调度类型: CRON:定时任务 FIX_RATE:固定速率
	ScheduleConf           string `validate:"required_if=ScheduleType CRON"` // CRON时: 就是毫秒定时任务表达式
	CronGenDisplay         string `validate:"required_if=ScheduleType CRON"` // CRON时: 就是毫秒定时任务表达式
	ScheduleConfCRON       string // 与调度类型有关
	ScheduleConfFixRate    string // 与调度类型有关
	ScheduleConfFixDelay   string // 与调度类型有关
	GlueType               string `validate:"required"` // 必填 运行模式
	ExecutorHandler        string `validate:"required"` // 必填 JobHandler
	ExecutorParam          string // 任务参数
	ExecutorRouteStrategy  string `validate:"required"` // 路由策略
	ChildJobID             string // 子任务ID
	MisfireStrategy        string // 调度过期策略
	ExecutorBlockStrategy  string `validate:"required"` // 阻塞处理策略
	ExecutorTimeout        int    // 任务超时时间
	ExecutorFailRetryCount int    // 失败重试次数
	GlueRemark             string
	GlueSource             string
	TriggerStatus          int // 状态 1:启动 0:停止
}

type JobInfoAddResp struct {
	CommonResp
}

func JobInfoAdd(req JobInfoAddReq) (resp *JobInfoAddResp, err error) {
	err = validate.Struct(req)
	if err != nil {
		return nil, err
	}
	host := viper.GetString("xxl_job_admin.host")
	request := httplib.NewHttpRequest(host + ApiJobInfoAdd)

	values := url.Values{}
	strconv.Itoa(req.JobGroup)
	values.Set("jobGroup", strconv.Itoa(req.JobGroup))
	values.Set("jobDesc", req.JobDesc)
	values.Set("author", req.Author)
	if req.AlarmEmail != "" {
		values.Set("alarmEmail", req.AlarmEmail)
	}
	values.Set("scheduleType", req.ScheduleType)
	if req.ScheduleConf != "" {
		values.Set("scheduleConf", req.ScheduleConf)
	}
	if req.CronGenDisplay != "" {
		values.Set("cronGen_display", req.CronGenDisplay)
	}
	if req.ScheduleConfCRON != "" {
		values.Set("schedule_conf_CRON", req.ScheduleConfCRON)
	}
	if req.ScheduleConfFixRate != "" {
		values.Set("schedule_conf_FIX_RATE", req.ScheduleConfFixRate)
	}
	if req.ScheduleConfFixDelay != "" {
		values.Set("schedule_conf_FIX_DELAY", req.ScheduleConfFixDelay)
	}
	values.Set("glueType", req.GlueType)
	values.Set("executorHandler", req.ExecutorHandler)
	if req.ExecutorParam != "" {
		values.Set("executorParam", req.ExecutorParam)
	}
	values.Set("executorRouteStrategy", req.ExecutorRouteStrategy)
	if req.ChildJobID != "" {
		values.Set("childJobId", req.ChildJobID)
	}
	if req.MisfireStrategy != "" {
		values.Set("misfireStrategy", req.MisfireStrategy)
	}
	values.Set("executorBlockStrategy", req.ExecutorBlockStrategy)

	if req.ExecutorTimeout > 0 {
		values.Set("executorTimeout", strconv.Itoa(req.ExecutorTimeout))
	}
	if req.ExecutorFailRetryCount > 0 {
		values.Set("executorFailRetryCount", strconv.Itoa(req.ExecutorFailRetryCount))
	}
	if req.GlueRemark != "" {
		values.Set("glueRemark", req.GlueRemark)
	}
	if req.GlueSource != "" {
		values.Set("glueSource", req.GlueSource)
	}
	values.Set("triggerStatus", strconv.Itoa(req.TriggerStatus))

	params := values.Encode()
	request.SetBody(strings.NewReader(params))

	resp = new(JobInfoAddResp)
	err = retry.Do(func() error {

		xxlJobLoginIdentity, err := GetXxlJobLoginIdentity()
		if err != nil {
			return err
		}
		request.SetHeader(map[string]string{
			"Content-Type": "application/x-www-form-urlencoded",
			"Cookie":       fmt.Sprintf("%s=%s", "XXL_JOB_LOGIN_IDENTITY", xxlJobLoginIdentity),
		})

		respContent, err := request.Post()
		if err != nil {
			return err
		}

		err = json.Unmarshal([]byte(respContent), resp)
		if err != nil {
			return err
		}

		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return resp, nil
}
