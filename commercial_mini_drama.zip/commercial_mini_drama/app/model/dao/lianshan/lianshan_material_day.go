package lianshan

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/lianshan"
	"goserver/app/library/driver/dorisdb"
	"log"
	"strings"
)

// MaterialDayDao 巨量素材天报表DAO
type MaterialDayDao struct {
	Ctx context.Context
}

func NewMaterialDayDao(ctx context.Context) *MaterialDayDao {
	return &MaterialDayDao{Ctx: ctx}
}

// InsertBatchSize 批量插入数据
func (r *MaterialDayDao) InsertBatchSize(data []lianshan.MaterialDayEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 1000
	}

	db := dorisdb.DorisClient()
	tx := db.Begin()
	eg := new(errgroup.Group)

	total := len(data)
	batchCount := (total + batchSize - 1) / batchSize // 计算批次数量

	for i := 0; i < batchCount; i++ {
		start := i * batchSize
		end := start + batchSize
		if end > total {
			end = total
		}
		batchData := data[start:end]

		eg.Go(func() error {
			defer func() {
				if r := recover(); r != nil {
					log.Printf("Recovered in InsertBatchSize: %v", r)
				}
			}()
			return r.buildInsertSQL(tx, batchData)
		})
	}

	if err := eg.Wait(); err != nil {
		tx.Rollback()
		return fmt.Errorf("batch insert failed: %w", err)
	}
	return tx.Commit().Error
}

// 构建插入SQL语句
func (r *MaterialDayDao) buildInsertSQL(tx *gorm.DB, data []lianshan.MaterialDayEntity) error {
	if len(data) == 0 {
		return nil
	}

	columns := []string{
		"id", "advertiser_id", "material_id", "cdp_project_id", "landing_type",
		"external_action", "pricing", "delivery_mode", "cdp_promotion_id", "app_code",
		"image_mode", "stat_time_day", "stat_cost", "show_cnt", "click_cnt",
		"convert_cnt", "cpm_platform", "ctr", "cpc_platform", "attribution_convert_cnt",
		"attribution_convert_cost", "attribution_conversion_rate", "conversion_rate",
		"attribution_micro_game_0d_ltv", "attribution_micro_game_3d_ltv", "total_play",
		"play_duration_3s", "valid_play", "valid_play_cost", "play_over_rate", "dy_like",
		"dislike_cnt", "play_duration_3s_rate", "stat_time", "uid", "create_time", "update_time",
	}

	sqlStr := fmt.Sprintf(
		"INSERT INTO %s (%s) VALUES ",
		lianshan.MaterialDayTableName(),
		strings.Join(columns, ", "),
	)

	var placeholders []string
	var values []interface{}

	for _, entity := range data {
		placeholders = append(placeholders, "("+strings.Repeat("?,", len(columns)-1)+"?)")

		values = append(values,
			entity.ID,
			entity.AdvertiserID,
			entity.MaterialID,
			entity.CdpProjectID,
			entity.LandingType,
			entity.ExternalAction,
			entity.Pricing,
			entity.DeliveryMode,
			entity.CdpPromotionID,
			entity.AppCode,
			entity.ImageMode,
			entity.StatTimeDay,
			entity.StatCost,
			entity.ShowCnt,
			entity.ClickCnt,
			entity.ConvertCnt,
			entity.CpmPlatform,
			entity.Ctr,
			entity.CpcPlatform,
			entity.AttributionConvertCnt,
			entity.AttributionConvertCost,
			entity.AttributionConversionRate,
			entity.ConversionRate,
			entity.AttributionMicroGame0dLtv,
			entity.AttributionMicroGame3dLtv,
			entity.TotalPlay,
			entity.PlayDuration3s,
			entity.ValidPlay,
			entity.ValidPlayCost,
			entity.PlayOverRate,
			entity.DyLike,
			entity.DislikeCnt,
			entity.PlayDuration3sRate,
			entity.StatTime,
			entity.UID,
			entity.CreateTime,
			entity.UpdateTime,
		)
	}

	sqlStr += strings.Join(placeholders, ",")
	return tx.Exec(sqlStr, values...).Error
}
