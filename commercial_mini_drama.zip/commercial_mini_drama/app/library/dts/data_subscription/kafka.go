package data_subscription

import (
	"context"
	"github.com/IBM/sarama"
	protobuf "google.golang.org/protobuf/proto"
	lianshanEntity "goserver/app/common/repository/lianshan"
	proto "goserver/app/library/dts/proto"
	"goserver/app/model/dao/lianshan"
	"log"
	"sync"
	"time"
)

type Handler struct {
	Topic          string
	PartitionCount map[int32]int
	TotalCount     int
	Mu             sync.Mutex
	dataChan       chan []map[string]interface{} // 传递数据批次
	workerCount    int                           // 工作协程数量
	ctx            context.Context
	cancel         context.CancelFunc
	wg             sync.WaitGroup
	batchSize      int           // 添加批量大小配置
	flushInterval  time.Duration // 添加刷新间隔配置
}

type Config struct {
	username string
	password string
	topic    string
	group    string
	addr     string
}

func (h *Handler) Setup(session sarama.ConsumerGroupSession) error {
	return nil
}
func (h *Handler) Cleanup(sarama.ConsumerGroupSession) error {
	return nil
}
func (h *Handler) ConsumeClaim(session sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	// 批量处理消息
	batchSize := 1000 // 每次处理的消息数量
	messages := make([]*sarama.ConsumerMessage, 0, batchSize)

	for message := range claim.Messages() {
		messages = append(messages, message)

		// 处理批量消息
		if len(messages) >= batchSize {
			h.processMessageBatch(messages)

			// 标记最后一条消息并提交
			session.MarkMessage(messages[len(messages)-1], "")
			messages = messages[:0] // 清空批量
		}
	}

	// 处理剩余的消息
	if len(messages) > 0 {
		h.processMessageBatch(messages)
		session.MarkMessage(messages[len(messages)-1], "")
	}

	return nil
}

func ConvertTo(c *proto.Column) interface{} {
	switch c.Value.(type) {
	case *proto.Column_Uint64Value:
		return c.GetUint64Value()
	case *proto.Column_StringValue:
		return c.GetStringValue()
	case *proto.Column_FloatValue:
		return c.GetFloatValue()
	case *proto.Column_Int64Value:
		return c.GetInt64Value()
	case *proto.Column_BoolValue:
		return c.GetBoolValue()
	case *proto.Column_BinaryValue:
		return c.GetBinaryValue()
	}
	return nil
}

// NewHandler 初始化Handler时启动工作池
func NewHandler(workerCount int, topic string, batchSize int, flushInterval time.Duration) *Handler {
	ctx, cancel := context.WithCancel(context.Background())
	h := &Handler{
		PartitionCount: make(map[int32]int),
		dataChan:       make(chan []map[string]interface{}, 1000),
		workerCount:    workerCount,
		ctx:            ctx,
		cancel:         cancel,
		Topic:          topic,
		batchSize:      batchSize,
		flushInterval:  flushInterval,
	}

	for i := 0; i < workerCount; i++ {
		h.wg.Add(1)
		go h.batchProcessor()
	}
	return h
}

// Close 关闭Handler时优雅停止
func (h *Handler) Close() {
	h.cancel()
	close(h.dataChan)
	h.wg.Wait()
}

// 批量处理器
func (h *Handler) batchProcessor() {
	defer h.wg.Done()

	batch := make([]map[string]interface{}, 0, h.batchSize)
	ticker := time.NewTicker(h.flushInterval)
	defer ticker.Stop()

	for {
		select {
		case data, ok := <-h.dataChan:
			if !ok {
				if len(batch) > 0 {
					h.flushBatch(batch)
				}
				return
			}
			batch = append(batch, data...)
			if len(batch) >= h.batchSize {
				h.flushBatch(batch)
				batch = batch[:0]
				ticker.Reset(h.flushInterval) // 重置计时器
			}

		case <-ticker.C:
			if len(batch) > 0 {
				h.flushBatch(batch)
				batch = batch[:0]
			}

		case <-h.ctx.Done():
			if len(batch) > 0 {
				h.flushBatch(batch)
			}
			return
		}
	}
}

// 执行批量插入
func (h *Handler) flushBatch(batch []map[string]interface{}) {
	if len(batch) == 0 {
		return
	}

	start := time.Now()
	convertStructList := lianshanEntity.ConvertToStruct(batch)

	// 使用带超时的上下文
	ctx, cancel := context.WithTimeout(context.Background(), 70*time.Second)
	defer cancel()

	reportLianshanDao := lianshan.NewReportLianshanDao(ctx)
	if err := reportLianshanDao.InsertBatchSize(convertStructList, 1000); err != nil {
		log.Printf("Batch insert failed: %v", err)
	} else {
		log.Printf("Inserted %d records in %v", len(batch), time.Since(start))
	}
}

func (h *Handler) processMessageBatch(messages []*sarama.ConsumerMessage) {
	list := make([]map[string]interface{}, 0)

	for _, msg := range messages {
		h.Mu.Lock()
		h.TotalCount++
		h.PartitionCount[msg.Partition]++
		h.Mu.Unlock()

		entry := &proto.Entry{}
		if err := protobuf.Unmarshal(msg.Value, entry); err != nil {
			log.Printf("Unmarshal failed: %v | Message: %x", err, msg.Value)
			continue
		}

		if entry.GetEntryType() == proto.EntryType_DML {
			event := entry.GetDmlEvent()
			cols := event.ColumnDefs

			for _, row := range event.Rows {
				rowMap := make(map[string]interface{})
				for i, col := range row.AfterCols {
					rowMap[cols[i].GetName()] = ConvertTo(col)
				}
				list = append(list, rowMap)
			}
		}
	}

	// 发送到批量处理通道
	if len(list) > 0 {
		select {
		case h.dataChan <- list:
		case <-time.After(100 * time.Millisecond):
			log.Println("Data channel full, dropping batch after timeout")
		}
	}
}
