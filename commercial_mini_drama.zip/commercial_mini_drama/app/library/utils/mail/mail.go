package mail

import (
	"github.com/spf13/viper"
	"gopkg.in/gomail.v2"
	"goserver/app/library/log"
	"strings"
)

func SendMail(mailTo string, subject string, body string) error {
	open := viper.GetBool("mail.open")
	log.Debugf("[sendAlert] mail open: %t", open)
	if !open {
		return nil
	}

	sender := viper.GetString("mail.sender")
	m := gomail.NewMessage()

	//设置发件人
	m.SetHeader("From", sender)

	//设置发送给多个用户
	mailArrTo := strings.Split(mailTo, ",")
	m.SetHeader("To", mailArrTo...)

	//设置邮件主题
	m.SetHeader("Subject", subject)

	//设置邮件正文
	m.SetBody("text/html", body)

	d := gomail.NewDialer("localhost", 25, "", "")

	err := d.DialAndSend(m)
	if err != nil {
		log.Debugf("[sendAlert] from: %s, to: %s, subject: %s, body: %d error: %s", sender, mailTo, subject, len(body), err)
	}
	log.Debugf("[sendAlert] from: %s, to: %s, subject: %s, body: %d success", sender, mailTo, subject, len(body))
	return err
}
