package optimizer

import (
	"goserver/app/common/repository"
	"time"
)

// OptimizerCityEntityTable 优化师地区表
const OptimizerCityEntityTable = "optimizer_city"

type OptimizerCityEntity struct {
	OptimizerCityId   int64     `gorm:"column:optimizer_city_id"`   // 优化师地区主键
	OptimizerCityName string    `gorm:"column:optimizer_city_name"` // 优化师地区名称 唯一
	CreatedAt         time.Time `gorm:"column:created_at"`          // 创建时间
	UpdatedAt         time.Time `gorm:"column:updated_at"`          // 更新时间
}

// OptimizerCityEntityTableName 表名称
func OptimizerCityEntityTableName() string {
	if repository.IsDebugTable(OptimizerCityEntityTable) {
		return OptimizerCityEntityTable + "_dev"
	} else {
		return OptimizerCityEntityTable
	}
}
