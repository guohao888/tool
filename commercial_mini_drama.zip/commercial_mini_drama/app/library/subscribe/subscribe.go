package subscribe

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
)

func IsValidToken(body []byte, signature []byte) bool {
	if len(signature) == 0 {
		return false
	}
	reSignature := Signature(body)
	fmt.Println("计算加密串：", reSignature, "返回头加密串：", string(signature))
	return reSignature == string(signature)
}

func Signature(body []byte) string {
	secretKey := "0e8dbfe3e26c4a028002a37a30e525c5"
	hash := hmac.New(sha256.New, []byte(secretKey))
	hash.Write(body)
	hashSum := hash.Sum(nil)
	hashString := hex.EncodeToString(hashSum)
	return hashString
}
