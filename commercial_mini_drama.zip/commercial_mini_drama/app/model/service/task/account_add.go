package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	"goserver/app/model/service/accountadd"
)

// SyncAccountAdd 推送spi订阅素材
func SyncAccountAdd(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("推送spi订阅素材参数解析错误, err: %s", err)
		}
	}
	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("推送spi订阅素材时间错误, err: %s", err)
	}
	//
	accountAddService := accountadd.NewAccountAddService(ctx)
	for _, crontabDate := range crontabDateList {
		err = accountAddService.SubscribeAccountAdd(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("推送spi订阅素材失败, err: %s", err)
		}
	}
	return "推送spi订阅素材成功"
}

// SyncAccountRemove 取消推送spi订阅素材
func SyncAccountRemove(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("取消推送spi订阅素材参数解析错误, err: %s", err)
		}
	}
	accountAddService := accountadd.NewAccountAddService(ctx)

	err := accountAddService.SubscribeAccountRemove(ctx)
	if err != nil {
		return fmt.Sprintf("取消推送spi订阅素材失败, err: %s", err)
	}

	return "取消推送spi订阅素材成功"
}

// SyncAccountAddDay 推送spi订阅素材
func SyncAccountAddDay(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("推送天级spi订阅素材参数解析错误, err: %s", err)
		}
	}
	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("推送天级spi订阅素材时间错误, err: %s", err)
	}
	//
	accountAddService := accountadd.NewAccountAddService(ctx)
	for _, crontabDate := range crontabDateList {
		err = accountAddService.SubscribeAccountAddDay(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("推送天级spi订阅素材失败, err: %s", err)
		}
	}
	return "推送天级spi订阅素材成功"
}

// SyncAccountRemoveDay 取消推送spi订阅素材
func SyncAccountRemoveDay(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("取消推送天级spi订阅素材参数解析错误, err: %s", err)
		}
	}
	accountAddService := accountadd.NewAccountAddService(ctx)

	err := accountAddService.SubscribeAccountRemoveDay(ctx)
	if err != nil {
		return fmt.Sprintf("取消推送天级spi订阅素材失败, err: %s", err)
	}

	return "取消推送天级spi订阅素材成功"
}
