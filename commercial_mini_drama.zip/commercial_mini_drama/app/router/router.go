package route

import (
	"goserver/app/controller/account"
	"goserver/app/controller/fanqie"
	"goserver/app/controller/material"
	"goserver/app/controller/optimizer"
	"goserver/app/controller/promotion"
	"goserver/app/controller/raw"
	"goserver/app/controller/roi"
	"goserver/app/controller/spi"
	"goserver/app/controller/subscribe"
	"goserver/app/controller/warning"
	"goserver/app/library/utils/pprof"
	"goserver/app/router/middleware"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
)

func SetupRouter(engine *gin.Engine) {
	//签名中间件
	cors := viper.GetBool("secure.cors")
	if cors {
		engine.Use(middleware.CrosHeaderMiddleware())
	}
	//mode := viper.GetString("env")
	//if mode != "prod" {
	_ = pprof.Init([]string{":22222"})
	//}

	// 404 Handler.
	engine.NoRoute(func(c *gin.Context) {
		c.String(http.StatusNotFound, "404 not find")
	})

	engine.GET("/status", func(c *gin.Context) {
		c.Writer.WriteString("ok\n")
	})

	//路由中间件(注意顺序) // 推推小程序
	MiniAppRouter := engine.Group("/miniapp/api").Use(
		middleware.LoggerMiddleware(),
		middleware.ExceptionMiddleware(),
		middleware.RequestMiddleware(),
		middleware.RbacMiddleware(),
		middleware.PermissionMiddleware(),
	)

	//API路由中间件(注意顺序)
	ApiRouter := engine.Group("/api").Use(
		middleware.LoggerMiddleware(),
		middleware.ExceptionMiddleware(),
		middleware.RequestMiddleware(),
		middleware.RbacMiddleware(),
		middleware.PermissionMiddleware(),
	)

	//签名中间件
	checkSign := viper.GetBool("secure.sign")
	if checkSign {
		ApiRouter.Use(middleware.SignMiddleware())
	}

	//防重放中间件
	checkReplay := viper.GetBool("secure.antireplay")
	if checkReplay {
		ApiRouter.Use(middleware.AntiReplayMiddleware())
	}

	ApiRouter.Use()
	{
		//ApiRouter.POST("/roi/report_data", roi.ReportData) // demo
		// 账户相关
		ApiRouter.POST("/mini_drama/account/filter", account.Filter)                // 筛选项
		ApiRouter.POST("/mini_drama/account/option_search", account.OptionSearch)   // 账户ID、账户名称、剧目检索
		ApiRouter.POST("/mini_drama/account/list", account.DataList)                // 账户维度列表
		ApiRouter.POST("/mini_drama/account/add_options", account.AddFilterOptions) // 新增账户下的筛选项数据
		ApiRouter.POST("/mini_drama/account/add", account.Add)                      // 新增账户
		ApiRouter.POST("/mini_drama/account/import", account.Import)                // 批量导入账户
		ApiRouter.POST("/mini_drama/account/batch_action", account.BatchAction)     // 批量账户关停
		ApiRouter.POST("/mini_drama/account/update", account.Update)                // 账户信息编辑 账户关停操作
		ApiRouter.POST("/mini_drama/account/export", account.Export)                // 账户信息导出

		ApiRouter.POST("/mini_drama/oauth_config/list", account.ConfigList) // 授权配置列表

		ApiRouter.POST("/mini_drama/account/sync_promotion_url", account.SyncPromotionUrl) // 账户同步小程序推广链

		// oauth授权相关
		ApiRouter.POST("/auth_appid/add", account.AddAppID)   // 添加appid配置
		ApiRouter.POST("/auth_appid/edit", account.EditAppID) // 编辑单个appid信息
		ApiRouter.POST("/auth_appid/list", account.AppIDList) // 获取appid列表

		// 报表相关
		ApiRouter.POST("/roi/option_search", roi.OptionSearch) //ROI报表筛选项搜索

		ApiRouter.POST("/roi/params", roi.Params)              //ROI报表页面筛选项
		ApiRouter.POST("/roi/list", roi.ReportData)            //ROI报表查询列表
		ApiRouter.POST("/roi/export", roi.Export)              //ROI报表查询导出
		ApiRouter.POST("/roi/last_modified", roi.LastExecTime) //ROI报表最后更新时间

		ApiRouter.POST("/roi/project_params", roi.ProjectParams)              //ROI报表页面筛选项（项目维度）
		ApiRouter.POST("/roi/project_list", roi.ProjectReportData)            //ROI报表查询列表（项目维度）
		ApiRouter.POST("/roi/project_export", roi.ProjectExport)              //ROI报表查询导出（项目维度）
		ApiRouter.POST("/roi/project_last_modified", roi.ProjectLastExecTime) //ROI报表最后更新时间（项目维度）

		// 快手ROI报表
		ApiRouter.POST("/kuaishou_roi/core_data/filter_options", roi.CoreDataFilterOptions) // 短剧总览数据 获取筛选项
		ApiRouter.POST("/kuaishou_roi/core_data/filter_search", roi.CoreDataFilterSearch)   // 短剧总览数据 筛选项搜索
		ApiRouter.POST("/kuaishou_roi/core_data/list", roi.CoreDataList)                    // 短剧总览数据 列表查询
		ApiRouter.POST("/kuaishou_roi/core_data/export", roi.CoreDataFilterExport)          // 短剧总览数据 列表导出

		ApiRouter.POST("/kuaishou_roi/ad_data/filter_options", roi.AdDataFilterOptions) // 广告投放数据 获取筛选项
		ApiRouter.POST("/kuaishou_roi/ad_data/filter_search", roi.AdDataFilterSearch)   // 广告投放数据 筛选项搜索
		ApiRouter.POST("/kuaishou_roi/ad_data/list", roi.AdDataList)                    // 广告投放数据 列表查询
		ApiRouter.POST("/kuaishou_roi/ad_data/export", roi.AdDataFilterExport)          // 广告投放数据 列表导出

		// 批量创建推广链接
		ApiRouter.POST("/promotion/package_list", promotion.PackageList)                //获取剧场信息
		ApiRouter.POST("/promotion/bound_package_list", promotion.BoundPackageList)     //获取渠道信息
		ApiRouter.POST("/promotion/book_meta", promotion.BookMeta)                      //根据book_id获取单个短剧信息
		ApiRouter.POST("/promotion/callback_config_list", promotion.CallbackConfigList) //获取回传规则
		ApiRouter.POST("/promotion/create", promotion.Create)                           //创建推广链
		ApiRouter.POST("/promotion/retry", promotion.Retry)                             //重新推送
		ApiRouter.POST("/promotion/list_params", promotion.ListOptions)                 //获取推广链列表查询参数
		ApiRouter.POST("/promotion/list", promotion.List)                               //获取推广链列表数据

		ApiRouter.POST("/material/params", material.Params)              //素材报表页面筛选项
		ApiRouter.POST("/material/option_search", material.OptionSearch) //素材报表筛选项搜索
		ApiRouter.POST("/material/list", material.ReportData)            //素材报表查询列表
		ApiRouter.POST("/material/export", material.Export)              //素材报表查询导出

		ApiRouter.POST("/coefficient/save", fanqie.TomatoAddCoefficient)     //IAA系数保存
		ApiRouter.POST("/coefficient/list", fanqie.GetTomatoCoefficientList) //IAA系数列表

		ApiRouter.POST("/warning/save_or_update", warning.SaveOrUpdateWarning) // 新建或修改告警任务
		ApiRouter.POST("/warning/list", warning.FindWarningList)               // 获取告警任务列表
		ApiRouter.POST("/warning/search_option", warning.GetSearchOption)      // 获取投放人员列表
		ApiRouter.POST("/warning/export_album", warning.Export)                // 剧目消耗查询导出

		// 新增优化师和地区表管理
		//ApiRouter.POST("/optimizer/update", optimizer.UpdateOptimizer)                                // 优化师新增、编辑(已弃用)
		ApiRouter.POST("/optimizer/list", optimizer.OptimizerList)                                    // 优化师查询列表
		ApiRouter.POST("/optimizer_city/update", optimizer.UpdateOptimizerCity)                       // 优化师地区新增、编辑
		ApiRouter.POST("/optimizer_city/list", optimizer.OptimizerCityList)                           // 优化师地区列表查询
		ApiRouter.POST("/optimizer_city_relation/update", optimizer.UpdateOptimizerCityRelation)      // 优化师-地区绑定关联新增、编辑
		ApiRouter.POST("/optimizer_city_relation/list", optimizer.OptimizerCityRelationList)          // 优化师地区绑定列表
		ApiRouter.POST("/optimizer_city_relation/get_relation", optimizer.GetRelationByOptimizerName) // 通过优化师名称获取关联数据
		ApiRouter.POST("/optimizer/refresh_data", optimizer.RefreshData)                              // 根据优化师更新手机号数据

		ApiRouter.POST("/monitor/save_or_update", warning.SaveOrUpdateMonitor)        // 新建或修改盯盘任务
		ApiRouter.POST("/monitor/get_list", warning.FindMonitorList)                  // 查询盯盘任务列表
		ApiRouter.POST("/monitor/delete", warning.DeleteMonitorInfo)                  // 删除盯盘任务
		ApiRouter.POST("/monitor/verity_account", warning.VerityAccountList)          // 验证账号
		ApiRouter.POST("/monitor/optimizer_account", warning.GetOptimizerAccountList) // 获取推推投手信息
		ApiRouter.POST("/mini_drama/raw_referral/import", raw.Import)                 // 端原生推广链接导入
		ApiRouter.POST("/mini_drama/craw_data/update_cookie", raw.UpdateCookie)       // 数据爬取更新cookie
	}

	MiniAppRouter.Use()
	{
		MiniAppRouter.POST("/roi/board/top_data", roi.BoardTopData)                   // 推推投放顶部数据
		MiniAppRouter.POST("/roi/board/today_market_data", roi.TodayMarketData)       // 推推大盘数据（今日）
		MiniAppRouter.POST("/roi/board/today_time_data", roi.TodayTimeData)           // 推推分时、趋势数据
		MiniAppRouter.POST("/roi/board/today_book_ranking", roi.TodayBookRanking)     // 推推今日短剧数据排名
		MiniAppRouter.POST("/roi/board/today_region_ranking", roi.TodayRegionRanking) // 推推今日地区数据排名

		MiniAppRouter.POST("/roi/board/options", roi.Options) // 推推小程序获取筛选项列表
	}

}

func SetupHttpsRouter(engine *gin.Engine) {
	// 404 Handler.
	engine.NoRoute(func(c *gin.Context) {
		c.String(http.StatusNotFound, "404 not find")
	})
	engine.Use(middleware.DomainWhiteListMiddleware())

	engine.GET("/status", func(c *gin.Context) {
		_, _ = c.Writer.WriteString("ok\n")
	})

	// ROI平台oauth授权回调路由组
	oauthRouter := engine.Group("/api/oauth2/callback").Use(
		middleware.LoggerMiddleware(),
		middleware.ExceptionMiddleware(),
	)
	{
		oauthRouter.GET("/toutiao", account.CallbackToutiao)                // 头条Oauth授权回调
		oauthRouter.GET("/kuaishou", account.CallbackKuaishou)              // 快手Oauth授权回调
		oauthRouter.GET("/toutiao/push", account.CallbackToutiaoPush)       // 推送应用回调
		oauthRouter.GET("/kuaishou_magnet", account.CallbackKuaishouMagnet) // 快手Oauth授权回调
		oauthRouter.GET("/assist", account.CallbackAssist)                  // 协管Oauth授权回调
	}
	tomatoRouter := engine.Group("/api/push").Use(
		middleware.LoggerMiddleware(),
		middleware.ExceptionMiddleware(),
	)
	{
		tomatoRouter.POST("/buyuser", fanqie.TomatoUserData)      // 番茄用户
		tomatoRouter.POST("/motivate", fanqie.TomatoIAAOrderData) // 番茄IAA订单
		tomatoRouter.POST("/order", fanqie.TomatoIAPOrderData)    // 番茄IAP订单
	}
	// 巨量SPI订阅回调路由组
	spiRouter := engine.Group("/api/spi").Use(
		middleware.LoggerMiddleware(),
		middleware.ExceptionMiddleware(),
	)
	{
		spiRouter.Any("/web_hook", spi.WebHook)                      // spi 回调
		spiRouter.Any("/callback", subscribe.VerifyChallengeAndData) // SIP 账号订阅回调地址
	}
}
