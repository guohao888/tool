package mediareport

import (
	"context"
	report "goserver/app/common/dto/mediareport"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	timeUtil "goserver/app/library/utils/time"
	accountdao "goserver/app/model/dao/accounts"
	"time"
)

// GetActiveAccountAndToken 获取活跃账号及token
func GetActiveAccountAndToken(ctx context.Context, params report.AccountReportSyncExecutorParams) (activeList []accountrepo.OauthActiveAccountEntity, oauthList []accountrepo.OauthEntity, err error) {
	media := repo.MediaToutiao
	// 1.获取活跃账号数据
	activeDao := accountdao.NewOauthActiveAccountDao(ctx)
	activeList, err = activeDao.ListByMediaAndAppIds(media, params.AppIds, params.AccountIds)
	if err != nil {
		return
	}
	// 2. 获取token
	oauthDao := accountdao.NewOauthDao(ctx)
	oauthList, err = oauthDao.ListOauthByMediaAppIds(media, params.AppIds)
	if err != nil {
		return
	}
	return
}

// GetExecTime 获取执行时间
func GetExecTime(crontabTime time.Time) (startDate, endDate string) {
	var pointDate time.Time
	// 时间点所属的日期
	pointDate, _ = timeUtil.GetDayTime(crontabTime)
	// 头条广告接口查询时间范围,和过滤条件hour
	startDate = pointDate.Format("2006-01-02")
	endDate = startDate
	return
}
