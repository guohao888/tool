package mediareport

import (
	"github.com/shopspring/decimal"
	"goserver/app/common/repository"
	"time"
)

const ReportMinuteEntityTable = "report_minute"

// ReportMinuteEntity 巨量消耗明细
type ReportMinuteEntity struct {
	SearchDate    time.Time       `gorm:"column:search_date"`    // 日期
	PromotionId   string          `gorm:"column:promotion_id"`   // 广告id
	PromotionName string          `gorm:"column:promotion_name"` // 广告名称
	AdvertiserId  string          `gorm:"column:advertiser_id"`  // 广告主ID
	ProjectId     string          `gorm:"column:project_id"`     // 项目id
	ProjectName   string          `gorm:"column:project_name"`   // 项目名称
	ShowCnt       int64           `gorm:"column:show_cnt"`       // 展现数
	Click         int64           `gorm:"column:click"`          // 点击数
	Active        int64           `gorm:"column:active"`         // 激活数
	ActivePay     int64           `gorm:"column:active_pay"`     // 首次付费数
	Cost          decimal.Decimal `gorm:"column:cost"`           // 总花费
	ConvertCnt    int64           `gorm:"column:convert_cnt"`    // 转化数
	CreatedTime   time.Time       `gorm:"column:created_time"`   // 数据创建时间
	UpdatedTime   time.Time       `gorm:"column:updated_time"`   // 数据更新时间
}

func (*ReportMinuteEntity) TableName() string {
	return ReportMinuteEntityTable
}

func ReportMinuteEntityTableName() string {
	if repository.IsDebugTable(ReportMinuteEntityTable) {
		return ReportMinuteEntityTable + "_dev"
	} else {
		return ReportMinuteEntityTable
	}
}
