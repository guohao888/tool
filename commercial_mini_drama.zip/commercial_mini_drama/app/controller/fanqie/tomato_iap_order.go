package fanqie

import (
	"github.com/gin-gonic/gin"
	fanqie2 "goserver/app/common/dto/fanqie"
	"goserver/app/library/kafka"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
)

// TomatoIAPOrderData 番茄IAP用户买入推送接口
func TomatoIAPOrderData(c *gin.Context) {
	r := response.Gin{Ctx: c}
	// 解析参数
	req := fanqie2.NewIAPOrderDataReq(c)
	// 推送数据到Kafka
	producer := kafka.POrderKafkaProducer()
	err := producer.AddIAPOrders(*req)
	if err != nil {
		r.Response(myerror.KafkaExecError.Code, myerror.KafkaExecError.Message, nil)
		return
	}
	r.Response(200, myerror.OK.Message, nil)
}
