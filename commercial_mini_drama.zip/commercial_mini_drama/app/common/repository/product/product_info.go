package product

import "goserver/app/common/repository"

const InfoProductEntityTable = "product_info"

type InfoProductEntity struct {
	AdvertiserId   string `gorm:"column:advertiser_id"`   // 账号ID
	PlatformId     int64  `gorm:"column:platform_id"`     // 商品库ID
	ProductId      int64  `gorm:"column:product_id"`      // 商品ID
	Name           string `gorm:"column:name"`            // 商品名称
	Description    string `gorm:"column:description"`     // 商品描述
	ImageUrl       string `gorm:"column:image_url"`       // 商品主图url链接，展示在信息流中的原始素材
	OnlineTime     int64  `gorm:"column:online_time"`     // 商品上线时间，格式为十位unix时间戳类型
	OfflineTime    int64  `gorm:"column:offline_time"`    // 商品下线时间，格式为十位unix时间戳类型
	Status         int32  `gorm:"column:status"`          // 商品投放状态，0代表不可投放，1代表可投放
	Title          string `gorm:"column:title"`           // 商品标题
	Video          string `gorm:"column:video"`           // 视频链接url
	CopyRightOwner string `gorm:"column:copyright_owner"` // 版权方
}

func (InfoProductEntity) TableName() string {
	return InfoProductEntityTable
}

func InfoProductEntityTableName() string {
	if repository.IsDebugTable(InfoProductEntityTable) {
		return InfoProductEntityTable + "_dev"
	} else {
		return InfoProductEntityTable
	}
}
