package spi

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"goserver/app/common/dto/spidto"
	"goserver/app/library/log"
	spiservice "goserver/app/model/service/spi"
	"net/http"
	"strconv"
)

// TaskGet 获取推送数据列表
func TaskGet(c *gin.Context) {
	// 设置时间范围
	//startTime := time.Date(2025, 4, 28, 1, 0, 0, 0, time.Local)
	//endTime := time.Date(2025, 4, 29, 0, 0, 0, 0, time.Local)

	//startTimeStr := "2025-04-29 00:00:00"
	//endTimeStr := "2025-04-29 00:30:00"
	//
	//cursor := int64(0)
	//
	//service := spiservice.NewTaskGetService(c.Request.Context(), startTimeStr, endTimeStr, cursor)
	//service.TaskGet()

	return
	// 计算需要执行的小时数
	//hours := int(endTime.Sub(startTime).Hours())
	//if hours <= 0 {
	//	c.String(http.StatusOK, "时间范围无效")
	//	return
	//}

	// 创建等待组
	//var wg sync.WaitGroup
	//wg.Add(4) // 固定4个协程

	// 创建错误通道
	//errChan := make(chan error, hours)

	// 为每个协程分配小时区间
	//for i := 0; i < 4; i++ {
	//	go func(workerID int) {
	//		defer wg.Done()
	//
	//		// 计算当前协程负责的小时范围
	//		hoursPerWorker := hours / 4
	//		remainder := hours % 4
	//
	//		// 分配额外的小时给前面的协程
	//		startHour := workerID * hoursPerWorker
	//		if workerID < remainder {
	//			startHour += workerID
	//		} else {
	//			startHour += remainder
	//		}
	//
	//		endHour := startHour + hoursPerWorker
	//		if workerID < remainder {
	//			endHour += 1
	//		}
	//
	//		// 处理分配的小时区间
	//		for hour := startHour; hour < endHour; hour++ {
	//			// 计算当前小时区间的开始和结束时间
	//			currentStart := startTime.Add(time.Duration(hour) * time.Hour)
	//			currentEnd := currentStart.Add(time.Hour)
	//
	//			// 格式化时间
	//			startTimeStr := currentStart.Format("2006-01-02 15:04:05")
	//			endTimeStr := currentEnd.Format("2006-01-02 15:04:05")
	//
	//			// 执行任务
	//			service := spiservice.NewTaskGetService(c.Request.Context(), startTimeStr, endTimeStr, int64(0))
	//			service.TaskGet()
	//		}
	//	}(i)
	//}

	// 等待所有协程完成
	//go func() {
	//	wg.Wait()
	//	close(errChan)
	//}()
	//
	//// 检查是否有错误发生
	//var hasError bool
	//for err := range errChan {
	//	if err != nil {
	//		hasError = true
	//		log.Errorf("任务执行出错: %v", err)
	//	}
	//}

	//if hasError {
	//	c.String(http.StatusInternalServerError, "部分任务执行失败")
	//} else {
	//	c.String(http.StatusOK, "所有任务执行完成")
	//}
}

// WebHook 处理巨量引擎SPI回调
func WebHook(c *gin.Context) {

	// 处理验证事件
	if event := c.Query("event"); event == "verify_webhook" {
		c.JSON(http.StatusOK, handleVerify(c))
		return
	}

	// 获取并记录原始数据
	body, err := c.GetRawData()
	log.Infof("oceanengine spi 巨量引擎SPI请求体: %s", string(body))
	if err != nil {
		handleError(c, http.StatusInternalServerError, err)
		return
	}

	// 验证签名
	if !validateSignature(c, body) {
		handleError(c, http.StatusBadRequest, fmt.Errorf("签名验证失败"))
		return
	}

	// 重新设置请求体
	//c.Request.Body = io.NopCloser(strings.NewReader(string(body)))
	//解析请求体
	//var req spidto.SpiMaterialRequest
	//if err := c.ShouldBindJSON(&req); err != nil {
	//	handleError(c, http.StatusBadRequest, err)
	//	return
	//}

	err = spiservice.NewWebHookService(c, body).SendDataToKafka()
	if err != nil {
		handleError(c, http.StatusInternalServerError, fmt.Errorf("业务异常请重试"))
		return
	}

	c.JSON(http.StatusOK, spidto.VerifyResponse{
		BaseResp: spidto.NewBaseResp(http.StatusOK, "ok"),
	})
}

// handleVerify 处理订阅验证请求
func handleVerify(c *gin.Context) spidto.VerifyResponse {
	challenge, _ := strconv.ParseInt(c.Query("challenge"), 10, 64)
	return spidto.VerifyResponse{
		BaseResp:  spidto.NewBaseResp(http.StatusOK, "ok"),
		Challenge: challenge,
	}
}

// handleError 统一错误处理
func handleError(c *gin.Context, status int, err error) {
	c.JSON(status, spidto.VerifyResponse{
		BaseResp: spidto.NewBaseResp(status, err.Error()),
	})
}

// validateSignature 验证请求签名
func validateSignature(c *gin.Context, body []byte) bool {
	secretKey := viper.GetString("oceanengine_spi.secret_key")
	util := &spiservice.AuthTokenUtil{SecretKey: secretKey}
	sign := c.GetHeader("X-Open-Signature")
	res := util.IsValidToken(c, body, []byte(sign))
	if !res {
		log.Infof("oceanengine spi validateSignature err, sign:%s", sign)
	}
	return res
}
