package novelsale

import (
	"encoding/json"
	"fmt"
	"goserver/app/common/repository"
	"goserver/app/library/utils/httplib"
	"goserver/app/library/utils/md5"
	"net/url"
	"strconv"
	"strings"
	"time"

	"github.com/avast/retry-go"
)

const (
	host = "https://www.changdunovel.com"
)

const (
	OpenapiWxGetPackageListV2           = "/novelsale/openapi/wx/get_package_list/v2/"            // 【IAA】2.25 获取账户下分包信息V2（快应用|微信H5|小程序）,【IAP】2.1.1 获取账户下分包信息
	OpenapiWxGetBoundPackageListV1      = "/novelsale/openapi/wx/get_bound_package_list/v1/"      // 【IAA】2.26 获取小程序绑定的渠道信息,【IAP】2.1.2 获取小程序渠道信息
	OpenapiPromotionListV1              = "/novelsale/openapi/promotion/list/v1/"                 // 【IAA】2.8 获取推广链接列表,【IAP】2.3.1 获取推广链列表
	OpenapiContentBookMetaV1            = "/novelsale/openapi/content/book_meta/v1/"              // 【IAA】2.2.1 获取短剧信息
	OpenapiAdCallbackConfigConfigListV1 = "/novelsale/openapi/ad_callback_config/config_list/v1/" // 【IAA】2.4.1 获取广告回传规则列表
	OpenapiPromotionCreateV1            = "/novelsale/openapi/promotion/create/v1/"               // 【IAA】2.2.2 创建推广链
)

const (
	AuthStatusAuthorized   = 1 // 有授权
	AuthStatusUnauthorized = 2 // 无授权
)

type CommonResp struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

type WxGetPackageListV2Req struct {
	DistributorId int64  // 分销商标识，用于获取对应广告账号信息，从而获取广告账号下所有分包信息。因此提供相同广告账号的不同渠道的distributor_id获取到的分包信息相同。当提供app_type时只返回对应渠道的分包信息
	SecretKey     string //
	PageIndex     int    // 页码，从0开始
	PageSize      int    // 页面大小，最大为50条记录
	AppType       int    // 应用业务类型。枚举值，提供该字段则只返回对应渠道分包列表, 快应用=1, 微信h5=3, 微信付费短剧=4, 抖小付费短剧=7, 抖小付费网文=8, 抖音免费短剧 = 10, 微信付费网文=12
}

type PackageInfoOpenListItem struct {
	AppId   int64  `json:"app_id"`
	AppName string `json:"app_name"`
	AppType int    `json:"app_type"`
}

type WxGetPackageListV2Resp struct {
	CommonResp
	PackageInfoOpenList []PackageInfoOpenListItem `json:"package_info_open_list"`
	Total               int                       `json:"total"`
}

// WxGetPackageListV2
// 2.25 获取账户下分包信息V2（快应用|微信H5|小程序）【IAP】 https://bytedance.larkoffice.com/docx/doxcnoXWGp3qywnQYC8zVw069Bb
//
//		接口说明：
//	 1. 不同快应用/公众号区分：快应用/公众号/小程序与distributor_id为1对1关系，即每个公众号都有不同的distributor_id；
//	 2. 区分快应用/公众号获取信息：接口1的2.25可使用任何一个公众号/快应用/小程序的distributor_id请求，可获取账户内所有快应用/公众号/小程序的distributor_id，其他接口使用不同的distributor_id请求，只返回对应快应用/公众号/小程序信息；
//	 3. 小程序(微信、抖音)类型需配合2.26 获取子账号渠道信息，快应用|H5类型只需此接口；
//
// 2.1.1 获取账户下分包信息 【IAA】 https://bytedance.larkoffice.com/docx/YO75ddCoGopUlox6unJcuj6on9d
//
//	无
func WxGetPackageListV2(req WxGetPackageListV2Req) (resp *WxGetPackageListV2Resp, err error) {
	request := httplib.NewHttpRequest(host + OpenapiWxGetPackageListV2)

	params := url.Values{}
	params.Add("distributor_id", strconv.FormatInt(req.DistributorId, 10))
	params.Add("app_type", strconv.Itoa(req.AppType))
	if req.PageIndex > 0 {
		params.Add("page_index", strconv.Itoa(req.PageIndex))
	}
	if req.PageSize > 0 {
		params.Add("page_size", strconv.Itoa(req.PageSize))
	}
	params = getSign(params, req.SecretKey)

	request.SetParams(params)

	resp = new(WxGetPackageListV2Resp)
	err = retry.Do(func() error {
		respContent, err := request.Get(false)
		if err != nil {
			return err
		}

		err = json.Unmarshal([]byte(respContent), resp)
		if err != nil {
			return err
		}

		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return resp, nil
}

type AllWxGetPackageListV2Req struct {
	DistributorId int64  // 分销商标识，用于获取对应广告账号信息，从而获取广告账号下所有分包信息。因此提供相同广告账号的不同渠道的distributor_id获取到的分包信息相同。当提供app_type时只返回对应渠道的分包信息
	SecretKey     string //
	AppType       int    // 应用业务类型。枚举值，提供该字段则只返回对应渠道分包列表, 快应用=1, 微信h5=3, 微信付费短剧=4, 抖小付费短剧=7, 抖小付费网文=8, 抖音免费短剧 = 10, 微信付费网文=12
}

func AllWxGetPackageListV2(req AllWxGetPackageListV2Req) ([]PackageInfoOpenListItem, error) {
	pageIndex := 0
	pageSizeMax := 50

	var list []PackageInfoOpenListItem
	for {
		resp, err := WxGetPackageListV2(WxGetPackageListV2Req{
			DistributorId: req.DistributorId,
			SecretKey:     req.SecretKey,
			PageIndex:     pageIndex,
			PageSize:      pageSizeMax,
			AppType:       req.AppType,
		})
		if err != nil {
			return nil, err
		}

		if len(resp.PackageInfoOpenList) > 0 {
			list = append(list, resp.PackageInfoOpenList...)
		}

		if len(resp.PackageInfoOpenList) < pageSizeMax || resp.Total == pageSizeMax {
			break
		}
		pageIndex++
	}

	return list, nil
}

func getSign(params url.Values, secretKey string) url.Values {
	ts := strconv.FormatInt(time.Now().Unix(), 10)
	params.Add("ts", ts)

	str := fmt.Sprintf("%s%s%s", params.Get("distributor_id"), secretKey, ts)
	sign := strings.ToLower(md5.GetStringMd5(str))
	params.Add("sign", sign)

	return params
}

type PromotionListV1Req struct {
	DistributorId    int64  // 必须 分销商标识
	SecretKey        string //
	BookId           string // 短剧/书本id
	PromotionId      string // 推广链id
	Begin            int64  // 数据查询开始时间点（unix 时间戳），默认为上一个小时开始时间点，最大支持获取3天内数据
	End              int64  // 数据查询截止时间点（unix 时间戳），默认为当前小时的开始时间点，最大时间范围为1小时
	Offset           int64  // 分页模式使用，指从第x条数据开始获取，默认为0，配合limit使用, limit=10，offset=1，本次拉取的数据为第11条-第20条, limit=100，offset=1，本次拉取的数据为第101条-第200条
	Limit            int64  // 分页模式使用，默认100，最大值1000
	OptimizerAccount string // 优化师邮箱，仅快应用填写
	OptimizerId      string // 优化师 id，仅快应用填写
}

type PromotionListV1RespResultItem struct {
	AdCallbackConfigId int64  `json:"ad_callback_config_id"`
	BookId             int64  `json:"book_id"`
	BookName           string `json:"book_name"`
	ChapterId          int64  `json:"chapter_id"`
	ChapterOrder       int    `json:"chapter_order"`
	ChapterTitle       string `json:"chapter_title"`
	CreateTime         string `json:"create_time"`
	MediaSource        int    `json:"media_source"`
	MonitorUrl         string `json:"monitor_url"`
	OptimizerAccount   string `json:"optimizer_account"`
	OptimizerId        int64  `json:"optimizer_id"`
	PackStrategyStatus int    `json:"pack_strategy_status"`
	PermissionStatus   int    `json:"permission_status"`
	PromotionHttpUrl   string `json:"promotion_http_url"`
	PromotionId        int64  `json:"promotion_id"`
	PromotionName      string `json:"promotion_name"`
	PromotionUrl       string `json:"promotion_url"`
}

func (ri *PromotionListV1RespResultItem) GetPromotionUrl(appType int) (string, error) {
	var promotionUrl string
	switch appType {
	case repository.FanQieAppType7, repository.FanQieAppType10:
		urlParse, err := url.Parse(ri.PromotionUrl)
		if err != nil {
			return "", err
		}
		promotionUrl = urlParse.Query().Get("code")
	case repository.FanQieAppType4:
		promotionUrl = ri.PromotionUrl
	}

	return promotionUrl, nil
}

type PromotionListV1Resp struct {
	CommonResp
	HasMore    bool                            `json:"has_more"`
	NextOffset int64                           `json:"next_offset"`
	Result     []PromotionListV1RespResultItem `json:"result"`
}

// PromotionListV1
// 2.18 用户点击推广链接口 【IAP】
// https://bytedance.larkoffice.com/docx/doxcnoXWGp3qywnQYC8zVw069Bb
// 2.3.1 获取推广链列表 【IAA】
// https://bytedance.larkoffice.com/docx/YO75ddCoGopUlox6unJcuj6on9d
func PromotionListV1(req PromotionListV1Req) (resp *PromotionListV1Resp, err error) {
	request := httplib.NewHttpRequest(host + OpenapiPromotionListV1)

	params := url.Values{}
	params.Add("distributor_id", strconv.FormatInt(req.DistributorId, 10))
	if req.BookId != "" {
		params.Add("book", req.BookId)
	}
	if req.PromotionId != "" {
		params.Add("promotion_id", req.PromotionId)
	}
	if req.Begin > 0 {
		params.Add("begin", strconv.FormatInt(req.Begin, 10))
	}
	if req.End > 0 {
		params.Add("end", strconv.FormatInt(req.Begin, 10))
	}
	if req.Offset > 0 {
		params.Add("offset", strconv.FormatInt(req.Offset, 10))
	}
	if req.Limit > 0 {
		params.Add("limit", strconv.FormatInt(req.Limit, 10))
	}
	if req.OptimizerAccount != "" {
		params.Add("optimizer_account", req.OptimizerAccount)
	}
	if req.OptimizerId != "" {
		params.Add("optimizer_id", req.OptimizerId)
	}
	params = getSign(params, req.SecretKey)

	request.SetParams(params)

	resp = new(PromotionListV1Resp)
	err = retry.Do(func() error {
		respContent, err := request.Get(false)
		if err != nil {
			return err
		}

		err = json.Unmarshal([]byte(respContent), resp)
		if err != nil {
			return err
		}

		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return resp, nil
}

type AllPromotionListV1Req struct {
	DistributorId    int64  // 必须 分销商标识
	SecretKey        string //
	BookId           string // 短剧/书本id
	PromotionId      string // 推广链id
	Begin            int64  // 数据查询开始时间点（unix 时间戳），默认为上一个小时开始时间点，最大支持获取3天内数据
	End              int64  // 数据查询截止时间点（unix 时间戳），默认为当前小时的开始时间点，最大时间范围为1小时
	OptimizerAccount string // 优化师邮箱，仅快应用填写
	OptimizerId      string // 优化师 id，仅快应用填写
}

func AllPromotionListV1(req AllPromotionListV1Req) ([]PromotionListV1RespResultItem, error) {
	offset := int64(0)
	limitMax := int64(1000)

	var list []PromotionListV1RespResultItem
	for {
		resp, err := PromotionListV1(PromotionListV1Req{
			DistributorId:    req.DistributorId,
			SecretKey:        req.SecretKey,
			BookId:           req.BookId,
			PromotionId:      req.PromotionId,
			Begin:            req.Begin,
			End:              req.End,
			Offset:           offset,
			Limit:            limitMax,
			OptimizerAccount: req.OptimizerAccount,
			OptimizerId:      req.OptimizerId,
		})
		if err != nil {
			return nil, err
		}

		if len(resp.Result) > 0 {
			list = append(list, resp.Result...)
		}

		if !resp.HasMore || int64(len(resp.Result)) < limitMax {
			break
		}

		offset = resp.NextOffset
	}

	return list, nil
}

type WxGetBoundPackageListV1Req struct {
	DistributorId int64  // 分销商标识，用于获取对应账号信息；
	SecretKey     string //
	PageIndex     int    // 页码，从0开始
	PageSize      int    // 页面大小，最大为50条记录
	AppId         int64  // 查询的小程序appid，2.25获取
}

type WxPackageInfoOpenListItem struct {
	AppId         int64  `json:"app_id"`
	AppName       string `json:"app_name"`
	AppType       int    `json:"app_type"`
	Channel       int    `json:"channel"`
	DistributorId int64  `json:"distributor_id"`
	NickName      string `json:"nick_name"`
	WechatAppId   string `json:"wechat_app_id"`
	WxOaName      string `json:"wx_oa_name"`
}

type WxGetBoundPackageListV1Resp struct {
	CommonResp
	Total                 int                         `json:"total"`
	WxPackageInfoOpenList []WxPackageInfoOpenListItem `json:"wx_package_info_open_list"`
}

// WxGetBoundPackageListV1
// 2.26 获取小程序绑定的渠道信息 【IAP】 https://bytedance.larkoffice.com/docx/doxcnoXWGp3qywnQYC8zVw069Bb
//
//	接口说明
//	接口1的2.26可使用任何一个小程序的distributor_id请求
//	app_id为要查询的小程序app_id
//
// 2.1.2 获取小程序渠道信息 【IAA】 https://bytedance.larkoffice.com/docx/YO75ddCoGopUlox6unJcuj6on9d
func WxGetBoundPackageListV1(req WxGetBoundPackageListV1Req) (resp *WxGetBoundPackageListV1Resp, err error) {
	request := httplib.NewHttpRequest(host + OpenapiWxGetBoundPackageListV1)

	params := url.Values{}
	params.Add("distributor_id", strconv.FormatInt(req.DistributorId, 10))
	if req.AppId > 0 {
		params.Add("app_id", strconv.FormatInt(req.AppId, 10))
	}
	if req.PageIndex > 0 {
		params.Add("page_index", strconv.Itoa(req.PageIndex))
	}
	if req.PageSize > 0 {
		params.Add("page_size", strconv.Itoa(req.PageSize))
	}
	params = getSign(params, req.SecretKey)

	request.SetParams(params)

	resp = new(WxGetBoundPackageListV1Resp)
	err = retry.Do(func() error {
		respContent, err := request.Get(false)
		if err != nil {
			return err
		}

		err = json.Unmarshal([]byte(respContent), resp)
		if err != nil {
			return err
		}

		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return resp, nil
}

type AllWxGetBoundPackageListV1Req struct {
	DistributorId int64  // 分销商标识，用于获取对应账号信息；
	SecretKey     string //
	AppId         int64  // 查询的小程序appid，2.25获取
}

func AllWxGetBoundPackageListV1(req AllWxGetBoundPackageListV1Req) ([]WxPackageInfoOpenListItem, error) {
	pageIndex := 0
	pageSizeMax := 50

	var list []WxPackageInfoOpenListItem
	for {
		resp, err := WxGetBoundPackageListV1(WxGetBoundPackageListV1Req{
			DistributorId: req.DistributorId,
			SecretKey:     req.SecretKey,
			PageIndex:     pageIndex,
			PageSize:      pageSizeMax,
			AppId:         req.AppId,
		})
		if err != nil {
			return nil, err
		}

		if len(resp.WxPackageInfoOpenList) > 0 {
			list = append(list, resp.WxPackageInfoOpenList...)
		}

		if len(resp.WxPackageInfoOpenList) < pageSizeMax || resp.Total == pageSizeMax {
			break
		}
		pageIndex++
	}

	return list, nil
}

type ContentBookMetaV1Req struct {
	DistributorId int64 // 分销商标识，用于获取对应账号信息；
	SecretKey     string
	BookId        int64 // 剧目id
}

type BookMetaResponse struct {
	CommonResp
	AppTypePermission map[string]int32 `json:"app_type_permission_status"`
	HasMore           bool             `json:"has_more"`
	NextOffset        int32            `json:"next_offset"`
	Result            []BookMetaItem   `json:"result"`
}

type BookMetaItem struct {
	Abstract       string `json:"abstract"`
	Author         string `json:"author"`
	BookId         string `json:"book_id"`
	BookName       string `json:"book_name"`
	Category       string `json:"category"`
	ChapterAmount  int64  `json:"chapter_amount"`
	CreationStatus int64  `json:"creation_status"`
	Genre          int64  `json:"genre"`
	LengthType     int64  `json:"length_type"`
	ThumbUrl       string `json:"thumb_url"`
	WordCount      int64  `json:"word_count"`
	AdEpisode      int64  `json:"ad_episode"`
}

func ContentBookMetaV1Request(req ContentBookMetaV1Req) (resp *BookMetaResponse, err error) {
	request := httplib.NewHttpRequest(host + OpenapiContentBookMetaV1)

	params := url.Values{}
	params.Add("distributor_id", strconv.FormatInt(req.DistributorId, 10))
	params.Add("book_id", strconv.FormatInt(req.BookId, 10))

	params = getSign(params, req.SecretKey)

	request.SetParams(params)

	resp = new(BookMetaResponse)
	err = retry.Do(func() error {
		respContent, err := request.Get(false)
		if err != nil {
			return err
		}

		err = json.Unmarshal([]byte(respContent), resp)
		if err != nil {
			return err
		}

		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return resp, nil
}

// GetContentBookMetaV1 获取短剧信息及授权状态
func GetContentBookMetaV1(req ContentBookMetaV1Req) ([]BookMetaItem, map[string]int32, error) {
	resp, err := ContentBookMetaV1Request(req)

	if err != nil {
		return nil, nil, err
	}
	var list []BookMetaItem
	if len(resp.Result) > 0 {
		list = resp.Result
	}
	return list, resp.AppTypePermission, nil
}

type AdCallbackConfigListV1Req struct {
	DistributorId    int64  // 分销商标识，用于获取对应账号信息；
	SecretKey        string //
	MediaSource      int    // 广告媒体平台 短剧 1 字节
	OptimizerAccount string // 投放账号
	OptimizerId      int64  // 投放账号ID
	PageIndex        int    // 页码，从0开始
	PageSize         int    // 页面大小，最大为50条记录
}

type AdCallbackConfigListItem struct {
	ConfigName string `json:"config_name"`
	ConfigId   int    `json:"config_id"`
}

type AdCallbackConfigListV1Resp struct {
	CommonResp
	ConfigList []AdCallbackConfigListItem `json:"config_list"`
	Total      int                        `json:"total"`
}

func AdCallbackConfigListV1Request(req AdCallbackConfigListV1Req) (resp *AdCallbackConfigListV1Resp, err error) {
	request := httplib.NewHttpRequest(host + OpenapiAdCallbackConfigConfigListV1)

	params := url.Values{}
	params.Add("distributor_id", strconv.FormatInt(req.DistributorId, 10))
	params.Add("media_source", strconv.Itoa(req.MediaSource))

	if req.PageIndex > 0 {
		params.Add("page_index", strconv.Itoa(req.PageIndex))
	}
	if req.PageSize > 0 {
		params.Add("page_size", strconv.Itoa(req.PageSize))
	}
	params = getSign(params, req.SecretKey)

	request.SetParams(params)

	resp = new(AdCallbackConfigListV1Resp)
	err = retry.Do(func() error {
		respContent, err := request.Get(false)
		if err != nil {
			return err
		}

		err = json.Unmarshal([]byte(respContent), resp)
		if err != nil {
			return err
		}

		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return resp, nil
}

type GetAdCallbackConfigListV1Req struct {
	DistributorId int64 // 分销商标识，用于获取对应广告账号信息，从而获取广告账号下所有分包信息。因此提供相同广告账号的不同渠道的distributor_id获取到的分包信息相同。当提供app_type时只返回对应渠道的分包信息
	SecretKey     string
	MediaSource   int // 广告媒体平台 短剧 1 字节
}

func GetAdCallbackConfigListV1(req GetAdCallbackConfigListV1Req) ([]AdCallbackConfigListItem, error) {
	pageIndex := 0
	pageSizeMax := 50

	var list []AdCallbackConfigListItem
	for {
		resp, err := AdCallbackConfigListV1Request(AdCallbackConfigListV1Req{
			DistributorId: req.DistributorId,
			SecretKey:     req.SecretKey,
			PageIndex:     pageIndex,
			PageSize:      pageSizeMax,
			MediaSource:   req.MediaSource,
		})
		if err != nil {
			return nil, err
		}

		if len(resp.ConfigList) > 0 {
			list = append(list, resp.ConfigList...)
		}

		if len(resp.ConfigList) < pageSizeMax || resp.Total == pageSizeMax {
			break
		}
		pageIndex++
	}

	return list, nil
}

type PromotionCreateV1Req struct {
	DistributorId      int64  // 分销商标识，用于获取对应账号信息；
	SecretKey          string //
	BookId             string `json:"book_id"`               // 短剧/书本id
	Index              int64  `json:"index"`                 // 章节序号，从1开始
	PromotionName      string `json:"promotion_name"`        // 推广链名称，长度限制[0, 100]，选填
	MediaSource        int64  `json:"media_source"`          // 媒体渠道来源，必填
	AdCallbackConfigId int64  `json:"ad_callback_config_id"` // 广告回调配置id，选填
	AdEpisode          int64  `json:"ad_episode"`            // 起始广告解锁剧集，选填
	//AdWordNumber       int64  `json:"ad_word_number"`        // 起始广告解锁字数，仅抖小网文适用，选填
	CustomizeParams string `json:"customize_params"` // 推广链自定义追加参数，选填
}

type PromotionCreateV1Resp struct {
	CommonResp
	PromotionId   string `json:"promotion_id"`   // 推广链id
	PromotionName string `json:"promotion_name"` // 推广链名称
	PromotionUrl  string `json:"promotion_url"`  // 推广链链接
}

func PromotionCreateV1(req PromotionCreateV1Req) (resp *PromotionCreateV1Resp, err error) {
	request := httplib.NewHttpRequest(host + OpenapiPromotionCreateV1)

	ts := time.Now().Unix()
	distributorIdStr := strconv.FormatInt(req.DistributorId, 10)
	tsStr := strconv.FormatInt(ts, 10)

	// 组装签名
	signStr := fmt.Sprintf("%s%s%s", distributorIdStr, req.SecretKey, tsStr)
	sign := strings.ToLower(md5.GetStringMd5(signStr))

	// 组装所有参数到 map
	params := map[string]interface{}{
		"distributor_id":        req.DistributorId,
		"sign":                  sign,
		"ts":                    ts,
		"book_id":               req.BookId,
		"index":                 req.Index,
		"promotion_name":        req.PromotionName,
		"ad_callback_config_id": req.AdCallbackConfigId,
		"media_source":          req.MediaSource,
	}
	if req.AdEpisode > 0 {
		params["ad_episode"] = req.AdEpisode
	}
	if len(req.CustomizeParams) > 0 {
		params["customize_params"] = req.CustomizeParams
	}

	jsonBytes, err := json.Marshal(params)
	if err != nil {
		return nil, err
	}

	request.SetBody(strings.NewReader(string(jsonBytes)))
	request.SetHeader(map[string]string{"Content-Type": "application/json"})

	resp = new(PromotionCreateV1Resp)
	err = retry.Do(func() error {
		respContent, err := request.Post()
		if err != nil {
			return err
		}

		err = json.Unmarshal([]byte(respContent), resp)
		if err != nil {
			return err
		}

		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))
	if err != nil {
		return nil, err
	}

	return resp, nil
}
