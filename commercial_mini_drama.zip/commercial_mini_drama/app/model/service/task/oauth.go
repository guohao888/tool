package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	accountsvc "goserver/app/model/service/accounts"
)

func OauthRefreshToutiao(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.OauthRefreshExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
	}

	media := repository.MediaToutiao

	// 换取授权令牌接口，并将token和数据入库
	oauthService := accountsvc.NewOauthService(ctx)
	err := oauthService.OauthRefresh(media, params)
	if err != nil {
		panic(fmt.Errorf("头条oauth刷新失败, %w", err))
	}
	return "头条oauth刷新成功"
}

func OauthRefreshKuaishou(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.OauthRefreshExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
	}

	media := repository.MediaKuaishou

	// 换取授权令牌接口，并将token和数据入库
	oauthService := accountsvc.NewOauthService(ctx)
	err := oauthService.OauthRefresh(media, params)
	if err != nil {
		panic(fmt.Errorf("快手oauth刷新失败, %w", err))
	}
	return "快手oauth刷新成功"
}

func OauthRefreshKuaishouMagnet(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.OauthRefreshExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
	}

	media := repository.MediaKuaishouMagnet

	// 换取授权令牌接口，并将token和数据入库
	oauthService := accountsvc.NewOauthService(ctx)
	err := oauthService.OauthRefresh(media, params)
	if err != nil {
		panic(fmt.Errorf("快手oauth刷新失败, %w", err))
	}
	return "快手oauth刷新成功"
}

func OauthCheckValidity(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.OauthCheckValidityParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
	}
	if len(params.Media) == 0 {
		params.Media = append(params.Media,
			repository.MediaToutiao,
			repository.MediaKuaishou,
		)
	}

	oauthService := accountsvc.NewOauthService(ctx)
	err := oauthService.OauthCheckValidity(params)
	if err != nil {
		panic(fmt.Errorf("校测oauth有效性失败, %w", err))
	}

	return "校测oauth有效性完成"
}
