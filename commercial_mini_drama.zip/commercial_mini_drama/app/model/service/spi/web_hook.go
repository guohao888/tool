package spi

import (
	"context"
	"goserver/app/library/kafka"
	"goserver/app/library/log"
)

type WebHookService struct {
	Ctx     context.Context
	ReqBody []byte
}

func NewWebHookService(Ctx context.Context, ReqBody []byte) *WebHookService {
	return &WebHookService{
		Ctx:     Ctx,
		ReqBody: ReqBody,
	}
}

func (s *WebHookService) SendDataToKafka() error {
	producer := kafka.SpiMaterialKafkaProducer()
	err := producer.AddSpiMaterialRequests(s.ReqBody)
	if err != nil {
		log.Errorf("oceanengine spi SendDataToKafka error %s", err.Error())
		return err
	}
	return nil
}

func (s *WebHookService) HandleWebHook() {
	// 创建数据实体
	//advertiserIDsJSON, _ := json.Marshal(s.Req.AdvertiserIDs)
	//accountRelationJSON, _ := json.Marshal(s.Req.AccountRelation)
	//dataJSON, _ := json.Marshal(s.Req.Data)
	//
	//spiData := &commonRoi.SpiRequestsDataEntity{
	//	MessageID:       s.Req.MessageID,
	//	SubscribeTaskID: s.Req.SubscribeTaskID,
	//	AdvertiserIDs:   string(advertiserIDsJSON),
	//	AccountRelation: string(accountRelationJSON),
	//	ServiceLabel:    s.Req.ServiceLabel,
	//	PublishTime:     s.Req.PublishTime,
	//	Timestamp:       s.Req.Timestamp,
	//	Nonce:           s.Req.Nonce,
	//	Data:            string(dataJSON),
	//}

	// 调用DAO层方法入库
	//spiDao := roiDao.NewSpiRequestsDao(s.Ctx)
	//if err := spiDao.AddOSpiRequests(spiData); err != nil {
	//	log.Errorf("oceanengine spi HandleWebHook save data err req id %s :%s", s.Req.MessageID, err.Error())
	//	return
	//}
	//log.Infof("oceanengine spi HandleWebHook save data success, message_id: %s", s.Req.MessageID)
}
