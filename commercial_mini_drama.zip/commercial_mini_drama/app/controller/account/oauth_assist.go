package account

import (
	"github.com/gin-gonic/gin"
	accountdto "goserver/app/common/dto/accounts"
	repo "goserver/app/common/repository"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	account "goserver/app/model/service/accounts"
)

// CallbackAssist 协管账号授权回调
func CallbackAssist(c *gin.Context) {
	r := response.Gin{Ctx: c}

	var req accountdto.CallbackToutiaoReq
	err := c.ShouldBindQuery(&req)
	if err != nil {
		panic(myerror.ParamsError)
	}

	// 根据auth_code获取token
	oauthAssistService := account.NewOauthAssistService(c)
	err = oauthAssistService.Callback(repo.MediaToutiao, req)

	if err != nil {
		r.Response(myerror.OauthAccessTokenError.Code, myerror.OauthAccessTokenError.Message, gin.H{
			"error": err.Error(),
		})
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}
