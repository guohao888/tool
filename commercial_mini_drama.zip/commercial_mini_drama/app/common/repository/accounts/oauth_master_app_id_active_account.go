package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const (
	OauthMasterAppIdActiveAccountView              = "oauth_master_app_id_active_account_view"                 // 主应用授权的管家下的活跃广告主的视图
	OauthMasterAppIdActiveAccountHasReportDataView = "oauth_master_app_id_active_account_has_report_data_view" // 当日有报表数据的活跃广告主视图
	OauthMasterAppIdActiveAccountNoReportDataView  = "oauth_master_app_id_active_account_no_report_data_view"  // 当日无报表数据的活跃广告主视图
)

type OauthMasterAppIdActiveAccountEntity struct {
	Media          string    `gorm:"column:media"`           // 媒体
	AdvertiserId   string    `gorm:"column:advertiser_id"`   // 广告主id
	AdvertiserName string    `gorm:"column:advertiser_name"` // 广告主名称
	OauthId        string    `gorm:"column:oauth_id"`        // 授权唯一标识
	UserId         string    `gorm:"column:user_id"`         // 管家账户ID
	Status         int       `gorm:"column:status"`          // 状态 0:启用 1:默认
	UpdatedAt      time.Time `gorm:"column:updated_at"`      // 更新时间
}

func (*OauthMasterAppIdActiveAccountEntity) TableName() string {
	return OauthMasterAppIdActiveAccountTableName()
}

func OauthMasterAppIdActiveAccountTableName() string {
	if repository.IsDebugTable(OauthMasterAppIdActiveAccountView) {
		return OauthMasterAppIdActiveAccountView + "_dev"
	} else {
		return OauthMasterAppIdActiveAccountView
	}
}

func OauthMasterAppIdActiveAccountHasReportDataViewName() string {
	if repository.IsDebugTable(OauthMasterAppIdActiveAccountNoReportDataView) {
		return OauthMasterAppIdActiveAccountHasReportDataView + "_dev"
	} else {
		return OauthMasterAppIdActiveAccountHasReportDataView
	}
}

func OauthMasterAppIdActiveAccountNoReportDataViewName() string {
	if repository.IsDebugTable(OauthMasterAppIdActiveAccountNoReportDataView) {
		return OauthMasterAppIdActiveAccountNoReportDataView + "_dev"
	} else {
		return OauthMasterAppIdActiveAccountNoReportDataView
	}
}