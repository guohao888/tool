package accounts

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	accountDto "goserver/app/common/dto/accounts"
	accountsRepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
)

type AccountCommonFilterDao struct {
	Ctx                   context.Context
	commonFilterQueryFunc CommonFilterQueryFunc
}

func NewAccountCommonFilterDao(ctx context.Context) *AccountCommonFilterDao {
	return &AccountCommonFilterDao{Ctx: ctx}
}

type QueryConfig struct {
	ExcludeColumns []string
	ColumnMapping  map[string]string
}

type CommonFilterQueryFunc func(*gorm.DB, *QueryConfig) *gorm.DB

func (f CommonFilterQueryFunc) CommonFilterFunc(qc *QueryConfig) func(*gorm.DB) *gorm.DB {
	return func(db *gorm.DB) *gorm.DB {
		return f(db, qc)
	}
}

func (qc *QueryConfig) GetQueryColumn() func(originalColumn string) (resultColumn string, isExclude bool) {
	m := make(map[string]struct{})
	for _, v := range qc.ExcludeColumns {
		m[v] = struct{}{}
	}

	return func(column string) (string, bool) {
		if _, ok := m[column]; ok {
			return column, true // 如果排查就直接返回原始的字段 和 需要排查这个查询条件
		}

		if v, ok := qc.ColumnMapping[column]; ok {
			return v, false
		}

		return column, false
	}
}

func (d *AccountCommonFilterDao) CommonFilterQueryFunc(filter accountDto.DataFilter) (CommonFilterQueryFunc, error) {
	d.commonFilterQueryFunc = func(q *gorm.DB, qc *QueryConfig) *gorm.DB {
		return d.accountDataWhere(q, filter, qc)
	}
	return d.commonFilterQueryFunc, nil
}

func (d *AccountCommonFilterDao) statusConditionWhere(q *gorm.DB, sqlExpr *gorm.SqlExpr, filter accountDto.DataFilter) *gorm.DB {
	if sqlExpr == nil {
		return q
	}
	q = q.Joins("LEFT JOIN ? AS s ON advertiser_id = s.s_advertiser_id AND media = s.s_media", sqlExpr)
	/*// 获取账户停用条件
	if filter.Status == StatusClose {
		q = q.Where("s.s_advertiser_id IS NOT NULL")
	} else if filter.Status == StatusOpen {
		q = q.Where("s.s_advertiser_id IS NULL")
	}*/
	return q
}

func (d *AccountCommonFilterDao) accountDataWhere(q *gorm.DB, filter accountDto.DataFilter, qc *QueryConfig) *gorm.DB {
	if qc == nil {
		qc = &QueryConfig{}
	}
	queryColumnFunc := qc.GetQueryColumn()
	var joinQuery *gorm.SqlExpr
	db := dorisdb.DorisClient()

	q0 := db.Table(accountsRepo.AccountStatusTableName())
	q0 = q0.Select("advertiser_id as s_advertiser_id,media as s_media").Group("advertiser_id,media")
	q0 = q0.Where("status=?", StatusClose)
	joinQuery = q0.SubQuery()
	// 账户状态 0为正常 1为停用
	q = d.statusConditionWhere(q, joinQuery, filter)

	if c, ie := queryColumnFunc("apu_create_time"); !ie {
		q = q.Where(fmt.Sprintf("%s >= ?", c), filter.Start).Where(fmt.Sprintf("%s < ?", c), filter.End)
	}

	if c, ie := queryColumnFunc("app_name"); !ie {
		if len(filter.AppName) == 1 {
			q = q.Where(fmt.Sprintf("%s = ?", c), filter.AppName[0])
		} else if len(filter.AppName) > 1 {
			q = q.Where(fmt.Sprintf("%s in (?)", c), filter.AppName)
		}
	}

	if c, ie := queryColumnFunc("advertiser_id"); !ie {
		if len(filter.AdvertiserId) == 1 {
			q = q.Where(fmt.Sprintf("%s = ?", c), filter.AdvertiserId[0])
		} else if len(filter.AdvertiserId) > 1 {
			q = q.Where(fmt.Sprintf("%s in (?)", c), filter.AdvertiserId)
		}
	}

	if c, ie := queryColumnFunc("advertiser_name"); !ie {
		if len(filter.AdvertiserName) == 1 {
			q = q.Where(fmt.Sprintf("%s = ?", c), filter.AdvertiserName[0])
		} else if len(filter.AdvertiserName) > 1 {
			q = q.Where(fmt.Sprintf("%s in (?)", c), filter.AdvertiserName)
		}
	}

	if c, ie := queryColumnFunc("media"); !ie {
		if len(filter.Media) == 1 {
			q = q.Where(fmt.Sprintf("%s = ?", c), filter.Media[0])
		} else if len(filter.Media) > 1 {
			q = q.Where(fmt.Sprintf("%s in (?)", c), filter.Media)
		}
	}

	if c, ie := queryColumnFunc("optimizer_name"); !ie {
		if len(filter.NickName) == 1 {
			q = q.Where(fmt.Sprintf("%s = ?", c), filter.NickName[0])
		} else if len(filter.NickName) > 1 {
			q = q.Where(fmt.Sprintf("%s in (?)", c), filter.NickName)
		}
	}

	if c, ie := queryColumnFunc("book_name"); !ie {
		if len(filter.BookName) == 1 {
			q = q.Where(fmt.Sprintf("%s = ?", c), filter.BookName[0])
		} else if len(filter.BookName) > 1 {
			q = q.Where(fmt.Sprintf("%s in (?)", c), filter.BookName)
		}
	}

	return q
}
