package accounts

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/myerror"
)

type AccountPromotionUrlSyncExecutorParams struct {
	Media                 string   `json:"-"`
	AdvertiserIds         []string `json:"advertiser_ids"`
	IsSyncAll             bool     `json:"is_sync_all"`             // 是否同步全量
	PrevDays              int      `json:"prev_days"`               // 前几天
	PoolWorkers           int      `json:"pool_workers"`            // 并发数量
	AppIds                []string `json:"app_ids"`                 // 应用Id
	InsertBatchSize       int      `json:"insert_batch_size"`       // 数据库分批数量
	IsBackgroundOperation bool     `json:"is_background_operation"` // 是否后台操作
	AppType               string   `json:"app_type"`                // 小程序类型
	Priority              string   `json:"priority"`                // 优先级
}

func (p *AccountPromotionUrlSyncExecutorParams) IsSyncWechatApplet() bool {
	return p.IsSyncAppType(accountrepo.AppTypeWechatApplet)
}

func (p *AccountPromotionUrlSyncExecutorParams) IsSyncAppType(appType string) bool {
	if p.AppType == "" || p.AppType == appType {
		return true
	}
	return false
}

func (p *AccountPromotionUrlSyncExecutorParams) IsSyncByteMicroApp() bool {
	return p.IsSyncAppType(accountrepo.AppTypeByteMicroApp)
}

type SyncPromotionUrlParams struct {
	Media        string   `json:"media"`
	AdvertiserId []string `json:"advertiser_id" binding:"required,gt=0"`
}

type SyncPromotionUrlReq struct {
	common.CommonParams
	Params *SyncPromotionUrlParams `json:"params"`
}

func NewSyncPromotionUrlReq(c *gin.Context) *SyncPromotionUrlReq {
	req := &SyncPromotionUrlReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)

	return req
}
