package fanqie

import (
	"github.com/gin-gonic/gin"
	"goserver/app/library/myerror"
)

// TomatoIAAOrderReq IAA 订单数据推送数据参数
type TomatoIAAOrderReq struct {
	DistributorId string `json:"distributor_id" form:"distributor_id"` // 快应用/公众号对应distributor_id
	AppId         string `json:"app_id" form:"app_id"`                 // 公众号/快应用/小程序id（分销平台id）【v1.2】
	AppName       string `json:"app_name" form:"app_name"`             // 快应用/公众号/小程序名称【v1.2】
	DeviceId      string `json:"device_id" form:"device_id"`           // 脱敏后的用户设备ID
	PromotionId   string `json:"promotion_id" form:"promotion_id"`     // 推广链id
	EcpmCost      string `json:"ecpm_cost" form:"ecpm_cost"`           // 激励点击金额，单位十万分之一元
	EcpmNo        string `json:"ecpm_no" form:"ecpm_no"`               // 激励收益的唯一键，对齐抖开接口的req_id
	EventTime     string `json:"event_time" form:"event_time"`         // 激励点击的时间戳
	RegisterTime  string `json:"register_time" form:"register_time"`   // 用户染色时间戳
	BookId        string `json:"book_id" form:"book_id"`               // 染色推广链的短剧ID
	BookName      string `json:"book_name" form:"book_name"`           // 染色推广链的短剧名称
	BookGender    string `json:"book_gender" form:"book_gender"`       // 染色推广链短剧性别(0女生、1男生、2无性别)
	BookCategory  string `json:"book_category" form:"book_category"`   // 染色推广链的短剧类型
}

// NewIAAOrderDataReq 解析绑定IAA订单推送数据参数
func NewIAAOrderDataReq(c *gin.Context) *TomatoIAAOrderReq {
	req := &TomatoIAAOrderReq{}
	if err := c.ShouldBind(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}
