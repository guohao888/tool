package main

import (
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	"goserver/app/library/limiter"
	"goserver/app/library/log"
	"goserver/app/model/service/cron"
	"goserver/app/model/service/task"
	"net/http"
	"os"
	"os/signal"
	"time"

	"github.com/spf13/pflag"
	"github.com/spf13/viper"
	"goserver/app/router"
	"goserver/entrance"
	"syscall"
)

var (
	cfg = pflag.StringP("config", "c", "default", "config file path.")
	tpl = pflag.StringP("tpl", "t", "default", "tpl file path.")
)

func main() {
	pflag.Parse()

	// step 0: init env.
	// step 1: load config.
	// step 2: init log system.
	// step 3: init mysql.
	// step 4: init redis.
	// step 5: init subsystem.
	// step 6: init gin.

	entrance.NewEntrance()
	e := entrance.Entrance
	e.InitEnv(*cfg, *tpl)
	e.LoadConfig()
	e.InitLogSystem()
	//e.InitMySQL()
	e.InitRedis()
	e.InitStarRocks()

	// 默认不启动cron 防止本地环境影响测试环境 如果需要启动cron 请修改配置文件中cron参数
	m := viper.GetBool("cron")
	if m {
		_ = cron.InitCron() // 定时任务初始化
		fmt.Println("cron running")
		_ = task.SendShutdownMsg() // 服务重启 推推播报
	}
	//gl.Init()
	// 除正式环境  其他均不启动kafka消费
	ka := viper.GetBool("kafka_control")
	if ka {
		// 消费常读数据
		go task.ExecUserKafka2DB()
		go task.ExecIAAOrderKafka2DB()
		//go task.ExecIAPOrderKafka2DB()
		go task.ExecSpiMaterialKafka2DB()
		go task.ExecSubscribeKafka2DB()
		// dts 订阅消费
		go task.ExecDtsKafka2DB()
	}

	// 初始化Kafka客户端
	e.InitKafka()

	//初始化限流器
	_ = limiter.InitGlobalLimit()

	gin.SetMode(viper.GetString("runmode"))

	engine := gin.New()

	//设置路由
	route.SetupRouter(engine)

	httpsEngine := gin.New()
	route.SetupHttpsRouter(httpsEngine)

	// start HTTP server
	server := &http.Server{
		Addr:    viper.GetString("addr"),
		Handler: engine,
	}

	fmt.Println("|-----------------------------------|")
	fmt.Println("|            go-gin-api             |")
	fmt.Println("|-----------------------------------|")
	fmt.Println("|  Go Http Server Start Successful  |")
	fmt.Println("|    Port" + viper.GetString("addr") + "     Pid:" + fmt.Sprintf("%d", os.Getpid()) + "        |")
	fmt.Println("|-----------------------------------|")
	fmt.Println("")

	go func() {
		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatalf("HTTP server listen: %s\n", err)
		}
	}()

	// start HTTPS server
	httpsServerEnable := len(viper.GetString("https_addr")) > 0
	httpsServer := &http.Server{
		Addr:    viper.GetString("https_addr"),
		Handler: httpsEngine,
	}
	certFile := viper.GetString("httptls.crt")
	certKey := viper.GetString("httptls.key")

	if httpsServerEnable {
		fmt.Println("|-----------------------------------|")
		fmt.Println("|            go-gin-api             |")
		fmt.Println("|-----------------------------------|")
		fmt.Println("|  Go Https Server Start Successful  |")
		fmt.Println("|    Port" + viper.GetString("https_addr") + "     Pid:" + fmt.Sprintf("%d", os.Getpid()) + "        |")
		fmt.Println("|-----------------------------------|")
		fmt.Println("")

		go func() {
			if err := httpsServer.ListenAndServeTLS(certFile, certKey); err != nil && err != http.ErrServerClosed {
				log.Fatalf("HTTPS server listen: %s\n", err)
			}
		}()
	}

	// 等待中断信号以优雅地关闭服务器（设置 5 秒的超时时间）
	signalChan := make(chan os.Signal)
	signal.Notify(signalChan,
		os.Interrupt,
		syscall.SIGHUP,
		syscall.SIGINT,
		syscall.SIGTERM,
		syscall.SIGQUIT)
	sig := <-signalChan
	fmt.Println("Get Signal:", sig)
	fmt.Println("Shutdown Server ...")

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()

	if err := server.Shutdown(ctx); err != nil {
		fmt.Println("Server Shutdown:", err)
	}
	fmt.Println("Server exiting")

	//stop https server
	if httpsServerEnable {
		if err := httpsServer.Shutdown(ctx); err != nil {
			fmt.Println("https Server Shutdown:", err)
		}
		fmt.Println("https Server exiting")
	}

	defer cron.CloseExecutor() //解除cron注册
}
