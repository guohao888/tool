package project

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/project"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// InfoProjectDao DAO
type InfoProjectDao struct {
	Ctx context.Context
}

func NewInfoProjectDao(ctx context.Context) *InfoProjectDao {
	return &InfoProjectDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (ip *InfoProjectDao) InsertBatchSize(data []*project.InfoProjectEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = ip.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (ip *InfoProjectDao) buildInsertSentence(tx *gorm.DB, data []*project.InfoProjectEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + project.InfoProjectEntityTableName() + " ( advertiser_id, project_id, delivery_mode, delivery_type, landing_type,app_promotion_type, marketing_goal,ad_type,opt_status, name,project_create_time,project_modify_time,status, pricing,package_name,app_name, feed_delivery_search, search_bid_ratio,audience_extend, keywords, related_product, delivery_product,delivery_medium, multi_delivery_medium,download_url,download_type, download_mode, launch_type,promotion_type,asset_type, micro_promotion_type, micro_app_instance_id,optimize_goal, value_optimized_type, delivery_range,audience, bid ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.ProjectId,
			v.DeliveryMode,
			v.DeliveryType,
			v.LandingType,
			v.AppPromotionType,
			v.MarketingGoal,
			v.AdType,
			v.OptStatus,
			v.Name,
			v.ProjectCreateTime,
			v.ProjectModifyTime,
			v.Status,
			v.Pricing,
			v.PackageName,
			v.AppName,
			v.FeedDeliverySearch,
			v.SearchBidRatio,
			v.AudienceExtend,
			v.Keywords,
			v.RelatedProduct,
			v.DeliveryProduct,
			v.DeliveryMedium,
			v.MultiDeliveryMedium,
			v.DownloadUrl,
			v.DownloadType,
			v.DownloadMode,
			v.LaunchType,
			v.PromotionType,
			v.AssetType,
			v.MicroPromotionType,
			v.MicroAppInstanceId,
			v.OptimizeGoal,
			v.ValueOptimizedType,
			v.DeliveryRange,
			v.Audience,
			v.Bid,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

type OauthProductInfos struct {
	AdvertiserId      string `gorm:"column:advertiser_id"`       // 广告主id
	UserId            string `gorm:"column:user_id"`             // 管家账号ID
	ProductId         int64  `gorm:"column:product_id"`          // 商品ID
	ProductPlatformId int64  `gorm:"column:product_platform_id"` // 商品库ID
}

func (ip *InfoProjectDao) GetProductList(date string) ([]OauthProductInfos, error) {
	db := dorisdb.DorisClient()
	var res []OauthProductInfos
	sql := " SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id, product_id, product_platform_id FROM ( SELECT ad.advertiser_id, product_id, product_platform_id FROM ( SELECT advertiser_id FROM report_project_hour WHERE date(search_date) = '" + date + "' GROUP BY advertiser_id ) ad LEFT JOIN ( SELECT advertiser_id, CAST(related_product->'product_id' as CHAR) as product_id, CAST(related_product->'product_platform_id' as CHAR) as product_platform_id FROM project_info WHERE delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME'  GROUP BY advertiser_id, product_id, product_platform_id ) pr ON ad.advertiser_id = pr.advertiser_id WHERE pr.product_id IS NOT NULL ) has LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) ac ON has.advertiser_id = ac.advertiser_id "
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}
