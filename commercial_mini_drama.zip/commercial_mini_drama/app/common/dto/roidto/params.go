package roidto

type IDLabel struct {
	ID        string `json:"id"`
	Label     string `json:"label"`
	IsDefault bool   `json:"isdefault"`
}

type BoardTopData struct {
	CountTime string `json:"count_time"` //统计时间
	StartHour int    `json:"start_hour"` //统计开始时
	EndHour   int    `json:"end_hour"`   //统计结束时
}

type SelectOption struct {
	Name  string    `json:"name"`
	Value []IDLabel `json:"value"`
}

type KpiOption struct {
	ID        int    `json:"id"`
	Label     string `json:"label"`
	Prop      string `json:"prop"`
	Format    string `json:"format"`
	SortAble  bool   `json:"sortable"`
	IsDefault bool   `json:"isdefault"`
}

type Params struct {
	GroupType       []IDLabel    `json:"group_type"`       //时间周期
	Media           SelectOption `json:"media"`            //媒体
	Region          SelectOption `json:"region"`           //地区
	PayType         SelectOption `json:"pay_type"`         //付费类型
	AppName         SelectOption `json:"app_name"`         //应用包名
	UserID          SelectOption `json:"user_id"`          //账管名称
	BookName        SelectOption `json:"book_name"`        //剧目名称
	OptimizerID     SelectOption `json:"optimizer_id"`     //投放人员
	AccountID       SelectOption `json:"account_id"`       //账户名称
	DeliveryProduct SelectOption `json:"delivery_product"` //推广产品
	CopyRightOwner  SelectOption `json:"copyright_owner"`  //版权方
	GroupBy         SelectOption `json:"group_by"`         //维度聚合
	KpiFilter       []KpiOption  `json:"kpi_filter"`       //指标筛选
}

type MergeExecTime struct {
	ExecTime string `json:"exec_time"` //执行时间
}

type BoardTopDataResp struct {
	CountTime string `json:"count_time"` //统计时间
	StartHour int    `json:"start_hour"` //统计开始时
	EndHour   int    `json:"end_hour"`   //统计结束时
}

var GroupTypeArr = []IDLabel{
	{ID: "d", Label: "日", IsDefault: true},
	{ID: "w", Label: "周"},
	{ID: "m", Label: "月"},
	{ID: "h", Label: "小时"}}

var GroupTypeMapping = map[string]string{
	"d": "日",
	"w": "周",
	"m": "月",
	"h": "小时",
}

var PayTypeArr = []IDLabel{
	{ID: "1", Label: "IAA"},
	{ID: "2", Label: "IAP"}}

var PayTypeMapping = map[string]string{
	"1": "IAA",
	"2": "IAP",
}

var DeliveryProductArr = []IDLabel{
	{ID: "PRODUCT", Label: "商品"},
	{ID: "OTHER", Label: "其他"},
}

var DeliveryProductMapping = map[string]string{
	"PRODUCT": "商品",
	"OTHER":   "其他",
}

var groupByArr = []IDLabel{
	{ID: "media", Label: "投放载体", IsDefault: true},
	{ID: "region", Label: "地区"},
	{ID: "pay_type", Label: "付费方式"},
	{ID: "app_name", Label: "应用包名", IsDefault: true},
	{ID: "book_name", Label: "剧目名称", IsDefault: true},
	{ID: "optimizer_nickname", Label: "投放人员", IsDefault: true},
	{ID: "copyright_owner", Label: "端原生版权方", IsDefault: true},
	{ID: "account_name", Label: "账户名称", IsDefault: true},
	{ID: "project_id", Label: "推广组ID"},
	{ID: "promotion_name", Label: "推广计划"},
	{ID: "mid_id", Label: "推广创意"},
	{ID: "mid_type", Label: "素材类型"},
	{ID: "user_id", Label: "账管"},
}

var groupByMapping = map[string]string{
	"media":              "投放载体",
	"region":             "地区",
	"pay_type":           "付费方式",
	"app_name":           "应用包名",
	"book_name":          "剧目名称",
	"optimizer_nickname": "投放人员",
	"account_name":       "账户名称",
	"project_id":         "推广组ID",
	"promotion_name":     "推广计划",
	"mid_id":             "推广创意",
	"mid_type":           "素材类型",
	"copyright_owner":    "端原生版权方",
	"user_id":            "账管ID",
}

var kpiFilterArr = []KpiOption{
	{Label: "实际消耗", Prop: "cost", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "媒体消耗", Prop: "media_cost", Format: "cost", SortAble: true},
	{Label: "展示数", Prop: "show_count", Format: "num", SortAble: true},
	{Label: "点击数", Prop: "click_count", Format: "num", SortAble: true},
	{Label: "点击率", Prop: "click_rate", Format: "rate", SortAble: true},
	{Label: "千展成本", Prop: "show_cost", Format: "cost", SortAble: true},
	{Label: "点击成本", Prop: "click_cost", Format: "cost", SortAble: true},
	{Label: "媒体激活数", Prop: "media_active_count", Format: "num", SortAble: true},
	{Label: "媒体激活成本", Prop: "media_active_cost", Format: "cost", SortAble: true},
	{Label: "媒体激活率", Prop: "media_active_rate", Format: "rate", SortAble: true},
	{Label: "媒体转化数", Prop: "media_convert_count", Format: "num"},
	{Label: "媒体转化成本", Prop: "media_convert_cost", Format: "cost"},
	{Label: "媒体首日付费数", Prop: "media_first_pay_count", Format: "num"},
	{Label: "媒体首日付费成本", Prop: "media_first_pay_cost", Format: "cost"},
	{Label: "环比消耗", Prop: "cost_hb", Format: "cost"},
	{Label: "环比消耗率", Prop: "cost_hb_ratio", Format: "rate"},
	{Label: "同比消耗", Prop: "cost_tb", Format: "cost"},
	{Label: "同比消耗率", Prop: "cost_tb_ratio", Format: "rate"},
	{Label: "实际收入", Prop: "income", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "实际ROI", Prop: "roi", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "实际激活数", Prop: "active_count", Format: "num"},
	{Label: "实际激活成本", Prop: "active_cost", Format: "cost"},
	{Label: "实际新增用户付费数", Prop: "new_pay_count", Format: "num"},
	{Label: "实际活跃用户付费数", Prop: "active_pay_count", Format: "num"},
	{Label: "首日新增收入", Prop: "first_income", Format: "cost", SortAble: true},
	{Label: "首日新增ROI", Prop: "first_roi", Format: "rate", SortAble: true},
	{Label: "新用户累计收入", Prop: "new_sum_income", Format: "cost"},
	{Label: "新用户累计ROI", Prop: "new_sum_roi", Format: "rate"},
	{Label: "人均IPU次数", Prop: "avg_ipu", Format: "num"},
	{Label: "ARPU", Prop: "arpu", Format: "cost"},
	{Label: "日利润", Prop: "profit", Format: "cost"},
	{Label: "ROI环比", Prop: "roi_hb", Format: "rate"},
	{Label: "ROI同比", Prop: "roi_tb", Format: "rate"},
	{Label: "环比收入", Prop: "income_hb", Format: "cost"},
	{Label: "环比收入率", Prop: "income_hb_ratio", Format: "rate"},
	{Label: "同比收入", Prop: "income_tb", Format: "cost"},
	{Label: "同比收入率", Prop: "income_tb_ratio", Format: "rate"},
	{Label: "赠款支出", Prop: "reward_cost", Format: "cost"},
	{Label: "共享返货支出", Prop: "shared_wallet_cost", Format: "cost"},
	//{Label: "新用户2日收入", Prop: "income2", Format: "cost"},
	//{Label: "新用户3日收入", Prop: "income3", Format: "cost"},
	//{Label: "新用户4日收入", Prop: "income4", Format: "cost"},
	//{Label: "新用户5日收入", Prop: "income5", Format: "cost"},
	//{Label: "新用户6日收入", Prop: "income6", Format: "cost"},
	//{Label: "新用户7日收入", Prop: "income7", Format: "cost"},
	//{Label: "新用户2日ROI", Prop: "roi2", Format: "rate"},
	//{Label: "新用户3日ROI", Prop: "roi3", Format: "rate"},
	//{Label: "新用户4日ROI", Prop: "roi4", Format: "rate"},
	//{Label: "新用户5日ROI", Prop: "roi5", Format: "rate"},
	//{Label: "新用户6日ROI", Prop: "roi6", Format: "rate"},
	//{Label: "新用户7日ROI", Prop: "roi7", Format: "rate"}
}

var SortKpiMapping = map[string]string{
	"date":               "日期",
	"cost":               "实际消耗",
	"media_cost":         "媒体消耗",
	"show_count":         "展示数",
	"click_count":        "点击数",
	"click_rate":         "点击率",
	"show_cost":          "千展成本",
	"click_cost":         "点击成本",
	"media_active_count": "媒体激活数",
	"media_active_cost":  "媒体激活成本",
	"media_active_rate":  "媒体激活率",
	"income":             "实际收入",
	"roi":                "实际ROI",
	"first_income":       "首日新增收入",
	"first_roi":          "首日新增ROI",
}

var kpiMapping = map[string]string{
	"cost":                  "实际消耗",
	"media_cost":            "媒体消耗",
	"show_count":            "展示数",
	"click_count":           "点击数",
	"click_rate":            "点击率",
	"show_cost":             "千展成本",
	"click_cost":            "点击成本",
	"media_active_count":    "媒体激活数",
	"media_active_cost":     "媒体激活成本",
	"media_active_rate":     "媒体激活率",
	"media_convert_count":   "媒体转化数",
	"media_convert_cost":    "媒体转化成本",
	"media_first_pay_count": "媒体首日付费数",
	"media_first_pay_cost":  "媒体首日付费成本",
	"cost_hb":               "环比消耗",
	"cost_hb_ratio":         "环比消耗率",
	"cost_tb":               "同比消耗",
	"cost_tb_ratio":         "同比消耗率",
	"income":                "实际收入",
	"roi":                   "实际ROI",
	"active_count":          "实际激活数",
	"active_cost":           "实际激活成本",
	"new_pay_count":         "实际新增用户付费数",
	"active_pay_count":      "实际活跃用户付费数",
	"first_income":          "首日新增收入",
	"first_roi":             "首日新增ROI",
	"new_sum_income":        "新用户累计收入",
	"new_sum_roi":           "新用户累计ROI",
	"avg_ipu":               "人均IPU次数",
	"arpu":                  "ARPU",
	"profit":                "日利润",
	"roi_hb":                "ROI环比",
	"roi_tb":                "ROI同比",
	"income_hb":             "环比收入",
	"income_hb_ratio":       "环比收入率",
	"income_tb":             "同比收入",
	"income_tb_ratio":       "同比收入率",
	"reward_cost":           "赠款支出",
	"shared_wallet_cost":    "共享返货支出",
	//"income2":         "新用户2日收入",
	//"income3":         "新用户3日收入",
	//"income4":         "新用户4日收入",
	//"income5":         "新用户5日收入",
	//"income6":         "新用户6日收入",
	//"income7":         "新用户7日收入",
	//"roi2":            "新用户2日ROI",
	//"roi3":            "新用户3日ROI",
	//"roi4":            "新用户4日ROI",
	//"roi5":            "新用户5日ROI",
	//"roi6":            "新用户6日ROI",
	//"roi7":            "新用户7日ROI",
}

// GetKpiFilterArr 聚合条件是否有推广计划  true有 false 没有
func GetKpiFilterArr(proGroup bool) []KpiOption {
	result := make([]KpiOption, 0, len(kpiFilterArr))
	for _, row := range kpiFilterArr {
		result = append(result, row)
	}
	return result
}

// GetKpiMapping 聚合条件是否有推广计划  true有 false 没有
func GetKpiMapping(proGroup bool) map[string]string {
	result := make(map[string]string, len(kpiMapping))
	for k, v := range kpiMapping {
		result[k] = v
	}
	return result
}

// GetGroupByMapping 聚合条件是否有推广计划  true有 false 没有
func GetGroupByMapping(proGroup bool) map[string]string {
	result := make(map[string]string, len(groupByMapping))
	for k, v := range groupByMapping {
		if !proGroup {
			if k == "promotion_name" || k == "mid_id" || k == "mid_type" {
				continue
			}
		}
		result[k] = v
	}
	return result
}

// GetGroupByArr 聚合条件是否有推广计划  true有 false 没有
func GetGroupByArr(proGroup bool) []IDLabel {
	result := make([]IDLabel, 0, len(groupByArr))
	for _, row := range groupByArr {
		if !proGroup {
			if row.ID == "promotion_name" || row.ID == "mid_id" || row.ID == "mid_type" {
				continue
			}
		}
		result = append(result, row)
	}
	return result
}

type OptionsResp struct {
	Media           []string `json:"media"`
	DeliveryProduct []string `json:"delivery_product"`
}
