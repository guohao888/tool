package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const DistributorPromotionUrlTable = "distributor_promotion_url"

type DistributorPromotionUrlEntity struct {
	Distributor        string    `gorm:"column:distributor"`
	AppId              int64     `gorm:"column:app_id"`
	OptimizerId        int64     `gorm:"column:optimizer_id"`
	PromotionUrl       string    `gorm:"column:promotion_url"`
	PromotionId        int64     `gorm:"column:promotion_id"`
	PromotionName      string    `gorm:"column:promotion_name"`
	OptimizerName      string    `gorm:"column:optimizer_name"`
	BookId             int64     `gorm:"column:book_id"`
	BookName           string    `gorm:"column:book_name"`
	AppName            string    `gorm:"column:app_name"`
	ApiId              string    `gorm:"column:key"`
	AppType            int       `gorm:"column:app_type"`
	DistributorId      int64     `gorm:"column:distributor_id"`
	ProfitModel        string    `gorm:"column:profit_model"`
	MediaSource        int       `gorm:"column:media_source"`
	AdCallBackConfigId int64     `gorm:"column:ad_callback_config_id"`
	CreateTime         string    `gorm:"column:create_time"`
	CreatedAt          time.Time `gorm:"column:created_at"`
	UpdatedAt          time.Time `gorm:"column:updated_at"`
}

func (*DistributorPromotionUrlEntity) TableName() string {
	return DistributorPromotionUrlTableName()
}

func DistributorPromotionUrlTableName() string {
	if repository.IsDebugTable(DistributorPromotionUrlTable) {
		return DistributorPromotionUrlTable + "_dev"
	} else {
		return DistributorPromotionUrlTable
	}
}
