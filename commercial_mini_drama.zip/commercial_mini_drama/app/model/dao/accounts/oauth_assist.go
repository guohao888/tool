package accounts

import (
	"context"
	"errors"
	"github.com/jinzhu/gorm"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
)

type OauthAssistDao struct {
	Ctx context.Context
}

func NewOauthAssistDao(ctx context.Context) *OauthAssistDao {
	return &OauthAssistDao{Ctx: ctx}
}

// Save 保存协管授权
func (d *OauthAssistDao) Save(oauth accountrepo.OauthAssistEntity) error {
	db := dorisdb.DorisClient()

	// 判断授权是否存在
	var exist accountrepo.OauthAssistEntity
	err := db.Table(accountrepo.OauthAssistTableName()).Select("media, oauth_id").Where("media = ? and oauth_id = ?", oauth.Media, oauth.OauthId).First(&exist).Error
	// 存在则更新
	if err == nil && exist.OauthId != "" && exist.Media != "" { // 没有错误，且存在，更新
		err = d.UpdateById(exist.Media, exist.OauthId, &oauth)
	} else if err != nil && errors.Is(err, gorm.ErrRecordNotFound) { // 有错误，是不存在的错误，创建
		err = db.Table(accountrepo.OauthAssistTableName()).Save(&oauth).Error
	}

	return err
}

func (d *OauthAssistDao) UpdateById(media string, oauthId string, oauth *accountrepo.OauthAssistEntity) error {
	db := dorisdb.DorisClient()

	err := db.Model(&accountrepo.OauthAssistEntity{}).
		Select("access_token", "refresh_token", "expire_at", "refresh_expire_at", "expire_time", "refresh_expire_time", "ext").
		Where("media = ? and oauth_id = ?", media, oauthId).
		Updates(oauth).Error
	return err
}

func (d *OauthAssistDao) ListOauthByMedia(media string) ([]accountrepo.OauthAssistEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.OauthAssistTableName())
	var list []accountrepo.OauthAssistEntity
	if media != "" {
		q = q.Where("media = ?", media)
	}
	err := q.Order("created_at desc").Find(&list).Error
	if err != nil {
		return nil, err
	}

	return list, err
}

func (d *OauthAssistDao) ListOauthByMediaAppIds(media string, appIds []string) ([]accountrepo.OauthAssistEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.OauthAssistTableName())
	var list []accountrepo.OauthAssistEntity
	if media != "" {
		q = q.Where("media = ?", media)
	}
	if len(appIds) > 0 {
		q = q.Where("app_id in (?)", appIds)
	}
	err := q.Order("created_at desc").Find(&list).Error
	if err != nil {
		return nil, err
	}

	return list, err
}
