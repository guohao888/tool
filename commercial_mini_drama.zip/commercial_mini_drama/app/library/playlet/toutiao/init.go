package toutiao

import (
	"github.com/oceanengine/ad_open_sdk_go"
	"github.com/oceanengine/ad_open_sdk_go/config"
	"goserver/app/library/playlet/toutiao/middleware"
)

var apiClient *ad_open_sdk_go.Client

func init() {
	configuration := config.NewConfiguration()
	configuration.LogEnable = true // 启用日志
	configuration.UseLogMw = false // 是否使用默认的日志中间件

	apiClient = ad_open_sdk_go.Init(configuration)
	pathAppIdLimiter := middleware.NewPathAppIdLimiter(
		map[string]middleware.RateConfig{
			OpenApiV30ToolsWechatAppletList: {10, 10},
			OpenApiV30ToolsMicroAppList:     {10, 10},
			OpenApiV30ToolsAssetLinkList:    {10, 10},
			OpenApiV30ToolsMicroAppUpdate:   {5, 5},
		},
		CtxPathKey,
		CtxAppIdKey,
	)
	apiClient.Use(middleware.LogMiddleware, pathAppIdLimiter.LimiterMiddleware())
}
