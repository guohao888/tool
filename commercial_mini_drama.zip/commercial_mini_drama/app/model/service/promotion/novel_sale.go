package promotion

import (
	"context"
	"encoding/json"
	"errors"
	promotionDto "goserver/app/common/dto/promotion"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	promotionRepo "goserver/app/common/repository/promotion"
	"goserver/app/library/log"
	"goserver/app/library/playlet/novelsale"
	"goserver/app/library/playlet/toutiao"
	"goserver/app/library/utils"
	accountdao "goserver/app/model/dao/accounts"
	promotionDao "goserver/app/model/dao/promotion"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/oceanengine/ad_open_sdk_go/models"

	"github.com/jinzhu/copier"
)

const curDistributorId = "1799926004993337"
const appType = 4
const mediaSource = 1

const maxConcurrency = 3

type NovelSaleService struct {
	Ctx       context.Context
	apiId     int64
	apiSecret string
	appType   int
}

func NewNovelSaleService(ctx context.Context) *NovelSaleService {
	distributorConfigDao := accountdao.NewDistributorConfigDao(ctx)
	apiIds := []string{curDistributorId}
	configs, err := distributorConfigDao.ListByDistributor(repo.DistributorFanqie, apiIds)
	if err == nil && len(configs) > 0 {
		apiId, _ := strconv.ParseInt(curDistributorId, 10, 64)
		return &NovelSaleService{
			Ctx:       ctx,
			apiId:     apiId,
			apiSecret: configs[0].ApiSecret,
			appType:   configs[0].AppType,
		}
	}
	if err == nil {
		err = errors.New("未找到该appid的配置")
	}
	log.Errorf("NovelSaleService.init 获取番茄密钥配置错误, err: %s", err)
	return &NovelSaleService{}
}

func (n *NovelSaleService) GetPackageList(req *promotionDto.PackageListReq) (*promotionDto.PackageList, error) {
	wxGetPackageListV2List, err := novelsale.AllWxGetPackageListV2(novelsale.AllWxGetPackageListV2Req{
		DistributorId: n.apiId,
		SecretKey:     n.apiSecret,
		AppType:       n.appType,
	})
	if err != nil {
		return nil, err
	}

	var pkgInfos []promotionDto.PackageDetail
	for _, v := range wxGetPackageListV2List {
		pkgInfo := promotionDto.PackageDetail{
			AppId:   v.AppId,
			AppName: v.AppName,
		}
		pkgInfos = append(pkgInfos, pkgInfo)
	}
	return &promotionDto.PackageList{
		PackageList: pkgInfos,
	}, nil
}

func (n *NovelSaleService) GetBoundPackageList(req *promotionDto.BoundPackageListReq) (*promotionDto.BoundPackageList, error) {
	boundPackageList, err := novelsale.AllWxGetBoundPackageListV1(novelsale.AllWxGetBoundPackageListV1Req{
		DistributorId: n.apiId,
		SecretKey:     n.apiSecret,
		AppId:         req.AppId,
	})
	if err != nil {
		return nil, err
	}

	var pkgInfos []promotionDto.BoundPackageDetail
	for _, v := range boundPackageList {
		pkgInfo := promotionDto.BoundPackageDetail{
			AppId:          v.AppId,
			AppName:        v.AppName,
			Channel:        v.Channel,
			NickName:       v.NickName,
			BoundPackageId: strconv.FormatInt(v.DistributorId, 10),
		}
		pkgInfos = append(pkgInfos, pkgInfo)
	}
	return &promotionDto.BoundPackageList{
		PackageList: pkgInfos,
	}, nil
}

func (n *NovelSaleService) GetBookMeta(req *promotionDto.BookMeatReq) (*promotionDto.BookMeta, error) {
	bookId, _ := strconv.ParseInt(req.BookId, 10, 64)
	bookMetas, AppTypePermission, err := novelsale.GetContentBookMetaV1(novelsale.ContentBookMetaV1Req{
		DistributorId: n.apiId,
		SecretKey:     n.apiSecret,
		BookId:        bookId,
	})

	if err != nil {
		return nil, err
	}
	if len(bookMetas) == 0 {
		return nil, errors.New("未查到该ID下的剧目")
	}

	bookMeta := bookMetas[0]
	var resp promotionDto.BookMeta
	copier.Copy(&resp, &bookMeta)
	permission, ok := AppTypePermission[strconv.Itoa(n.appType)]
	resp.AppTypePermissionStatus = novelsale.AuthStatusUnauthorized
	if ok {
		resp.AppTypePermissionStatus = int64(permission)
	}
	return &resp, nil
}

func (n *NovelSaleService) GetAdCallbackConfigList(req *promotionDto.AdCallbackConfigReq) (*promotionDto.AdCallbackConfigList, error) {
	boundPackageID, _ := strconv.ParseInt(req.BoundPackageID, 10, 64)
	adCallbackConfigList, err := novelsale.GetAdCallbackConfigListV1(novelsale.GetAdCallbackConfigListV1Req{
		DistributorId: boundPackageID,
		SecretKey:     n.apiSecret,
		MediaSource:   mediaSource,
	})
	if err != nil {
		return nil, err
	}

	var configInfos []promotionDto.AdCallbackConfigDetail
	for _, v := range adCallbackConfigList {
		configInfo := promotionDto.AdCallbackConfigDetail{
			ConfigId:   v.ConfigId,
			ConfigName: v.ConfigName,
		}
		configInfos = append(configInfos, configInfo)
	}
	return &promotionDto.AdCallbackConfigList{
		ConfigList: configInfos,
	}, nil
}

func (n *NovelSaleService) handleFanqie(promotionInfo *promotionRepo.PromotionInfoEntity) (*promotionRepo.PromotionInfoEntity, error) {
	if promotionInfo.StateCode == promotionRepo.CreatePromotionDefault || promotionInfo.StateCode == promotionRepo.CreatePromotionFanqieFailed {
		requestReq := novelsale.PromotionCreateV1Req{
			DistributorId:      promotionInfo.BoundPackageID,
			SecretKey:          n.apiSecret,
			BookId:             promotionInfo.BookID,
			Index:              promotionInfo.BookIndex,
			MediaSource:        mediaSource,
			PromotionName:      "",
			AdCallbackConfigId: promotionInfo.AdCallbackConfigID,
			AdEpisode:          promotionInfo.AdEpisode,
		}
		resp, fanqieErr := novelsale.PromotionCreateV1(requestReq)
		if fanqieErr == nil && resp.Code != 200 {
			fanqieErr = errors.New(resp.Message)
		}
		if fanqieErr != nil {
			n.savePromotionInfo(promotionInfo, promotionRepo.CreatePromotionFanqieFailed, fanqieErr)
			return promotionInfo, errors.New("番茄推送失败")
		}

		promotionInfo.PromotionID = resp.PromotionId
		promotionInfo.PromotionURL = resp.PromotionUrl
		promotionInfo.PromotionName = resp.PromotionName
	}
	return promotionInfo, nil
}

func (n *NovelSaleService) handleOcean(promotionInfo *promotionRepo.PromotionInfoEntity, advAndTokenInfo accountrepo.AdvAndTokenInfo, opzName string) error {
	promotionInfo.AdvertiserName = advAndTokenInfo.AdvertiserName
	// 获取资产id
	microAppList, instanceErr := toutiao.AllToolsMicroAppList(n.Ctx, toutiao.AllToolsMicroAppListReq{
		AccessToken:  advAndTokenInfo.AccessToken,
		AdvertiserId: promotionInfo.AdvertiserID,
		Filtering: func() *models.ToolsMicroAppListV30Filtering {
			filtering := &models.ToolsMicroAppListV30Filtering{
				SearchKey:   &promotionInfo.AppName,
				AuditStatus: models.AUDIT_ACCEPTED_ToolsMicroAppListV30FilteringAuditStatus.Ptr(),
			}
			return filtering
		}(),
	})

	if instanceErr == nil && len(microAppList) == 0 {
		instanceErr = errors.New("未查到对应资产id")
	}
	if instanceErr != nil {
		n.savePromotionInfo(promotionInfo, promotionRepo.CreatePromotionOceanFailed, instanceErr)
		return errors.New("巨量推送失败")
	}

	microApp := microAppList[0]
	promotionInfo.InstanceID = *microApp.InstanceId

	promotionName := strings.ReplaceAll(promotionInfo.PromotionNameFormat, "<账户名称>", advAndTokenInfo.AdvertiserName)
	promotionName = strings.ReplaceAll(promotionName, "<剧名>", promotionInfo.BookName)
	promotionName = strings.ReplaceAll(promotionName, "<账户所属投手名>", opzName)

	urlParts := strings.SplitN(promotionInfo.PromotionURL, "?", 2)

	// 更新小程序
	updateReq := toutiao.ToolsMicroAppUpdateReq{
		AdvertiserId:      promotionInfo.AdvertiserID,
		AccessToken:       advAndTokenInfo.AccessToken,
		InstanceId:        promotionInfo.InstanceID,
		TagInfo:           getTagInfo(*microApp.TagInfo),
		AppPageLink:       "",
		AppPageRemark:     promotionName,
		AppPageStartPage:  urlParts[0],
		AppPageStartParam: urlParts[1],
	}

	updateErr := toutiao.ToolsMicroAppUpdate(n.Ctx, updateReq)
	if updateErr != nil {
		n.savePromotionInfo(promotionInfo, promotionRepo.CreatePromotionOceanFailed, updateErr)
		return errors.New("巨量推送失败")
	}
	n.savePromotionInfo(promotionInfo, promotionRepo.CreatePromotionSuccess, nil)
	return nil
}

func (n *NovelSaleService) Create(req *promotionDto.CreateReq) error {
	// 查询小程序信息的时候使用
	n.Ctx = context.WithValue(n.Ctx, toutiao.CreatePromotionCase, "1")

	oaDao := accountdao.NewOauthAccountDao(n.Ctx)
	advAndTokenInfos, _ := oaDao.FindAccessTokenByAdvertiserIDs(req.AdvertiserIDs)

	aaDao := accountdao.NewAssistAccountDao(n.Ctx)
	opzNames, _ := aaDao.FindUserNameByAdvertiserId(req.AdvertiserIDs)

	// 并发数量控制变量
	var wg sync.WaitGroup
	sem := make(chan struct{}, maxConcurrency)

	for _, advId := range req.AdvertiserIDs {
		wg.Add(1)
		sem <- struct{}{} // 占用一个并发槽

		advIdCopy := advId
		go func() {
			defer wg.Done()
			defer func() { <-sem }() // 释放并发槽

			var handleParams promotionRepo.PromotionInfoEntity
			_ = copier.Copy(&handleParams, req)
			boundPackageId, _ := strconv.ParseInt(req.BoundPackageID, 10, 64)

			handleParams.AppType = appType
			handleParams.Distributor = repo.DistributorFanqie
			handleParams.DistributorID = n.apiId
			handleParams.MediaSource = mediaSource
			handleParams.BoundPackageID = boundPackageId
			handleParams.AdvIDs = strings.Join(req.AdvertiserIDs, ",")
			if req.UserInfo != nil {
				handleParams.UserName = req.UserInfo.Name
			}
			advertiserID, _ := strconv.ParseInt(advIdCopy, 10, 64)
			handleParams.AdvertiserID = advertiserID

			// 推送番茄
			promotion, err := n.handleFanqie(&handleParams)
			if err != nil {
				return
			}

			// 推送巨量
			_ = n.handleOcean(promotion, advAndTokenInfos[advIdCopy], opzNames[advIdCopy])
		}()
	}
	wg.Wait()
	return nil
}

func (n *NovelSaleService) Retry(req *promotionDto.RetryReq) error {
	n.Ctx = context.WithValue(n.Ctx, toutiao.CreatePromotionCase, "1")
	dao := promotionDao.NewPromotionInfoDao(n.Ctx)
	promotionInfo, err := dao.GetInfoByRequestId(req.RequestId)
	if err != nil {
		return err
	}
	if promotionInfo == nil {
		return errors.New("未查到该记录")
	}
	if promotionInfo.StateCode == promotionRepo.CreatePromotionSuccess {
		return errors.New("该记录已提交成功，无需重新提交")
	}

	oaDao := accountdao.NewOauthAccountDao(n.Ctx)
	aaDao := accountdao.NewAssistAccountDao(n.Ctx)

	advId := strconv.FormatInt(promotionInfo.AdvertiserID, 10)
	advAndTokenInfos, _ := oaDao.FindAccessTokenByAdvertiserIDs([]string{advId})
	opzNames, _ := aaDao.FindUserNameByAdvertiserId([]string{advId})

	// 修复promotionInfo变量被重新赋值导致的未使用问题
	if promotionInfo.StateCode == promotionRepo.CreatePromotionFanqieFailed {
		_, err := n.handleFanqie(promotionInfo)
		if err != nil {
			return err
		}
	}
	return n.handleOcean(promotionInfo, advAndTokenInfos[advId], opzNames[advId])
}

func (n *NovelSaleService) ListOptions(req *promotionDto.ListOptionsReq) (*promotionDto.ListFilterOptions, error) {
	var resp promotionDto.ListFilterOptions

	// 短剧类型
	resp.AppType = []promotionDto.FilterOption{
		{Value: int64(appType), ShowName: repo.MediaToutiao},
	}

	// 推送状态
	resp.Status = []promotionDto.FilterOption{
		{Value: int64(1), ShowName: "成功"},
		{Value: int64(2), ShowName: "番茄推送失败"},
		{Value: int64(3), ShowName: "巨量推送失败"},
	}

	// 剧场
	wxGetPackageListV2List, err := novelsale.AllWxGetPackageListV2(novelsale.AllWxGetPackageListV2Req{
		DistributorId: n.apiId,
		SecretKey:     n.apiSecret,
		AppType:       n.appType,
	})
	if err == nil {
		for _, v := range wxGetPackageListV2List {
			resp.Package = append(resp.Package, promotionDto.FilterOption{
				Value:    int64(v.AppId),
				ShowName: v.AppName,
			})
		}
	}

	// 根据剧场获取渠道
	type boundPackageResult struct {
		appId int64
		list  []novelsale.WxPackageInfoOpenListItem
		err   error
	}
	boundPkg := make(map[int64][]promotionDto.FilterOption)

	ch := make(chan boundPackageResult, len(resp.Package))
	for _, pkg := range resp.Package {
		boundPkg[pkg.Value] = []promotionDto.FilterOption{}
		go func(pkg promotionDto.FilterOption) {
			boundPackageList, err := novelsale.AllWxGetBoundPackageListV1(novelsale.AllWxGetBoundPackageListV1Req{
				DistributorId: n.apiId,
				SecretKey:     n.apiSecret,
				AppId:         pkg.Value,
			})
			ch <- boundPackageResult{
				appId: pkg.Value,
				list:  boundPackageList,
				err:   err,
			}
		}(pkg)
	}

	// 收集所有结果，并对同一个appid下的nickname去重
	for i := 0; i < len(resp.Package); i++ {
		result := <-ch
		if result.err == nil {
			for _, v := range result.list {
				item := promotionDto.FilterOption{
					Value:    v.DistributorId,
					ShowName: v.NickName,
				}
				boundPkg[v.AppId] = append(boundPkg[v.AppId], item)
			}
		}
	}
	resp.BoundPackage = boundPkg
	return &resp, nil
}

type Category struct {
	CategoryID   int64       `json:"category_id"`
	CategoryName string      `json:"category_name"`
	Categories   []*Category `json:"categories"`
}

func getTagInfo(jsonStr string) string {
	var root Category
	if err := json.Unmarshal([]byte(jsonStr), &root); err != nil {
		return ""
	}

	// 递归获取末级分类ID
	lastCategoryID := getLastCategoryID(&root)
	return strconv.FormatInt(lastCategoryID, 10)
}

// 递归查找末级分类ID（末级分类的Categories为空）
func getLastCategoryID(category *Category) int64 {
	// 若当前分类无下级分类，返回当前ID
	if len(category.Categories) == 0 {
		return category.CategoryID
	}

	// 递归处理下级分类（假设末级只有一个子节点，如需处理多分支需调整逻辑）
	for _, subCategory := range category.Categories {
		return getLastCategoryID(subCategory) // 仅处理第一个子节点（可根据需求修改为遍历所有）
	}

	return 0 // 兜底返回（正常逻辑不会走到这里）
}

// 推广信息入库
func (n *NovelSaleService) savePromotionInfo(promotionInfo *promotionRepo.PromotionInfoEntity, StateCode int64, err error) {
	promotionInfo.StateCode = StateCode
	if err != nil {
		promotionInfo.FailedReason = err.Error()
	}
	if promotionInfo.RequestID == "" {
		promotionInfo.RequestID = utils.GetUUID()
	} else {
		promotionInfo.UpdatedAt = time.Now()
	}
	_ = promotionDao.NewPromotionInfoDao(n.Ctx).Insert(promotionInfo)
	if err != nil {
		log.Errorf("批量创建推广链失败，request_id：%s", promotionInfo.RequestID)
	}
}
