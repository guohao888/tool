package fanqie

import (
	"github.com/gin-gonic/gin"
	"goserver/app/library/myerror"
)

// TomatoUserReq 用户数据推送数据参数
type TomatoUserReq struct {
	DistributorId   string   `json:"distributor_id" form:"distributor_id"`     // 快应用/公众号对应distributor_id
	AppId           string   `json:"app_id" form:"app_id"`                     // 公众号/快应用/小程序id（分销平台id）【v1.2】
	AppName         string   `json:"app_name" form:"app_name"`                 // 快应用/公众号/小程序名称【v1.2】
	DeviceId        string   `json:"device_id" form:"device_id"`               // 脱敏后的用户设备ID
	PromotionId     string   `json:"promotion_id" form:"promotion_id"`         // 推广链id
	AdId            string   `json:"ad_id" form:"ad_id"`                       // ad_id(仅支持快应用) 仅快应用一跳（快应用推广目的）有，二跳（应用推广/线索推广）没有
	Ip              string   `json:"ip" form:"ip"`                             // 用户点击推广链时的IP
	UserAgent       string   `json:"user_agent" form:"user_agent"`             // 用户点击推广链时的UA
	BuyingTimestamp string   `json:"buying_timestamp" form:"buying_timestamp"` // 用户点击推广链时间戳（非染色时间）
	Attributed      string   `json:"attributed" form:"attributed"`             // 用户是否成功染色
	BookId          string   `json:"book_id" form:"book_id"`                   // 染色推广链的短剧ID
	BookName        string   `json:"book_name" form:"book_name"`               // 染色推广链的短剧名称
	BookGender      string   `json:"book_gender" form:"book_gender"`           // 染色推广链短剧性别(0女生、1男生、2无性别)
	BookCategory    string   `json:"book_category" form:"book_category"`       // 染色推广链的短剧类型
	ActionId        string   `json:"action_id" form:"action_id"`               // 用户点击推广链的唯一标识，平台为了尽可能通知到分销商会有重试策略，分销商可以以此进行去重
	ProjectId       string   `json:"project_id" form:"project_id"`             // 巨量2.0广告计划组ID
	AdIdV2          string   `json:"ad_id_v2" form:"ad_id_v2"`                 // 巨量2.0广告计划ID（promotion_id）
	Mid             []string `json:"mid" form:"mid"`                           // 素材id（分别代表图片、标题、视频、试玩、落地页）（仅小程序均支持）
	ClueToken       string   `json:"clue_token" form:"clue_token"`             // 巨量小程序广告参数
	Channel         string   `json:"channel" form:"channel"`                   // 渠道号
	UnionId         string   `json:"union_id" form:"union_id"`                 // 用户在微信/抖音开放平台下的唯一id
	MidId           string   `json:"mid_id" form:"mid_id"`                     // 图片或视频ID
}

// NewUserDataReq 解析绑定IAA用户推送数据参数
func NewUserDataReq(c *gin.Context) *TomatoUserReq {
	req := &TomatoUserReq{}
	if err := c.ShouldBind(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}
