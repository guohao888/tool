package optimizer

import (
	"context"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"goserver/app/common/dto/optimizerdto"
	"goserver/app/common/dto/page"
	"goserver/app/common/repository/optimizer"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/library/myerror"
	"time"
)

const COMMERCIAL_MINI_DRAMA_OPTIMIZER_ID = "commercial_mini_drama:OptimizerId" // 优化师主键

type OptimizerDao struct {
	Ctx context.Context
}

func NewOptimizerDao(ctx context.Context) *OptimizerDao {
	return &OptimizerDao{Ctx: ctx}
}

// AddOptimizer 添加优化师
func (m *OptimizerDao) AddOptimizer(data *optimizerdto.OptimizerInfoParams) error {
	db := dorisdb.DorisClient()
	tx := db.Begin() // 开始事务

	// 验证优化师ID是否存在
	qId := tx.Table(optimizer.OptimizerEntityTableName())
	qId = qId.Where("optimizer_id = ?", data.OptimizerId)
	var idInfo optimizer.OptimizerEntity
	err := qId.First(&idInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}

	if idInfo.OptimizerId != 0 {
		tx.Rollback()                                            // 回滚事务
		return errors.New(myerror.OptimizerIdEmptyError.Message) // 优化师ID不能为空
	}

	// 验证优化师名称是否存在
	qName := tx.Table(optimizer.OptimizerEntityTableName())
	qName = qName.Where("optimizer_name = ?", data.OptimizerName)
	var NameInfo optimizer.OptimizerEntity
	err = qName.First(&NameInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}
	if NameInfo.OptimizerName != "" {
		tx.Rollback()                                              // 回滚事务
		return errors.New(myerror.OptimizerNameExistError.Message) // 优化师名称已存在
	}

	// 新增优化师数据
	insert := tx.Table(optimizer.OptimizerEntityTableName())
	err = insert.Create(optimizer.OptimizerEntity{
		OptimizerId:   data.OptimizerId,
		OptimizerName: data.OptimizerName,
		CreatedAt:     time.Now(),
		UpdatedAt:     time.Now(),
	}).Error
	if err != nil {
		tx.Rollback() // 回滚事务
		return err
	}

	tx.Commit() // 提交事务
	return nil
}

// UpdateOptimizer 编辑优化师
func (m *OptimizerDao) UpdateOptimizer(data *optimizerdto.OptimizerInfoParams) error {
	db := dorisdb.DorisClient()
	tx := db.Begin() // 开始事务

	// 验证优化师ID是否存在
	qId := tx.Table(optimizer.OptimizerEntityTableName())
	qId = qId.Where("optimizer_id = ?", data.OptimizerId)
	var idInfo optimizer.OptimizerEntity
	err := qId.First(&idInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}

	if idInfo.OptimizerId == 0 {
		tx.Rollback()                                            // 回滚事务
		return errors.New(myerror.OptimizerIdEmptyError.Message) // 优化师ID不能为空
	}

	// 验证优化师名称是否存在
	qName := tx.Table(optimizer.OptimizerEntityTableName())
	qName = qName.Where("optimizer_name = ?", data.OptimizerName)
	qName = qName.Where("optimizer_id != ?", data.OptimizerId)
	var NameInfo optimizer.OptimizerEntity
	err = qName.First(&NameInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}
	if NameInfo.OptimizerName != "" {
		tx.Rollback()                                              // 回滚事务
		return errors.New(myerror.OptimizerNameExistError.Message) // 优化师名称已存在
	}

	// 新增优化师数据
	update := tx.Table(optimizer.OptimizerEntityTableName())

	idInfo.OptimizerId = 0
	idInfo.OptimizerName = data.OptimizerName
	idInfo.UpdatedAt = time.Now()
	err = update.Where("optimizer_id = ?", data.OptimizerId).Update(idInfo).Error
	if err != nil {
		tx.Rollback() // 回滚事务
		return err
	}

	tx.Commit() // 提交事务
	return nil
}

// RefreshData 优化师
func (m *OptimizerDao) RefreshData(data optimizerdto.GetOptimizerRefresh) (msg string, err error) {
	db := dorisdb.DorisClient()

	// 验证优化师ID是否存在
	qId := db.Table(optimizer.OptimizerEntityTableName())
	qId = qId.Where("optimizer_name = ?", data.OptimizerName)
	var idInfo optimizer.OptimizerEntity
	err = qId.First(&idInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return fmt.Sprintf("优化师:%s错误,", data.OptimizerName), err
	}

	if err != nil && gorm.IsRecordNotFoundError(err) {
		return fmt.Sprintf("优化师:%s不存在,", data.OptimizerName), nil
	}

	// 更新优化师数据
	update := db.Table(optimizer.OptimizerEntityTableName())
	idInfo.Phone = data.Phone
	idInfo.UpdatedAt = time.Now()
	err = update.Create(idInfo).Error
	if err != nil {
		return fmt.Sprintf("更新优化师:%s不存在,", data.OptimizerName), err
	}

	return
}

// OptimizerInfoList 优化师列表
func (m *OptimizerDao) OptimizerInfoList(params *optimizerdto.OptimizerInfoListParams) (*page.Paginator, error) {
	db := dorisdb.DorisClient()
	q := db.Table(optimizer.OptimizerEntityTableName())  // 分页
	q2 := db.Table(optimizer.OptimizerEntityTableName()) // 总数

	if params.OptimizerName != "" {
		q = q.Where("optimizer_name like ?", "%"+params.OptimizerName+"%")
		q2 = q2.Where("optimizer_name like ?", "%"+params.OptimizerName+"%")
	}

	var total int64
	err := q2.Count(&total).Error
	// 分页数据
	pagination := params.Pagination
	var res []*optimizer.OptimizerEntity
	err = q.Offset(pagination.GetOffset()).Limit(pagination.GetLimit()).Order("created_at desc").Find(&res).Error
	if err != nil {
		return nil, err
	}
	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)

	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return &paginator, nil
}
