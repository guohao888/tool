package mediareport

import (
	"context"
	"fmt"
	"github.com/panjf2000/ants/v2"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/common/repository/mediareport"
	"goserver/app/library/playlet/toutiao"
	"goserver/app/model/dao"
	accountdao "goserver/app/model/dao/accounts"
	mediadao "goserver/app/model/dao/mediareport"
	spi "goserver/app/model/dao/roi"
	"strconv"
	"sync"
)

// RejectService 素材拒审Service
type RejectService struct {
	Ctx context.Context
}

func NewRejectService(ctx context.Context) *RejectService {
	return &RejectService{Ctx: ctx}
}
func (r *RejectService) DistributeRejectAccounts(ctx context.Context) error {
	// 1.获取活跃账号数据
	spiDao := spi.NewSpiMaterialDao(r.Ctx)
	activeList, err := spiDao.ListActiveQueue()
	if err != nil {
		return err
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncRejectReasonNew(activeList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func SyncRejectReasonNew(activeList []accountrepo.OauthAccountEntity, oauth map[string]string, appId string) {
	// 获取账号下promotion_id  如果消耗表全  就用消耗表查询
	// 数据库限制 in 最长为1000  分批查询
	promotionLists, err := batchGetPromotionIds(context.Background(), activeList)
	if err != nil {
		return
	}
	m2 := make(map[string][]int64)
	for _, v := range promotionLists {
		promotionId, _ := strconv.Atoi(v.PromotionId)
		m2[v.AdvertiserId] = append(m2[v.AdvertiserId], int64(promotionId))
	}

	resMaChan := make(chan *mediareport.RejectMaterialEntity)
	//resProChan := make(chan *mediareport.RejectPromotionEntity)
	errChan := make(chan error, len(activeList))

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	once.Do(func() {
		go func() {
			insertErr := execRejectMaterialDB(context.Background(), resMaChan)
			if insertErr != nil {
				errChan <- fmt.Errorf("execRejectMaterialDB error：%v", insertErr)
			}
		}()
		//go func() {
		//	insertErr := execRejectPromotionDB(context.Background(), resProChan)
		//	if insertErr != nil {
		//		errChan <- fmt.Errorf("execRejectPromotionDB error：%v", insertErr)
		//	}
		//}()
	})

	for _, v := range activeList {
		currentItem := v
		wg.Add(1)

		task := func() {
			advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
			advertiserIdStr := currentItem.AdvertiserId
			userId := currentItem.UserId
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			// 构建媒体素材ID Map
			promotionIds, mOk := m2[advertiserIdStr]
			if !mOk {
				errChan <- fmt.Errorf("没有获取到对应的promotionID信息, %s", advertiserIdStr)
				return
			}
			if len(promotionIds) == 0 {
				return
			}
			// 如果promotionIds 长度超过10  分批执行
			batchPage := dao.BatchPage(len(promotionIds), 10)
			for i := 0; i < batchPage; i++ {
				start := i * 10
				end := (i + 1) * 10
				if end > len(promotionIds) {
					end = len(promotionIds)
				}
				// 获取拒审数据
				materialInfos, _, execErr, code := ExecQueryReject(context.Background(), int64(advertiserId), oauth[userId], promotionIds[start:end], appId)
				if execErr != nil && code != 4000 {
					errChan <- fmt.Errorf("素材拒审请求失败, advertiserId: %d, token: %s, appId: %s, err: %s", advertiserId, oauth[userId], appId, execErr.Error())
				}
				// 保存素材维度拒审信息
				if len(materialInfos) > 0 {
					for _, row := range materialInfos {
						maInfo := &mediareport.RejectMaterialEntity{
							AdvertiserId:  advertiserIdStr,
							PromotionId:   strconv.Itoa(int(row.PromotionId)),
							Type:          row.Type,
							Item:          row.Item,
							RejectReason:  row.RejectReason,
							Suggestion:    row.Suggestion,
							AuditPlatform: row.AuditPlatform,
						}
						resMaChan <- maInfo
					}
				}
				// 保存广告维度拒审信息
				//if len(promotionInfos) > 0 {
				//	for _, row := range promotionInfos {
				//		proInfo := &mediareport.RejectPromotionEntity{
				//			AdvertiserId: advertiserIdStr,
				//			PromotionId:  strconv.Itoa(int(row.PromotionId)),
				//			Content:      row.Content,
				//			RejectReason: row.RejectReason,
				//			Suggestion:   row.Suggestion,
				//		}
				//		resProChan <- proInfo
				//	}
				//}
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resMaChan)
		//close(resProChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		errs = append(errs, errL)
	}

	if len(errs) > 0 {
		_ = sendMsg(errs, "获取拒审信息\n")
	}
	return
}

// batchGetPromotionIds 分批次获取账号下广告信息
func batchGetPromotionIds(ctx context.Context, activeList []accountrepo.OauthAccountEntity) (promotionLists []mediareport.ReportHourEntity, err error) {
	batchPage := dao.BatchPage(len(activeList), 888)
	for i := 0; i < batchPage; i++ {
		start := i * 888
		end := (i + 1) * 888
		if end > len(activeList) {
			end = len(activeList)
		}
		// 获取账号下的promotion_id
		promotionList, getErr := GetPromotionIds(ctx, activeList[start:end])
		if getErr != nil {
			return nil, getErr
		}
		promotionLists = append(promotionLists, promotionList...)
	}
	return
}

// GetPromotionIds 获取账号下广告信息
func GetPromotionIds(ctx context.Context, activeList []accountrepo.OauthAccountEntity) (promotionLists []mediareport.ReportHourEntity, err error) {
	var adList []string
	for _, v := range activeList {
		adList = append(adList, v.AdvertiserId)
	}
	reportHourDao := mediadao.NewReportHourDao(ctx)
	promotionLists, err = reportHourDao.GetAdvertiserPromotions(adList)
	if err != nil {
		return
	}
	return
}

// ExecQueryReject 查询头条自定义报表 获取素材报表数据
func ExecQueryReject(ctx context.Context, advertiserId int64, accessToken string, promotionIds []int64, appId string) (rejectMaterial []toutiao.RejectMaterialInfo, rejectPromotion []toutiao.RejectPromotionInfo, err error, code int64) {
	res, err := toutiao.RejectReasonGet(ctx, toutiao.RejectReasonGetReq{
		AccessToken:  accessToken,
		AdvertiserId: advertiserId,
		PromotionIds: promotionIds,
	}, appId)
	code = *res.Code
	if err != nil {
		return
	}
	rejectMaterial = toutiao.DataRows2InnerTransformRejectMaterial(res)
	//rejectPromotion = toutiao.DataRows2InnerTransformRejectPromotion(res)

	return
}

// execRejectMaterialDB 保存素材维度拒审信息到SR
func execRejectMaterialDB(ctx context.Context, resChan <-chan *mediareport.RejectMaterialEntity) (err error) {
	rejectDao := mediadao.NewRejectDao(ctx)
	// 将数据写入 report_hour
	var data = make([]*mediareport.RejectMaterialEntity, 0, 5000)
	var errs []error
	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			err = rejectDao.InsertMaterialBatchSize(data, 5000)
			if err != nil {
				errs = append(errs, err)
			}
			data = data[:0]
		}
	}
	if len(data) > 0 {
		err = rejectDao.InsertMaterialBatchSize(data, 5000)
		if err != nil {
			errs = append(errs, err)
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execRejectMaterialDB errors: %v", errs)
	}
	return nil
}

// execRejectPromotionDB 保存广告维度拒审信息到SR
func execRejectPromotionDB(ctx context.Context, resChan <-chan *mediareport.RejectPromotionEntity) (err error) {
	rejectDao := mediadao.NewRejectDao(ctx)
	// 将数据写入 report_hour
	var data = make([]*mediareport.RejectPromotionEntity, 0, 5000)
	var errs []error
	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			err = rejectDao.InsertPromotionBatchSize(data, 5000)
			if err != nil {
				errs = append(errs, err)
			}
			data = data[:0]
		}
	}
	if len(data) > 0 {
		err = rejectDao.InsertPromotionBatchSize(data, 5000)
		if err != nil {
			errs = append(errs, err)
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execRejectMaterialDB errors: %v", errs)
	}
	return nil
}
