package accounts

import (
	"context"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/model/dao/accounts"
)

type AccountDistributorPromotionUrlService struct {
	Ctx context.Context
}

func NewAccountDistributorPromotionUrlService(ctx context.Context) *AccountDistributorPromotionUrlService {
	return &AccountDistributorPromotionUrlService{Ctx: ctx}
}

func (s *AccountDistributorPromotionUrlService) JoinMerge(params accountdto.PromotionUrlMergeExecutorParams) error {

	accountDistributorPromotionUrlDao := accounts.NewAccountDistributorPromotionUrlDao(s.Ctx)
	err := accountDistributorPromotionUrlDao.Merge(params)
	if err != nil {
		return err
	}

	accountDistributorDao := accounts.NewAccountDistributorDao(s.Ctx)
	err = accountDistributorDao.GroupInsert(params)
	if err != nil {
		return err
	}

	return nil
}
