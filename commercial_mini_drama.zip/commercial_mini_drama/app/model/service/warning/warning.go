package warning

import (
	"context"
	"goserver/app/common/dto/page"
	"goserver/app/common/dto/warningdto"
	repo "goserver/app/common/repository"
	wModel "goserver/app/common/repository/warning"
	"goserver/app/library/utils"
	"goserver/app/model/dao/mediareport"
	"goserver/app/model/dao/warning"
	"strings"
	"time"
)

type MsgWarningService struct {
	Ctx context.Context
}

func NewMsgWarningService(ctx context.Context) *MsgWarningService {
	return &MsgWarningService{Ctx: ctx}
}

// GetWarningList 查询告警任务
func (m *MsgWarningService) GetWarningList(params *warningdto.SearchFilter) (*page.Paginator, error) {
	warningDao := warning.NewMsgWarningDao(m.Ctx)
	paginator, err := warningDao.FindTaskInfo(params)
	var list []*warningdto.TaskList
	for _, v := range paginator.List.([]*wModel.TaskWarningEntity) {
		info := &warningdto.TaskList{
			SearchDate: v.CreatedTime.Format(time.DateOnly),
			TaskId:     v.ForeignKey,
			TaskName:   v.TaskName,
			ExecTime:   "", // todo
		}
		list = append(list, info)
	}
	paginator.List = list
	return paginator, err
}

// SaveOrUpdateWarningInfo 新建/修改/更改状态 告警任务
func (m *MsgWarningService) SaveOrUpdateWarningInfo(params *warningdto.TaskInfos) error {
	warningDao := warning.NewMsgWarningDao(m.Ctx)
	key := utils.GetUUID()
	// 构建 task_warning 保存实体
	list := buildTaskWarning(key, params)
	err := warningDao.InsertBatchSizeWarningTask(list, 100)
	if err != nil {
		return err
	}
	// 构建 task_info 保存实体
	warningList := buildTaskInfo(key, params)
	err = warningDao.InsertBatchSizeTaskInfos(warningList, 2000)
	if err != nil {
		return err
	}
	return nil
}

func buildTaskWarning(key string, params *warningdto.TaskInfos) (list []*wModel.TaskWarningEntity) {
	info := &wModel.TaskWarningEntity{
		ForeignKey:  key,
		CreatedTime: time.Now(),
		TaskName:    params.TaskName,
		Media:       repo.MediaToutiao,
		CreateBy:    params.UserInfo.Name,
		WarningTag:  params.WarningTag,
		Dimension:   params.Dimension,
		Metrics:     params.Metrics,
		Interval:    params.Interval,
		Condition:   params.Condition,
		Numerical:   params.Numerical,
		State:       0,
		MsgTo:       params.MsgTo,
	}
	list = append(list, info)
	return
}

func buildTaskInfo(key string, params *warningdto.TaskInfos) (warningList []*wModel.TaskInfoEntity) {
	for _, v := range strings.Split(params.Content, ";") {
		info := &wModel.TaskInfoEntity{
			PrimaryKey: key,
			Content:    v,
		}
		warningList = append(warningList, info)
	}
	return
}

// 导出告警任务明细

// GetOptionSearch 获取页面筛选数据
func (m *MsgWarningService) GetOptionSearch(searchType string, val string) (res warningdto.SearchResp, err error) {
	searchDao := mediareport.NewReportMediaDao(m.Ctx)
	if searchType == "" {
		res.AdvertiserList, _ = searchDao.GetAdvertiserIds(val)
		res.AlbumList, _ = searchDao.GetAlbumName(val)
		res.MaList, _ = searchDao.GetMaterialIds(val)
		res.OptimizerList, _ = searchDao.GetOptimizer(val)
		res.MediaList, _ = searchDao.GetMedia(val)
	} else if searchType == "advertiser" {
		res.AdvertiserList, _ = searchDao.GetAdvertiserIds(val)
	} else if searchType == "album" {
		res.AlbumList, _ = searchDao.GetAlbumName(val)
	} else if searchType == "material" {
		res.MaList, _ = searchDao.GetMaterialIds(val)
	} else if searchType == "optimizer" {
		res.OptimizerList, _ = searchDao.GetOptimizer(val)
	} else if searchType == "media" {
		res.MediaList, _ = searchDao.GetMedia(val)
	}
	return res, err
}
