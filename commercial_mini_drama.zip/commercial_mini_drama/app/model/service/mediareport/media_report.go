package mediareport

import (
	"context"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"github.com/panjf2000/ants/v2"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/common/repository/mediareport"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
	mediadao "goserver/app/model/dao/mediareport"
	"strconv"
	"sync"
	"time"
)

type ReportMediaService struct {
	Ctx context.Context
}

func NewReportMediaService(ctx context.Context) *ReportMediaService {
	return &ReportMediaService{Ctx: ctx}
}

/***********************         新授权逻辑 令牌桶方式获取素材  start       ***********************/

func (r *ReportMediaService) DistributeMediaAccounts(crontabTime time.Time, ctx context.Context, isFast int) error {
	// 获取执行时间
	startDate, endDate := GetExecTime(crontabTime)
	// 按快慢队列查询出所有活跃账号
	activeDao := accountdao.NewOauthActiveAccountDao(ctx)
	activeList, err := activeDao.ListSpiQueen(startDate)
	if err != nil {
		return fmt.Errorf("查询活跃账号失败, err: %v", err)
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return fmt.Errorf("查询活跃账号为空")
	}

	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}

	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncMediaReport(startDate, endDate, activeList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

// SyncMediaReport 快慢队列  同步媒体素材报表数据
func SyncMediaReport(start, end string, activeList []accountrepo.OauthAccountEntity, oauth map[string]string, appId string) {

	resChan := make(chan *mediareport.ReportMediaEntity)
	errChan := make(chan error, len(activeList))

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	once.Do(func() {
		go func() {
			insertErr := execMediaDB(context.Background(), resChan)
			if insertErr != nil {
				errChan <- fmt.Errorf("execMediaDB error: %v", insertErr)
			}
		}()
	})

	// 获取所有活跃账号及token 请求接口数据
	for _, v := range activeList {
		currentItem := v
		wg.Add(1)

		task := func() {
			advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
			advertiserIdStr := currentItem.AdvertiserId
			userId := currentItem.UserId

			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			// 获取MATERIAL_DATA数据
			allMediaReport, getErr := ExecQuery(context.Background(), int64(advertiserId), oauth[userId], start, end, appId)
			if getErr != nil {
				errChan <- fmt.Errorf("素材报表请求失败, advertiserId: %d, token: %s, appId: %s, err: %s", advertiserId, oauth[userId], appId, getErr.Error())
				return
			}
			// 查询无数据直接返回
			if allMediaReport == nil {
				return
			}
			for _, row := range allMediaReport.DataRows2InnerTransformMedia() {
				pointTimeStr := row.StatTimeDay[0:16] + ":00"
				pointTime, _ := time.ParseInLocation(time.DateTime, pointTimeStr, time.Local)
				info := &mediareport.ReportMediaEntity{
					AdvertiserId:  advertiserIdStr,
					MaterialId:    row.MaterialId,
					PromotionId:   row.CdpPromotionId,
					PromotionName: row.CdpPromotionName,
					CreateTime:    pointTime,
					CreateHour:    row.StatTimeDay[11:13],
					ConvertCnt:    row.ConvertCnt,
					ClickCnt:      row.ClickCnt,
					ShowCnt:       row.ShowCnt,
					StatCost:      row.StatCost,
					Active:        row.Active,
					ActivePay:     row.ActivePay,
					ProjectId:     row.CdpProjectId,
				}
				resChan <- info
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		errs = append(errs, errL)
	}

	if len(errs) > 0 {
		_ = sendMsg(errs, "同步素材报表\n")
	}
	return
}

/***********************         新授权逻辑 令牌桶方式获取素材  end       ***********************/

// ExecQuery 查询头条自定义报表 获取素材报表数据
func ExecQuery(ctx context.Context, advertiserId int64, accessToken string, startDate, endDate string, appId string) (allMediaReport toutiao.Rows, err error) {
	statTimeHourSort := models.ASC_ReportCustomGetV30OrderByType
	// topic类型
	dataTopic := models.MATERIAL_DATA_ReportCustomGetV30DataTopic

	allMediaReport, err = toutiao.AllReportCustomGetV30(ctx, toutiao.AllReportCustomGetV30Req{
		AccessToken: accessToken,
		Dimensions: []string{
			"stat_time_hour",     // 按小时获取数据
			"cdp_project_id",     // 项目ID
			"cdp_promotion_id",   // 广告ID
			"cdp_promotion_name", // 项目的名称，对应推广计划名称
			"material_id",        // 媒体ID
		},
		AdvertiserId: advertiserId,
		Metrics: []string{
			"stat_cost",   // 花费
			"show_cnt",    // 曝光
			"click_cnt",   // 点击
			"active",      // 媒体激活
			"active_pay",  // 媒体付费认量
			"convert_cnt", // 转化数
		},
		Filters: []*models.ReportCustomGetV30FiltersInner{
			{Field: "image_mode", Operator: 7, Type: 1, Values: []string{"154", "131", "156", "180", "188", "4", "157", "148", "16", "15", "5", "3", "2"}},
		},
		OrderBy: []*models.ReportCustomGetV30OrderByInner{
			{Field: "stat_time_hour", Type: &statTimeHourSort},
		},
		StartTime: startDate,
		EndTime:   endDate,
		DataTopic: dataTopic, // 素材数据
	}, appId)
	if err != nil {
		return nil, err
	}
	return
}

// ExecQueryDay 天级查询头条自定义报表 获取素材报表数据
func ExecQueryDay(ctx context.Context, advertiserId int64, accessToken string, startDate, endDate string, appId string) (allMediaReport toutiao.Rows, err error) {
	// topic类型
	dataTopic := models.MATERIAL_DATA_ReportCustomGetV30DataTopic

	allMediaReport, err = toutiao.AllReportCustomGetV30(ctx, toutiao.AllReportCustomGetV30Req{
		AccessToken: accessToken,
		Dimensions: []string{
			"stat_time_day",
			"cdp_promotion_id",   // 广告ID
			"cdp_promotion_name", // 项目的名称，对应推广计划名称
			"material_id",        // 媒体ID
		},
		AdvertiserId: advertiserId,
		Metrics: []string{
			"stat_cost",   // 花费
			"show_cnt",    // 曝光
			"click_cnt",   // 点击
			"active",      // 媒体激活
			"active_pay",  // 媒体付费认量
			"convert_cnt", // 转化数
		},
		Filters: []*models.ReportCustomGetV30FiltersInner{
			{Field: "image_mode", Operator: 7, Type: 1, Values: []string{"154", "131", "156", "180", "188", "4", "157", "148", "16", "15", "5", "3", "2"}},
		},
		OrderBy:   []*models.ReportCustomGetV30OrderByInner{},
		StartTime: startDate,
		EndTime:   endDate,
		DataTopic: dataTopic, // 素材数据
	}, appId)
	if err != nil {
		return nil, err
	}
	return
}

// execMediaDB 保存素材数据报表到SR
func execMediaDB(ctx context.Context, resChan <-chan *mediareport.ReportMediaEntity) (err error) {
	reportMediaDao := mediadao.NewReportMediaDao(ctx)
	// 将数据写入 report_hour
	var data = make([]*mediareport.ReportMediaEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			err = reportMediaDao.InsertBatchSize(data, 5000)
			if err != nil {
				errs = append(errs, err)
			}
			data = data[:0]
		}
	}
	if len(data) > 0 {
		err = reportMediaDao.InsertBatchSize(data, 5000)
		if err != nil {
			errs = append(errs, err)
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execMediaDB errors: %v", errs)
	}
	return nil
}
