package fanqie

//import (
//	"github.com/gin-gonic/gin"
//	"goserver/app/library/myerror"
//)
//
//// TomatoIAPUserReq IAP 用户数据推送数据参数
//type TomatoIAPUserReq struct {
//	DeviceId        string   `json:"device_id"`        // 用户设备id
//	BuyingTimestamp string   `json:"buying_timestamp"` // 用户点击推广链时间戳（非染色时间）
//	DistributorId   string   `json:"distributor_id"`   // 快应用/公众号对应distributor_id
//	AppId           string   `json:"app_id"`           // 公众号/快应用/小程序id（分销平台id）【v1.2】
//	AppName         string   `json:"app_name"`         // 快应用/公众号/小程序名称【v1.2】
//	OpenId          string   `json:"open_id"`          // 用户openid（H5书城、微信小程序、抖音小程序）
//	PromotionId     string   `json:"promotion_id"`     // 推广链id
//	ClickId         string   `json:"click_id"`         // 巨量广告下发的唯一标识
//	Ip              string   `json:"ip"`               // IP
//	UserAgent       string   `json:"user_agent"`       // 用户点击推广链时的UA
//	Attributed      string   `json:"attributed"`       // 用户是否成功染色
//	BookId          string   `json:"book_id"`          // 染色推广链的书籍ID【v1.2】
//	BookName        string   `json:"book_name"`        // 染色推广链的书籍名称【v1.2】
//	BookGender      string   `json:"book_gender"`      // 染色推广链书籍性别(0女生、1男生、2无性别)【v1.2】
//	BookCategory    string   `json:"book_category"`    // 染色推广链的书籍类型【v1.2】
//	ActionId        string   `json:"action_id"`        // 用户点击推广链的唯一标识，平台为了尽可能通知到分销商会有重试策略，分销商可以以此进行去重【v1.4.1】
//	ProjectId       string   `json:"project_id"`       // 巨量2.0广告计划组ID（快应用、小程序均支持)
//	AdIdV2          string   `json:"ad_id_v2"`         // 巨量2.0广告计划ID（promotion_id）（快应用、小程序均支持)
//	Mid             []string `json:"mid"`              // 素材id（分别代表图片、标题、视频、试玩、落地页
//	ClueToken       string   `json:"clue_token"`       // 巨量小程序广告参数
//}
//
//// NewIAPUserDataReq 解析绑定IAP用户推送数据参数
//func NewIAPUserDataReq(c *gin.Context) *TomatoIAPUserReq {
//	req := &TomatoIAPUserReq{}
//	if err := c.ShouldBindJSON(req); err != nil {
//		panic(myerror.ParamsError)
//	}
//	return req
//}
