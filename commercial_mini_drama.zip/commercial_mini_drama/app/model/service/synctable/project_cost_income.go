package synctable

import (
	"context"
	"github.com/avast/retry-go"
	"goserver/app/model/dao/roi"
	"goserver/app/model/dao/synctable"
	"time"
)

type ProjectCostService struct {
	Ctx context.Context
}

func NewProjectCostService(ctx context.Context) *ProjectCostService {
	return &ProjectCostService{Ctx: ctx}
}

// QueryAndSaveCostInfos 查询保存消耗数据
func (p *ProjectCostService) QueryAndSaveCostInfos(isHistory int) map[string]string {
	projectCostIncomeDao := synctable.NewProjectCostIncomeDao(p.Ctx)
	var execTime string
	errList := make(map[string]string)
	startDate := time.Now().Add(-172800 * time.Second)
	endDate := time.Now().Add(-86400 * time.Second)
	//startDate := time.Date(time.Now().Year(), time.Now().Month(), time.Now().AddDate(0, 0, -3).Day(), 0, 0, 0, 0, time.UTC)
	//endDate := time.Date(time.Now().Year(), time.Now().Month(), time.Now().AddDate(0, 0, -1).Day(), 0, 0, 0, 0, time.UTC)
	// isHistory = 1 刷新历史数据记录
	if isHistory == 1 {
		for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
			execTime = currentDate.Format(time.DateOnly)
			errHasCost := projectCostIncomeDao.BuildAggHasCostEntityDate(execTime)
			if errHasCost != nil {
				errList[execTime] = errHasCost.Error()
				continue
			}
			errNoCost := projectCostIncomeDao.BuildAggNoCostEntityDate(execTime)
			if errNoCost != nil {
				errList[execTime] = errNoCost.Error()
				continue
			}
		}
	} else {
		execTime = time.Now().Format(time.DateOnly)
		errHasCost := projectCostIncomeDao.BuildAggHasCostEntityDate(execTime)
		if errHasCost != nil {
			errList[execTime] = errHasCost.Error()
		}
		errNoCost := projectCostIncomeDao.BuildAggNoCostEntityDate(execTime)
		if errNoCost != nil {
			errList[execTime] = errNoCost.Error()
		}
	}
	return errList

}

// QueryAndSaveFinalInfos 查询保存最终数据
func (p *ProjectCostService) QueryAndSaveFinalInfos(isHistory int) map[string]string {
	finalDao := roi.NewReportDataDao(p.Ctx)

	var execTime string
	errList := make(map[string]string)
	startDate := time.Now().Add(-172800 * time.Second)
	endDate := time.Now().Add(-86400 * time.Second)

	if isHistory == 1 {
		for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
			err := retry.Do(func() error {
				execTime = currentDate.Format(time.DateOnly)
				errHasCostAndIncome := finalDao.BuildAggHasCostAndIncomeProjectFinalData(execTime)
				if errHasCostAndIncome != nil {
					errList[execTime] = errHasCostAndIncome.Error()
					return errHasCostAndIncome
				}
				errHasCostNoIncome := finalDao.BuildAggNoCostProjectFinalData(execTime)
				if errHasCostNoIncome != nil {
					errList[execTime] = errHasCostNoIncome.Error()
					return errHasCostNoIncome
				}
				// 执行账单数据
				err := finalDao.BuildAggProjectFinalBillEntity(execTime)
				if err != nil {
					errList[execTime] = err.Error()
				}
				return nil
			}, retry.Delay(time.Second*300), retry.Attempts(3))
			if err != nil {
				errList[execTime] = err.Error()
				return errList
			}
		}
	} else {
		execTime = time.Now().Format(time.DateOnly)
		errHasCostAndIncome := finalDao.BuildAggHasCostAndIncomeProjectFinalEntityDataToday(execTime)
		if errHasCostAndIncome != nil {
			errList[execTime] = errHasCostAndIncome.Error()
		}
		errHasCostNoIncome := finalDao.BuildAggHasCostNoIncomeProjectFinalEntityDataToday(execTime)
		if errHasCostNoIncome != nil {
			errList[execTime] = errHasCostNoIncome.Error()
		}
	}
	return errList
}

// SwapProjectTable 原子交换表
func (p *ProjectCostService) SwapProjectTable() error {
	finalDao := roi.NewReportDataDao(p.Ctx)
	err := finalDao.SwapProjectTable()
	if err != nil {
		return err
	}
	return nil
}

// InsertProjectExecTime 保存有效数据时间
func (p *ProjectCostService) InsertProjectExecTime(time string) error {
	finalDao := roi.NewReportDataDao(p.Ctx)
	err := finalDao.ExecProjectTimetable(time)
	if err != nil {
		return err
	}
	return nil
}

// QueryAndSaveCostInfosReplenish 查询保存消耗数据  项目维度补充数据
func (p *ProjectCostService) QueryAndSaveCostInfosReplenish(startDate, endDate time.Time) map[string]string {
	projectCostIncomeDao := synctable.NewProjectCostIncomeDao(p.Ctx)
	var execTime string
	errList := make(map[string]string)
	for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
		execTime = currentDate.Format(time.DateOnly)
		errHasCost := projectCostIncomeDao.BuildAggHasCostEntityDate(execTime)
		if errHasCost != nil {
			errList[execTime] = errHasCost.Error()
			continue
		}
		errNoCost := projectCostIncomeDao.BuildAggNoCostEntityDate(execTime)
		if errNoCost != nil {
			errList[execTime] = errNoCost.Error()
			continue
		}
	}
	return errList

}

// QueryAndSaveFinalInfosReplenish 查询保存最终数据 项目维度补充数据
func (p *ProjectCostService) QueryAndSaveFinalInfosReplenish(startDate, endDate time.Time) map[string]string {
	finalDao := roi.NewReportDataDao(p.Ctx)

	var execTime string
	errList := make(map[string]string)
	for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
		execTime = currentDate.Format(time.DateOnly)
		errHasCostAndIncome := finalDao.BuildAggHasCostAndIncomeProjectFinalData(execTime)
		if errHasCostAndIncome != nil {
			errList[execTime] = errHasCostAndIncome.Error()
			continue
		}
		errHasCostNoIncome := finalDao.BuildAggNoCostProjectFinalData(execTime)
		if errHasCostNoIncome != nil {
			errList[execTime] = errHasCostNoIncome.Error()
			continue
		}
		// 执行账单数据
		err := finalDao.BuildAggReplenishFinalBillEntity(execTime)
		if err != nil {
			errList[execTime] = err.Error()
		}
	}

	return errList
}
