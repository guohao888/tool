package accounts

import (
	"context"
	"fmt"
	"github.com/duke-git/lancet/v2/slice"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/library/log"
	"goserver/app/model/dao"
	"strings"
	"sync"
	"time"
)

type AccountInstanceIdDao struct {
	Ctx context.Context
}

func NewAccountInstanceIdDao(ctx context.Context) *AccountInstanceIdDao {
	return &AccountInstanceIdDao{Ctx: ctx}
}

func (d *AccountInstanceIdDao) InsertBatchSize(data []accountrepo.AccountInstanceIdEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsert(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		// 如果出现错误，回滚事务
		tx.Rollback()
		return err
	}

	tx.Commit()

	return nil
}

func (d *AccountInstanceIdDao) batchInsert(tx *gorm.DB, data []accountrepo.AccountInstanceIdEntity) error {
	insertColumns := []string{"media", "advertiser_id", "instance_id", "search_type", "create_time", "modify_time"}
	// 占位符
	placeholders := strings.Join(slice.Repeat("?", len(insertColumns)), ",")

	sqlStr := fmt.Sprintf("INSERT INTO "+accountrepo.AccountInstanceIdTableName()+" (%s) VALUES ", strings.Join(insertColumns, ","))
	var vals []interface{}
	for _, v := range data {
		sqlStr += fmt.Sprintf("(%s),", placeholders)
		vals = append(vals,
			v.Media,
			v.AdvertiserId,
			v.InstanceId,
			v.SearchType,
			v.CreateTime,
			v.ModifyTime,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

type AdvertiserIdAccountInstanceIdMap struct {
	media  string
	appId  string
	aiMap  sync.Map
	ticker *time.Ticker
	closed chan struct{}
}

func NewAdvertiserIdAccountInstanceIdMap(media string, appType string, appId string) (*AdvertiserIdAccountInstanceIdMap, error) {
	m := AdvertiserIdAccountInstanceIdMap{
		media:  media,
		appId:  appId,
		ticker: time.NewTicker(1 * time.Minute), // 每1分钟更新一次
		closed: make(chan struct{}),
	}

	if appType == "" || appType == accountrepo.AppTypeByteMicroApp { // 只有同步字节小程序的时候才执行
		err := m.UpdateAll()
		if err != nil {
			return nil, err
		}

		go func() {
			for {
				select {
				case t := <-m.ticker.C:
					err := m.UpdateAll()
					if err != nil {
						log.Infof("获取字节小程序的资产信息更新了, media: %s, app_id: %s, t: %s, err: %s", m.media, m.appId, t.Format(time.DateTime), err)
					} else {
						log.Infof("获取字节小程序的资产信息更新了, media: %s, app_id: %s, t: %s", m.media, m.appId, t.Format(time.DateTime))
					}
				case <-m.closed:
					m.ticker.Stop()
					log.Infof("获取字节小程序的资产信息关闭了, media: %s, app_id: %s", m.media, m.appId)
					return
				}
			}
		}()
	}

	return &m, nil
}

func (m *AdvertiserIdAccountInstanceIdMap) GetInstanceIds(advertiserId string, searchType string) ([]int64, error) {
	if v, ok := m.aiMap.Load(fmt.Sprintf("%s_%s", advertiserId, searchType)); ok {
		if v != nil {
			return v.([]int64), nil
		}
		return nil, nil
	}

	return m.UpdateOne(advertiserId, searchType)
}

func (m *AdvertiserIdAccountInstanceIdMap) Done() {
	close(m.closed)
}

func (m *AdvertiserIdAccountInstanceIdMap) UpdateOne(advertiserId string, searchType string) ([]int64, error) {
	key := fmt.Sprintf("%s_%s", advertiserId, searchType)

	// 再查询一次
	db := dorisdb.DorisClient()

	var instanceIds []int64
	err := db.Table(accountrepo.AccountInstanceIdTableName()).
		Where("media = ? and advertiser_id = ? and search_type = ?", m.media, advertiserId, searchType).
		Pluck("DISTINCT instance_id", &instanceIds).
		Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}

	if len(instanceIds) > 0 {
		m.aiMap.Store(key, instanceIds)
	}

	return instanceIds, err
}

func (m *AdvertiserIdAccountInstanceIdMap) UpdateAll() error {
	db := dorisdb.DorisClient()

	subQuery1 := db.Table(accountrepo.OauthTableName()).Select("oauth_id").Where("app_id = ?", m.appId).QueryExpr()
	subQuery2 := db.Table(accountrepo.OauthActiveAccountTableName()).Select("DISTINCT advertiser_id").Where("oauth_id in (?)", subQuery1).QueryExpr()

	var res []accountrepo.AccountInstanceIdEntity
	err := db.Table(accountrepo.AccountInstanceIdTableName()).
		Select("advertiser_id,instance_id,search_type").
		Where("media = ? and advertiser_id in (?)", m.media, subQuery2).
		Order("advertiser_id desc, instance_id desc").
		Find(&res).
		Error
	if err != nil {
		return err
	}

	mm := make(map[string][]int64)
	for _, v := range res {
		mm[fmt.Sprintf("%s_%s", v.AdvertiserId, v.SearchType)] = append(mm[v.AdvertiserId], v.InstanceId)
	}

	for k, v := range mm {
		m.aiMap.Store(k, v)
	}
	return nil
}
