package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	"goserver/app/model/service/promotion"
)

// SyncPromotionInfoLimit 广告维度数据拉取
func SyncPromotionInfoLimit(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("广告信息拉取解析失败, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("拉取广告信息数据时间错误, err: %s", err)
	}
	//
	promotionService := promotion.NewInfoPromotion(ctx)
	for _, crontabDate := range crontabDateList {
		err = promotionService.DistributePromotionAccounts(crontabDate, ctx, params.IsReplenish)
		if err != nil {
			return fmt.Sprintf("拉取广告信息数据失败, err: %s", err)
		}
	}
	return "拉取广告信息数据数据成功"
}

// SyncPromotionInfoLimitReplenish 广告维度数据拉取 补充拉取
func SyncPromotionInfoLimitReplenish(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("广告信息拉取解析失败, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("拉取广告信息数据时间错误, err: %s", err)
	}
	//
	promotionService := promotion.NewInfoPromotion(ctx)
	for _, crontabDate := range crontabDateList {
		err = promotionService.DistributePromotionAccountsRe(crontabDate, ctx, params.IsReplenish, params.AccountIds)
		if err != nil {
			return fmt.Sprintf("拉取广告信息数据失败, err: %s", err)
		}
	}
	return "拉取广告信息数据数据成功"
}
