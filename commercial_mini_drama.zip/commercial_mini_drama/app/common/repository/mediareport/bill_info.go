package mediareport

import (
	"github.com/shopspring/decimal"
	"goserver/app/common/repository"
	"time"
)

const BillInfoEntityTable = "bill_details"

type BillInfoEntity struct {
	AdvertiserId      string          `gorm:"column:advertiser_id"`
	SearchDate        time.Time       `gorm:"column:search_date"`
	Balance           decimal.Decimal `gorm:"column:balance"`
	GrantBalance      decimal.Decimal `gorm:"column:grant_balance"`
	NonGrantBalance   decimal.Decimal `gorm:"column:non_grant_balance"`
	CashCost          decimal.Decimal `gorm:"column:cash_cost"`
	Cost              decimal.Decimal `gorm:"column:cost"`
	Frozen            decimal.Decimal `gorm:"column:frozen"`
	Income            decimal.Decimal `gorm:"column:income"`
	RewardCost        decimal.Decimal `gorm:"column:reward_cost"`
	SharedWalletCost  decimal.Decimal `gorm:"column:shared_wallet_cost"`
	CompanyWalletCost decimal.Decimal `gorm:"column:company_wallet_cost"`
	TransferIn        decimal.Decimal `gorm:"column:transfer_in"`
	TransferOut       decimal.Decimal `gorm:"column:transfer_out"`
}

func (*BillInfoEntity) TableName() string {
	return BillInfoEntityTable
}

func BillInfoTableName() string {
	if repository.IsDebugTable(BillInfoEntityTable) {
		return BillInfoEntityTable + "_dev"
	} else {
		return BillInfoEntityTable
	}
}
