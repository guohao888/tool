package mediareport

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	repo "goserver/app/common/repository/mediareport"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// BillInfoDao 头条账单
type BillInfoDao struct {
	Ctx context.Context
}

func NewBillInfoDao(ctx context.Context) *BillInfoDao {
	return &BillInfoDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (r *BillInfoDao) InsertBatchSize(data []*repo.BillInfoEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = r.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *BillInfoDao) buildInsertSentence(tx *gorm.DB, data []*repo.BillInfoEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.BillInfoTableName() + " ( advertiser_id, search_date, balance, grant_balance, non_grant_balance, cash_cost, cost, frozen, income, reward_cost, shared_wallet_cost, company_wallet_cost, transfer_in, transfer_out ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.SearchDate,
			v.Balance,
			v.GrantBalance,
			v.NonGrantBalance,
			v.CashCost,
			v.Cost,
			v.Frozen,
			v.Income,
			v.RewardCost,
			v.SharedWalletCost,
			v.CompanyWalletCost,
			v.TransferIn,
			v.TransferOut,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
