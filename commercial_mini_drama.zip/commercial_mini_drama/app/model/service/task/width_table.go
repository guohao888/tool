package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	"goserver/app/common/dto/mediareport"
	report "goserver/app/common/dto/widthtable"
	"goserver/app/model/service/fanqie"
	"goserver/app/model/service/synctable"
	"time"
)

func SyncCostIncomeHistory(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewCostIncomeService(ctx)
	// 中间表数据查询
	midErrMap := syncService.QueryAndSaveCostInfos(params.IsHistory)
	for date, errMessage := range midErrMap {
		if errMessage != "" {
			errMsg += fmt.Sprintf("消耗收入关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	// 最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfos(params.IsHistory)
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	return "最终关联数据刷新成功"
}

func SyncCostIncomeToday(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewCostIncomeService(ctx)
	// 中间表数据查询
	midErrMap := syncService.QueryAndSaveCostInfos(params.IsHistory)
	for date, errMessage := range midErrMap {
		if errMessage != "" {
			errMsg += fmt.Sprintf("消耗收入关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	// 最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfos(params.IsHistory)
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	return "最终关联数据刷新成功"
}

/********************************        当日/历史 ROI 分离  start     ********************************/

func SyncCostIncomeToday1(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewCostIncomeService(ctx)
	// 中间表数据查询
	midErrMap := syncService.QueryAndSaveCostInfos(params.IsHistory)
	for date, errMessage := range midErrMap {
		if errMessage != "" {
			errMsg += fmt.Sprintf("消耗收入关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	//最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfosToday(params.IsHistory)
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	// swap
	err := syncService.SwapTable()
	if err != nil {
		return err.Error()
	}
	// 写入最终关联数据时间表
	err = syncService.InsertExecTime(time.Now().Format(time.DateTime))
	if err != nil {
		return err.Error()
	}
	return "最终关联数据刷新成功"
}

/********************************        当日/历史 ROI 分离   end    ********************************/

func SyncCoefficientToday(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := mediareport.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("同步报表数据时间错误, err: %s", err)
	}
	syncService := fanqie.NewTomatoIAACoefficientService(ctx)
	err = syncService.SaveIAACoefficientInfos(crontabDateList, params.Coefficient)
	if err != nil {
		return fmt.Sprintf("刷新IAA订单系数失败 %s", err.Error())
	}
	return "刷新IAA订单系数成功"
}

func SyncMediaIncomeHistory(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewMediaIncomeService(ctx)
	// 中间表数据查询
	midErrMap := syncService.QueryAndSaveMediaInfos(params.IsHistory)
	for date, errMessage := range midErrMap {
		if errMessage != "" {
			errMsg += fmt.Sprintf("媒体关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	// 最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfos(params.IsHistory)
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	return "最终媒体关联数据刷新成功"
}

func SyncMediaIncomeToday(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewMediaIncomeService(ctx)
	// 中间表数据查询
	midErrMap := syncService.QueryAndSaveMediaInfos(params.IsHistory)
	for date, errMessage := range midErrMap {
		if errMessage != "" {
			errMsg += fmt.Sprintf("媒体关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	// 最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfos(params.IsHistory)
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	return "最终媒体关联数据刷新成功"
}

func SyncMediaIncomeHistoryRe(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewMediaIncomeService(ctx)
	// 中间表数据查询
	midErrMap := syncService.QueryAndSaveMediaInfosRe(params.IsHistory)
	for date, errMessage := range midErrMap {
		if errMessage != "" {
			errMsg += fmt.Sprintf("媒体关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	//最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfos(params.IsHistory)
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	return "最终媒体关联数据刷新成功"
}
