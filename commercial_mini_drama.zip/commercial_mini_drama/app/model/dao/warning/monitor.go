package warning

import (
	"context"
	"github.com/jinzhu/gorm"
	"goserver/app/common/dto/page"
	"goserver/app/common/dto/warningdto"
	"goserver/app/common/repository/warning"
	"goserver/app/library/driver/dorisdb"
	"time"
)

type MonitorDao struct {
	Ctx context.Context
}

func NewMonitorDao(ctx context.Context) *MonitorDao {
	return &MonitorDao{Ctx: ctx}
}

// InsertMonitorInfo 保存盯盘任务
func (m *MonitorDao) InsertMonitorInfo(data warning.MonitorInfoEntity) error {
	db := dorisdb.DorisClient()

	var exist warning.MonitorInfoEntity
	err := db.Table(warning.MonitorInfoEntityTableName()).Select("task_id").Where("task_id = ?", exist.TaskId).First(&exist).Error
	if err == nil && exist.TaskId != "" { // 没有错误，且存在，更新
		err = m.UpdateByTaskId(exist.TaskId, &data)
	} else {
		err = db.Table(warning.MonitorInfoEntityTableName()).Save(&data).Error
	}
	return err
}

// UpdateByTaskId 根据任务ID更新监控
func (m *MonitorDao) UpdateByTaskId(taskId string, data *warning.MonitorInfoEntity) error {
	db := dorisdb.DorisClient()
	err := db.Model(warning.MonitorInfoEntityTableName()).
		Select("task_type", "task_name", "media", "monitor_object", "metrics", "date_condition", "condition", "numerical", "metrics_two", "date_condition_two", "condition_two", "numerical_two", "interval_type", "interval_value", "effective_type", "effective_value", "msg_to", "scope_type", "scope_value", "status").
		Where("task_id = ?", taskId).
		Updates(data).Error
	return err
}

// DeleteMonitorInfo 删除盯盘任务
func (m *MonitorDao) DeleteMonitorInfo(taskId string) error {
	db := dorisdb.DorisClient()
	err := db.Table(warning.MonitorInfoEntityTableName()).Where("task_id = ?", taskId).Update("is_delete", 1).Error
	return err
}

// FindMonitorList 按条件搜索盯盘数据
func (m *MonitorDao) FindMonitorList(params *warningdto.MonitorListReq) (*page.Paginator, error) {
	db := dorisdb.DorisClient()
	q := db.Table(warning.MonitorInfoEntityTableName())
	q2 := db.Table(warning.MonitorInfoEntityTableName())
	q = q.Where("is_delete = ?", 0)
	q2 = q2.Where("is_delete = ?", 0)
	if params.Media != 1 {
		q = q.Where("media = ?", params.Media)
		q2 = q2.Where("media = ?", params.Media)
	}
	if params.TaskType != 1 {
		q = q.Where("task_type = ?", params.TaskType)
		q2 = q2.Where("task_type = ?", params.TaskType)
	}
	if params.TaskStatus != 3 {
		q = q.Where("status = ?", params.TaskStatus)
		q2 = q2.Where("status = ?", params.TaskStatus)
	}
	if params.MonitorObject != 1 {
		q = q.Where("monitor_object = ?", params.MonitorObject)
		q2 = q2.Where("monitor_object = ?", params.MonitorObject)
	}
	if params.TaskName != "" {
		q = q.Where("task_name LIKE ?", "%"+params.TaskName+"%")
		q2 = q2.Where("task_name LIKE ?", "%"+params.TaskName+"%")
	}
	if params.OperationType != 1 {
		q = q.Where("operation = ?", params.OperationType)
		q2 = q2.Where("operation = ?", params.OperationType)
	}
	var total int64
	err := q2.Count(&total).Error
	// 分页数据
	pagination := params.Pagination
	var res []*warning.MonitorInfoEntity
	err = q.Order("created_at DESC").Offset(pagination.GetOffset()).Limit(pagination.GetLimit()).Find(&res).Error
	if err != nil {
		return nil, err
	}
	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)

	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return &paginator, nil
}

// FindExecMonitorList 查询执行盯盘任务
func (m *MonitorDao) FindExecMonitorList(interval int) ([]*warning.MonitorInfoEntity, error) {
	db := dorisdb.DorisClient()
	q := db.Table(warning.MonitorInfoEntityTableName())
	var res []*warning.MonitorInfoEntity
	err := q.Where("is_delete = ? AND `status` = ? AND SUBSTR(effective_value, 1, 10) <= ? AND interval_type = ? ", 0, 1, time.Now().Format(time.DateOnly), interval).Find(&res).Error
	if err != nil {
		return nil, err
	}
	return res, nil
}

func (m *MonitorDao) ExecRejectTask(v warning.ExecSqlInfo) (resList []warning.RejectInfo, msgTo string, err error) {
	db := dorisdb.DorisClient()
	msgTo = v.MsgTo
	var startTime, endTime, startTimeTwo, endTimeTwo, rejWhere, acWhere string
	for _, vv := range v.Start {
		if vv.K == 2 {
			startTime = vv.V
		} else {
			startTimeTwo = vv.V
		}
	}
	for _, vv := range v.End {
		if vv.K == 2 {
			endTime = vv.V
		} else {
			endTimeTwo = vv.V
		}
	}
	if startTime != "" {
		rejWhere = " WHERE date(created_at)  BETWEEN '" + startTime + "' AND '" + endTime + "' "
	} else {
		rejWhere = " WHERE 1 = 1 "
	}
	if startTimeTwo != "" {
		acWhere = " WHERE date(date) BETWEEN '" + startTimeTwo + "' AND '" + endTimeTwo + "' "
	} else {
		acWhere = " WHERE 1 = 1 "
	}
	rej := "SELECT advertiser_id, promotion_id, item, count(*) as reject_time, max(reject_reason) as reject_reason, max(suggestion) as suggestion FROM reject_material " + rejWhere + "  GROUP BY advertiser_id, promotion_id, item "
	f := " SELECT advertiser_id, material_id, video_id, filename FROM video_file "
	ac := " SELECT account_id, account_name, project_id, project_name, optimizer_nickname, sum(media_cost/1.02) as media_cost FROM ( SELECT * FROM roi_project_hourly WHERE pay_type = 1 UNION SELECT * FROM roi_project_hourly_today WHERE pay_type = 1 ) t  " + acWhere + " GROUP BY account_id, account_name, project_id, project_name, optimizer_nickname "
	queryFile := " rej.advertiser_id as advertiser_id, f.material_id as material_id, f.filename as filename, ac.account_name as account_name, ac.project_id as project_id, ac.project_name as project_name, rej.reject_reason as reject_reason, rej.suggestion as suggestion, rej.reject_time as reject_time, ac.optimizer_nickname as nick_name "
	where := " WHERE " + v.WhereSql
	sql := "SELECT " + queryFile + " FROM ( " + rej + " ) rej LEFT JOIN (" + f + " ) f ON rej.advertiser_id = f.advertiser_id AND rej.item = f.video_id LEFT JOIN (" + ac + " ) ac ON rej.advertiser_id = ac.account_id " + where
	err = db.Raw(sql).Scan(&resList).Error
	if err != nil {
		return
	}
	for _, vv := range resList {
		msgTo += "," + vv.NickName
	}
	return
}

func (m *MonitorDao) ExecROITask(v warning.ExecSqlInfo) (resList []warning.ROIMonitor, msgTo string, errs error) {
	db := dorisdb.DorisClient()
	msgTo = v.MsgTo
	var startTime, endTime, startTimeTwo, endTimeTwo, cosWhere, cosrWhere string
	for _, vv := range v.Start {
		if vv.K == 1 {
			startTime = vv.V
		} else {
			startTimeTwo = vv.V
		}
	}
	for _, vv := range v.End {
		if vv.K == 1 {
			endTime = vv.V
		} else {
			endTimeTwo = vv.V
		}
	}
	if startTime != "" {
		cosWhere = " WHERE date(date)  BETWEEN '" + startTime + "' AND '" + endTime + "' "
	} else {
		cosWhere = " WHERE 1 = 1 "
	}
	if startTimeTwo != "" {
		cosrWhere = " WHERE date(date) BETWEEN '" + startTimeTwo + "' AND '" + endTimeTwo + "' "
	} else {
		cosrWhere = " WHERE 1 = 1 "
	}
	cos := "SELECT account_id, account_name, sum(media_cost/1.02) as media_cost FROM ( SELECT * FROM roi_project_hourly WHERE pay_type = 1 UNION SELECT * FROM roi_project_hourly_today WHERE pay_type = 1 ) a " + cosWhere + " GROUP BY account_id, account_name"
	cosr := "SELECT account_id, account_name, optimizer_nickname, round(sum(media_cost/1.02), 2) as media_cost, round(sum(income*1.28), 2) as income, ROUND(sum(income*1.28)/sum(media_cost/1.02), 2) as roi FROM ( SELECT * FROM roi_project_hourly WHERE pay_type = 1 UNION SELECT * FROM roi_project_hourly_today WHERE pay_type = 1 ) b " + cosrWhere + " GROUP BY account_id, account_name, optimizer_nickname "
	queryFile := "cos.account_id as advertiser_id, cos.account_name as advertiser_name, cosr.media_cost as media_cost, cosr.income as income, cosr.roi as roi, cosr.optimizer_nickname as nick_name "
	where := " WHERE " + v.WhereSql
	sql := "SELECT " + queryFile + " FROM ( " + cos + " ) cos LEFT JOIN (" + cosr + " ) cosr ON cos.account_id = cosr.account_id " + where
	err := db.Raw(sql).Scan(&resList).Error
	if err != nil {
		return
	}
	for _, vv := range resList {
		msgTo += "," + vv.NickName
	}
	return
}

func (m *MonitorDao) ExecKuaishouROITask(v warning.ExecSqlInfo) (resList []warning.ROIMonitor, msgTo string, errs error) {
	db := dorisdb.DorisClient()
	msgTo = v.MsgTo
	var startTime, endTime, startTimeTwo, endTimeTwo, cosWhere, cosrWhere string
	for _, vv := range v.Start {
		if vv.K == 1 {
			startTime = vv.V
		} else {
			startTimeTwo = vv.V
		}
	}
	for _, vv := range v.End {
		if vv.K == 1 {
			endTime = vv.V
		} else {
			endTimeTwo = vv.V
		}
	}
	if startTime != "" {
		cosWhere = " WHERE date(date)  BETWEEN '" + startTime + "' AND '" + endTime + "' "
	} else {
		cosWhere = " WHERE 1 = 1 "
	}
	if startTimeTwo != "" {
		cosrWhere = " WHERE date(date) BETWEEN '" + startTimeTwo + "' AND '" + endTimeTwo + "' "
	} else {
		cosrWhere = " WHERE 1 = 1 "
	}
	cos := "SELECT account_id, sum(total_charge/1000) as cost FROM kuaishou_ad_detail " + cosWhere + " AND is_today = 1 GROUP BY account_id"
	cosr := "SELECT account_id, sum(total_charge/1000) as media_cost, sum(event_pay_purchase_amount) as income, round(sum(event_pay_purchase_amount)/sum(total_charge/1000), 2) as roi FROM kuaishou_ad_detail " + cosrWhere + " AND is_today = 1 GROUP BY account_id "
	optimizer := "SELECT account_id, account_name, SUBSTRING_INDEX(account_name,'-',1) as nick_name FROM kuaishou_account_info"
	queryFile := "cos.account_id as advertiser_id, op.account_name as advertiser_name, cosr.media_cost as media_cost, cosr.income as income, cosr.roi as roi, cosr.nick_name as nick_name "
	where := " WHERE " + v.WhereSql
	sql := "SELECT " + queryFile + " FROM ( " + cos + " ) cos LEFT JOIN ( " + optimizer + " ) op ON cos.account_id = op.account_id LEFT JOIN (" + cosr + " ) cosr ON cos.account_id = cosr.account_id " + where
	err := db.Raw(sql).Scan(&resList).Error
	if err != nil {
		return
	}
	for _, vv := range resList {
		msgTo += "," + vv.NickName
	}
	return
}

// ExecWeekSchedule 查询项目维度账号+项目维度满足条件数据
func (m *MonitorDao) ExecWeekSchedule(v warning.ExecSqlInfo) (resList []warning.WeekSchedule, msgTo string, errs error) {
	db := dorisdb.DorisClient()
	msgTo = v.MsgTo
	var startTime, endTime, startTimeTwo, endTimeTwo, cosWhere, roiWhere string
	for _, vv := range v.Start {
		if vv.K == 1 {
			startTime = vv.V
		} else {
			startTimeTwo = vv.V
		}
	}
	for _, vv := range v.End {
		if vv.K == 1 {
			endTime = vv.V
		} else {
			endTimeTwo = vv.V
		}
	}
	if startTime != "" {
		cosWhere = " WHERE date(date)  BETWEEN '" + startTime + "' AND '" + endTime + "' "
	} else {
		cosWhere = " WHERE 1 = 1 "
	}
	if startTimeTwo != "" {
		roiWhere = " WHERE date(date) BETWEEN '" + startTimeTwo + "' AND '" + endTimeTwo + "' "
	} else {
		roiWhere = " WHERE 1 = 1 "
	}
	cos := "SELECT  account_id, account_name, project_id, project_name, sum(media_cost/1.02) as cost, optimizer_nickname FROM ( SELECT date, account_id, account_name, project_id, project_name, media_cost, income, optimizer_nickname FROM roi_project_hourly UNION SELECT date, account_id, account_name, project_id, project_name, media_cost, income, optimizer_nickname FROM roi_project_hourly_today ) a " + cosWhere + " GROUP BY account_id, account_name, project_id, project_name, optimizer_nickname"
	roi := "SELECT account_id, project_id, round(sum(income)/sum(media_cost/1.02), 2) as roi FROM ( SELECT date, account_id, account_name, project_id, project_name, media_cost, income, optimizer_nickname FROM roi_project_hourly UNION SELECT date, account_id, account_name, project_id, project_name, media_cost, income, optimizer_nickname FROM roi_project_hourly_today ) b " + roiWhere + " GROUP BY account_id, project_id"
	where := " WHERE " + v.WhereSql
	sql := "SELECT cos.account_id as advertiser_id, cos.account_name as advertiser_name, cos.project_id as project_id, cos.project_name as project_name, cost as cost, roi as roi, cos.optimizer_nickname as nick_name FROM (" + cos + ") cos LEFT JOIN (" + roi + ") roi ON cos.account_id = roi.account_id AND cos.project_id = roi.project_id " + where
	err := db.Raw(sql).Scan(&resList).Error
	if err != nil {
		return
	}
	for _, vv := range resList {
		msgTo += "," + vv.NickName
	}
	return
}

// ExecKuaishouSchedule 查询项目维度账号+项目维度满足条件数据
func (m *MonitorDao) ExecKuaishouSchedule(v warning.ExecSqlInfo) (resList []warning.WeekSchedule, msgTo string, errs error) {
	db := dorisdb.DorisClient()
	msgTo = v.MsgTo
	var startTime, endTime, startTimeTwo, endTimeTwo, cosWhere, roiCosWhere string
	for _, vv := range v.Start {
		if vv.K == 1 {
			startTime = vv.V
		} else {
			startTimeTwo = vv.V
		}
	}
	for _, vv := range v.End {
		if vv.K == 1 {
			endTime = vv.V
		} else {
			endTimeTwo = vv.V
		}
	}
	if startTime != "" {
		cosWhere = " WHERE date(date)  BETWEEN '" + startTime + "' AND '" + endTime + "' "
	} else {
		cosWhere = " WHERE 1 = 1 "
	}
	if startTimeTwo != "" {
		roiCosWhere = "WHERE date(date)  BETWEEN '" + startTimeTwo + "' AND '" + endTimeTwo + "' "
	} else {
		roiCosWhere = " WHERE 1 = 1 "
	}
	cos := "SELECT account_id, sum(total_charge/1000) as cost FROM kuaishou_ad_detail " + cosWhere + " AND is_today = 1 GROUP BY account_id"
	roi := "SELECT account_id, sum(total_charge/1000) as media_cost, sum(event_pay_purchase_amount+mini_game_iaa_purchase_amount) as income, round(sum(event_pay_purchase_amount+mini_game_iaa_purchase_amount)/sum(total_charge/1000), 2) as roi FROM kuaishou_ad_detail " + roiCosWhere + " AND is_today = 1 GROUP BY account_id "
	optimizer := "SELECT account_id, account_name, SUBSTRING_INDEX(account_name,'-',1) as nick_name FROM kuaishou_account_info"
	queryFile := "cos.account_id as advertiser_id, op.account_name as advertiser_name, cosr.media_cost as cost, cosr.roi as roi, op.nick_name as nick_name"
	where := " WHERE " + v.WhereSql
	sql := "SELECT " + queryFile + " FROM ( " + cos + " ) cos LEFT JOIN ( " + optimizer + " ) op ON cos.account_id = op.account_id LEFT JOIN (" + roi + " ) cosr ON cos.account_id = cosr.account_id " + where
	err := db.Raw(sql).Scan(&resList).Error
	if err != nil {
		return
	}
	for _, vv := range resList {
		msgTo += "," + vv.NickName
	}
	return
}
