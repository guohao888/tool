package kuaishou

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common"
	"goserver/app/common/dto/kuaishoudto"
	"goserver/app/common/repository/kuaishou"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strconv"
	"strings"
	"time"
)

// AdDetailDao 短剧广告报表明细
type AdDetailDao struct {
	Ctx context.Context
}

func NewAdDetailDao(ctx context.Context) *AdDetailDao {
	return &AdDetailDao{Ctx: ctx}
}

func (a *AdDetailDao) List(req *kuaishoudto.AdDataListReq) ([]kuaishou.AdDetailEntity, int64, error) {
	db := dorisdb.DorisClient()
	querySql := a.getQuerySql(req)

	pagination := req.Pagination
	limit := pagination.GetLimit()
	offset := pagination.GetOffset()

	// 总量
	type Dist struct {
		Cnt int64 `gorm:"column:cnt"`
	}
	var dist Dist
	countSql := querySql.CountSql
	err := db.Raw(countSql).Scan(&dist).Error
	if err != nil {
		return nil, 0, err
	}

	// 分页明细
	var items []kuaishou.AdDetailEntity
	itemSql := querySql.ItemSql +
		" LIMIT " + strconv.FormatInt(limit, 10) + " OFFSET " + strconv.FormatInt(offset, 10)
	err = db.Raw(itemSql).Scan(&items).Error
	if err != nil {
		return nil, 0, err
	}

	// 汇总数据
	var summaryItem kuaishou.AdDetailEntity
	summarySql := querySql.SummarySql
	err = db.Raw(summarySql).Scan(&summaryItem).Error
	if err != nil {
		return nil, 0, err
	}

	// 拼接数据
	var list []kuaishou.AdDetailEntity
	list = append(list, summaryItem)
	list = append(list, items...)

	return list, dist.Cnt, nil
}

func (a *AdDetailDao) Export(req *kuaishoudto.AdDataListReq) (result []kuaishou.AdDetailEntity, err error) {
	db := dorisdb.DorisClient()
	querySql := a.getQuerySql(req)

	// 分页明细
	var items []kuaishou.AdDetailEntity
	itemSql := querySql.ItemSql
	err = db.Raw(itemSql).Scan(&items).Error
	if err != nil {
		return nil, err
	}

	// 汇总数据
	var summaryItem kuaishou.AdDetailEntity
	summarySql := querySql.SummarySql
	err = db.Raw(summarySql).Scan(&summaryItem).Error
	if err != nil {
		return nil, err
	}

	// 拼接数据
	var list []kuaishou.AdDetailEntity
	list = append(list, summaryItem)
	list = append(list, items...)

	return list, nil
}

func (a *AdDetailDao) getQuerySql(req *kuaishoudto.AdDataListReq) *sqlQuery {
	detailTableName := kuaishou.AdDetailTableName() + " as d"
	seriesTableName := kuaishou.SeriesInfoTableName() + " as s"
	accountTableName := kuaishou.AccountInfoTableName() + " as a"

	var columns, summaryColumns, groups, where, sorts []string
	var filterStr string

	if req.GroupType == "w" {
		columns = append(columns, "DATE_FORMAT(d.date, '%xW%v') AS date_str")
		groups = append(groups, "DATE_FORMAT(d.date, '%xW%v')")
	} else if req.GroupType == "m" {
		columns = append(columns, "DATE_FORMAT(d.date, '%Y-%m') AS date_str")
		groups = append(groups, "DATE_FORMAT(d.date, '%Y-%m')")
	} else {
		columns = append(columns, "DATE_FORMAT(d.date, '%Y-%m-%d') AS date_str")
		groups = append(groups, "DATE_FORMAT(d.date, '%Y-%m-%d')")
	}

	if req.StartDate == req.EndDate {
		where = append(where, "d.date='"+req.StartDate+"'")
		if req.StartDate == time.Now().Format("2006-01-02") {
			where = append(where, "d.is_today=1")
		} else {
			where = append(where, "d.is_today=2")
		}
	} else {
		where = append(where, "d.date>='"+req.StartDate+"' AND d.date<='"+req.EndDate+"'")
		where = append(where, "d.is_today=2")
	}

	if req.SeriesType > 0 {
		filterStr = "d.series_type=" + strconv.Itoa(int(req.SeriesType))
		where = append(where, filterStr)
	}

	if req.AccountID != "" {
		filterStr = "d.account_id=" + req.AccountID
		where = append(where, filterStr)
	}

	if req.AccountName != "" {
		filterStr = "a.account_name='" + req.AccountName + "'"
		where = append(where, filterStr)
	}

	if req.SeriesID != "" {
		filterStr = "d.series_id=" + req.SeriesID
		where = append(where, filterStr)
	}

	if req.SeriesName != "" {
		filterStr = "s.series_name='" + req.SeriesName + "'"
		where = append(where, filterStr)
	}

	if req.OptimizerName != "" {
		if req.OptimizerName == "-" {
			filterStr = "INSTR(a.account_name, '-') = 0"
		} else {
			filterStr = "a.account_name LIKE '" + req.OptimizerName + "-%'"
		}
		where = append(where, filterStr)
	}

	// 排序 (sort)
	if len(req.Sorts) == 0 {
		req.Sorts = append(req.Sorts,
			common.Sort{Key: "date_str", Order: "asc"},
			common.Sort{Key: "total_charge", Order: "desc"},
		)
	}
	for _, sort := range req.Sorts {
		if sort.Key == "date" {
			sort.Key = "date_str"
		}
		sorts = append(sorts, fmt.Sprintf("%s %s", sort.Key, sort.Order))
	}

	for _, v := range req.GroupBy {
		if v == "account_name" {
			columns = append(columns, "a.account_name")
			columns = append(columns, "d.account_id")
			groups = append(groups, "a.account_name")
			groups = append(groups, "d.account_id")
		}

		if v == "series_name" {
			columns = append(columns, "s.series_name")
			columns = append(columns, "d.series_id")
			groups = append(groups, "s.series_name")
			groups = append(groups, "d.series_id")
		}

		if v == "media" {
			columns = append(columns, "'快手' AS media")
			groups = append(groups, "media")
		}
	}

	var sumColumns = []string{
		"likes",              // 点赞数
		"share",              // 分享数
		"photo_click",        // 封面点击数
		"impression",         // 封面曝光数
		"event_pay",          // 付费次数
		"t0_direct_paid_cnt", // 付费次数(计费时间)

		"t0_direct_paid_amt",                  // 付费金额(计费时间)
		"ad_show",                             // 广告曝光
		"total_charge",                        // 媒体消耗
		"event_app_invoked",                   // 唤起应用数
		"event_pay_purchase_amount_first_day", // 激活当日付费金额
		"event_pay_purchase_amount_one_day_by_conversion",   // 激活后24h付费金额(激活时间)
		"event_pay_purchase_amount_week_by_conversion",      // 激活后七日付费金额
		"event_pay_purchase_amount_three_day_by_conversion", // 激活后三日付费金额
		"conversion",                           // 激活数
		"t0_direct_conversion_cnt",             // 激活数(计费时间)
		"negative",                             // 减少此类作品数
		"report",                               // 举报数
		"block",                                // 拉黑数
		"comment",                              // 评论数
		"event_pay_first_day",                  // 首日付费次数
		"played_num",                           // 素材曝光数
		"played_three_seconds",                 // 3s播放数
		"ad_photo_played75percent",             // 75%播放进度数
		"played_end",                           // 完播数
		"follow",                               // 新增粉丝数
		"event_new_user_pay",                   // 新增付费人数
		"ad_item_click",                        // 行为数
		"t7_paid_cnt",                          // 7日累计付费次数
		"t7_paid_amt",                          // 7日累计付费金额
		"conversion_num_by_impression7d",       // 转化数(计费时间)
		"deep_conversion_num_by_impression7d",  // 深度转化数(计费时间)
		"conversion_num",                       // 转化数(回传时间)
		"deep_conversion_num",                  // 深度转化数
		"t0_paid_cnt",                          // 当日累计付费次数
		"t0_paid_amt",                          // 当日累计付费金额
		"event_pay_cost",                       // 付费次数成本
		"event_app_invoked_cost",               // 唤起应用成本
		"deep_conversion_cost_by_impression7d", // 深度转化成本(计费时间)，单位元
		"event_pay_first_day_cost",             // 首日付费次数成本，单位元
		"event_new_user_pay_cost",              // 新增付费人数成本，单位元
		"key_action",                           // 关键行为数
		"ad_photo_played75percent_ratio",       // 75%进度播放数
		"mini_game_iaa_purchase_amount",        // IAA广告变现LTV（元)
	}

	var kpiArr []string
	for _, v := range sumColumns {
		kpiArr = append(kpiArr, "SUM(d."+v+") AS "+v)
	}

	var complexKpiArr = []string{
		"SUM(d.event_pay_purchase_amount) AS event_pay_purchase_amount",                                                       // 付费金额
		"SUM(d.event_pay_purchase_amount)*0.9*0.99 AS actual_event_pay_purchase_amount",                                       // 实际付费金额
		"SUM(d.total_charge)/1.072 as actual_charge",                                                                          // 实际消耗
		"SUM(d.t0_paid_amt)*0.9*0.99 AS actual_t0_paid_amt",                                                                   // 当日累计实际付费金额
		"SUM(d.played_three_seconds)/SUM(d.played_num) AS play3s_ratio",                                                       // 3s播放率
		"SUM(d.ad_photo_played75percent)/SUM(d.played_num) AS ad_photo_played_75percent_ratio",                                // 75%进度播放率
		"SUM(d.t7_paid_amt)*1000/SUM(d.total_charge) AS t7_paid_roi",                                                          // 7日累计ROI
		"SUM(d.t0_paid_amt)*1000/SUM(d.total_charge) AS t0_paid_roi",                                                          // 当日累计ROI
		"SUM(d.t0_paid_amt)*0.9*0.99*1000/(SUM(d.total_charge)/1.072) AS actual_t0_paid_roi",                                  // 当日累计实际ROI
		"SUM(d.photo_click)/SUM(d.impression) AS photo_click_ratio",                                                           // 封面点击率
		"SUM(d.event_pay_purchase_amount)*1000/SUM(d.total_charge) AS event_pay_roi",                                          // 付费ROI
		"SUM(d.event_app_invoked)/SUM(d.ad_show) AS event_app_invoked_ratio",                                                  // 唤起应用率
		"SUM(d.total_charge)/1000/SUM(d.conversion) AS conversion_cost",                                                       // 激活单价
		"SUM(d.total_charge)/1000/SUM(d.photo_click) AS photo_click_cost",                                                     // 平均封面点击单价（元
		"SUM(d.total_charge)/1000/SUM(d.impression) AS impression1k_cost",                                                     // 平均千次封面曝光花费（元）
		"SUM(d.total_charge)/1000/SUM(d.played_num) AS click1k_cost",                                                          // 平均千次素材曝光花费（元）
		"SUM(d.total_charge)/1000/SUM(d.ad_item_click) AS action_cost",                                                        // 平均行为单价（元
		"SUM(d.deep_conversion_num_by_impression7d)/SUM(d.t0_direct_conversion_cnt) AS deep_conversion_ratio_by_impression7d", // 深度转化率(计费时间)
		"SUM(d.ad_item_click)/SUM(d.played_num) AS action_ratio",                                                              // 素材点击率
		"SUM(d.played_end)/SUM(d.played_num) AS play_end_ratio",                                                               // 完播率
		"SUM(d.ad_item_click)/SUM(d.ad_show) AS action_new_ratio",                                                             // 行为率
		"SUM(d.total_charge)/1000/SUM(d.conversion_num_by_impression7d) AS conversion_cost_by_impression7d",                   // 转化成本(计费时间)，单位元
		"SUM(d.conversion_num_by_impression7d)/SUM(d.t0_direct_conversion_cnt) AS conversion_ratio_by_impression7d",           // 转化率(计费时间)
		"SUM(d.mini_game_iaa_purchase_amount)*1000/SUM(d.total_charge) AS mini_game_iaa_roi",                                  // IAA广告变现ROI
		"SUM(d.mini_game_iaa_purchase_amount)*0.9*0.99 AS actual_mini_game_iaa_purchase_amount",                               // 实际IAA广告变现LTV（元）
	}

	summaryColumns = []string{
		"STR_TO_DATE('1970-01-01', '%Y-%m-%d') as date",
		"'' AS media", // 媒体
	}

	countBaseSql := "SELECT " + strings.Join(columns, ",") +
		" FROM " + detailTableName +
		" LEFT JOIN " + seriesTableName + " ON d.series_id=s.series_id AND d.advertiser_id=s.advertiser_id" +
		" LEFT JOIN " + accountTableName + " ON d.account_id=a.account_id AND d.advertiser_id=a.advertiser_id" +
		" WHERE " + strings.Join(where, " AND ") +
		" GROUP BY " + strings.Join(groups, ",")

	baseSql := "SELECT " + strings.Join(columns, ",") + "," + strings.Join(kpiArr, ",") + "," + strings.Join(complexKpiArr, ",") +
		" FROM " + detailTableName +
		" LEFT JOIN " + seriesTableName + " ON d.series_id=s.series_id AND d.advertiser_id=s.advertiser_id" +
		" LEFT JOIN " + accountTableName + " ON d.account_id=a.account_id AND d.advertiser_id=a.advertiser_id" +
		" WHERE " + strings.Join(where, " AND ") +
		" GROUP BY " + strings.Join(groups, ",")

	summaryBaseSql := "SELECT d.*" +
		" FROM " + detailTableName +
		" LEFT JOIN " + seriesTableName + " ON d.series_id=s.series_id AND d.advertiser_id=s.advertiser_id" +
		" LEFT JOIN " + accountTableName + " ON d.account_id=a.account_id AND d.advertiser_id=a.advertiser_id" +
		" WHERE " + strings.Join(where, " AND ")

	// 总量
	countSql := "SELECT COUNT(*) as cnt" + " FROM (" + countBaseSql + ") t"

	// 分页明细
	itemSql := baseSql + " ORDER BY " + strings.Join(sorts, ",")

	// 汇总数据
	summarySql := "SELECT " + strings.Join(summaryColumns, ",") + "," + strings.Join(kpiArr, ",") + "," + strings.Join(complexKpiArr, ",") +
		" FROM (" + summaryBaseSql + ") d"

	return &sqlQuery{
		CountSql:   countSql,
		ItemSql:    itemSql,
		SummarySql: summarySql,
	}

}

// InsertBatchSize 插入更新数据
func (a *AdDetailDao) InsertBatchSize(data []*kuaishou.AdDetailEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = a.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (a *AdDetailDao) buildInsertSentence(tx *gorm.DB, data []*kuaishou.AdDetailEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + kuaishou.AdDetailTableName() + " ( advertiser_id, date, is_today, series_type, likes, share, photo_click, impression, event_pay, t0_direct_paid_cnt, event_pay_purchase_amount, t0_direct_paid_amt, ad_show, total_charge, event_app_invoked, event_pay_purchase_amount_first_day, event_pay_purchase_amount_one_day_by_conversion, event_pay_purchase_amount_week_by_conversion, event_pay_purchase_amount_three_day_by_conversion, conversion, t0_direct_conversion_cnt, report, block, comment, event_pay_first_day, played_num, played_three_seconds, ad_photo_played75percent, played_end, follow, event_new_user_pay, ad_item_click, t7_paid_cnt, t7_paid_amt, conversion_num_by_impression7d, deep_conversion_num_by_impression7d, conversion_num, deep_conversion_num, t0_paid_cnt, t0_paid_amt, play3s_ratio, ad_photo_played_75percent_ratio, t7_paid_roi, t0_paid_roi, photo_click_ratio, event_pay_cost, event_pay_roi, event_app_invoked_cost, event_app_invoked_ratio, conversion_cost, event_pay_first_day_roi, event_pay_purchase_amount_one_day_by_conversion_roi, event_pay_purchase_amount_three_day_by_conversion_roi, event_pay_purchase_amount_week_by_conversion_roi, photo_click_cost, impression1k_cost, click1k_cost, action_cost, deep_conversion_cost_by_impression7d, deep_conversion_ratio_by_impression7d, event_pay_first_day_cost, action_ratio, play_end_ratio, event_new_user_pay_cost, event_new_user_pay_ratio, action_new_ratio, conversion_cost_by_impression7d, conversion_ratio_by_impression7d, key_action, ad_photo_played75percent_ratio, mini_game_iaa_roi, mini_game_iaa_purchase_amount, account_id, series_id, recharge_rate ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.Date,
			v.IsToday,
			v.SeriesType,
			v.Likes,
			v.Share,
			v.PhotoClick,
			v.Impression,
			v.EventPay,
			v.T0DirectPaidCnt,
			v.EventPayPurchaseAmount,
			v.T0DirectPaidAmt,
			v.AdShow,
			v.TotalCharge,
			v.EventAppInvoked,
			v.EventPayPurchaseAmountFirstDay,
			v.EventPayPurchaseAmountOneDayByConversion,
			v.EventPayPurchaseAmountWeekByConversion,
			v.EventPayPurchaseAmountThreeDayByConversion,
			v.Conversion,
			v.T0DirectConversionCnt,
			//v.Negative,
			v.Report,
			v.Block,
			v.Comment,
			v.EventPayFirstDay,
			v.PlayedNum,
			v.PlayedThreeSeconds,
			v.AdPhotoPlayed75percent,
			v.PlayedEnd,
			v.Follow,
			v.EventNewUserPay,
			v.AdItemClick,
			v.T7PaidCnt,
			v.T7PaidAmt,
			v.ConversionNumByImpression7d,
			v.DeepConversionNumByImpression7d,
			v.ConversionNum,
			v.DeepConversionNum,
			v.T0PaidCnt,
			v.T0PaidAmt,
			v.Play3sRatio,
			v.AdPhotoPlayed75PercentRatio,
			v.T7PaidRoi,
			v.T0PaidRoi,
			v.PhotoClickRatio,
			v.EventPayCost,
			v.EventPayRoi,
			v.EventAppInvokedCost,
			v.EventAppInvokedRatio,
			v.ConversionCost,
			v.EventPayFirstDayRoi,
			v.EventPayPurchaseAmountOneDayByConversionRoi,
			v.EventPayPurchaseAmountThreeDayByConversionRoi,
			v.EventPayPurchaseAmountWeekByConversionRoi,
			v.PhotoClickCost,
			v.Impression1kCost,
			v.Click1kCost,
			v.ActionCost,
			v.DeepConversionCostByImpression7d,
			v.DeepConversionRatioByImpression7d,
			v.EventPayFirstDayCost,
			v.ActionRatio,
			v.PlayEndRatio,
			v.EventNewUserPayCost,
			v.EventNewUserPayRatio,
			v.ActionNewRatio,
			v.ConversionCostByImpression7d,
			v.ConversionRatioByImpression7d,
			v.KeyAction,
			v.AdPhotoPlayed75percentRatio,
			v.MiniGameIaaRoi,
			v.MiniGameIaaPurchaseAmount,
			v.AccountId,
			v.SeriesId,
			v.RechargeRate,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func (a *AdDetailDao) GetSeriesIdsAndType(date string) (res []*kuaishou.AdDetailEntity, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT advertiser_id, series_id, series_type FROM kuaishou_ad_detail WHERE series_type != 0 AND date(date) = '" + date + "' GROUP BY advertiser_id, series_id, series_type"
	err = db.Raw(sql).Scan(&res).Error
	return
}

func (a *AdDetailDao) DistinctSeriesIds() (res []*kuaishou.AdDetailEntity, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT advertiser_id, series_id FROM kuaishou_ad_detail WHERE date(date) = CURRENT_DATE AND series_type = 0 GROUP BY advertiser_id, series_id"
	err = db.Raw(sql).Scan(&res).Error
	return
}

type SeriesMsg struct {
	Date       string
	SeriesId   string
	SeriesName string
	Cost       float64
	Hcost      float64
	Income     float64
	Roi        float64
}

func (a *AdDetailDao) SeriesCost() (res []SeriesMsg, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT substr(date, 1, 10) as date, cos.series_id, series_name, cost, hcost, income, roi FROM ( SELECT date(date) as date, series_id, round(sum(total_charge/1000), 2) as cost, round(sum(pay_amt+mini_game_iaa_purchase_amount)*0.9*0.99, 2) as income, round(sum(pay_amt+mini_game_iaa_purchase_amount)*0.9*0.99/ sum(total_charge/1000)/1.072, 2) as roi FROM kuaishou_core_data WHERE date(date) = CURRENT_DATE GROUP BY date(date), series_id) cos LEFT JOIN ( SELECT series_id, series_name FROM kuaishou_series_info ) se ON cos.series_id = se.series_id LEFT JOIN ( SELECT series_id, round(total_charge/1000/1.072, 2) as hcost FROM kuaishou_core_data WHERE date(date) = CURRENT_DATE AND HOUR(date) = HOUR(CURRENT_TIME)-1 ) h ON cos.series_id = h.series_id WHERE cost > 300 AND roi < 0.8 ORDER BY cost DESC"
	err = db.Raw(sql).Scan(&res).Error
	return
}

func (a *AdDetailDao) SavePullTime(pullTime string, pullType int) error {
	db := dorisdb.DorisClient()
	insertSql := "INSERT INTO kuaishou_pull_time (`pull_time`, `pull_type` ) VALUES ('" + pullTime + "', '" + strconv.Itoa(pullType) + "')"
	err := db.Exec(insertSql).Error
	if err != nil {
		return err
	}
	return nil
}
