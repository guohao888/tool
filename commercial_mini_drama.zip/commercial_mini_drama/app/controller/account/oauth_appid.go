package account

import (
	"github.com/gin-gonic/gin"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	account "goserver/app/model/service/accounts"
)

func AppIDList(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := accountdto.NewAppIdListReq(c)
	oauthConfigService := account.NewOauthConfigService(c)
	paginator, _ := oauthConfigService.ConfigList(req.Params)
	r.Response(myerror.OK.Code, myerror.OK.Message, paginator)
}

func AddAppID(c *gin.Context) {
	r := response.Gin{Ctx: c}
	addReq := accountdto.NewSingleAppIdReq(c)
	oauthConfigService := account.NewOauthConfigService(c)
	err := oauthConfigService.AddAppId(addReq)
	if err != nil {
		r.Response(myerror.AccountOauthConfigInsertError.Code, myerror.AccountOauthConfigInsertError.Message+"。"+err.Error(), nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

func EditAppID(c *gin.Context) {
	r := response.Gin{Ctx: c}
	editReq := accountdto.NewSingleAppIdReq(c)
	oauthConfigService := account.NewOauthConfigService(c)
	err := oauthConfigService.EditAppId(editReq)
	if err != nil {
		r.Response(myerror.AccountOauthConfigUpdateError.Code, myerror.AccountOauthConfigUpdateError.Message+"。"+err.Error(), nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}
