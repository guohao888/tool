package accounts

import (
	"context"
	"errors"
	"fmt"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/library/playlet"
	"goserver/app/model/dao"
	"strings"

	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
)

type OauthAccountDao struct {
	Ctx context.Context
}

func NewOauthAccountDao(ctx context.Context) *OauthAccountDao {
	return &OauthAccountDao{Ctx: ctx}
}

func (d *OauthAccountDao) InsertBatchSize(media string, oauthId string, userId string, data []playlet.AdvertiserInfo, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsert(tx, media, oauthId, userId, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		// 如果出现错误，回滚事务
		tx.Rollback()
		return err
	}

	tx.Commit()

	return nil
}

func (d *OauthAccountDao) batchInsert(tx *gorm.DB, media string, oauthId string, userId string, data []playlet.AdvertiserInfo) error {

	insertColumns := []string{"media", "advertiser_id", "advertiser_name", "oauth_id", "user_id"}
	sqlStr := fmt.Sprintf("INSERT INTO "+accountrepo.OauthAccountTableName()+" (%s) VALUES ", strings.Join(insertColumns, ","))
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?),"
		vals = append(vals,
			media,
			v.AdvertiserId,
			v.AdvertiserName,
			oauthId,
			userId,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func (d *OauthAccountDao) FindAccountByAds(ids []string) ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.OauthAccountTableName())
	var list []accountrepo.OauthAccountEntity
	err := q.Where("advertiser_id in (?) ", ids).Find(&list).Error
	if err != nil && errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}
	return list, err
}

func (d *OauthAccountDao) FindAccessTokenByAdvertiserIDs(advIDs []string) (map[string]accountrepo.AdvAndTokenInfo, error) {
	db := dorisdb.DorisClient()
	var results []accountrepo.AdvAndTokenInfo

	sql := fmt.Sprintf(`
		SELECT 
			oa.advertiser_id,
			oa.advertiser_name,
			o.access_token,
			o.expire_at
		FROM %s oa
		LEFT JOIN %s o ON oa.oauth_id = o.oauth_id
		WHERE oa.advertiser_id IN (?)
	`, accountrepo.OauthAccountTableName(), accountrepo.OauthTableName())

	err := db.Raw(sql, advIDs).Scan(&results).Error
	if err != nil {
		return nil, err
	}

	resp := make(map[string]accountrepo.AdvAndTokenInfo)
	if len(results) > 0 {
		for _, v := range results {
			resp[v.AdvertiserID] = v
		}
	}
	return resp, nil
}

func (d *OauthAccountDao) FindAccountByConfig() ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var list []accountrepo.OauthAccountEntity
	sql := ""
	err := db.Raw(sql).Scan(&list).Error
	return list, err
}
