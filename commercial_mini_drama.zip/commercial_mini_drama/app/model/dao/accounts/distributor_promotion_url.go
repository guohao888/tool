package accounts

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	accountdto "goserver/app/common/dto/accounts"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

type DistributorPromotionUrlDao struct {
	Ctx context.Context
}

func NewDistributorPromotionUrlDao(ctx context.Context) *DistributorPromotionUrlDao {
	return &DistributorPromotionUrlDao{Ctx: ctx}
}

func (d *DistributorPromotionUrlDao) InsertBatchSize(data []accountrepo.DistributorPromotionUrlEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsert(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		// 如果出现错误，回滚事务
		tx.Rollback()
		return err
	}

	tx.Commit()

	return nil
}

func (d *DistributorPromotionUrlDao) batchInsert(tx *gorm.DB, data []accountrepo.DistributorPromotionUrlEntity) error {
	insertColumns := []string{"distributor", "app_id", "optimizer_id", "promotion_url", "promotion_id", "promotion_name", "optimizer_name", "app_name", "api_id", "app_type", "distributor_id", "profit_model", "media_source", "book_id", "book_name", "create_time", "ad_callback_config_id"}
	sqlStr := fmt.Sprintf("INSERT INTO "+accountrepo.DistributorPromotionUrlTableName()+" (%s) VALUES ", strings.Join(insertColumns, ","))
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.Distributor,
			v.AppId,
			v.OptimizerId,
			v.PromotionUrl,
			v.PromotionId,
			v.PromotionName,
			v.OptimizerName,
			v.AppName,
			v.ApiId,
			v.AppType,
			v.DistributorId,
			v.ProfitModel,
			v.MediaSource,
			v.BookId,
			v.BookName,
			v.CreateTime,
			v.AdCallBackConfigId,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func (d *DistributorPromotionUrlDao) MergeQuery(params accountdto.PromotionUrlMergeExecutorParams) *gorm.SqlExpr {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.DistributorPromotionUrlTableName())

	if startTime := params.GetStartTime(); startTime != "" {
		q = q.Where("updated_at >= ?", startTime)
	}

	return q.QueryExpr()
}
