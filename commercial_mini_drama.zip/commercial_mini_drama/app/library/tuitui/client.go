package tuitui

import (
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
)

const SendNotificationMsgUrl = "https://im.live.360.cn:8282/minimanage/app/sendbotmsg"
const GetAccessTokenUrl = "https://im.live.360.cn:8282/minimanage/applogin"
const GetFieldUrl = "https://im.live.360.cn:8282/minimanage/app/upload"

type Client interface {
	GetAccessToken(refresh bool) (string, error)
	SendNotificationMsg(req *NotificationReq) (*NotificationRes, error)
	DoUpload(req *UploadReq) (res *UploadRes, err error)
}

type client struct {
	Ctx *gin.Context

	appId  string
	appKey string
	iss    string
}

func newClient(c *gin.Context, appId string, appKey string, iss string) *client {
	cli := &client{
		Ctx:    c,
		appId:  appId,
		appKey: appKey,
		iss:    iss,
	}

	return cli
}

func NewClient(c *gin.Context, appId string, appKey string, iss string) Client {
	return newClient(c, appId, appKey, iss)
}

func GetTuituiClient(c *gin.Context) Client {
	appId := viper.GetString("miniapp.get_access_token.app_id")
	appKey := viper.GetString("miniapp.get_access_token.app_key")
	iss := viper.GetString("miniapp.get_access_token.iss")

	return newClient(c, appId, appKey, iss)
}
