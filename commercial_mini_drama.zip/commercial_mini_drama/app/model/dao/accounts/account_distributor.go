package accounts

import (
	"context"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	accountsDto "goserver/app/common/dto/accounts"
	"goserver/app/common/dto/page"
	"goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"strings"
)

type AccountDistributorDao struct {
	Ctx context.Context
}

const (
	SelectColumnOptimizerName  = "optimizer_name"
	SelectColumnAdvertiserName = "advertiser_name"
	SelectColumnAdvertiserId   = "advertiser_id"
	SelectColumnAppName        = "app_name"
	SelectColumnMedia          = "media"
	SelectColumnBookName       = "book_name"
)

const (
	StatusAll       = -1
	StatusOpen      = 0 // 正常
	StatusClose     = 1 // 停用
	StatusAllName   = "全部"
	StatusOpenName  = "开启" // 正常
	StatusCloseName = "关停" // 停用
)

const (
	ExportTypeAccount   = "account"   // 账户列表
	ExportTypePromotion = "promotion" // 推广连接列表
)

var SelectColumnError = errors.New("select column not allow")

var SelectAllowColumn = map[string]struct{}{
	SelectColumnMedia:          {},
	SelectColumnAppName:        {},
	SelectColumnAdvertiserId:   {},
	SelectColumnAdvertiserName: {},
	SelectColumnOptimizerName:  {},
}

// LikeSelectAllowColumn 模糊搜索支持字段
var LikeSelectAllowColumn = map[string]struct{}{
	SelectColumnAdvertiserId:   {},
	SelectColumnAdvertiserName: {},
	SelectColumnBookName:       {},
}

func NewAccountDistributorDao(ctx context.Context) *AccountDistributorDao {
	return &AccountDistributorDao{Ctx: ctx}
}

func (d *AccountDistributorDao) DistinctList(column string) (res []string, err error) {
	if _, ok := SelectAllowColumn[column]; !ok {
		return nil, SelectColumnError
	}

	table := accounts.AccountDistributorTableName()
	db := dorisdb.DorisClient()
	err = db.Table(table).Where(fmt.Sprintf("%s != ''", column)).
		Order(fmt.Sprintf("%s asc", column)).
		Pluck(fmt.Sprintf("distinct(%s)", column), &res).Error
	return
}

func (d *AccountDistributorDao) DistinctLikeSearchList(column string, search string) (res []string, err error) {
	if _, ok := LikeSelectAllowColumn[column]; !ok {
		return nil, SelectColumnError
	}

	table := accounts.AccountDistributorTableName()
	db := dorisdb.DorisClient()
	err = db.Table(table).Where(fmt.Sprintf("%s != ''", column)).
		Where(fmt.Sprintf("%s like ?", column), "%"+search+"%").
		Order(fmt.Sprintf("%s asc", column)).
		Pluck(fmt.Sprintf("distinct(%s)", column), &res).Error
	return
}

func (d *AccountDistributorDao) Insert(infoList []*accounts.AccountDistributorEntity) error {
	if infoList == nil {
		return errors.New("info is nil")
	}
	table := accounts.AccountDistributorTableName()
	db := dorisdb.DorisClient()

	sqlStr := fmt.Sprintf("INSERT INTO %s (%s) VALUES ", table, strings.Join(accounts.AccountDistributorColumns(), ","))
	var vals []interface{}
	for _, v := range infoList {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.Module,
			v.Media,
			v.Distributor,
			v.AdvertiserId,
			v.OptimizerId,
			v.AppName,
			v.BookId,
			v.BookName,
			v.Region,
			v.OptimizerName,
			v.AdvertiserName,
			v.ApuCreateTime,
			v.DpuCreateTime,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := db.Exec(sqlStr, vals...).Error
	return err
}

func (d *AccountDistributorDao) GetDataList(params *accountsDto.DataListParams) (*page.Paginator, error) {
	db := dorisdb.DorisClient()
	table := accounts.AccountDistributorTableName()
	if params.ListType == ExportTypePromotion {
		table = accounts.AccountDistributorPromotionUrlTableName()
	}
	q := db.Table(table)  // 分页
	q2 := db.Table(table) // 总数
	// 刷选条件 (where)
	filter := params.Filter
	commonFilter := NewAccountCommonFilterDao(d.Ctx)
	queryFunc, e := commonFilter.CommonFilterQueryFunc(filter)
	if e != nil {
		return nil, e
	}
	q = queryFunc(q, nil)
	q2 = queryFunc(q2, nil)
	// 总数量
	var total int64
	err := q2.Count(&total).Error
	if err != nil {
		return nil, err
	}
	// 分页
	pagination := params.Pagination
	q = q.Select(fmt.Sprintf("%s.*, IF(s.s_advertiser_id IS NOT NULL, 1, 0) as status", table)).
		Order("apu_create_time desc").
		Offset(pagination.GetOffset()).Limit(pagination.GetLimit())
	// 分页数据
	var res []accounts.AccountDistributorEntity
	err = q.Find(&res).Error
	if err != nil {
		return nil, err
	}
	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)
	return &paginator, nil
}

func (d *AccountDistributorDao) GetDataById(advertiserIdSlice []string) ([]accounts.AccountDistributorEntity, error) {
	var res []accounts.AccountDistributorEntity
	db := dorisdb.DorisClient()
	table := accounts.AccountDistributorTableName()
	q := db.Table(table).Where("advertiser_id in (?)", advertiserIdSlice).Select("advertiser_id, media")
	err := q.Find(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return res, nil
}

func (d *AccountDistributorDao) GroupInsert(params accountsDto.PromotionUrlMergeExecutorParams) error {
	db := dorisdb.DorisClient()

	q := db.Table(accounts.AccountDistributorPromotionUrlTableName())
	if startTime := params.GetStartTime(); startTime != "" {
		q = q.Where("updated_at >= ?", startTime)
	}
	columns := []string{
		"module",
		"media",
		"distributor",
		"advertiser_id",
		"app_name",
		"optimizer_id",
		"book_id",
		"book_name",
		"region",
		"optimizer_name",
		"advertiser_name",
		"apu_create_time",
		"dpu_create_time",
	}

	partitionColumns := []string{
		"module",
		"media",
		"distributor",
		"advertiser_id",
		"app_name",
	}
	selectColumns := append(columns, fmt.Sprintf("ROW_NUMBER() OVER (PARTITION BY %s ORDER BY apu_create_time DESC) AS rn", strings.Join(partitionColumns, ",")))
	selectQuery := q.Select(strings.Join(selectColumns, ",")).QueryExpr()

	insertSql := fmt.Sprintf("INSERT INTO %s(%s) SELECT %s FROM (?) AS t1 WHERE t1.rn = 1",
		accounts.AccountDistributorTableName(),
		strings.Join(columns, ","),
		strings.Join(columns, ","),
	)
	err := db.Exec(insertSql, selectQuery).Error

	return err
}
