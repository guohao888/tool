package fanqie

import (
	"goserver/app/common/repository"
)

const distributorCallbackConfig = "distributor_callback_config"

type CallbackConfigEntity struct {
	ConfigId   int64  `gorm:"column:config_id"`   // 广告回传配置id，0代表平台默认规则
	ConfigName string `gorm:"column:config_name"` // 配置名称
}

func (*CallbackConfigEntity) TableName() string {
	return distributorCallbackConfig
}

func CallbackConfigEntityTableName() string {
	if repository.IsDebugTable(distributorCallbackConfig) {
		return distributorCallbackConfig + "_dev"
	} else {
		return distributorCallbackConfig
	}
}
