package accounts

import (
	"encoding/json"
	"errors"
	"goserver/app/common/repository"
	"strconv"
	"time"
)

const OauthEntityTable = "oauth"

var MediaMatchError = errors.New("platform no match")

// OauthEntity 平台oauth授权表
type OauthEntity struct {
	Media             string    `gorm:"column:media"`               // 授权媒体
	OauthId           string    `gorm:"column:oauth_id"`            // 授权唯一标识
	AccessToken       string    `gorm:"column:access_token"`        // access token
	RefreshToken      string    `gorm:"column:refresh_token"`       // refresh token
	ExpireAt          time.Time `gorm:"column:expire_at"`           // access token 到期时间
	RefreshExpireAt   time.Time `gorm:"column:refresh_expire_at"`   // refresh token 到期时间
	ExpireTime        int64     `gorm:"column:expire_time"`         // access token 有效时长
	RefreshExpireTime int64     `gorm:"column:refresh_expire_time"` // refresh token 有效时长
	AppId             string    `gorm:"column:app_id"`              // app id
	UserId            string    `gorm:"column:user_id"`             // 管家账户ID
	AppSecret         string    `gorm:"column:app_secret"`          // app secret
	Ext               string    `gorm:"column:ext"`                 // 扩展数据，根据平台存储所需数据
	CreatedAt         time.Time `gorm:"column:created_at"`          // 创建时间
	UpdatedAt         time.Time `gorm:"column:updated_at"`          // 更新时间
}

func (*OauthEntity) TableName() string {
	return OauthTableName()
}

func OauthTableName() string {
	if repository.IsDebugTable(OauthEntityTable) {
		return OauthEntityTable // + "_dev"
	} else {
		return OauthEntityTable
	}
}

type CommonExt struct {
	UserId   int64  `json:"user_id"`   // 授权管家账户id
	UserName string `json:"user_name"` // 授权管家账户名称
}

func (e *OauthEntity) GetCommonExt() (*CommonExt, error) {
	var ext CommonExt
	err := json.Unmarshal([]byte(e.Ext), &ext)
	if err != nil {
		return nil, err
	}
	return &ext, err
}

type ToutiaoExt struct {
	CommonExt
}

func (e *OauthEntity) UserIdInt64() (int64, error) {
	i, err := strconv.ParseInt(e.UserId, 10, 64)
	return i, err
}

func (e *OauthEntity) GetToutiaoExt() (*ToutiaoExt, error) {
	if e.Media != repository.MediaToutiao {
		return nil, MediaMatchError
	}

	var ext ToutiaoExt
	err := json.Unmarshal([]byte(e.Ext), &ext)
	if err != nil {
		return nil, err
	}
	return &ext, err
}

type KuaishouExt struct {
	CommonExt
}

func (e *OauthEntity) GetKuaishouExt() (*KuaishouExt, error) {
	if e.Media != repository.MediaKuaishou {
		return nil, MediaMatchError
	}

	var ext KuaishouExt
	err := json.Unmarshal([]byte(e.Ext), &ext)
	if err != nil {
		return nil, err
	}
	return &ext, err
}

type CallbackKuaishouState struct {
	AppId json.Number `json:"app_id"`
}
