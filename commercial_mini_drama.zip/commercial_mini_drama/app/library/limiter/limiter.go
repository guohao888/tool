package limiter

import (
	"context"
	"golang.org/x/time/rate"
	repo "goserver/app/common/repository"
	accountdao "goserver/app/model/dao/accounts"
	"sync"
)

const (
	CUSTOM = "custom" // 自定义报表
	BILL   = "bill"   // 账单
	VIDEO  = "video"  // 视频
	REJECT = "reject" // 拒审
)

// 全局限流管理器实例
var globalLimiterManager *ManagerLimiter

// ManagerLimiter 管理所有应用和接口的限流器
type ManagerLimiter struct {
	mu       sync.RWMutex
	limiters map[string]map[string]*rate.Limiter // 外层map键为appID，内层map键为interfaceName
}

type InterfaceConfig struct {
	Rate  rate.Limit
	Burst int
}

// 定义接口配置
var interfaceConfigs = map[string]InterfaceConfig{
	"custom": {450, 500},
	"bill":   {45, 50},
	"video":  {45, 50},
	"reject": {45, 50},
}

// InitGlobalLimit 创建新的ManagerLimiter实例
func InitGlobalLimit() error {
	// 查询出所有appId
	oauthDao := accountdao.NewOauthDao(context.Background())
	appIds, err := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if err != nil {
		panic(err.Error())
	}

	lm := &ManagerLimiter{
		limiters: make(map[string]map[string]*rate.Limiter),
	}

	// 获取写锁以创建新的限流器 防止动态加载配置引发panic
	lm.mu.Lock()
	defer lm.mu.Unlock()

	for _, appId := range appIds {
		// 检查是否已存在
		if _, ok := lm.limiters[appId]; !ok {
			lm.limiters[appId] = make(map[string]*rate.Limiter)
			for interfaceName, config := range interfaceConfigs {
				limiter := rate.NewLimiter(config.Rate, config.Burst)
				lm.limiters[appId][interfaceName] = limiter
			}
		}
	}
	globalLimiterManager = lm
	return nil
}

// GetLimiter 获取或创建指定应用和接口的限流器
func (lm *ManagerLimiter) GetLimiter(appID, interfaceName string) *rate.Limiter {
	// 先尝试读锁定，检查是否已存在
	lm.mu.RLock()
	if appLimits, ok := lm.limiters[appID]; ok {
		if limiter, ok := appLimits[interfaceName]; ok {
			lm.mu.RUnlock()
			return limiter
		}
	}
	lm.mu.RUnlock()

	// 获取写锁以创建新的限流器
	lm.mu.Lock()
	defer lm.mu.Unlock()

	// 初始化 appID 的所有接口（确保完整性）
	if _, ok := lm.limiters[appID]; !ok {
		lm.limiters[appID] = make(map[string]*rate.Limiter)
		for name, config := range interfaceConfigs {
			lm.limiters[appID][name] = rate.NewLimiter(config.Rate, config.Burst)
		}
	}

	// 若请求的接口未注册，使用默认配置
	if _, ok := lm.limiters[appID][interfaceName]; !ok {
		config := InterfaceConfig{45, 50} // 默认配置
		if cfg, ok := interfaceConfigs[interfaceName]; ok {
			config = cfg
		}
		lm.limiters[appID][interfaceName] = rate.NewLimiter(config.Rate, config.Burst)
	}
	return lm.limiters[appID][interfaceName]
}

func ManagerLimiterClient() *ManagerLimiter {
	return globalLimiterManager
}
