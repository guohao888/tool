package middleware

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common"
)

func RequestMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		common.GetRequest(c)
	}
}
