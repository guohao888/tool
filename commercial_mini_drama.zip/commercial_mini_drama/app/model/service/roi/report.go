package roi

import (
	"context"
	"encoding/json"
	"fmt"
	"goserver/app/common"
	"goserver/app/common/dto/roidto"
	repo "goserver/app/common/repository/roi"
	dao "goserver/app/model/dao/roi"
	"strconv"
	"strings"
	"time"

	"github.com/shopspring/decimal"
)

var userIDSlice = []string{
	"3555158764303067", "4276435909881498", "2953759842637195", "1039482055045739", "1707985131813675", "19130664097418", "2798701795608554", "699728516351343",
	"2992216187613658", "89505498669882", "4241263196376859", "3766274174494090", "212653320443738", "406168770189385", "1338557119342393", "4065321896381578",
	"3502392103930347", "3766274897498922", "4030157691840171", "4294040481965643", "2270939087644761", "4452371938152186", "1637598082118985", "3168144364152041",
	"3009814784381387", "3907016290997882", "2077428943174697", "1971875831618075", "4258860018174089", "3537580391138793", "3959793180482121", "1514479321376841",
	"3484804158858955", "2112613648968587", "2577701849545534", "2552418998435674", "1813547186389754", "4311637645067770", "335803602962313", "828385801282698",
	"4276454280136507", "54329645730379", "3467213724453994", "3097777832988793", "300620252724105", "2622788811622699", "2059838869737321", "3783873103684105",
	"3361660639120025", "4452376175184298", "1620034225724378", "4206085573975850", "3379252831466299", "353397471978345", "3467214424656587", "71922524357371",
	"3168147276826698", "670056867180409", "2429275472946571", "4329204695959289", "142293315910699", "652466715901801", "265436592616235", "494135015907401",
	"3871834748238953", "36738195786074", "2781121699389242", "2112618568352330", "3713507561055114", "4030166912998361", "1954288903655947",
}

type ReportService struct {
	Ctx context.Context
	// 聚合维度是否包含promotion_id true包含 false 不包含
	ProGroup bool
}

type ProductTodayReportData struct {
	Date              string  `json:"column:date"`
	Hour              string  `json:"column:hour"`
	DayCost           float64 `json:"column:day_cost"`
	DayRoi            float64 `json:"column:day_roi"`
	HourCost          float64 `json:"column:hour_cost"`
	HourRoi           float64 `json:"column:hour_roi"`
	HourDiffOfLast    string  `json:"column:hour_diff_of_last"`     // 消耗环比
	HourDiffRoiOfLast string  `json:"column:hour_diff_roi_of_last"` // roi 环比

}

//{"日期", "时间", "累计消耗", "今日ROI", "分时消耗", "分时ROI", "消耗环比(对比上一个小时)", "ROI环比(环比上一个小时)"}

type ProductTodayReportDataVO struct {
	Date      string  `json:"column:date"`
	Hour      string  `json:"column:hour"`
	DayCost   float64 `json:"column:day_cost"`
	DayRoi    string  `json:"column:day_roi"`
	HourCost  string  `json:"column:hour_cost"`
	HourRoi   string  `json:"column:hour_roi"`
	CostRatio string  `json:"column:hour_diff_of_last"`     // 消耗环比
	RoiRatio  string  `json:"column:hour_diff_roi_of_last"` // roi 环比

}

type AccountDataInfo struct {
	Date           string
	Cost           float64
	Roi            string
	Income         float64
	AccountID      string
	AccountName    string
	UserID         string
	UserName       string
	TodayIncome    string
	ThreeDayIncome string
	ThreeIncomeRoi string
	TodayIncomeRoi string
	IncomeRoi24    string
	ProFit         string // 利润
}

type AccountNum struct {
	Hour   int
	Roi    string
	Income float64
	Cost   float64
}

// 剧目统计
type ProductBookData struct {
	BookName       string  `json:"book_name"` // 剧目名称
	BookID         int64   `json:"book_id"`   // 剧目ID
	HourCost       float64 `json:"hour_cost"` // 当前小时消耗
	HourRoi        float64 `json:"hour_roi"`  // 当前小时消耗
	DayCost        float64 `json:"day_cost"`  // 今日消耗
	DayRoi         float64 `json:"day_roi"`   // 今日ROI
	HourDiffOfLast string  `json:"hour_diff_of_last,omitempty"`
}

type ProductBookDataVO struct {
	BookName       string  `json:"book_name"`
	BookID         int64   `json:"book_id"`
	HourCost       float64 `json:"hour_cost"`
	HourRoi        float64 `json:"hour_roi"`
	DayCost        string  `json:"day_cost"`
	DayRoi         string  `json:"day_roi"`
	CostRadio      string  `json:"cost_radio"`                  //消耗环比
	RoiRadio       string  `json:"roi_radio"`                   // roi 环比
	HourDiffOfLast string  `json:"hour_diff_of_last,omitempty"` // 时速消耗差
}

type ProductRegionData struct {
	Region   string  `json:"book_name"` // 地区名称
	HourCost float64 `json:"hour_cost"` // 当前小时消耗
	HourRoi  float64 `json:"hour_roi"`  // 当前小时roi
	DayCost  float64 `json:"day_cost"`  // 今日消耗
	DayRoi   float64 `json:"day_roi"`   // 今日ROI
}

type ProductRegionDataVO struct {
	Region       string  `json:"book_name"`  // 地区名称
	HourCost     float64 `json:"hour_cost"`  // 当前小时消耗
	HourRoi      string  `json:"hour_roi"`   // 当前小时ROI
	DayCost      string  `json:"day_cost"`   // 今日消耗
	DayRoi       string  `json:"day_roi"`    // 今日ROI
	CostRadio    string  `json:"cost_radio"` //消耗环比
	RoiRadio     string  `json:"roi_radio"`  // roi 环比
	DayCostFloat float64 // 用来做排序的冗余字段
}
type OptimizeData struct {
	OptimizeID   int64     `json:"optimize_id"`   // 投手ID
	OptimizeName string    `json:"optimize_name"` // 投手昵称
	Date         time.Time `json:"date"`          // 日期
	HourRoi      float64   `json:"hour_roi"`      // 当前小时roi
	HourCost     float64   `json:"hour_cost"`     // 当前小时消耗
	DayCost      float64   `json:"day_cost"`      // 今日消耗
	DayRoi       float64   `json:"day_roi"`       // 今日ROI
}

// {"投手", "日期", "今日累计消耗", "今日ROI", "今日累计消耗环比",
// "今日ROI环比", "商品库消耗", "商品库ROI", "商品库消耗环比", "商品库ROI环比"}
type OptimizeDataVo struct {
	OptimizeName    string  `json:"optimize_name"`     // 投手昵称
	Date            string  `json:"date"`              // 日期
	DayCost         string  `json:"day_cost"`          // 今日累计消耗
	DayRoi          string  `json:"day_roi"`           // 今日ROI
	CostRadio       string  `json:"cost_radio"`        //今日累计消耗环比
	RoiRadio        string  `json:"roi_radio"`         // 今日roi 环比(环比上个小时)
	DayProductCost  string  `json:"day_product_cost"`  // 今日商品库消耗
	DayProductRoi   string  `json:"day_product_roi"`   // 今日商品库ROI
	ProductRadio    string  `json:"product_radio"`     // 商品库消耗环比
	ProductRoiRadio string  `json:"product_roi_radio"` // 商品库ROI环比
	DayCostFloat    float64 // 用来做排序的冗余字段

}

type UserInfo struct {
	UserID   int64  `json:"user_id"`
	UserName string `json:"user_name"`
}

func NewReportService(ctx context.Context, proGroup bool) *ReportService {
	return &ReportService{Ctx: ctx, ProGroup: proGroup}
}

func (s *ReportService) GetLastExecTime() string {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	lastTime, err := reportDataDao.GetLastExecTime()
	if err != nil {
		return ""
	}
	return lastTime.Format(time.DateTime)
}

func (s *ReportService) ProjectGetLastExecTime() string {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	lastTime, err := reportDataDao.GetProjectLastExecTime()
	if err != nil {
		return ""
	}
	return lastTime.Format(time.DateTime)
}

func (s *ReportService) BoardTopData() (result roidto.BoardTopData) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	lastTime, err := reportDataDao.GetProjectLastExecTime()
	if err != nil {
		return result
	}

	result.CountTime = lastTime.Format(time.DateTime)
	result.StartHour = 0
	result.EndHour = lastTime.Hour()
	return
}

func (s *ReportService) TodayMarketData(params *roidto.TodayMarketDataReq) (data roidto.TodayMarketDataResp, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)

	result, err := reportDataDao.TodayMarketData(params)
	if err != nil {
		return
	}

	if !result.Cost.IsZero() {
		percentage, _ := decimal.NewFromString("100")

		data.Cost = result.Cost.Round(2).String()
		data.Roi = result.Income.Div(result.Cost).Mul(percentage).Round(2).String()
		roi := result.Income.Div(result.Cost)
		if !result.CostHb.IsZero() {
			data.CostHbRate = (result.Cost.Sub(result.CostHb)).Div(result.CostHb).Mul(percentage).Round(2).String()
			roiHb := result.IncomeHb.Div(result.CostHb)
			data.RoiHbRate = (roi.Sub(roiHb)).Div(roiHb).Mul(percentage).Round(2).String()
		}

		if !result.CostTb.IsZero() {
			data.CostTbRate = (result.Cost.Sub(result.CostTb)).Div(result.CostTb).Mul(percentage).Round(2).String()
			roiTb := result.IncomeTb.Div(result.CostTb)
			data.RoiTbRate = (roi.Sub(roiTb)).Div(roiTb).Mul(percentage).Round(2).String()
		}
		/*if !result.CostHbSame.IsZero() {
			data.CostHbSameRate = (result.Cost.Sub(result.CostHbSame)).Div(result.CostHbSame).Mul(percentage).Round(2).String()
			roiHb := result.IncomeHb.Div(result.CostHbSame)
			data.RoiHbSameRate = (roi.Sub(roiHb)).Div(roiHb).Mul(percentage).Round(2).String()
		}*/
	}

	return data, err
}

func (s *ReportService) TodayTimeData(params *roidto.TodayTodayTimeDataReq) (data []roidto.TodayTimeDataResp, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	// 汇总数据
	resultInfo, err := reportDataDao.TodayTotalData(params)
	if err != nil {
		return
	}
	percentage100, _ := decimal.NewFromString("100")
	percentage1000, _ := decimal.NewFromString("1000")

	data = append(data, roidto.TodayTimeDataResp{
		Index:    -1,
		Hour:     "汇总",
		Cost:     resultInfo.Cost.Round(2),
		Profit:   resultInfo.Profit.Round(2),
		Roi:      resultInfo.Roi.Mul(percentage100).Round(2),
		ShowCost: resultInfo.ShowCost.Mul(percentage1000).Round(2),
	})

	// 分时数据
	result, err := reportDataDao.TodayTimeData(params)
	if err != nil {
		return
	}

	for _, item := range result {
		data = append(data, roidto.TodayTimeDataResp{
			Index:    item.Hour,
			Hour:     fmt.Sprintf("%d-%d时", item.Hour, item.Hour+1),
			Cost:     item.Cost.Round(2),
			Profit:   item.Profit.Round(2),
			Roi:      item.Roi.Mul(percentage100).Round(2),
			ShowCost: item.ShowCost.Mul(percentage1000).Round(2),
		})
	}
	return data, err
}

func (s *ReportService) TodayBookRankingData(params *roidto.TodayBookRankingDataReq) (data []roidto.TodayBookRankingDataResp, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)

	result, err := reportDataDao.TodayBookRankingData(params)

	if err != nil {
		return
	}

	percentage, _ := decimal.NewFromString("100")
	for i, item := range result {
		data = append(data, roidto.TodayBookRankingDataResp{
			Rank:      i + 1,
			BookId:    item.BookId,
			BookName:  item.BookName,
			TotalCost: item.TotalCost.Round(2),
			Cost:      item.Cost.Round(2),
			Profit:    item.Profit.Round(2),
			Roi:       item.Roi.Mul(percentage).Round(2),
		})
	}
	return data, err
}

func (s *ReportService) TodayRegionRankingData(params *roidto.TodayRegionRankingReq) (data []roidto.TodayRegionRankingDataResp, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)

	result, err := reportDataDao.TodayRegionRankingData(params)

	if err != nil {
		return
	}

	percentage, _ := decimal.NewFromString("100")
	for i, item := range result {
		data = append(data, roidto.TodayRegionRankingDataResp{
			Rank:      i + 1,
			Region:    item.Region,
			TotalCost: item.TotalCost.Round(2),
			Cost:      item.Cost.Round(2),
			Profit:    item.Profit.Round(2),
			Roi:       item.Roi.Mul(percentage).Round(2),
		})
	}
	return data, err
}

func (s *ReportService) ReportParams() (params *roidto.Params, err error) {
	params = &roidto.Params{}
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	//时间周期
	params.GroupType = []roidto.IDLabel{}
	for _, row := range roidto.GroupTypeArr {
		params.GroupType = append(params.GroupType, row)
	}
	//媒体
	params.Media = roidto.SelectOption{Name: "投放载体", Value: make([]roidto.IDLabel, 0)}
	var IDLabels []roidto.IDLabel
	IDLabels, err = reportDataDao.MediaAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.Media.Value = append(params.Media.Value, row)
	}
	//地区
	params.Region = roidto.SelectOption{Name: "地区", Value: make([]roidto.IDLabel, 0)}
	IDLabels, err = reportDataDao.RegionAry()
	if err != nil {
		return nil, err
	}
	params.Region.Value = append(params.Region.Value, IDLabels...)
	//付费类型
	params.PayType = roidto.SelectOption{Name: "付费类型", Value: make([]roidto.IDLabel, 0)}
	for _, row := range roidto.PayTypeArr {
		params.PayType.Value = append(params.PayType.Value, row)
	}
	//应用包名
	params.AppName = roidto.SelectOption{Name: "应用包名", Value: make([]roidto.IDLabel, 0)}
	IDLabels, err = reportDataDao.AppAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.AppName.Value = append(params.AppName.Value, row)
	}
	// 账管信息
	params.UserID = roidto.SelectOption{Name: "账管", Value: make([]roidto.IDLabel, 0)}
	IDLabels, err = reportDataDao.ManagerAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.UserID.Value = append(params.UserID.Value, row)
	}

	//剧目名称
	params.BookName = roidto.SelectOption{Name: "剧目名称", Value: make([]roidto.IDLabel, 0)}
	IDLabels, err = reportDataDao.BookAry("", 100)
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.BookName.Value = append(params.BookName.Value, row)
	}
	//投放人员
	params.OptimizerID = roidto.SelectOption{Name: "投放人员", Value: make([]roidto.IDLabel, 0)}
	IDLabels, err = reportDataDao.OptimizerAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.OptimizerID.Value = append(params.OptimizerID.Value, row)
	}
	//账户名称
	params.AccountID = roidto.SelectOption{Name: "账户名称", Value: make([]roidto.IDLabel, 0)}
	IDLabels, err = reportDataDao.AccountAry("", 100)
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.AccountID.Value = append(params.AccountID.Value, row)
	}
	//推广产品
	params.DeliveryProduct = roidto.SelectOption{Name: "推广产品", Value: make([]roidto.IDLabel, 0)}
	for _, row := range roidto.DeliveryProductArr {
		params.DeliveryProduct.Value = append(params.DeliveryProduct.Value, row)
	}
	//版权方
	params.CopyRightOwner = roidto.SelectOption{Name: "版权方", Value: make([]roidto.IDLabel, 0)}
	IDLabels, err = reportDataDao.CopyRightAry()
	if err != nil {
		return nil, err
	}
	for _, row := range IDLabels {
		params.CopyRightOwner.Value = append(params.CopyRightOwner.Value, row)
	}
	//维度聚合
	params.GroupBy = roidto.SelectOption{Name: "维度聚合", Value: make([]roidto.IDLabel, 0)}
	for _, row := range roidto.GetGroupByArr(s.ProGroup) {
		params.GroupBy.Value = append(params.GroupBy.Value, row)
	}
	//指标筛选
	params.KpiFilter = []roidto.KpiOption{}
	for i, row := range roidto.GetKpiFilterArr(s.ProGroup) {
		if row.Label != "" {
			row.ID = i + 1
			params.KpiFilter = append(params.KpiFilter, row)
		}
	}
	return
}

func (s *ReportService) ReportOptionSearch(keywords, searchType string) (result []roidto.IDLabel, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	if searchType == "book" {
		result, err = reportDataDao.BookAry(keywords, 100)
	} else if searchType == "account" {
		result, err = reportDataDao.AccountAry(keywords, 100)
	}
	return
}

func (s *ReportService) ReportData(params *roidto.ReportDataReq) (*common.Paginator, error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	// 分页数据
	paginator, err := reportDataDao.ReportData(params)
	if err != nil {
		return nil, err
	}
	return paginator, err
}

func (s *ReportService) Export(params *roidto.ReportDataReq) (result *[]repo.ReportDataViewEntity, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	result, err = reportDataDao.ExportData(params)
	return
}

func (s *ReportService) ProjectReportData(params *roidto.ReportDataReq) (*common.Paginator, error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	// 分页数据
	paginator, err := reportDataDao.ProjectReportData(params)
	if err != nil {
		return nil, err
	}
	return paginator, err
}

func (s *ReportService) ProjectReportDataNew(params *roidto.ReportDataReq) (*common.Paginator, error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	// 分页数据
	paginator, err := reportDataDao.ProjectReportDataNew(params)
	if err != nil {
		return nil, err
	}
	return paginator, err
}

func (s *ReportService) ProjectExportNew(params *roidto.ReportDataReq) (result []repo.ProjectReportDataViewEntity, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	result, err = reportDataDao.ProjectExportDataNew(params)
	return
}

func (s *ReportService) ProjectExport(params *roidto.ReportDataReq) (result *[]repo.ProjectReportDataViewEntity, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	result, err = reportDataDao.ProjectExportData(params)
	return
}

func (s *ReportService) GetTuiTuiReportData() (result []ProductTodayReportDataVO, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	hourData, err := reportDataDao.FindReportData()
	if err != nil {
		return result, err
	}
	if len(hourData) == 0 {
		return result, nil
	}
	for _, row := range hourData {
		var hDate ProductTodayReportDataVO
		hDate.Hour = fmt.Sprintf("%d时", row.Hour)
		hDate.HourCost = fmt.Sprintf("%.2f", row.HourCost)
		hDate.HourRoi = fmt.Sprintf("%.2f%%", row.HourRoi)
		hDate.Date = row.Date.Format("01/02/2006")
		hDate.DayCost = row.DayCost
		hDate.DayRoi = fmt.Sprintf("%.2f%%", row.DayRoi)
		hDate.CostRatio = fmt.Sprintf("%.2f%%", row.CostRatio)
		hDate.RoiRatio = fmt.Sprintf("%.2f%%", row.RoiRatio)
		result = append(result, hDate)
	}
	return result, nil

}
func (s *ReportService) MediaOptionsAry() (result []string, err error) {
	filterOptionsDao := dao.NewFilterOptionsDao(s.Ctx)
	result, err = filterOptionsDao.OptionsAry(dao.ValueTypeMedia)
	return
}

func (s *ReportService) DeliveryProductOptionsAry() (result []string, err error) {
	filterOptionsDao := dao.NewFilterOptionsDao(s.Ctx)
	result, err = filterOptionsDao.OptionsAry(dao.ValueTypeDeliveryProduct)
	return
}

// 查询剧目数据
func (s *ReportService) GetBookData(typeInt int) (result []ProductBookData, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	bookData, err := reportDataDao.FindBookReportData(typeInt)
	if err != nil {
		return result, err
	}
	if len(bookData) == 0 {
		return result, nil
	}
	for _, val := range bookData {
		result = append(result, ProductBookData{
			BookID:   val.BookID,
			BookName: val.BookName,
			HourCost: val.HourCost,
			HourRoi:  val.HourRoi,
			DayRoi:   val.DayRoi,
			DayCost:  val.DayCost,
		})
	}

	return result, nil

}

// 根据地区统计
func (s *ReportService) GetProductByRegin(typeInt int) (result []ProductRegionData, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	bookData, err := reportDataDao.FindProductReginData(typeInt)
	if err != nil {
		return result, err
	}
	if len(bookData) == 0 {
		return result, nil
	}
	for _, val := range bookData {
		result = append(result, ProductRegionData{
			Region:   val.Region,
			HourCost: val.HourCost,
			HourRoi:  val.HourRoi,
			DayRoi:   val.DayRoi,
			DayCost:  val.DayCost,
		})
	}

	return result, nil

}

// 获取数据by投手
func (s *ReportService) GetDataByOptimize(typeInt int, isProduct bool) (result []OptimizeData, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	optimizeData, err := reportDataDao.FindOptimizeData(typeInt, isProduct)
	if err != nil {
		return result, err
	}
	if len(optimizeData) == 0 {
		return result, nil
	}
	for _, val := range optimizeData {
		result = append(result, OptimizeData{
			OptimizeID:   val.OptimizeID,
			OptimizeName: val.OptimizeName,
			Date:         val.Date,
			DayCost:      val.DayCost,
			DayRoi:       val.DayRoi,
			HourCost:     val.HourCost,
			HourRoi:      val.HourRoi,
		})
	}
	return result, nil
}

func (s *ReportService) GetAccountInfo(typeInt int) (result []AccountDataInfo, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	userIdsStrs := strings.Join(userIDSlice, ",")
	accountData, err := reportDataDao.FindAccountDataInfo(userIdsStrs, typeInt)
	if err != nil {
		return result, err
	}
	if len(accountData) == 0 {
		return result, nil
	}
	for _, row := range accountData {
		var acInfo AccountDataInfo
		acInfo.Date = row.SearchDate.Format(time.DateOnly)
		acInfo.AccountName = row.AccountName
		acInfo.AccountID = fmt.Sprintf("%d", row.AccountID)
		acInfo.Cost = row.Cost
		acInfo.Roi = fmt.Sprintf("%s%%", row.Roi)
		acInfo.Income = row.Income
		acInfo.TodayIncome = fmt.Sprintf("%0.2f", row.TodayIncome)
		acInfo.ThreeIncomeRoi = fmt.Sprintf("%0.2f%%", row.ThreeIncomeRoi*100)
		acInfo.TodayIncomeRoi = fmt.Sprintf("%0.2f%%", row.TodayIncomeRoi*100)
		acInfo.ThreeDayIncome = fmt.Sprintf("%0.2f", row.ThreeDayIncome)
		acInfo.IncomeRoi24 = fmt.Sprintf("%0.2f%%", row.IncomeRoi24*100)
		result = append(result, acInfo)
	}
	return result, nil

}

func (s *ReportService) GetAccountData() (result AccountNum, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	userIDsStr := strings.Join(userIDSlice, ",")
	accountData, err := reportDataDao.FindAccountCount(userIDsStr)
	if err != nil {
		return result, err
	}
	result.Hour = accountData.Hour
	result.Cost = accountData.Cost
	result.Roi = fmt.Sprintf("%s%%", accountData.Roi)
	result.Income = accountData.Income
	return result, nil

}

// 获取账管数据
func (s *ReportService) GetUserData(typeInt int) (result []AccountDataInfo, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	userIDsStr := strings.Join(userIDSlice, ",")
	accountData, err := reportDataDao.FindInfoData(userIDsStr, typeInt)
	if err != nil {
		return result, err
	}
	// 获取账管名称
	managerInfos, err := reportDataDao.GetAccountManage(userIDsStr)
	if err != nil {
		return result, err
	}
	if len(managerInfos) < 1 {
		return result, fmt.Errorf("没有获取到账管信息")
	}

	var managerMap = make(map[int64]UserInfo)
	for _, val := range managerInfos {
		var userInfo UserInfo
		_ = json.Unmarshal([]byte(val.Ext), &userInfo)

		managerMap[val.UserID] = userInfo
	}

	var hasUserMap = make(map[int64]bool)
	for _, val := range accountData {
		if _, ok := managerMap[val.UserID]; ok {
			val.UserName = managerMap[val.UserID].UserName
			hasUserMap[val.UserID] = true
		}

		result = append(result, AccountDataInfo{
			Date:           val.SearchDate.Format(time.DateOnly),
			Cost:           val.Cost,
			Income:         val.Income,
			Roi:            fmt.Sprintf("%s%%", val.Roi),
			UserID:         fmt.Sprintf("%d", val.UserID),
			UserName:       val.UserName,
			TodayIncome:    fmt.Sprintf("%.2f", val.TodayIncome),
			ThreeDayIncome: fmt.Sprintf("%.2f", val.ThreeDayIncome),
			ThreeIncomeRoi: fmt.Sprintf("%.2f%%", val.ThreeIncomeRoi*100),
			TodayIncomeRoi: fmt.Sprintf("%.2f%%", val.TodayIncomeRoi*100),
			IncomeRoi24:    fmt.Sprintf("%.2f%%", val.IncomeRoi24*100),
		})

	}

	if typeInt == dao.Yesterday {
		return result, nil
	}
	for _, val := range managerMap {
		if _, ok := hasUserMap[val.UserID]; !ok {
			result = append(result, AccountDataInfo{
				Date:           time.Now().Format(time.DateOnly),
				Cost:           0,
				Income:         0,
				Roi:            "0.00%",
				UserID:         fmt.Sprintf("%d", val.UserID),
				UserName:       val.UserName,
				TodayIncome:    "0",
				ThreeDayIncome: "0",
				ThreeIncomeRoi: "0.00%",
				TodayIncomeRoi: "0.00%",
				IncomeRoi24:    "0.00%",
			})
		}
	}

	return result, nil
}

// 获取账管的数据
func (s *ReportService) GetMangeData(typeInt int) (result []AccountDataInfo, err error) {
	reportDataDao := dao.NewReportDataDao(s.Ctx)
	accountData, err := reportDataDao.GetAccountManageToday(typeInt)
	if err != nil {
		return result, err
	}
	if len(accountData) == 0 {
		return result, nil
	}
	var userIds []string
	for _, val := range accountData {
		userIds = append(userIds, fmt.Sprintf("%d", val.UserID))

	}
	userIdsStrs := strings.Join(userIds, ",")
	// 获取账管名称
	managerInfos, err := reportDataDao.GetAccountManage(userIdsStrs)

	if err != nil {
		return result, err
	}
	if len(managerInfos) < 1 {
		return result, fmt.Errorf("没有获取到账管信息")
	}

	var managerMap = make(map[int64]UserInfo)
	for _, val := range managerInfos {
		var userInfo UserInfo
		_ = json.Unmarshal([]byte(val.Ext), &userInfo)

		managerMap[val.UserID] = userInfo
	}

	for _, val := range accountData {
		if _, ok := managerMap[val.UserID]; ok {
			val.UserName = managerMap[val.UserID].UserName
		}
		// 只需要账面消耗大于5000 且 账面roi低于0.85的端原生管家
		tempRoi, _ := strconv.ParseFloat(val.Roi, 64)
		if val.Cost > 5000 && tempRoi < 0.85 {
			result = append(result, AccountDataInfo{
				Cost:     val.Cost,   // 消耗
				Income:   val.Income, //收入
				Roi:      fmt.Sprintf("%s%%", val.Roi),
				UserID:   fmt.Sprintf("%d", val.UserID),
				UserName: val.UserName,
				ProFit:   fmt.Sprintf("%0.2f", val.ProFit),
			})
		}
	}
	return result, nil
}
