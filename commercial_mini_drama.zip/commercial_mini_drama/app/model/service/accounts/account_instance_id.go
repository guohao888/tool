package accounts

import (
	"context"
	"github.com/alitto/pond"
	"github.com/duke-git/lancet/v2/slice"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"golang.org/x/sync/errgroup"
	accountdto "goserver/app/common/dto/accounts"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
)

type AccountInstanceIdService struct {
	Ctx context.Context
}

func NewAccountInstanceIdService(ctx context.Context) *AccountInstanceIdService {
	return &AccountInstanceIdService{Ctx: ctx}
}

func (s *AccountInstanceIdService) SyncToutiao(params accountdto.AccountInstanceIdSyncExecutorParams) interface{} {
	oauthDao := accountdao.NewOauthDao(s.Ctx)
	oauthList, err := oauthDao.ListOauthByMediaAppIds(params.Media, params.AppIds)
	if err != nil {
		log.Errorf("[AccountPromotionUrlService.SyncToutiao] 根据媒体获取oauth授权列表错误, err: %s", err)
		return err
	}
	oauthMap := slice.KeyBy(oauthList, func(item accountrepo.OauthEntity) string {
		return item.OauthId
	})

	oauthActiveAccountDao := accountdao.NewOauthActiveAccountDao(s.Ctx)
	var activeAccountList []accountrepo.OauthActiveAccountEntity
	if params.Priority == accountrepo.PriorityHigh {
		// 高优先级
		activeAccountList, err = oauthActiveAccountDao.ListHighHasReportData(params.Media, params.AppIds, params.AdvertiserIds)
	} else if params.Priority == accountrepo.PriorityLow {
		// 低优先级
		activeAccountList, err = oauthActiveAccountDao.ListLowNoReportData(params.Media, params.AppIds, params.AdvertiserIds)
	} else {
		// 默认全量
		activeAccountList, err = oauthActiveAccountDao.ListByMediaAndAppIds(params.Media, params.AppIds, params.AdvertiserIds)
	}
	if err != nil {
		log.Errorf("[AccountPromotionUrlService.SyncToutiao] 根据媒体获取再投账户列表错误, err: %s", err)
		return err
	}

	m := make(map[string]accountrepo.OauthActiveAccountEntityList)
	for _, v := range activeAccountList {
		o, ok := oauthMap[v.OauthId]
		if !ok {
			continue
		}
		m[o.AppId] = append(m[o.AppId], v)
	}

	var eg errgroup.Group
	for _, v := range m {
		appIdActiveAccountList := v
		eg.Go(func() error {
			err := s.AppIdSyncToutiao(oauthMap, appIdActiveAccountList, params)
			if err != nil {
				log.Errorf("[AccountPromotionUrlService.SyncToutiao] 根据头条广告主字节小程序资产id错误, err: %s", err)
			}
			return err
		})
	}
	err = eg.Wait()
	if err != nil {
		log.Errorf("[AccountPromotionUrlService.SyncToutiao] 根据头条广告主字节小程序资产id错误, err: %s", err)
	}
	return err
}

func (s *AccountInstanceIdService) AppIdSyncToutiao(
	oauthMap map[string]accountrepo.OauthEntity,
	appIdActiveAccountList accountrepo.OauthActiveAccountEntityList,
	params accountdto.AccountInstanceIdSyncExecutorParams,
) error {
	resChan := make(chan accountrepo.AccountInstanceIdEntity)
	errChan := make(chan error)

	ctx := s.Ctx
	go func() {
		pool := pond.New(params.PoolWorkers, 1000)
		defer pool.StopAndWait()
		group, _ := pool.GroupContext(context.Background())

		for k, v := range appIdActiveAccountList {
			i := k
			activeAccount := v

			group.Submit(func() error {
				log.Infof("AccountInstanceIdService.SyncToutiao 开始执行, %d, %s, %s", i, activeAccount.OauthId, activeAccount.AdvertiserId)

				oauth, ok := oauthMap[activeAccount.OauthId]
				if !ok {
					log.Infof("AccountInstanceIdService.SyncToutiao 没有获取到对应的oauth信息, %s, %s", activeAccount.OauthId, activeAccount.AdvertiserId)
					return nil
				}

				advertiserId, err := activeAccount.GetAdvertiserId()
				if err != nil {
					return err
				}

				if params.SearchType == "" || params.SearchType == accountrepo.SearchTypeCreateOnly {
					searchTypeCreateOnly := accountrepo.SearchTypeCreateOnly
					microAppList1, err := toutiao.AllToolsMicroAppList(ctx, toutiao.AllToolsMicroAppListReq{
						AccessToken:  oauth.AccessToken,
						AdvertiserId: advertiserId,
						Filtering: func() *models.ToolsMicroAppListV30Filtering {
							filtering := &models.ToolsMicroAppListV30Filtering{
								SearchType: toolsMicroAppListV30FilteringSearchType(searchTypeCreateOnly),
							}
							return filtering
						}(),
					})
					if err != nil {
						log.Errorf("AccountInstanceIdService.SyncToutiao 获取字节小程序错误, searchType: %s, err: %s, %#v", searchTypeCreateOnly, err, activeAccount)
					}
					if len(microAppList1) > 0 {
						for _, vv := range microAppList1 {
							resChan <- accountrepo.AccountInstanceIdEntity{
								Media:        params.Media,
								AdvertiserId: activeAccount.AdvertiserId,
								InstanceId:   *vv.InstanceId,
								SearchType:   searchTypeCreateOnly,
								CreateTime:   *vv.CreateTime,
								ModifyTime:   *vv.ModifyTime,
							}
						}
					}
				}

				if params.SearchType == "" || params.SearchType == accountrepo.SearchTypeShareOnly {
					searchTypeShareOnly := accountrepo.SearchTypeShareOnly
					microAppList2, err := toutiao.AllToolsMicroAppList(ctx, toutiao.AllToolsMicroAppListReq{
						AccessToken:  oauth.AccessToken,
						AdvertiserId: advertiserId,
						Filtering: func() *models.ToolsMicroAppListV30Filtering {
							filtering := &models.ToolsMicroAppListV30Filtering{
								SearchType: toolsMicroAppListV30FilteringSearchType(searchTypeShareOnly),
							}
							return filtering
						}(),
					})
					if err != nil {
						log.Errorf("AccountInstanceIdService.SyncToutiao 获取字节小程序错误, searchType: %s, err: %s, %#v", searchTypeShareOnly, err, activeAccount)
					}
					if len(microAppList2) > 0 {
						for _, vv := range microAppList2 {
							resChan <- accountrepo.AccountInstanceIdEntity{
								Media:        params.Media,
								AdvertiserId: activeAccount.AdvertiserId,
								SearchType:   searchTypeShareOnly,
								InstanceId:   *vv.InstanceId,
								CreateTime:   *vv.CreateTime,
								ModifyTime:   *vv.ModifyTime,
							}
						}
					}
				}

				return nil
			})
		}

		e := group.Wait()
		if e != nil {
			errChan <- e
			close(errChan)
		}
		close(resChan)
	}()

	accountInstanceIdDao := accountdao.NewAccountInstanceIdDao(s.Ctx)

	batchSize := params.InsertBatchSize
	var data []accountrepo.AccountInstanceIdEntity
	for {
		var breakFlag bool

		select {
		case err, ok := <-errChan:
			if ok {
				return err
			}
		case res, ok := <-resChan:
			if ok {
				data = append(data, res)
				if len(data) >= batchSize {
					err := accountInstanceIdDao.InsertBatchSize(data, batchSize)
					if err != nil {
						log.Errorf("AccountInstanceIdService.AppIdSyncToutiao 数据插入失败, err: %s", err)
						return err
					}
					data = data[:0]
				}
			} else {
				breakFlag = true
			}
		}

		if breakFlag {
			break
		}
	}
	if len(data) > 0 {
		err := accountInstanceIdDao.InsertBatchSize(data, batchSize)
		if err != nil {
			log.Errorf("AccountInstanceIdService.AppIdSyncToutiao 数据插入失败, err: %s", err)
			return err
		}
	}

	return nil
}
