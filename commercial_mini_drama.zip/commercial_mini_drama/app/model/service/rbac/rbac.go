package rbac

import (
	"bytes"
	"encoding/json"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"goserver/app/common"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/httplib"
)

type RbacService struct {
	Ctx *gin.Context
}

type RbacResp struct {
	ErrorNo  int              `json:"error_no"`
	ErrorMsg string           `json:"error_msg"`
	Data     *common.UserInfo `json:"data"`
}

func (r *RbacService) SetUserRbac() {
	rbacUrl := viper.GetString("rbac.url")
	req := common.GetRequest(r.Ctx)
	cli := httplib.NewHttpRequest(rbacUrl)
	paramsJson, _ := json.Marshal(req)
	bodyBuffer := bytes.NewBuffer(paramsJson)
	cli.SetBody(bodyBuffer)
	respJson, err := cli.Post()
	if err != nil {
		panic(myerror.NoLogin)
	}
	resp := RbacResp{}
	err = json.Unmarshal([]byte(respJson), &resp)
	if err != nil {
		panic(myerror.ForbiddenServerError)
	}
	if len(resp.Data.Products) <= 0 {
		panic(myerror.ForbiddenServerError)
	}
	req.UserInfo = resp.Data
}
