package accounts

import (
	"context"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/model/dao/accounts"
)

type AccountDistributorService struct {
	Ctx context.Context
}

func NewAccountDistributorService(ctx context.Context) *AccountDistributorService {
	return &AccountDistributorService{Ctx: ctx}
}

func (s *AccountDistributorService) GroupInsert(params accountdto.PromotionUrlMergeExecutorParams) error {
	accountDistributorDao := accounts.NewAccountDistributorDao(s.Ctx)
	return accountDistributorDao.GroupInsert(params)
}
