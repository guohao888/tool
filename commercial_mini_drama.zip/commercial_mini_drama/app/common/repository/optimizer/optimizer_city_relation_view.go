package optimizer

import (
	"goserver/app/common/repository"
	"time"
)

// OptimizerCityRelationViewEntityTable 优化师地区关联视图表
const OptimizerCityRelationViewEntityTable = "optimizer_city_view"

// OptimizerCityRelationViewEntity 优化师地区关联视图结构体
type OptimizerCityRelationViewEntity struct {
	OptimizerCityRelationId int64     `gorm:"column:optimizer_city_relation_id"` // 优化师地区关联主键
	OptimizerId             string    `gorm:"column:optimizer_id"`               // 优化师主键
	OptimizerCityId         int64     `gorm:"column:optimizer_city_id"`          // 优化师地区主键
	Status                  int64     `gorm:"column:status"`                     // 状态
	OptimizerName           string    `gorm:"column:optimizer_name"`             // 优化师名称
	Phone                   string    `gorm:"column:phone"`                      // 手机号
	OptimizerCityName       string    `gorm:"column:optimizer_city_name"`        // 优化师地区名称
	CreatedAt               time.Time `gorm:"column:created_at"`                 // 创建时间
	UpdatedAt               time.Time `gorm:"column:updated_at"`                 // 更新时间
}

// OptimizerCityRelationViewEntityTableName 表名称
func OptimizerCityRelationViewEntityTableName() string {
	if repository.IsDebugTable(OptimizerCityRelationViewEntityTable) {
		return OptimizerCityRelationViewEntityTable + "_dev"
	} else {
		return OptimizerCityRelationViewEntityTable
	}
}

/**
	视图建表语句

CREATE VIEW commercial_mini_drama.optimizer_city_view
(
    optimizer_city_relation_id COMMENT '关联表主键ID',
    optimizer_id COMMENT '优化师ID',
    optimizer_city_id COMMENT '优化师区域ID',
    status COMMENT '状态 1=启用 2=停用',
    updated_at COMMENT '更新时间',
    created_at COMMENT '创建时间',
    optimizer_name COMMENT '优化师名字',
	phone COMMENT '手机号',
    optimizer_city_name COMMENT '优化师区域名字'
)
COMMENT '优化师地区视图表'
AS
SELECT
optimizer_city_relation.optimizer_city_relation_id,
optimizer_city_relation.optimizer_id,
optimizer_city_relation.optimizer_city_id,
optimizer_city_relation.status,
optimizer_city_relation.updated_at,
optimizer_city_relation.created_at,
optimizer.optimizer_name,
optimizer.phone,
optimizer_city.optimizer_city_name
FROM optimizer_city_relation
left join optimizer on optimizer_city_relation.optimizer_id = optimizer.optimizer_id
left join optimizer_city on optimizer_city_relation.optimizer_city_id = optimizer_city.optimizer_city_id;

**/
