package warningdto

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common"
	"goserver/app/library/myerror"
)

// MonitorListReq 监控列表请求
type MonitorListReq struct {
	common.CommonParams
	common.Pagination        // 分页
	Media             int    `json:"media"`          // 媒体 1: 全部 2:巨量广告
	TaskType          int    `json:"task_type"`      // 任务类型 1：全部 2：素材拒审监控: 3：投放异常预警
	TaskStatus        int    `json:"task_status"`    // 任务状态 1:全部；2:开启；3:关闭
	MonitorObject     int    `json:"monitor_object"` // 监控对象 1:全部；2:账户
	TaskName          string `json:"task_name"`      // 任务名称
	OperationType     int    `json:"operation_type"` // 通知类型 1：全部；2：消息通知
}

// NewMonitorListReq 解析绑定监控列表查询
func NewMonitorListReq(c *gin.Context) *MonitorListReq {
	req := &MonitorListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

type MonitorInfoReq struct {
	common.CommonParams
	MonitorInfos
}

type MonitorInfos struct {
	TaskId        string    `json:"task_id"`        // 任务ID
	TaskType      int       `json:"task_type"`      // 任务类型 2：素材拒审监控: 3：投放异常预警
	TaskName      string    `json:"task_name"`      // 任务名称
	Media         int       `json:"media"`          // 媒体
	MonitorObject int       `json:"monitor_object"` // 应用媒体 2: 巨量广告
	RuleList      []Rules   `json:"rule_list"`      // 规则列表
	Interval      Interval  `json:"interval"`       // 检查频率
	EffectiveTime Effective `json:"effective_time"` // 生效时间
	MsgTo         []string  `json:"msg_to"`
	Scope         Scope     `json:"scope"`       // 账号范围
	Status        int       `json:"status"`      // 状态  1 开启  2 关闭
	CreateUser    string    `json:"create_user"` // 创建人
	Operation     int       `json:"operation"`   // 操作类型 1 推推 2 拉空
	CreatedAt     string    `json:"created_at"`  // 创建时间
}
type Rules struct {
	Metrics       int    `json:"metrics"`        // 指标 1:消耗 2：拒审 3：ROI
	DateCondition int    `json:"date_condition"` // 时间条件 1.过去24小时  2：当天 3：过去三天
	Condition     string `json:"condition"`      // 条件 >, <,<=,>=,=, between
	Numerical     string `json:"numerical"`      // 条件数值 ;号分割
}

type Interval struct {
	IntervalType  int    `json:"interval_type"`  // 1: 间隔执行  2：定时
	IntervalValue string `json:"interval_value"` // 小时 09:00
}

type Effective struct {
	EffectiveType  int    `json:"effective_type"`  // 1:长期  2：开始-结束时间
	EffectiveValue string `json:"effective_value"` // ;号分割  2025-01-01；2025-03-01
}

type Scope struct {
	ScopeType  int    `json:"scope_type"`  // 1:ALL 2: 指定账号
	ScopeValue string `json:"scope_value"` // 账号: 逗号分割
}

// NewMonitorInfoReq 解析绑定监控数据
func NewMonitorInfoReq(c *gin.Context) *MonitorInfoReq {
	req := &MonitorInfoReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

type AdvertiserVerify struct {
	AdvertiserList []string `json:"advertiser_list"`
}

type AdvertiserInfo struct {
	AdvertiserId   string `json:"advertiser_id"`
	AdvertiserName string `json:"advertiser_name"`
}

// NewAdvertiserVerify 验证账号数据
func NewAdvertiserVerify(c *gin.Context) *AdvertiserVerify {
	req := &AdvertiserVerify{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}
