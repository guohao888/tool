package fanqie

import (
	"goserver/app/common/repository"
	"time"
)

const IAACoefficientEntityTable = "tomato_iaa_coefficient"

type IAACoefficientEntity struct {
	SearchDate  time.Time `gorm:"column:search_date"` // 日期
	Coefficient float64   `gorm:"column:coefficient"` // 系数
}

func (*IAACoefficientEntity) TableName() string {
	return IAACoefficientEntityTable
}

func IAACoefficientTableName() string {
	if repository.IsDebugTable(IAACoefficientEntityTable) {
		return IAACoefficientEntityTable + "_dev"
	} else {
		return IAACoefficientEntityTable
	}
}
