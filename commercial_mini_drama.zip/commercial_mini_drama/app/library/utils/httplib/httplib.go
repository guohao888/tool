package httplib

import (
	"bytes"
	"errors"
	"goserver/app/library/log"
	"io"
	"io/ioutil"
	"net/http"
	"net/url"
	"sort"
	"strings"
	"sync"
	"time"
)

// HTTPRequest 对外提供http相关方法.
type HTTPRequest struct {
	url            string
	params         url.Values
	headers        map[string]string
	body           io.Reader
	downloadFile   bool
	disableRespLog bool
}

func NewHttpRequest(url string) *HTTPRequest {
	return &HTTPRequest{
		url: url,
	}
}

func (httpReq *HTTPRequest) SetDownloadOption(download bool) {
	httpReq.downloadFile = download
}

func (httpReq *HTTPRequest) DisableRespLog(d bool) {
	httpReq.disableRespLog = d
}

func (httpReq *HTTPRequest) SetParams(params url.Values) {
	httpReq.params = params
}

func (httpReq *HTTPRequest) SetHeader(headers map[string]string) {
	httpReq.headers = headers
}

func (httpReq *HTTPRequest) SetBody(body io.Reader) {
	httpReq.body = body
}

var HttpClient = NewClient(&Options{Timeout: 30000, MaxIdleConns: 50})

type Client struct {
	Opt *Options
}

func NewClient(opt *Options) *Client {
	opt.init()

	c := Client{
		Opt: opt,
	}
	return &c
}

func (c *Client) GetPool() *sync.Pool {
	if c.Opt == nil {
		return nil
	}
	return c.Opt.Pool
}

type Options struct {
	Timeout      int
	MaxIdleConns int
	Pool         *sync.Pool
}

func (opt *Options) init() {
	opt.Pool = &sync.Pool{
		New: func() interface{} {
			return &http.Client{
				Timeout: (time.Duration(opt.Timeout) * time.Millisecond),
				Transport: &http.Transport{
					DisableKeepAlives:   true,
					MaxIdleConnsPerHost: opt.MaxIdleConns,
				},
			}
		},
	}
}

func (httpReq *HTTPRequest) Get(isUrlEncode bool) (string, error) {
	//1、set params
	buf := bytes.NewBufferString(httpReq.url)
	if httpReq.params != nil {
		if isUrlEncode {
			buf.WriteString("?")
			buf.WriteString(httpReq.params.Encode())
		} else {
			buf.WriteString("?")
			buf.WriteString(encode(httpReq.params))
		}
	}
	//2、new request
	req, err := http.NewRequest(http.MethodGet, buf.String(), nil)
	if err != nil {
		return "", errors.New("new request is fail ")
	}
	//3、add headers
	if httpReq.headers != nil {
		for key, val := range httpReq.headers {
			req.Header.Add(key, val)
		}
	}
	//4、http client
	pool := HttpClient.GetPool()
	if pool == nil {
		err := errors.New("Geet pool is nil")
		log.Error(err)
		return "", err
	}
	c := pool.Get()
	cli, ok := c.(*http.Client)
	if !ok {
		err := errors.New("PostBodyData interface{} to httpClient failed.")
		log.Error(err)
		return "", err
	}
	defer pool.Put(c)
	log.Debug("method: " + http.MethodGet + ", url: " + httpReq.url + ", params: " + encode(httpReq.params))

	resp, err := cli.Do(req)
	if err != nil {
		return "", err
	}

	if resp.StatusCode != 200 {
		return "", errors.New(resp.Status)
	}

	content, err := ioutil.ReadAll(resp.Body)
	defer resp.Body.Close()

	if err != nil {
		return "", err
	}

	if httpReq.downloadFile == false {
		if !httpReq.disableRespLog {
			log.Debug("method: " + http.MethodGet + ", url: " + httpReq.url + ", params: " + encode(httpReq.params) + ", response: " + string(content))
		}
	} else {
		log.Debug("method: " + http.MethodGet + ", url: " + httpReq.url + ", params: " + encode(httpReq.params))
	}
	return string(content), nil
}

func (httpReq *HTTPRequest) PostWithParams(isUrlEncode bool) (string, error) {
	//1、set params
	buf := bytes.NewBufferString(httpReq.url)
	if httpReq.params != nil {
		if isUrlEncode {
			buf.WriteString("?")
			buf.WriteString(httpReq.params.Encode())
		} else {
			buf.WriteString("?")
			buf.WriteString(encode(httpReq.params))
		}
	}

	//数据重写回body
	requestStr, _ := ioutil.ReadAll(httpReq.body)
	log.Debugf("[http] method: %s, url: %s, body: %s \n", http.MethodPost, httpReq.url, requestStr)
	body := bytes.NewBuffer(requestStr)
	httpReq.SetBody(body)

	//1、new request
	req, err := http.NewRequest(http.MethodPost, buf.String(), bytes.NewBuffer(requestStr))
	if err != nil {
		log.Error(err)
		return "", errors.New("new request is fail: %v \n")
	}
	req.Header.Set("Content-type", "application/json")

	//2、add headers
	if httpReq.headers != nil {
		for key, val := range httpReq.headers {
			req.Header.Add(key, val)
		}
	}
	//3、http client
	pool := HttpClient.GetPool()
	if pool == nil {
		err := errors.New("Geet pool is nil")
		log.Error(err)
		return "", err
	}
	c := pool.Get()
	cli, ok := c.(*http.Client)
	if !ok {
		err := errors.New("PostBodyData interface{} to httpClient failed.")
		log.Error(err)
		return "", err
	}
	defer pool.Put(c)

	resp, err := cli.Do(req)
	if err != nil {
		return "", err
	}

	if resp.StatusCode != 200 {
		return "", errors.New(resp.Status)
	}

	content, err := ioutil.ReadAll(resp.Body)
	defer resp.Body.Close()

	if err != nil {
		return "", err
	}

	if !httpReq.disableRespLog {
		log.Debug("method: " + http.MethodPost + ", url: " + httpReq.url + ", body: " + string(requestStr) + ", response: " + string(content))
	}

	return string(content), err
}

func (httpReq *HTTPRequest) PostReturnResp() (*http.Response, error) {
	//数据重写回body
	requestStr, _ := ioutil.ReadAll(httpReq.body)
	log.Debugf("[http] method: %s, url: %s, body: %s \n", http.MethodPost, httpReq.url, requestStr)
	body := bytes.NewBuffer(requestStr)
	httpReq.SetBody(body)

	//1、new request
	req, err := http.NewRequest(http.MethodPost, httpReq.url, bytes.NewBuffer(requestStr))
	if err != nil {
		log.Error(err)
		return nil, errors.New("new request is fail: %v \n")
	}
	isContentType := true
	//2、add headers
	if httpReq.headers != nil {
		for key, val := range httpReq.headers {
			req.Header.Add(key, val)
			if strings.ToLower(key) == "content-type" {
				isContentType = false
			}
		}
	}
	if isContentType {
		req.Header.Set("Content-type", "application/json")
	}
	//3、http client
	pool := HttpClient.GetPool()
	if pool == nil {
		err := errors.New("Geet pool is nil")
		log.Error(err)
		return nil, err
	}
	c := pool.Get()
	cli, ok := c.(*http.Client)
	if !ok {
		err := errors.New("PostBodyData interface{} to httpClient failed.")
		log.Error(err)
		return nil, err
	}
	defer pool.Put(c)

	resp, err := cli.Do(req)
	if err != nil {
		return nil, err
	}

	return resp, err
}

func (httpReq *HTTPRequest) Post() (string, error) {
	//数据重写回body
	requestStr, _ := ioutil.ReadAll(httpReq.body)
	log.Debugf("[http] method: %s, url: %s, body: %s \n", http.MethodPost, httpReq.url, requestStr)
	body := bytes.NewBuffer(requestStr)
	httpReq.SetBody(body)

	//1、new request
	req, err := http.NewRequest(http.MethodPost, httpReq.url, bytes.NewBuffer(requestStr))
	if err != nil {
		log.Error(err)
		return "", errors.New("new request is fail: %v \n")
	}
	isContentType := true
	//2、add headers
	if httpReq.headers != nil {
		for key, val := range httpReq.headers {
			req.Header.Add(key, val)
			if strings.ToLower(key) == "content-type" {
				isContentType = false
			}
		}
	}
	if isContentType {
		req.Header.Set("Content-type", "application/json")
	}
	//3、http client
	pool := HttpClient.GetPool()
	if pool == nil {
		err := errors.New("Geet pool is nil")
		log.Error(err)
		return "", err
	}
	c := pool.Get()
	cli, ok := c.(*http.Client)
	if !ok {
		err := errors.New("PostBodyData interface{} to httpClient failed.")
		log.Error(err)
		return "", err
	}
	defer pool.Put(c)

	resp, err := cli.Do(req)
	if err != nil {
		return "", err
	}

	if resp.StatusCode != 200 {
		return "", errors.New(resp.Status)
	}

	content, err := ioutil.ReadAll(resp.Body)
	defer resp.Body.Close()

	if err != nil {
		return "", err
	}

	if !httpReq.disableRespLog {
		log.Debug("method: " + http.MethodPost + ", url: " + httpReq.url + ", body: " + string(requestStr) + ", response: " + string(content))
	}

	return string(content), err
}

func encode(v url.Values) string {
	if v == nil {
		return ""
	}
	var buf strings.Builder
	keys := make([]string, 0, len(v))
	for k := range v {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	for _, k := range keys {
		vs := v[k]
		for _, v := range vs {
			if buf.Len() > 0 {
				buf.WriteByte('&')
			}
			buf.WriteString(k)
			buf.WriteByte('=')
			buf.WriteString(v)
		}
	}
	return buf.String()
}
