package kuaishou

import (
	"context"
	"errors"
	"goserver/app/library/playlet/kuaishou/middleware"
	"strconv"
)

const (
	restOpenapiOauth2AuthorizeAccessToken  = "/rest/openapi/oauth2/authorize/access_token"  // 获取 token
	restOpenapiOauth2AuthorizeRefreshToken = "/rest/openapi/oauth2/authorize/refresh_token" // 刷新token
)

type AccessTokenReq struct {
	AppId    int64  `json:"app_id"`
	Secret   string `json:"secret"`
	AuthCode string `json:"auth_code"`
}

type TokenData struct {
	AccessToken           string  `json:"access_token"`
	RefreshTokenExpiresIn int64   `json:"refresh_token_expires_in"`
	RefreshToken          string  `json:"refresh_token"`
	AdvertiserIds         []int64 `json:"advertiser_ids"`
	UserId                int64   `json:"user_id"`
	ApprovalType          int     `json:"approval_type"`
	AccessTokenExpiresIn  int64   `json:"access_token_expires_in"`
	AdvertiserId          int64   `json:"advertiser_id"`
}

type AccessTokenResp struct {
	CommonRespField
	Data TokenData `json:"data"`
}

func OauthAccessToken(ctx context.Context, req AccessTokenReq) (resp *AccessTokenResp, err error) {
	ctx = middleware.WithValue(ctx,
		middleware.CtxAppIdKey, strconv.FormatInt(req.AppId, 10),
		middleware.CtxPathKey, restOpenapiOauth2AuthorizeAccessToken,
	)

	response, err := client.R().
		SetContext(ctx).
		SetBody(req).
		SetResult(&AccessTokenResp{}).
		Post(restOpenapiOauth2AuthorizeAccessToken)
	if err != nil {
		return
	}
	resp, ok := response.Result().(*AccessTokenResp)
	if !ok {
		err = errors.New("result type conversion failed")
		return
	}
	return
}

type RefreshTokenReq struct {
	AppId        int64  `json:"app_id"`
	Secret       string `json:"secret"`
	RefreshToken string `json:"refresh_token"`
}

type RefreshTokenResp struct {
	CommonRespField
	Data TokenData `json:"data"`
}

func OauthRefreshToken(ctx context.Context, req RefreshTokenReq) (resp *RefreshTokenResp, err error) {
	ctx = middleware.WithValue(ctx,
		middleware.CtxAppIdKey, strconv.FormatInt(req.AppId, 10),
		middleware.CtxPathKey, restOpenapiOauth2AuthorizeRefreshToken,
	)

	response, err := client.R().
		SetContext(ctx).
		SetBody(req).
		SetResult(&RefreshTokenResp{}).
		Post(restOpenapiOauth2AuthorizeRefreshToken)
	if err != nil {
		return
	}
	resp, ok := response.Result().(*RefreshTokenResp)
	if !ok {
		err = errors.New("result type conversion failed")
		return
	}
	return
}
