package lianshan

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/lianshan"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// ReportLianshanDao 巨量项目小时DAO
type ReportLianshanDao struct {
	Ctx context.Context
}

func NewReportLianshanDao(ctx context.Context) *ReportLianshanDao {
	return &ReportLianshanDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (r *ReportLianshanDao) InsertBatchSize(data []lianshan.ReportLianshanHourEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 1000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = r.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *ReportLianshanDao) buildInsertSentence(tx *gorm.DB, data []lianshan.ReportLianshanHourEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + lianshan.ReportLianshanHourTableName() + " ( `id`,`create_time`,`advertiser_id`,`cdp_project_id`,`cdp_promotion_id`,`stat_time_hour`,`stat_cost`,`show_cnt`,`click_cnt`,`convert_cnt`,`cpm_platform`,`ctr`,`cpc_platform`,`attribution_convert_cnt`,`attribution_convert_cost`,`conversion_cost`,`active`,`active_cost`,`stat_attribution_micro_game_24h_amount`,`attribution_micro_game_24h_roi`,`stat_micro_game_0d_amount`,`landing_type`,`external_action`,`pricing`,`delivery_mode`,`app_code`,`campaign_type`,`cdp_marketing_goal`,`attribution_conversion_rate`,`attribution_deep_convert_cnt`,`attribution_deep_convert_cost`,`attribution_deep_convert_rate`,`conversion_rate`,`deep_convert_cnt`,`deep_convert_cost`,`deep_convert_rate`,`active_rate`,`game_addiction_cost`,`game_addiction`,`game_addiction_rate`,`active_pay`,`active_pay_cost`,`active_pay_rate`,`game_pay_cost`,`game_pay_count`,`attribution_game_pay_7d_count`,`attribution_game_pay_7d_cost`,`attribution_active_pay_7d_per_count`,`attribution_billing_game_in_app_ltv_1day`,`attribution_billing_game_in_app_ltv_2days`,`attribution_billing_game_in_app_ltv_3days`,`attribution_billing_game_in_app_ltv_4days`,`attribution_billing_game_in_app_ltv_5days`,`attribution_billing_game_in_app_ltv_6days`,`attribution_billing_game_in_app_ltv_7days`,`attribution_billing_game_in_app_roi_1day`,`attribution_billing_game_in_app_roi_2days`,`attribution_billing_game_in_app_roi_3days`,`attribution_billing_game_in_app_roi_4days`,`attribution_billing_game_in_app_roi_5days`,`attribution_billing_game_in_app_roi_6days`,`attribution_billing_game_in_app_roi_7days`,`attribution_active_pay_cost`,`attribution_active_pay_rate`,`stat_pay_amount`,`pay_amount_roi`,`attribution_game_addiction_pay_conversion_rate`,`attribution_micro_game_0d_ltv`,`attribution_micro_game_3d_ltv`,`attribution_micro_game_7d_ltv`,`attribution_micro_game_0d_roi`,`attribution_micro_game_3d_roi`,`attribution_micro_game_7d_roi`,`attribution_micro_game_iaap_ltv_1day`,`attribution_micro_game_iaap_roi_1day`,`attribution_effect_active_30d_count`,`attribution_effect_active_30d_cost`,`attribution_micro_game_iaap_ltv_24h`,`attribution_micro_game_iaap_ltv_24h_roi`,`attribution_micro_game_iaap_ltv_7d`,`attribution_micro_game_iaap_ltv_7d_roi`,`stat_attribution_micro_game_7d_amount`,`stat_micro_game_iaap_iaa_cost`,`attribution_micro_game_iaap_iaa_7d_roi`,`stat_micro_game_iaap_iap_cost`,`attribution_micro_game_iaap_iap_roi_8days`,`attribution_billing_micro_game_0d_ltv`,`attribution_billing_micro_game_7d_ltv`,`attribution_billing_micro_game_0d_roi`,`stat_attribution_billing_micro_game_24h_amount`,`stat_attribution_billing_micro_game_3d_amount`,`stat_attribution_billing_micro_game_7d_amount`,`attribution_billing_micro_game_24h_roi`,`attribution_billing_micro_game_3d_roi`,`attribution_billing_micro_game_7d_roi`,`attribution_game_in_app_ltv_1day`,`attribution_game_in_app_ltv_2days`,`attribution_game_in_app_ltv_3days`,`attribution_game_in_app_ltv_4days`,`attribution_game_in_app_ltv_5days`,`attribution_game_in_app_ltv_6days`,`attribution_game_in_app_ltv_7days`,`attribution_game_in_app_ltv_8days`,`attribution_active_pay_intra_one_day_count`,`active_pay_intra_day_cost`,`attribution_active_pay_intra_one_day_cost`,`attribution_active_pay_intra_one_day_amount`,`first_pay_intra_24hour_amount`,`stat_time`,`uid`,`update_time` ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.ID,
			v.CreateTime,
			v.AdvertiserID,
			v.CdpProjectID,
			v.CdpPromotionID,
			v.StatTimeHour,
			v.StatCost,
			v.ShowCnt,
			v.ClickCnt,
			v.ConvertCnt,
			v.CpmPlatform,
			v.Ctr,
			v.CpcPlatform,
			v.AttributionConvertCnt,
			v.AttributionConvertCost,
			v.ConversionCost,
			v.Active,
			v.ActiveCost,
			v.StatAttributionMicroGame24hAmount,
			v.AttributionMicroGame24hRoi,
			v.StatMicroGame0dAmount,
			v.LandingType,
			v.ExternalAction,
			v.Pricing,
			v.DeliveryMode,
			v.AppCode,
			v.CampaignType,
			v.CdpMarketingGoal,
			v.AttributionConversionRate,
			v.AttributionDeepConvertCnt,
			v.AttributionDeepConvertCost,
			v.AttributionDeepConvertRate,
			v.ConversionRate,
			v.DeepConvertCnt,
			v.DeepConvertCost,
			v.DeepConvertRate,
			v.ActiveRate,
			v.GameAddictionCost,
			v.GameAddiction,
			v.GameAddictionRate,
			v.ActivePay,
			v.ActivePayCost,
			v.ActivePayRate,
			v.GamePayCost,
			v.GamePayCount,
			v.AttributionGamePay7dCount,
			v.AttributionGamePay7dCost,
			v.AttributionActivePay7dPerCount,
			v.AttributionBillingGameInAppLtv1day,
			v.AttributionBillingGameInAppLtv2days,
			v.AttributionBillingGameInAppLtv3days,
			v.AttributionBillingGameInAppLtv4days,
			v.AttributionBillingGameInAppLtv5days,
			v.AttributionBillingGameInAppLtv6days,
			v.AttributionBillingGameInAppLtv7days,
			v.AttributionBillingGameInAppRoi1day,
			v.AttributionBillingGameInAppRoi2days,
			v.AttributionBillingGameInAppRoi3days,
			v.AttributionBillingGameInAppRoi4days,
			v.AttributionBillingGameInAppRoi5days,
			v.AttributionBillingGameInAppRoi6days,
			v.AttributionBillingGameInAppRoi7days,
			v.AttributionActivePayCost,
			v.AttributionActivePayRate,
			v.StatPayAmount,
			v.PayAmountRoi,
			v.AttributionGameAddictionPayConversionRate,
			v.AttributionMicroGame0dLtv,
			v.AttributionMicroGame3dLtv,
			v.AttributionMicroGame7dLtv,
			v.AttributionMicroGame0dRoi,
			v.AttributionMicroGame3dRoi,
			v.AttributionMicroGame7dRoi,
			v.AttributionMicroGameIaapLtv1day,
			v.AttributionMicroGameIaapRoi1day,
			v.AttributionEffectActive30dCount,
			v.AttributionEffectActive30dCost,
			v.AttributionMicroGameIaapLtv24h,
			v.AttributionMicroGameIaapLtv24hRoi,
			v.AttributionMicroGameIaapLtv7d,
			v.AttributionMicroGameIaapLtv7dRoi,
			v.StatAttributionMicroGame7dAmount,
			v.StatMicroGameIaapIaaCost,
			v.AttributionMicroGameIaapIaa7dRoi,
			v.StatMicroGameIaapIapCost,
			v.AttributionMicroGameIaapIapRoi8days,
			v.AttributionBillingMicroGame0dLtv,
			v.AttributionBillingMicroGame7dLtv,
			v.AttributionBillingMicroGame0dRoi,
			v.StatAttributionBillingMicroGame24hAmount,
			v.StatAttributionBillingMicroGame3dAmount,
			v.StatAttributionBillingMicroGame7dAmount,
			v.AttributionBillingMicroGame24hRoi,
			v.AttributionBillingMicroGame3dRoi,
			v.AttributionBillingMicroGame7dRoi,
			v.AttributionGameInAppLtv1day,
			v.AttributionGameInAppLtv2days,
			v.AttributionGameInAppLtv3days,
			v.AttributionGameInAppLtv4days,
			v.AttributionGameInAppLtv5days,
			v.AttributionGameInAppLtv6days,
			v.AttributionGameInAppLtv7days,
			v.AttributionGameInAppLtv8days,
			v.AttributionActivePayIntraOneDayCount,
			v.ActivePayIntraDayCost,
			v.AttributionActivePayIntraOneDayCost,
			v.AttributionActivePayIntraOneDayAmount,
			v.FirstPayIntra24hourAmount,
			v.StatTime,
			v.UID,
			v.UpdateTime,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
