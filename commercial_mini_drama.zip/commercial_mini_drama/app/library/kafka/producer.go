package kafka

import (
	"encoding/json"
	"fmt"
	"goserver/app/common/dto"
	"goserver/app/common/dto/fanqie"
	"goserver/app/common/dto/subscribedto"

	"github.com/IBM/sarama"
	"github.com/spf13/viper"
)

var iOrderProducer *ProducerKafka
var pOrderProducer *ProducerKafka
var userProducer *ProducerKafka
var spiMaterialProducer *ProducerKafka
var subscribeProducer *ProducerKafka

type ProducerKafka struct {
	producer sarama.SyncProducer
	topic    string
}

func InitIOrderClient() (err error) {
	// 获取 kafka 配置信息
	dbPrefix := "kafka_iaa_order"
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	iOrderProducer, err = NewKafkaProducer(brokers, topic)
	if err != nil {
		return err
	}
	return nil
}

func InitPOrderClient() (err error) {
	// 获取 kafka 配置信息
	dbPrefix := "kafka_iap_order"
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	pOrderProducer, err = NewKafkaProducer(brokers, topic)
	if err != nil {
		return err
	}
	return nil
}

func InitUserClient() (err error) {
	//获取 kafka 配置信息
	dbPrefix := "kafka_user"
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	userProducer, err = NewKafkaProducer(brokers, topic)
	if err != nil {
		return err
	}
	return nil
}

func InitSpiMaterialClient() (err error) {
	//获取 kafka 配置信息
	dbPrefix := "kafka_spi_material"
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	spiMaterialProducer, err = NewKafkaProducer(brokers, topic)
	if err != nil {
		return err
	}
	return nil
}

func InitISubscribeClient() (err error) {
	// 获取 kafka 配置信息
	dbPrefix := "kafka_subscribe"
	brokers := []string{viper.GetString(dbPrefix + ".broker")}
	topic := viper.GetString(dbPrefix + ".topic_name")
	subscribeProducer, err = NewKafkaProducer(brokers, topic)
	if err != nil {
		return err
	}
	return nil
}

func IOrderKafkaProducer() *ProducerKafka {
	return iOrderProducer
}

func POrderKafkaProducer() *ProducerKafka {
	return pOrderProducer
}

func UserKafkaProducer() *ProducerKafka {
	return userProducer
}

func SpiMaterialKafkaProducer() *ProducerKafka {
	return spiMaterialProducer
}

func SubscribeKafkaProducer() *ProducerKafka {
	return subscribeProducer
}

func NewKafkaProducer(brokers []string, topic string) (*ProducerKafka, error) {
	config := sarama.NewConfig()
	config.Version = sarama.V1_1_1_0
	config.Producer.RequiredAcks = sarama.WaitForAll
	config.Producer.Retry.Max = 5
	config.Producer.Return.Successes = true
	config.Net.MaxOpenRequests = 10

	producer, err := sarama.NewSyncProducer(brokers, config)
	if err != nil {
		return nil, fmt.Errorf("failed to create producer: %w", err)
	}

	return &ProducerKafka{
		producer: producer,
		topic:    topic,
	}, nil
}

func (kp *ProducerKafka) AddUsers(info fanqie.TomatoUserReq) error {
	// 序列化数据
	payload, err := json.Marshal(info)
	if err != nil {
		return fmt.Errorf("marshal error: %w", err)
	}

	// 构造 Kafka 消息
	msg := &sarama.ProducerMessage{
		Topic: kp.topic,
		Value: sarama.ByteEncoder(payload),
	}

	// 发送消息
	_, _, err = kp.producer.SendMessage(msg)
	if err != nil {
		return fmt.Errorf("failed to send message: %w", err)
	}
	return nil
}

func (kp *ProducerKafka) AddIAAOrders(info fanqie.TomatoIAAOrderReq) error {
	// 序列化数据
	payload, err := json.Marshal(info)
	if err != nil {
		return fmt.Errorf("marshal error: %w", err)
	}

	// 构造 Kafka 消息
	msg := &sarama.ProducerMessage{
		Topic: kp.topic,
		Value: sarama.ByteEncoder(payload),
	}

	// 发送消息
	_, _, err = kp.producer.SendMessage(msg)
	if err != nil {
		return fmt.Errorf("failed to send message: %w", err)
	}
	return nil
}

func (kp *ProducerKafka) AddIAPOrders(info fanqie.TomatoIAPOrderReq) error {
	// 序列化数据
	payload, err := json.Marshal(info)
	if err != nil {
		return fmt.Errorf("marshal error: %w", err)
	}

	// 构造 Kafka 消息
	msg := &sarama.ProducerMessage{
		Topic: kp.topic,
		Value: sarama.ByteEncoder(payload),
	}

	// 发送消息
	_, _, err = kp.producer.SendMessage(msg)
	if err != nil {
		return fmt.Errorf("failed to send message: %w", err)
	}
	return nil
}

func (kp *ProducerKafka) AddSpiMaterialRequests(req []byte) error {
	// 构造通用kafka消息结构
	message := dto.KafkaMessage{
		Type:    dto.KafkaMessageSpiMaterial,
		Payload: req,
	}

	// 序列化数据
	payload, err := json.Marshal(message)
	if err != nil {
		return fmt.Errorf("marshal error: %w", err)
	}

	// 构造 Kafka 消息
	msg := &sarama.ProducerMessage{
		Topic: kp.topic,
		Value: sarama.ByteEncoder(payload),
	}

	// 发送消息
	_, _, err = kp.producer.SendMessage(msg)
	if err != nil {
		return fmt.Errorf("%s failed to send message: %w to kafka", message.Type, err)
	}
	return nil
}

func (kp *ProducerKafka) AddSubscribeInfo(info subscribedto.PostInfoReq) error {
	// 序列化数据
	payload, err := json.Marshal(info)
	if err != nil {
		return fmt.Errorf("marshal error: %w", err)
	}

	// 构造 Kafka 消息
	msg := &sarama.ProducerMessage{
		Topic: kp.topic,
		Value: sarama.ByteEncoder(payload),
	}

	// 发送消息
	_, _, err = kp.producer.SendMessage(msg)
	if err != nil {
		return fmt.Errorf("failed to send message: %w", err)
	}
	return nil
}

func (kp *ProducerKafka) Close() error {
	return kp.producer.Close()
}
