
# 项目结构

```
├── app                                             核心模块
│   ├── common                                          公共模块
│   │   ├── dto                                             请求数据层（定义请求数据和返回数据结构）
│   │   │   └── roidto
│   │   │       ├── pagination.go
│   │   │       └── roi.go
│   │   ├── repository                                      实体层（定义数据表结构）
│   │   │   └── roi
│   │   │       └── reportData.go
│   │   └── request.go
│   ├── controller                                      控制层
│   │   └── roi
│   ├── library                                         通用方法
│   │   ├── cipher                                  加密 
│   │   ├── config                                  配置加载
│   │   ├── constants                               公共变量声明
│   │   ├── cronlog                                 计划任务log下载
│   │   ├── driver                                  数据库加载
│   │   │   ├── dorisdb
│   │   │   ├── mysqldb
│   │   │   └── redisdb
│   │   ├── log                                     日志加载
│   │   ├── myerror                                 自定义错误码
│   │   │   └── myerror.go
│   │   ├── roi                                     投放媒体通用
│   │   │   ├── kuaishou
│   │   │   ├── toutiao
│   │   └── utils                                   通用函数
│   ├── model
│   │   ├── dao                                     数据处理层
│   │   │   └── roi
│   │   │       └── reportData.go
│   │   └── service                                业务逻辑层（定义主要业务处理逻辑）
│   │       ├── cron
│   │       │   ├── config.go
│   │       │   └── cron.go
│   │       └── roi
│   │           └── report.go
│   └── router
│       ├── middleware
│       └── router.go
├── cacrt                                           证书配置
├── conf                                            配置文件
│   ├── debug
│   └── release
├── deploy.sh                                       打包脚本
├── docker                                          docker
│   ├── Dockerfile
│   ├── release
├── entrance                                        核心入口定义
│   └── entrance.go
├── go.mod
├── go.sum
├── main.go
└── README.md
```