package mediareport

import (
	"goserver/app/common/repository"
	"time"
)

const VideoFileEntityTable = "video_file"

type VideoFileEntity struct {
	// 广告主ID
	AdvertiserId string `gorm:"column:advertiser_id"`
	// 素材id，即多合一报表中的素材id，一个素材唯一对应一个素材id
	MaterialId int64 `gorm:"column:material_id"`
	// 视频ID
	VideoId string `gorm:"column:video_id"`
	// 素材的上传时间，格式："yyyy-mm-dd HH:MM:SS"
	CreateTime time.Time `gorm:"column:create_time"`
	// 素材的文件名
	Filename string `gorm:"column:filename"`
	// 视频宽度
	Width int64 `gorm:"column:width"`
	// 视频大小
	Size int64 `gorm:"column:size"`
	// 视频时长
	Duration float64 `gorm:"column:duration"`
	// 视频格式
	Format string `gorm:"column:format"`
	// 码率，单位bps
	BitRate int64 `gorm:"column:bit_rate"`
	// 视频高度
	Height int64 `gorm:"column:height"`
	// 视频地址，链接仅做预览使用，预览链接有效期为1小时
	Url string `gorm:"column:url"`
	// 视频首帧截图，仅限同主体进行素材预览查看
	PosterUrl string `gorm:"column:poster_url"`
	// 视频md5值
	Signature string `gorm:"column:signature"`
	// 素材来源
	Source string `gorm:"column:source"`
	// 剪辑名称
	FileCutter string `gorm:"column:file_cutter"`
}

func (*VideoFileEntity) TableName() string {
	return VideoFileEntityTable
}

func VideoFileTableName() string {
	if repository.IsDebugTable(VideoFileEntityTable) {
		return VideoFileEntityTable + "_dev"
	} else {
		return VideoFileEntityTable
	}
}

type AdvertiserIdsAndMaterialIds struct {
	AdvertiserId string `gorm:"column:advertiser_id"`
	MaterialId   int64  `gorm:"column:material_id"`
	OauthId      string `gorm:"column:oauth_id"`
}

type AdvertiserIdsAndMaterialIdsNew struct {
	AdvertiserId string `gorm:"column:advertiser_id"`
	MaterialId   int64  `gorm:"column:material_id"`
	UserId       string `gorm:"column:user_id"`
}
