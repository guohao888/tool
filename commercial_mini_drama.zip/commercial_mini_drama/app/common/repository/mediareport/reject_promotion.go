package mediareport

import "goserver/app/common/repository"

const RejectPromotionEntityTable = "reject_promotion"

type RejectPromotionEntity struct {
	AdvertiserId string `gorm:"column:advertiser_id"`
	PromotionId  string `gorm:"column:promotion_id"`
	Content      string `gorm:"column:content"`
	RejectReason string `gorm:"column:reject_reason"`
	Suggestion   string `gorm:"column:suggestion"`
}

func (*RejectPromotionEntity) TableName() string {
	return RejectPromotionEntityTable
}

func RejectPromotionEntityTableName() string {
	if repository.IsDebugTable(RejectPromotionEntityTable) {
		return RejectPromotionEntityTable + "_dev"
	} else {
		return RejectPromotionEntityTable
	}
}
