package accounts

import "goserver/app/common/repository"

const OauthAccountEntityTable = "oauth_account"

type AdvAndTokenInfo struct {
	AdvertiserID   string `gorm:"column:advertiser_id"`
	AdvertiserName string `gorm:"column:advertiser_name"`
	AccessToken    string `gorm:"column:access_token"`
}

type OauthAccountEntity struct {
	Media          string `gorm:"column:media"`           // 媒体
	AdvertiserId   string `gorm:"column:advertiser_id"`   // 广告主id
	AdvertiserName string `gorm:"column:advertiser_name"` // 广告主名称
	OauthId        string `gorm:"column:oauth_id"`        // 授权唯一标识
	UserId         string `gorm:"column:user_id"`         // 管家账号ID
}

func (*OauthAccountEntity) TableName() string {
	return OauthAccountTableName()
}

func OauthAccountTableName() string {
	if repository.IsDebugTable(OauthAccountEntityTable) {
		return OauthAccountEntityTable + "_dev"
	} else {
		return OauthAccountEntityTable
	}
}
