package middleware

import (
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"goserver/app/library/utils"
	"net/http"
	"strings"
)

func DomainWhiteListMiddleware() gin.HandlerFunc {
	ips, _ := utils.GetIntranetIp()

	domainWhiteList := viper.GetStringSlice("domain_white_list")
	whiteMap := make(map[string]struct{}, len(domainWhiteList)+len(ips))
	for _, v := range domainWhiteList {
		whiteMap[v] = struct{}{}
	}

	// 添加本地ip地址
	for _, v := range ips {
		whiteMap[v] = struct{}{}
	}

	return func(c *gin.Context) {
		s := strings.Split(c.Request.Host, ":")
		if len(s) == 0 {
			c.AbortWithStatus(http.StatusForbidden)
			return
		}

		if _, ok := whiteMap[s[0]]; ok {
			c.Next()
		} else {
			c.AbortWithStatus(http.StatusForbidden)
		}
	}
}
