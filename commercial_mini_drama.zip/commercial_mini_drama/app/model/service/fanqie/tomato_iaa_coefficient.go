package fanqie

import (
	"context"
	fanqie2 "goserver/app/common/dto/fanqie"
	"goserver/app/common/dto/page"
	repo "goserver/app/common/repository/fanqie"
	"goserver/app/model/dao/fanqie"
	"time"
)

// TomatoIAACoefficientService 番茄IAA系数Service
type TomatoIAACoefficientService struct {
	Ctx context.Context
}

// NewTomatoIAACoefficientService 创建上下文IAA系数Service
func NewTomatoIAACoefficientService(ctx context.Context) *TomatoIAACoefficientService {
	return &TomatoIAACoefficientService{Ctx: ctx}
}

// SaveIAACoefficientInfos 保存IAA系数
func (t *TomatoIAACoefficientService) SaveIAACoefficientInfos(timeList []time.Time, coefficient float64) error {
	tomatoIAACoefficientDao := fanqie.NewTomatoIAACoefficientDao(t.Ctx)
	var data []*repo.IAACoefficientEntity
	for _, v := range timeList {
		info := &repo.IAACoefficientEntity{
			SearchDate:  v,
			Coefficient: coefficient,
		}
		data = append(data, info)
	}
	err := tomatoIAACoefficientDao.InsertCoefficient(data)
	return err
}

// SaveIAACoefficientInfo 前端修改/保存IAA系数
func (t *TomatoIAACoefficientService) SaveIAACoefficientInfo(searchDate string, coefficient float64) error {
	tomatoIAACoefficientDao := fanqie.NewTomatoIAACoefficientDao(t.Ctx)
	pointDate, _ := time.ParseInLocation(time.DateOnly, searchDate, time.Local)
	var data []*repo.IAACoefficientEntity
	info := &repo.IAACoefficientEntity{
		SearchDate:  pointDate,
		Coefficient: coefficient,
	}
	data = append(data, info)
	err := tomatoIAACoefficientDao.InsertCoefficient(data)
	return err
}

// GetIAACoefficientList 获取IAA系数列表
func (t *TomatoIAACoefficientService) GetIAACoefficientList(req *fanqie2.IAACoefficientFilter) (*page.Paginator, error) {
	tomatoIAACoefficientDao := fanqie.NewTomatoIAACoefficientDao(t.Ctx)
	paginator, err := tomatoIAACoefficientDao.FindCoefficientList(req)
	var list []*fanqie2.IAACoefficientResp
	for _, v := range paginator.List.([]*repo.IAACoefficientEntity) {
		info := &fanqie2.IAACoefficientResp{
			SearchDate:  v.SearchDate.Format(time.DateOnly),
			Coefficient: v.Coefficient,
		}
		list = append(list, info)
	}
	if err != nil {
		return nil, err
	}
	paginator.List = list
	return paginator, nil
}
