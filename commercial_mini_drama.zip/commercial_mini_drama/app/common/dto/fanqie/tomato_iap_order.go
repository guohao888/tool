package fanqie

import (
	"github.com/gin-gonic/gin"
	"goserver/app/library/myerror"
)

// TomatoIAPOrderReq IAP 订单数据推送数据参数
type TomatoIAPOrderReq struct {
	OutTradeNo    string `json:"out_trade_no" form:"out_trade_no"`     // 第三方订单号
	DeviceId      string `json:"device_id" form:"device_id"`           // 用户设备ID
	DistributorId string `json:"distributor_id" form:"distributor_id"` // 快应用/公众号对应distributor_id
	AppId         string `json:"app_id" form:"app_id"`                 // 公众号/快应用id（分销平台id）【v1.2】
	AppName       string `json:"app_name" form:"app_name"`             // 快应用/公众号名称【v1.2】
	TradeNo       string `json:"trade_no" form:"trade_no"`             // 脱敏后的订单ID（MD5加密）
	TradeNoRaw    string `json:"trade_no_raw" form:"trade_no_raw"`     // 未脱敏的订单ID（未加密）
	OpenId        string `json:"open_id" form:"open_id"`               // 用户openid（H5书城、微信小程序、抖音小程序)
	PayAmount     string `json:"pay_amount" form:"pay_amount"`         // 支付金额，单位分
	PromotionId   string `json:"promotion_id" form:"promotion_id"`     // 用户染色归属推广链ID
	PayTimestamp  string `json:"pay_timestamp" form:"pay_timestamp"`   // 付费时间戳
	Ip            string `json:"ip" form:"ip"`                         // 用户最近一次点击推广链时的IP
	UserAgent     string `json:"user_agent" form:"user_agent"`         // 用户最近一次点击推广链时的UA
	RegisterTime  string `json:"register_time" form:"register_time"`   // 用户染色时间戳
	BookId        string `json:"book_id" form:"book_id"`               // 染色推广链的书籍ID【v1.2】
	BookName      string `json:"book_name" form:"book_name"`           // 染色推广链的书籍名称【v1.2】
	BookGender    string `json:"book_gender" form:"book_gender"`       // 染色推广链书籍性别【v1.2】
	BookCategory  string `json:"book_category" form:"book_category"`   // 染色推广链的书籍类型【v1.2】
	ExternalId    string `json:"external_id" form:"external_id"`       // 企微用户企微id
	OrderType     string `json:"order_type" form:"order_type"`         // 订单类型：1 虚拟支付，2 非虚拟支付
	UnionId       string `json:"union_id" form:"union_id"`             // 用户在微信/抖音开放平台下的唯一id
}

// NewIAPOrderDataReq 解析绑定IAP订单推送数据参数
func NewIAPOrderDataReq(c *gin.Context) *TomatoIAPOrderReq {
	req := &TomatoIAPOrderReq{}
	if err := c.ShouldBind(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}
