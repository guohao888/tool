package dao

func BatchPage(count int, batchSize int) int {
	if count < 0 || batchSize < 0 {
		return 0
	}
	batchPage := count / batchSize
	if count%batchSize != 0 {
		batchPage += 1
	}
	return batchPage
}
