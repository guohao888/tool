package mediareport

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	repo "goserver/app/common/repository/mediareport"
	"goserver/app/common/repository/promotion"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// ReportHourDao 番茄IAA订单DAO
type ReportHourDao struct {
	Ctx context.Context
}

func NewReportHourDao(ctx context.Context) *ReportHourDao {
	return &ReportHourDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (r *ReportHourDao) InsertBatchSize(data []*repo.ReportHourEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = r.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *ReportHourDao) buildInsertSentence(tx *gorm.DB, data []*repo.ReportHourEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.ReportHourTableName() + " ( search_date, search_hour, promotion_id , promotion_name, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt, ad_platform_cdp_promotion_bid, conversion_cost, created_time , updated_time ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.SearchDate,
			v.SearchHour,
			v.PromotionId,
			v.PromotionName,
			v.AdvertiserId,
			v.ProjectId,
			v.ProjectName,
			v.ShowCnt,
			v.Click,
			v.Active,
			v.ActivePay,
			v.Cost,
			v.ConvertCnt,
			v.AdPlatformCdpPromotionBid,
			v.ConversionCost,
			v.CreatedTime,
			v.UpdatedTime,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func (r *ReportHourDao) GetAdvertiserPromotions(advertiserIds []string) (res []repo.ReportHourEntity, err error) {
	db := dorisdb.DorisClient()
	table := promotion.InfoPromotionEntityTableName()
	q := db.Table(table).Where("advertiser_id in (?)", advertiserIds).Select("advertiser_id, promotion_id").Group("advertiser_id, promotion_id")
	err = q.Find(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return res, nil
}
