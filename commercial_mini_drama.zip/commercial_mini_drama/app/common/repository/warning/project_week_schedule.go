package warning

import (
	"goserver/app/common/repository"
	"time"
)

const ProjectWeekScheduleEntityTable = "project_week_schedule"

type ProjectWeekScheduleEntity struct {
	Media         string    `gorm:"column:media"`
	AdvertiserId  string    `gorm:"column:advertiser_id"`
	ProjectId     string    `gorm:"column:project_id"`
	Operation     string    `gorm:"column:operation"`
	ScheduleTime  string    `gorm:"column:schedule_time"`
	ErrorMsg      string    `gorm:"column:error_msg"`
	Status        int       `gorm:"column:status"`
	ReverseStatus int       `gorm:"column:reverse_status"`
	CreatedTime   time.Time `gorm:"column:created_time"`
}

func (*ProjectWeekScheduleEntity) TableName() string {
	return ProjectWeekScheduleEntityTable
}

func ProjectWeekScheduleEntityTableName() string {
	if repository.IsDebugTable(ProjectWeekScheduleEntityTable) {
		return ProjectWeekScheduleEntityTable + "_dev"
	} else {
		return ProjectWeekScheduleEntityTable
	}
}
