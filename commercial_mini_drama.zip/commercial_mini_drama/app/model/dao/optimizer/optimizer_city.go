package optimizer

import (
	"context"
	"errors"
	"github.com/jinzhu/gorm"
	"github.com/spf13/cast"
	"goserver/app/common/dto/optimizerdto"
	"goserver/app/common/dto/page"
	"goserver/app/common/repository/optimizer"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/library/driver/redisdb"
	"goserver/app/library/myerror"
	"time"
)

const COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_ID = "commercial_mini_drama:OptimizerCityId"

type OptimizerCityDao struct {
	Ctx context.Context
}

func NewOptimizerCityDao(ctx context.Context) *OptimizerCityDao {
	return &OptimizerCityDao{Ctx: ctx}
}

// AddOptimizerCity 添加优化师地区
func (m *OptimizerCityDao) AddOptimizerCity(data *optimizerdto.OptimizerCityInfoParams) error {
	db := dorisdb.DorisClient()
	tx := db.Begin() // 开始事务

	// 验证优化师名称是否存在
	qName := tx.Table(optimizer.OptimizerCityEntityTableName())
	qName = qName.Where("optimizer_city_name = ?", data.OptimizerCityName)
	var NameInfo optimizer.OptimizerCityEntity
	err := qName.First(&NameInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}
	if NameInfo.OptimizerCityName != "" {
		tx.Rollback()                                              // 回滚事务
		return errors.New(myerror.OptimizerCityExistError.Message) // 该地区已存在，请重新配置
	}

	// 查找最大ID
	var redisMaxId int64 = 0

	redisMaxId, err = redisdb.GetIncrValue(COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_ID)
	_ = redisdb.SetKeyExpire(COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_ID, 5*3600)

	if err != nil {
		tx.Rollback() // 回滚事务
		return err
	}

	if redisMaxId == 1 {
		var MaxIdInfo optimizer.OptimizerCityEntity
		err = tx.Table(optimizer.OptimizerCityEntityTableName()).Order("optimizer_city_id DESC").First(&MaxIdInfo).Error
		if err != nil && !gorm.IsRecordNotFoundError(err) {
			tx.Rollback() // 回滚事务
			return err
		}
		optimizerCityId := "0"
		if MaxIdInfo.OptimizerCityId != 0 {
			optimizerCityId = cast.ToString(MaxIdInfo.OptimizerCityId)
		}

		//生成优化师数据主键 利用redis incr
		err = redisdb.Set(COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_ID, optimizerCityId)
		if err != nil {
			tx.Rollback() // 回滚事务
			return err
		}

		// 获取最大值
		redisMaxId, err = redisdb.GetIncrValue(COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_ID)
		if err != nil {
			tx.Rollback() // 回滚事务
			return err
		}
	}

	// 安全验证
	if redisMaxId == 0 {
		tx.Rollback()                                                // 回滚事务
		return errors.New(myerror.OptimizerCityPrimaryError.Message) // 优化师地区主键异常
	}

	var existInfo optimizer.OptimizerCityEntity
	err = tx.Table(optimizer.OptimizerCityEntityTableName()).
		Where("optimizer_city_id = ?", redisMaxId).First(&existInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}

	if err == nil && existInfo.OptimizerCityId != 0 {
		tx.Rollback()                                                // 回滚事务
		return errors.New(myerror.OptimizerCityPrimaryError.Message) // 优化师地区主键异常
	}

	// 新增优化师地区数据
	insert := tx.Table(optimizer.OptimizerCityEntityTableName())
	err = insert.Create(optimizer.OptimizerCityEntity{
		OptimizerCityId:   redisMaxId,
		OptimizerCityName: data.OptimizerCityName,
		CreatedAt:         time.Now(),
		UpdatedAt:         time.Now(),
	}).Error
	if err != nil {
		tx.Rollback() // 回滚事务
		return err
	}

	tx.Commit() // 提交事务
	return nil
}

// UpdateOptimizerCity 编辑优化师地区
func (m *OptimizerCityDao) UpdateOptimizerCity(data *optimizerdto.OptimizerCityInfoParams) error {
	db := dorisdb.DorisClient()
	tx := db.Begin() // 开始事务

	// 验证优化师区域ID是否存在
	qId := tx.Table(optimizer.OptimizerCityEntityTableName())
	qId = qId.Where("optimizer_city_id = ?", data.OptimizerCityId)
	var idInfo optimizer.OptimizerCityEntity
	err := qId.First(&idInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}

	if idInfo.OptimizerCityId == 0 {
		tx.Rollback()                                                // 回滚事务
		return errors.New(myerror.OptimizerCityPrimaryError.Message) // 优化师地区主键异常
	}

	// 验证优化师区域名称是否存在
	qName := tx.Table(optimizer.OptimizerCityEntityTableName())
	qName = qName.Where("optimizer_city_name = ?", data.OptimizerCityName)
	qName = qName.Where("optimizer_city_id != ?", data.OptimizerCityId)
	var NameInfo optimizer.OptimizerCityEntity
	err = qName.First(&NameInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}
	if NameInfo.OptimizerCityName != "" {
		tx.Rollback()                                              // 回滚事务
		return errors.New(myerror.OptimizerCityExistError.Message) // 该地区已存在，请重新配置
	}

	// 新增优化师数据
	update := tx.Table(optimizer.OptimizerCityEntityTableName())

	idInfo.OptimizerCityId = 0
	idInfo.OptimizerCityName = data.OptimizerCityName
	idInfo.UpdatedAt = time.Now()
	err = update.Where("optimizer_city_id = ?", data.OptimizerCityId).Update(idInfo).Error
	if err != nil {
		tx.Rollback() // 回滚事务
		return err
	}

	tx.Commit() // 提交事务
	return nil
}

// OptimizerCityInfoList 优化师地区列表
func (m *OptimizerCityDao) OptimizerCityInfoList(params *optimizerdto.OptimizerCityInfoListParams) (*page.Paginator, error) {
	db := dorisdb.DorisClient()
	q := db.Table(optimizer.OptimizerCityEntityTableName())  // 分页
	q2 := db.Table(optimizer.OptimizerCityEntityTableName()) // 总数

	if params.OptimizerCityName != "" {
		q = q.Where("optimizer_city_name like ?", "%"+params.OptimizerCityName+"%")
		q2 = q2.Where("optimizer_city_name like ?", "%"+params.OptimizerCityName+"%")
	}

	var total int64
	err := q2.Count(&total).Error
	// 分页数据
	pagination := params.Pagination
	var res []*optimizer.OptimizerCityEntity
	err = q.Offset(pagination.GetOffset()).Limit(pagination.GetLimit()).Order("created_at desc").Find(&res).Error
	if err != nil {
		return nil, err
	}
	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)

	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return &paginator, nil
}

// GetRelationByOptimizerName 通过优化师获取关联数据
func (m *OptimizerCityDao) GetRelationByOptimizerName(params *optimizerdto.GetRelationByOptimizerNameInfoParams) (*optimizer.OptimizerCityRelationViewEntity, error) {
	db := dorisdb.DorisClient()
	q := db.Table(optimizer.OptimizerCityRelationViewEntityTableName())

	if params.OptimizerName != "" {
		q = q.Where("optimizer_name = ?", params.OptimizerName)
	}

	var res optimizer.OptimizerCityRelationViewEntity
	err := q.First(&res).Error
	if err != nil {
		return nil, err
	}
	return &res, nil
}

// OptimizerCityRelationInfoList 优化师地区关联列表
func (m *OptimizerCityDao) OptimizerCityRelationInfoList(params *optimizerdto.OptimizerCityRelationInfoListParams) (*page.Paginator, error) {
	db := dorisdb.DorisClient()
	q := db.Table(optimizer.OptimizerCityRelationViewEntityTableName())  // 分页
	q2 := db.Table(optimizer.OptimizerCityRelationViewEntityTableName()) // 总数

	if params.OptimizerId != "" {
		q = q.Where("optimizer_id = ?", params.OptimizerId)
		q2 = q2.Where("optimizer_id = ?", params.OptimizerId)
	}

	if params.OptimizerCityId != 0 {
		q = q.Where("optimizer_city_id = ?", params.OptimizerCityId)
		q2 = q2.Where("optimizer_city_id = ?", params.OptimizerCityId)
	}

	if params.OptimizerName != "" {
		q = q.Where("optimizer_name like ?", "%"+params.OptimizerName+"%")
		q2 = q2.Where("optimizer_name like ?", "%"+params.OptimizerName+"%")
	}

	if params.OptimizerCityName != "" {
		q = q.Where("optimizer_city_name like ?", "%"+params.OptimizerCityName+"%")
		q2 = q2.Where("optimizer_city_name like ?", "%"+params.OptimizerCityName+"%")
	}

	var total int64
	err := q2.Count(&total).Error
	// 分页数据
	pagination := params.Pagination
	var res []*optimizer.OptimizerCityRelationViewEntity
	err = q.Offset(pagination.GetOffset()).Limit(pagination.GetLimit()).Order("created_at desc").Find(&res).Error
	if err != nil {
		return nil, err
	}
	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)

	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return &paginator, nil
}
