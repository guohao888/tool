##使用方法

```
package main

import "fmt"

func main() {
	ss := []string{":8869"}

	err := Init(ss)
	if err != nil {
		fmt.Println(err.Error())
	}

	defer Close()

	for {

	}

}
```
