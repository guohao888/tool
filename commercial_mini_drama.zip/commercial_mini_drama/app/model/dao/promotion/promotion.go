package promotion

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/promotion"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// InfoPromotionDao DAO
type InfoPromotionDao struct {
	Ctx context.Context
}

func NewInfoPromotionDao(ctx context.Context) *InfoPromotionDao {
	return &InfoPromotionDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (ip *InfoPromotionDao) InsertBatchSize(data []*promotion.InfoPromotionEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = ip.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (ip *InfoPromotionDao) buildInsertSentence(tx *gorm.DB, data []*promotion.InfoPromotionEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + promotion.InfoPromotionEntityTableName() + " ( advertiser_id, project_id, promotion_id, promotion_modify_date, promotion_create_time, promotion_modify_time, app_id, start_path, params, url, code, schedule_time, status_first, playlet_series_url, hash_res ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.ProjectId,
			v.PromotionId,
			v.PromotionModifyDate,
			v.PromotionCreateTime,
			v.PromotionModifyTime,
			v.AppId,
			v.StartPath,
			v.Params,
			v.Url,
			v.Code,
			v.ScheduleTime,
			v.StatusFirst,
			v.PlayletSeriesUrl,
			v.HashRes,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")
	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
