package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	accountsvc "goserver/app/model/service/accounts"
)

func AssistAccount(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.OauthAccountSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
		if params.MasterAppId == "" {
			return fmt.Sprintf("主应用ID不能为空")
		}
	}

	media := repository.MediaToutiao

	// 通过主应用获取其下所有协管的广告主ID
	assistAccountService := accountsvc.NewAssistAccountService(ctx)
	err := assistAccountService.AssistAccountSync(media, params)
	if err != nil {
		return fmt.Sprintf("协管广告主ID同步失败, %s", err)
	}

	return "协管广告主ID同步成功"
}
