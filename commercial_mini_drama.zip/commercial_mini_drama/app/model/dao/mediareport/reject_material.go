package mediareport

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	repo "goserver/app/common/repository/mediareport"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// RejectDao 拒审DAO
type RejectDao struct {
	Ctx context.Context
}

func NewRejectDao(ctx context.Context) *RejectDao {
	return &RejectDao{Ctx: ctx}
}

// InsertMaterialBatchSize 插入更新数据
func (r *RejectDao) InsertMaterialBatchSize(data []*repo.RejectMaterialEntity, batchSize int) error {
	data = GetExistInfo(data)
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}
	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = r.buildMaterialInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *RejectDao) buildMaterialInsertSentence(tx *gorm.DB, data []*repo.RejectMaterialEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.RejectMaterialEntityTableName() + " ( advertiser_id, promotion_id, type, item, reject_reason, suggestion, audit_platform ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.PromotionId,
			v.Type,
			v.Item,
			v.RejectReason,
			v.Suggestion,
			v.AuditPlatform,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func GetExistInfo(newL []*repo.RejectMaterialEntity) (res []*repo.RejectMaterialEntity) {
	var hasL []*repo.RejectMaterialEntity
	db := dorisdb.DorisClient()
	err := db.Table(repo.RejectMaterialEntityTableName()).
		Select("advertiser_id, promotion_id, item").
		Where("date(created_at) = CURRENT_DATE").
		Find(&hasL).Error
	if err != nil {
		return
	}
	hasMap := make(map[string]struct{})
	for _, v := range hasL {
		hasMap[v.AdvertiserId+v.PromotionId+v.Item] = struct{}{}
	}
	for _, v := range newL {
		if _, ok := hasMap[v.AdvertiserId+v.PromotionId+v.Item]; !ok {
			res = append(res, v)
		}
	}
	return
}

// InsertPromotionBatchSize 插入更新数据
func (r *RejectDao) InsertPromotionBatchSize(data []*repo.RejectPromotionEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = r.buildPromotionInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *RejectDao) buildPromotionInsertSentence(tx *gorm.DB, data []*repo.RejectPromotionEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.RejectPromotionEntityTableName() + " ( advertiser_id, promotion_id, content, reject_reason, suggestion ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.PromotionId,
			v.Content,
			v.RejectReason,
			v.Suggestion,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
