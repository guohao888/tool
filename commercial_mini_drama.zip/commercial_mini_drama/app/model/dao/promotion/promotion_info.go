package promotion

import (
	"context"
	"errors"
	"github.com/jinzhu/gorm"
	"goserver/app/common/dto/page"
	promotionDto "goserver/app/common/dto/promotion"
	promotionRepo "goserver/app/common/repository/promotion"
	"goserver/app/library/driver/dorisdb"
)

type UpdatePromotionValues struct {
	PromotionID   string
	PromotionURL  string
	PromotionName string
	StateCode     int8
}

type PromotionInfoDao struct {
	Ctx context.Context
}

func NewPromotionInfoDao(ctx context.Context) *PromotionInfoDao {
	return &PromotionInfoDao{Ctx: ctx}
}

func (d *PromotionInfoDao) GetInfoByRequestId(requestId string) (*promotionRepo.PromotionInfoEntity, error) {
	db := dorisdb.DorisClient()

	var res promotionRepo.PromotionInfoEntity
	err := db.Table(promotionRepo.PromotionInfoTableName()).
		Where("request_id = ?", requestId).
		First(&res).
		Error

	return &res, err
}

func (d *PromotionInfoDao) PromotionList(params *promotionDto.ListReq) (*page.Paginator, error) {
	db := dorisdb.DorisClient()
	promotionInfoTableName := promotionRepo.PromotionInfoTableName()
	q := db.Table(promotionInfoTableName)  // 分页
	q2 := db.Table(promotionInfoTableName) // 查询
	// 总数量
	var total int64
	// 应用相同的查询条件
	applyConditions := func(query *gorm.DB) *gorm.DB {
		if params.AppType != 0 {
			query = query.Where("app_type = ?", params.AppType)
		}
		if params.PackageId != 0 {
			query = query.Where("package_id = ?", params.PackageId)
		}
		if params.BoundPackageId != 0 {
			query = query.Where("bound_package_id = ?", params.BoundPackageId)
		}
		if params.BookId != "" {
			query = query.Where("book_id = ?", params.BookId)
		}
		if params.UserName != "" {
			query = query.Where("user_name = ?", params.UserName)
		}
		if params.StateCode != 0 {
			query = query.Where("state_code = ?", params.StateCode)
		}
		return query
	}
	q = applyConditions(q)
	q2 = applyConditions(q2)

	err := q2.Count(&total).Error
	if err != nil {
		return nil, err
	}

	// 分页
	pagination := params.Pagination
	q = q.Select("*").
		Order("created_at desc").
		Offset(pagination.GetOffset()).
		Limit(pagination.GetLimit())

	// 分页数据
	var res []promotionRepo.PromotionInfoEntity
	err = q.Find(&res).Error
	if err != nil {
		return nil, err
	}

	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)
	return &paginator, nil
}

func (d *PromotionInfoDao) Update(requestId string, data UpdatePromotionValues) error {
	db := dorisdb.DorisClient()
	result := db.Table(promotionRepo.PromotionInfoTableName()).
		Where("request_id = ?", requestId).
		Updates(data)
	if result.Error != nil {
		return result.Error
	} else if result.RowsAffected == 0 {
		return errors.New("未找到匹配的记录")
	} else {
		return nil
	}
}

func (d *PromotionInfoDao) Insert(data *promotionRepo.PromotionInfoEntity) error {
	db := dorisdb.DorisClient()
	return db.Table(promotionRepo.PromotionInfoTableName()).Create(data).Error
}

func (d *PromotionInfoDao) Delete(requestId string) error {
	db := dorisdb.DorisClient()
	return db.Table(promotionRepo.PromotionInfoTableName()).
		Where("request_id = ?", requestId).
		Delete(&promotionRepo.PromotionInfoEntity{}).Error
}
