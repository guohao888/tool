package mediareport

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	repo "goserver/app/common/repository/mediareport"
	"goserver/app/common/repository/warning"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// ReportProjectHourDao 巨量项目小时DAO
type ReportProjectHourDao struct {
	Ctx context.Context
}

func NewReportProjectHourDao(ctx context.Context) *ReportProjectHourDao {
	return &ReportProjectHourDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (r *ReportProjectHourDao) InsertBatchSize(data []*repo.ReportProjectHourEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = r.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *ReportProjectHourDao) buildInsertSentence(tx *gorm.DB, data []*repo.ReportProjectHourEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.ReportProjectHourTableName() + " ( search_date, search_hour, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt, created_time , updated_time, stat_attribution_micro_game_24h_amount, attribution_micro_game_24h_roi, stat_micro_game_0d_amount, attribution_micro_game_0d_ltv, attribution_micro_game_3d_ltv, attribution_micro_game_7d_ltv ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.SearchDate,
			v.SearchHour,
			v.AdvertiserId,
			v.ProjectId,
			v.ProjectName,
			v.ShowCnt,
			v.Click,
			v.Active,
			v.ActivePay,
			v.Cost,
			v.ConvertCnt,
			v.CreatedTime,
			v.UpdatedTime,
			v.StatAttributionMicroGame24HAmount,
			v.AttributionMicroGame24HRoi,
			v.StatMicroGame0DAmount,
			v.AttributionMicroGame0DLtv,
			v.AttributionMicroGame3DLtv,
			v.AttributionMicroGame7DLtv,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func (r *ReportProjectHourDao) FindRawRoi() (res []warning.RawRoi, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT substr(cos.date, 1, 10) as date, cos.`hour`, round(sum(cost), 2) as cost, round(sum(income), 2) as income, round(sum(income)/sum(cost), 2) as roi FROM ( SELECT date(search_date) as date, search_hour as hour, advertiser_id, project_id, sum(cost/1.02) as cost, sum(stat_micro_game_0d_amount*0.98*0.9) as income FROM report_project_hour WHERE date(search_date) = CURRENT_DATE GROUP BY date(search_date), search_hour, advertiser_id, project_id ) cos LEFT JOIN ( SELECT advertiser_id, project_id FROM project_info WHERE delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME' ) pro ON cos.advertiser_id = pro.advertiser_id AND cos.project_id = pro.project_id WHERE pro.advertiser_id IS NOT NULL GROUP BY cos.date, cos.`hour` ORDER BY cos.`hour` DESC"
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

func (r *ReportProjectHourDao) FindRawRoiSum() (res []warning.RawRoi, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT '汇总' as date, round(sum(cost), 2) as cost, round(sum(income), 2) as income, round(sum(income)/sum(cost), 2) as roi FROM ( SELECT date(search_date) as date, search_hour as hour, advertiser_id, project_id, sum(cost/1.02) as cost, sum(stat_micro_game_0d_amount*0.98*0.9) as income FROM report_project_hour WHERE date(search_date) = CURRENT_DATE GROUP BY date(search_date), search_hour, advertiser_id, project_id ) cos LEFT JOIN ( SELECT advertiser_id, project_id FROM project_info WHERE delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME' ) pro ON cos.advertiser_id = pro.advertiser_id AND cos.project_id = pro.project_id WHERE pro.advertiser_id IS NOT NULL "
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

type RawAlbumMsg struct {
	ProductId string
	Name      string
	Cost      float64
	Hcost     float64
	Income    float64
	Roi       float64
}

func (r *ReportProjectHourDao) FindRawAlbum(cost string) (res []RawAlbumMsg, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT book_name as name, round(sum(media_cost), 2) as cost, round(sum(case when `hour`= HOUR(CURRENT_TIME) then media_cost else 0 end), 2) as hcost, round(sum(income),2) as income, round(sum(income)/sum(media_cost), 2) as roi FROM roi_project_hourly_today WHERE media = '端原生' GROUP BY book_name HAVING sum(media_cost) > '" + cost + "' AND sum(income)/sum(media_cost) < 0.7 ORDER BY cost DESC"
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

func (r *ReportProjectHourDao) FindRawAlbumSpeed(cost string) (res []RawAlbumMsg, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT book_name as name, round(sum(media_cost), 2) as cost, round(sum(case when `hour`= HOUR(CURRENT_TIME) then media_cost else 0 end), 2) as hcost, round(sum(income),2) as income, round(sum(income)/sum(media_cost), 2) as roi FROM roi_project_hourly_today WHERE media = '端原生' GROUP BY book_name HAVING sum(case when `hour`= HOUR(CURRENT_TIME) then media_cost else 0 end) > '" + cost + "' ORDER BY cost DESC"
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}
