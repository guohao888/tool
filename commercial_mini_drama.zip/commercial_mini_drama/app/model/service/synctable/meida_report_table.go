package synctable

import (
	"context"
	"goserver/app/model/dao/material"
	"goserver/app/model/dao/synctable"
	"time"
)

type MediaIncomeService struct {
	Ctx context.Context
}

func NewMediaIncomeService(ctx context.Context) *MediaIncomeService {
	return &MediaIncomeService{Ctx: ctx}
}

// QueryAndSaveMediaInfos 查询保存消耗数据
func (t *MediaIncomeService) QueryAndSaveMediaInfos(isHistory int) map[string]string {
	mediaIncomeDao := synctable.NewMediaIncomeDao(t.Ctx)
	var execTime string
	errList := make(map[string]string)
	startDate := time.Now().Add(-172800 * time.Second)
	endDate := time.Now().Add(-86400 * time.Second)
	// isHistory = 1 刷新历史数据记录
	if isHistory == 1 {
		for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
			execTime = currentDate.Format(time.DateOnly)
			errMediaCost := mediaIncomeDao.BuildAggMediaReportEntityDate(execTime)
			if errMediaCost != nil {
				errList[execTime] = errMediaCost.Error()
				continue
			}
			errNoRelate := mediaIncomeDao.BuildAggMediaReportNoRelateEntityDate(execTime)
			if errNoRelate != nil {
				errList[execTime] = errNoRelate.Error()
				continue
			}
		}
	} else {
		execTime = time.Now().Format(time.DateOnly)
		errMediaCost := mediaIncomeDao.BuildAggMediaReportEntityDate(execTime)
		if errMediaCost != nil {
			errList[execTime] = errMediaCost.Error()
		}
		errNoRelate := mediaIncomeDao.BuildAggMediaReportNoRelateEntityDate(execTime)
		if errNoRelate != nil {
			errList[execTime] = errNoRelate.Error()
		}
	}
	return errList

}

// QueryAndSaveFinalInfos 查询保存最终数据
func (t *MediaIncomeService) QueryAndSaveFinalInfos(isHistory int) map[string]string {
	finalDao := material.NewReportDataDao(t.Ctx)

	var execTime string
	errList := make(map[string]string)
	startDate := time.Now().Add(-172800 * time.Second)
	endDate := time.Now().Add(-86400 * time.Second)
	if isHistory == 1 {
		for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
			execTime = currentDate.Format(time.DateOnly)
			errHasCostAndIncome := finalDao.BuildAggHasReferralFinalEntityData(execTime)
			if errHasCostAndIncome != nil {
				errList[execTime] = errHasCostAndIncome.Error()
				continue
			}
			errHasCostNoIncome := finalDao.BuildAggNoReferralFinalEntityData(execTime)
			if errHasCostNoIncome != nil {
				errList[execTime] = errHasCostNoIncome.Error()
				continue
			}
		}
	} else {
		execTime = time.Now().Format(time.DateOnly)
		errHasCostAndIncome := finalDao.BuildAggHasReferralFinalEntityData(execTime)
		if errHasCostAndIncome != nil {
			errList[execTime] = errHasCostAndIncome.Error()
		}
		errHasCostNoIncome := finalDao.BuildAggNoReferralFinalEntityData(execTime)
		if errHasCostNoIncome != nil {
			errList[execTime] = errHasCostNoIncome.Error()
		}
	}
	return errList
}

// QueryAndSaveMediaInfosRe 查询保存消耗数据
func (t *MediaIncomeService) QueryAndSaveMediaInfosRe(isHistory int) map[string]string {
	mediaIncomeDao := synctable.NewMediaIncomeDao(t.Ctx)
	var execTime string
	errList := make(map[string]string)
	startDate := time.Date(2025, time.March, 1, 0, 0, 0, 0, time.UTC)
	endDate := time.Date(time.Now().Year(), time.Now().Month(), time.Now().AddDate(0, 0, -1).Day(), 0, 0, 0, 0, time.UTC)
	// isHistory = 1 刷新历史数据记录
	if isHistory == 1 {
		for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
			execTime = currentDate.Format(time.DateOnly)
			errMediaCost := mediaIncomeDao.BuildAggMediaReportEntityDateReplenish(execTime)
			if errMediaCost != nil {
				errList[execTime] = errMediaCost.Error()
				continue
			}
			errNoRelate := mediaIncomeDao.BuildAggMediaReportNoRelateEntityDateReplenish(execTime)
			if errNoRelate != nil {
				errList[execTime] = errNoRelate.Error()
				continue
			}
		}
	} else {
		execTime = time.Now().Format(time.DateOnly)
		errMediaCost := mediaIncomeDao.BuildAggMediaReportEntityDate(execTime)
		if errMediaCost != nil {
			errList[execTime] = errMediaCost.Error()
		}
		errNoRelate := mediaIncomeDao.BuildAggMediaReportNoRelateEntityDate(execTime)
		if errNoRelate != nil {
			errList[execTime] = errNoRelate.Error()
		}
	}
	return errList

}
