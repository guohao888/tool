package cipher

import (
	"encoding/hex"
	"github.com/thinkoner/openssl"
)

func AesEcbDecrypt(content, key string) []byte {
	src, err := hex.DecodeString(content)
	if err != nil {
		panic(err)
	}

	k := []byte(key)
	dst, err := openssl.AesECBDecrypt(src, k, openssl.PKCS7_PADDING)
	if err != nil {
		panic(err)
	}

	return dst
}

func AesEcbEncrypt(content []byte, key string) string {
	k := []byte(key)
	dst, err := openssl.AesECBEncrypt(content, k, openssl.PKCS7_PADDING)
	if err != nil {
		panic(err)
	}
	src := hex.EncodeToString(dst)
	return src
}

func AesCbcDecrypt(content, key, iv string) ([]byte, error) {
	dst, err := openssl.AesCBCDecrypt([]byte(content), []byte(key), []byte(iv), openssl.PKCS7_PADDING)
	if err != nil {
		return nil, err
	}

	return dst, nil
}

func AesCbcEncrypt(content []byte, key, iv string) (string, error) {
	dst, err := openssl.AesCBCEncrypt(content, []byte(key), []byte(iv), openssl.PKCS7_PADDING)
	if err != nil {
		return "", err
	}

	return string(dst), err
}

func AesCbcZerosPaddingEncrypt(content, key, iv []byte) ([]byte, error) {
	dst, err := openssl.AesCBCEncrypt(content, key, iv, openssl.ZEROS_PADDING)
	if err != nil {
		return nil, err
	}
	return dst, err
}
