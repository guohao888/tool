package warning

import (
	"context"
	"github.com/jinzhu/gorm"
	"goserver/app/common/repository/warning"
	"goserver/app/library/driver/dorisdb"
	"strings"
)

type AlbumDao struct {
	Ctx context.Context
}

func NewAlbumDao(ctx context.Context) *AlbumDao {
	return &AlbumDao{Ctx: ctx}
}

func (a *AlbumDao) FindAlbumList(ids []string) (res []warning.Album, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT a.book_id as album_id, a.book_name as album_name, a.cost as media_cost, b.cost as hour_cost, round(a.income/a.cost, 2) as roi FROM ( SELECT book_id, book_name, round(sum(media_cost), 2) as cost, round(sum(income), 2) as income FROM roi_project_hourly_today WHERE date(date) = CURRENT_DATE AND book_id IN (" + strings.Join(ids, ",") + ") GROUP BY book_id, book_name ) a LEFT JOIN ( SELECT book_id, book_name, sum(media_cost) as cost FROM roi_project_hourly_today WHERE date(date) = CURRENT_DATE AND `hour` = HOUR(CURRENT_TIME)-1 GROUP BY book_id, book_name ) b ON a.book_id = b.book_id AND a.book_name = b.book_name"
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}
