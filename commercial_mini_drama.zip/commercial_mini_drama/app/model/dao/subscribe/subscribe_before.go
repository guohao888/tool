package subscribe

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/common/repository/subscribe"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
	"time"
)

type BeforeSubscribeDao struct {
	Ctx context.Context
}

func NewBeforeSubscribeDao(ctx context.Context) *BeforeSubscribeDao {
	return &BeforeSubscribeDao{Ctx: ctx}
}

// InsertBatchSizeBeforeTask 插入更新数据
func (b *BeforeSubscribeDao) InsertBatchSizeBeforeTask(data []*subscribe.BeforeSubscribeEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = b.batchInsertBefore(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (b *BeforeSubscribeDao) batchInsertBefore(tx *gorm.DB, data []*subscribe.BeforeSubscribeEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + subscribe.BeforeSubscribeEntityTableName() + " ( message_id, subscribe_task_id, advertiser_id, status ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?),"
		vals = append(vals,
			v.MessageId,
			v.SubscribeTaskId,
			v.AdvertiserId,
			v.Status,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// BeforeAdvertiserList 稳定账号
func (b *BeforeSubscribeDao) BeforeAdvertiserList(date string) ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	beforeDate, _ := time.ParseInLocation(time.DateOnly, date, time.Local)
	bDate := beforeDate.Add(86400).Format(time.DateOnly)
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT advertiser_id FROM (SELECT advertiser_id FROM subscribe_today WHERE date(created_at) = '" + date + "' UNION SELECT advertiser_id FROM subscribe_before WHERE date(created_at) = '" + bDate + "' ) a GROUP BY advertiser_id ) has LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) ac ON has.advertiser_id = ac.advertiser_id "
	err := db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	err = UpdateSubscribeBeforeStatus(res)
	return res, err
}

func (b *BeforeSubscribeDao) ReplenishManager(date string) ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	//sql := "SELECT advertiser_id, user_id FROM ( SELECT advertiser_id, oauth_id FROM oauth_account ) oa LEFT JOIN ( SELECT oauth_id, user_id, CAST(ext->'user_name' as CHAR) as user_name FROM oauth ) ou ON oa.oauth_id = ou.oauth_id WHERE user_name ='账管42-马国组'"
	//sql := "SELECT oc.advertiser_id, user_id FROM ( SELECT has.advertiser_id FROM ( SELECT ur.advertiser_id FROM ( SELECT promotion_id FROM tomato_iaa_award WHERE date(event_date) = '" + date + "' GROUP BY promotion_id ) o LEFT JOIN ( SELECT pu.advertiser_id, dpu.promotion_id FROM ( SELECT advertiser_id, `code` FROM promotion_url_info GROUP BY advertiser_id, `code` ) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url ) ur ON o.promotion_id = ur.promotion_id ) has LEFT JOIN ( SELECT advertiser_id FROM report_project_hour WHERE date(search_date) = '" + date + "' GROUP BY advertiser_id ) ad ON has.advertiser_id = ad.advertiser_id WHERE ad.advertiser_id is null ) t LEFT JOIN  ( SELECT advertiser_id, user_id FROM oauth_account ) oc ON oc.advertiser_id = t.advertiser_id "
	//sql := "SELECT advertiser_id, user_id FROM ( SELECT advertiser_id, oauth_id FROM oauth_account ) oc LEFT JOIN ( SELECT user_id, cast(ext->'user_name' as char) as user_name, oauth_id FROM oauth ) oa ON oc.oauth_id = oa.oauth_id WHERE oa.user_name in ( '管家32-景年组','账管33-马国组','账管34-何志强组','账管35-马国组','账管36-张单玉组','账管37-肖景年组','账管38-马国组','账管39-马国组','账管40-马国组','账管41-马国组','账管19 肖景年','账管16 张单玉','账管17 马国','账管48-马国','账管49-景年组' )"
	sql := "SELECT advertiser_id, user_id FROM oauth_account WHERE advertiser_id in ('1802273749683212','1807869803818059','1810706002887899','1811327613420714','1811327978583051','1819306358846554','1819398886522892','1819399232216075','1819405407270217','1820129584135450','1820129956590601','1820132542545179','1820132608571674','1821298416377044','1822015491844186','1822015493656772','1823936684394755','1823937452233740','1824551350158937','1824551683307787','1824551683844121','1825000184717731','1825001216011292','1825110973093940','1826807744056603','1826913499095203','1826917561834756','1826917565187140','1826917684399116','1826917923415243','1826918057376787','1826918285342283','1826919353489673','1826919468526659','1826919698975747','1826919958776858','1826919959603652','1826919962119251','1826919963699465','1826920082296067','1826920085522387','1826920203125001','1826920203910148','1826920326161420','1826920329045003','1826920450174691','1826920451762186','1826920452594004','1826920535239690','1826920574389379','1826920821421337','1826920935614867','1826921545141324','1826921779994953','1826921875160075','1826922007292932','1826922114094596','1826922115473667','1826922117357579','1826922223814659','1826922324106564','1826922723036403','1826922851102915','1826922955611467','1826922957096201','1826923177075147','1826923177617419','1826923182016970','1826923300206435','1826923981253700','1826924155508748','1826924339570058','1826924340187050','1826924358681987','1826924669335763','1826924690892812','1826924870094857','1827103119073497','1827105530325259','1827105666828617','1827105667575948','1827106033102347','1827106231693322','1827106611278538','1827106612401356','1827106707831808','1827107318095882','1827107710910922','1827107853139977','1827109387732313','1827176681968875','1827177228895833','1827177369615370','1827177726593098','1827178314204169','1827181763258379','1827188174318602','1827449199108681','1827449200113993','1827449246439626')"
	err := db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	return res, err
}

// UpdateSubscribeBeforeStatus 更新已拉取的数据状态
func UpdateSubscribeBeforeStatus(listAd []accountrepo.OauthAccountEntity) (err error) {

	batchPage := dao.BatchPage(len(listAd), 999)
	for i := 0; i < batchPage; i++ {
		start := i * 999
		end := (i + 1) * 999
		if end > len(listAd) {
			end = len(listAd)
		}
		var list string
		for k, v := range listAd[start:end] {
			if k == len(listAd[start:end])-1 {
				list += v.AdvertiserId
			} else {
				list += v.AdvertiserId + ","
			}
		}
		db := dorisdb.DorisClient()
		sql := "UPDATE subscribe_before SET `status` = 1 WHERE advertiser_id IN (" + list + ") "
		err = db.Exec(sql).Error
	}
	return
}

// UnionAdvertiserList 账单数据拉取
func (b *BeforeSubscribeDao) UnionAdvertiserList(date string) ([]accountrepo.OauthAccountEntity, error) {
	db := dorisdb.DorisClient()
	var res []accountrepo.OauthAccountEntity
	beforeDate, _ := time.ParseInLocation(time.DateOnly, date, time.Local)
	bDate := beforeDate.Add(86400).Format(time.DateOnly)
	//sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT t.advertiser_id FROM ( SELECT advertiser_id FROM assist_account WHERE user_id = '1770643181547547' ) t LEFT JOIN ( SELECT advertiser_id FROM ( SELECT advertiser_id FROM subscribe_today WHERE date(created_at) = '" + date + "' UNION SELECT advertiser_id FROM subscribe_before WHERE date(created_at) = '" + bDate + "' ) a GROUP BY advertiser_id) t2 ON t.advertiser_id = t2.advertiser_id WHERE t2.advertiser_id IS NOT NULL ) has LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) ac ON has.advertiser_id = ac.advertiser_id "
	sql := "SELECT has.advertiser_id as advertiser_id, ac.user_id as user_id FROM ( SELECT advertiser_id FROM (SELECT advertiser_id FROM subscribe_today WHERE date(created_at) = '" + date + "' UNION SELECT advertiser_id FROM subscribe_before WHERE date(created_at) = '" + bDate + "' ) a GROUP BY advertiser_id ) has LEFT JOIN ( SELECT advertiser_id, user_id FROM oauth_account ) ac ON has.advertiser_id = ac.advertiser_id "
	err := db.Raw(sql).Scan(&res).Error
	return res, err
}
