package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	accountsvc "goserver/app/model/service/accounts"
)

func OauthRefreshPush(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.OauthRefreshExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
	}

	media := repository.MediaToutiao

	// 换取授权令牌接口，并将token和数据入库
	oauthService := accountsvc.NewOauthPushService(ctx)
	err := oauthService.OauthPushRefresh(media, params)
	if err != nil {
		panic(fmt.Errorf("头条oauth协管数据刷新失败, %w", err))
	}
	return "头条oauth协管数据刷新成功"
}
