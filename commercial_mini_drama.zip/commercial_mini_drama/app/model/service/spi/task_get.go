package spi

import (
	"context"
	"encoding/json"
	"fmt"
	"goserver/app/common/dto/spidto"
	commonRoi "goserver/app/common/repository/roi"
	roiDao "goserver/app/model/dao/roi"
	"io"
	"math/rand"
	"net/http"
	"net/url"
	"strconv"
	"time"

	ad_open_sdk_go "github.com/oceanengine/ad_open_sdk_go"
	"github.com/oceanengine/ad_open_sdk_go/config"
	sdk_models "github.com/oceanengine/ad_open_sdk_go/models"
)

const appId = int64(1821364505845059)
const secret = "591a41a72f7f3e05792a7fe398661d536842d69f"

type ApiOpenApi2SpiTaskGetGetRequest struct {
	AppId        int64                         `json:"app_id,omitempty"`
	Count        int64                         `json:"count,omitempty"`
	Cursor       int64                         `json:"cursor,omitempty"`
	EndDate      string                        `json:"end_date,omitempty"`
	Page         int64                         `json:"page,omitempty"`
	PageSize     int64                         `json:"page_size,omitempty"`
	ServiceLabel string                        `json:"service_label,omitempty"`
	StartDate    string                        `json:"start_date,omitempty"`
	Status       sdk_models.SpiTaskGetV2Status `json:"status,omitempty"`
	SubscribeId  int64                         `json:"subscribe_id,omitempty"`
}

// BaseResponse 外层响应结构体
type BaseResponse struct {
	Code      int    `json:"code"`
	Message   string `json:"message"`
	RequestID string `json:"request_id"`
	Data      struct {
		CursorInfo struct {
			Count   int64 `json:"count"`
			Cursor  int64 `json:"cursor"`
			HasMore bool  `json:"has_more"`
		} `json:"cursor_info"`
		List []ListData `json:"list"`
	} `json:"data"`
}

// ListData 表示 data.list 中的每个元素
type ListData struct {
	TaskId int64  `json:"task_id"`
	Data   string `json:"data"`
}

type TaskGetService struct {
	Ctx       context.Context
	Token     string
	Req       *ApiOpenApi2SpiTaskGetGetRequest
	TaskData  []spidto.BaseRequest
	StartTime string //推送开始时间
	EndTime   string //推送结束
	Cursor    int64
}

//return "2025-04-28 00:00:00", "2025-04-28 01:00:00"

func NewTaskGetService(c context.Context, s string, e string, cur int64) *TaskGetService {
	return &TaskGetService{
		Ctx:       c,
		StartTime: s,
		EndTime:   e,
		Cursor:    cur,
	}
}

func (s *TaskGetService) TaskGet() {

	// fmt.Printf("开始时间: %s, 结束时间: %s\n", s.StartTime, s.EndTime)
	// return
	s.setRequest()
	s.execReq()
}

func (s *TaskGetService) execReq() {
	i := 1
	c := 1
	for {
		s.TaskData = []spidto.BaseRequest{}
		fmt.Println("第", i, "轮请求开始")
		resStr, err := s.buildRequest()
		if err != nil {
			break
		}
		pCode, taskInfo, cursor, err := s.parseResponse(resStr)
		if pCode != 0 {
			fmt.Println("第", c, "次重复第", i, "轮请求")
			c++
			if c >= 10 {
				return
				//break
			}
			time.Sleep(1 * time.Second)
			continue
		}
		i++
		fmt.Println("cursor：", cursor)
		s.TaskData = append(s.TaskData, taskInfo...)
		if err == nil && cursor > 0 {
			s.Req.Cursor = cursor
		} else {
			break
		}
		// 批量入库
		s.batchSaveToDB()
		c = 1
		time.Sleep(getSleepTime())
		//if i >= 2 {
		//	break
		//}
	}
	return
}

func getSleepTime() time.Duration {
	rand.Seed(time.Now().UnixNano())
	// 生成 1000 到 3000 之间的随机整数
	randomDelay := rand.Intn(500) + 400
	// 将随机延迟时间转换为时间间隔类型
	return time.Duration(randomDelay) * time.Millisecond
}

// ParseResponse 解析响应数据并返回 BaseRequest 数组
func (s *TaskGetService) parseResponse(jsonStr string) (int, []spidto.BaseRequest, int64, error) {
	// 1. 解析外层 JSON 到 BaseResponse
	var resp BaseResponse
	if err := json.Unmarshal([]byte(jsonStr), &resp); err != nil {
		fmt.Printf("解析外层响应失败: %v", err)
		return -1, nil, 0, fmt.Errorf("解析外层响应失败: %v", err)
	}

	// 2. 解析每个 list 项中的 data 字段到 BaseRequest
	var requests []spidto.BaseRequest
	for i, item := range resp.Data.List {
		// 首先解析外层的 data 字段
		var rawRequest struct {
			MessageID       string  `json:"message_id"`
			SubscribeTaskID int64   `json:"subscribe_task_id"`
			AdvertiserIDs   []int64 `json:"advertiser_ids"`
			AccountRelation string  `json:"account_relation"`
			ServiceLabel    string  `json:"service_label"`
			PublishTime     int64   `json:"publish_time"`
			Data            string  `json:"data"`
			Timestamp       int64   `json:"timestamp"`
			Nonce           int64   `json:"nonce"`
		}

		if err := json.Unmarshal([]byte(item.Data), &rawRequest); err != nil {
			fmt.Printf("解析 list[%d] 失败: %v", i, err)
			return -1, nil, 0, fmt.Errorf("解析 list[%d] 失败: %v", i, err)
		}

		// 创建最终的 BaseRequest
		request := spidto.BaseRequest{
			TaskID:          item.TaskId,
			MessageID:       rawRequest.MessageID,
			SubscribeTaskID: rawRequest.SubscribeTaskID,
			AdvertiserIDs:   rawRequest.AdvertiserIDs,
			ServiceLabel:    rawRequest.ServiceLabel,
			PublishTime:     rawRequest.PublishTime,
			Timestamp:       rawRequest.Timestamp,
			Nonce:           rawRequest.Nonce,
		}

		// 解析 account_relation 字符串
		var accountRelation struct {
			CoreUserIDs map[string][]int64 `json:"core_user_ids"`
		}
		if err := json.Unmarshal([]byte(rawRequest.AccountRelation), &accountRelation); err != nil {
			fmt.Printf("解析 account_relation[%d] 失败: %v", i, err)
			continue
		}
		request.AccountRelation = accountRelation

		// 解析 data 字符串
		var dataContent struct {
			AppID       int64   `json:"app_id"`
			CoreUserID  int64   `json:"core_user_id"`
			MaterialIDs []int64 `json:"material_ids"`
		}
		if err := json.Unmarshal([]byte(rawRequest.Data), &dataContent); err != nil {
			fmt.Printf("解析 data[%d] 失败: %v", i, err)
			continue
		}
		request.Data = dataContent

		requests = append(requests, request)
	}

	var cursor int64
	if resp.Data.CursorInfo.HasMore {
		cursor = resp.Data.CursorInfo.Cursor
	}
	return resp.Code, requests, cursor, nil
}

func (s *TaskGetService) batchSaveToDB() {
	fmt.Println("数据条数：", len(s.TaskData))

	var data []*commonRoi.SpiRequestsDataEntity
	for i, v := range s.TaskData {
		// 数据验证
		if v.TaskID == 0 {
			fmt.Printf("跳过第 %d 条数据: TaskID 为空\n", i+1)
			continue
		}

		// 将 AdvertiserIDs 转换为 JSON 字符串
		advertiserIDsJSON, err := json.Marshal(v.AdvertiserIDs)
		if err != nil {
			fmt.Printf("第 %d 条数据序列化 AdvertiserIDs 失败: %v, 数据内容: %+v\n", i+1, err, v.AdvertiserIDs)
			continue
		}

		// 将 AccountRelation 转换为 JSON 字符串
		accountRelationJSON, err := json.Marshal(v.AccountRelation)
		if err != nil {
			fmt.Printf("第 %d 条数据序列化 AccountRelation 失败: %v, 数据内容: %+v\n", i+1, err, v.AccountRelation)
			continue
		}

		// 将 Data 转换为 JSON 字符串
		dataJSON, err := json.Marshal(v.Data)
		if err != nil {
			fmt.Printf("第 %d 条数据序列化 Data 失败: %v, 数据内容: %+v\n", i+1, err, v.Data)
			continue
		}

		// 确保所有字段都有值，避免空值
		messageID := v.MessageID
		if messageID == "" {
			messageID = "0"
		}

		subscribeTaskID := v.SubscribeTaskID
		if subscribeTaskID == 0 {
			subscribeTaskID = 0
		}

		serviceLabel := v.ServiceLabel
		if serviceLabel == "" {
			serviceLabel = "report.material.activeprogram"
		}

		publishTime := v.PublishTime
		if publishTime == 0 {
			publishTime = time.Now().UnixMilli()
		}

		timestamp := v.Timestamp
		if timestamp == 0 {
			timestamp = time.Now().UnixMilli()
		}

		nonce := v.Nonce
		if nonce == 0 {
			nonce = time.Now().UnixNano()
		}

		// 创建实体对象
		enData := &commonRoi.SpiRequestsDataEntity{
			TaskID:          v.TaskID,
			MessageID:       messageID,
			SubscribeTaskID: subscribeTaskID,
			AdvertiserIDs:   string(advertiserIDsJSON),
			AccountRelation: string(accountRelationJSON),
			ServiceLabel:    serviceLabel,
			PublishTime:     publishTime,
			Timestamp:       timestamp,
			Nonce:           nonce,
			Data:            string(dataJSON),
			IsUpdated:       0,
		}

		// 验证实体对象的必填字段
		if enData.TaskID == 0 {
			fmt.Printf("跳过第 %d 条数据: TaskID 为空\n", i+1)
			continue
		}

		data = append(data, enData)
	}

	if len(data) == 0 {
		fmt.Println("没有有效数据需要入库")
		return
	}

	// 调用DAO层方法入库
	spiDao := roiDao.NewSpiRequestsDao(s.Ctx)

	err := spiDao.AddSpiTasks(data, 0)
	if err != nil {
		fmt.Println("入库失败：", err.Error())
		return
	}

	//if err := spiDao.AddOSpiRequests(data, 0); err != nil {
	//	fmt.Println("入库失败：", err.Error())
	//	return
	//}
	fmt.Printf("成功入库 %d 条数据\n", len(data))
}

func (s *TaskGetService) setRequest() {
	s.Token, _ = s.GetAppAccessToken()

	//configuration := config.NewConfiguration()
	//apiClient := ad_open_sdk_go.Init(configuration)
	//apiClient.SetLogEnable(true)
	sTime, eTime := s.setTimeRange()

	s.Req = &ApiOpenApi2SpiTaskGetGetRequest{
		AppId:        appId,
		StartDate:    sTime,
		EndDate:      eTime,
		SubscribeId:  int64(1830361399761290),
		ServiceLabel: "report.material.activeprogram",
		Status:       sdk_models.ALL_SpiTaskGetV2Status,

		Count:  100,      // 页面数据量
		Cursor: s.Cursor, // 页码游标值，第一次拉取，传入0
		//Page:     1,
		//PageSize: 2,
	}
}

func jsonStr() string {
	return `{"code": 0, "message": "OK", "request_id": "20250427141208EA62C31509709D3A306C", "data": {"cursor_info": {"count": 20, "has_more": true, "cursor": 1830531355242794}, "list": [{"task_id": 1830531354832123, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1827823013491722],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"3006538590716890\\\":[1827823013491722]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":3006538590716890,\\\"material_ids\\\":[7068172283694039044,7195734115467821111,7330390826395582527,7483628220005646386,7494359431799914522],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531354833355, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1829543034183882],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"3006538590716890\\\":[1829543034183882]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":3006538590716890,\\\"material_ids\\\":[7288898498934013989,7301561504624623666,7497079515023589413,7497079901383426057],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531354930283, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1826922411851082],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"860279472142000\\\":[1826922411851082]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":860279472142000,\\\"material_ids\\\":[7460345611508400166,7497502943446237247],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531354930299, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1827828984691082],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"1388057832989536\\\":[1827828984691082]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":1388057832989536,\\\"material_ids\\\":[7070029273935101966,7483777281350189068],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531354931659, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1828270921817292],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"1317672828018828\\\":[1828270921817292]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":1317672828018828,\\\"material_ids\\\":[6812596801008025611,7068172283694039044,7183941819243479079,7287516508271902739,7287520523009753148,7288898498934013989,7339115509332017163,7460345611508400166,7489273991225638923,7489274185501458486,7489274240933642294,7489278689331724307],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355090153, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1829542870884612],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"3006538590716890\\\":[1829542870884612]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":3006538590716890,\\\"material_ids\\\":[7491189966169767990],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355091193, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1827823101250122],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"3006538590716890\\\":[1827823101250122]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":3006538590716890,\\\"material_ids\\\":[6835943666189058055,7068172283694039044,7285274466472411192,7287516508271902739,7287520523009753148,7288898498934013989,7460345611508400166,7468515605291237415,7497074029762510899,7497075786052157466,7497075874561359908,7497076088483315724,7497076106235871286,7497076216131141642,7497076284809494567,7497076311439343635],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355092297, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1827645331013632],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"1001021870715323\\\":[1827645331013632]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":1001021870715323,\\\"material_ids\\\":[7287516508271902739,7288898498934013989,7468515605291237415,7468515622109839423,7468515629630521383,7468515631881977895,7468515645794910249,7468515651977789481,7491539350488875017,7491591560887861302,7495293138623135782,7495310604611207206],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355092313, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1828828120410122],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"1651924366798640\\\":[1828828120410122]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":1651924366798640,\\\"material_ids\\\":[7219193108516634684,7496703348445036571],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355092345, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1829711675138122],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"3076891770360940\\\":[1829711675138122]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":3076891770360940,\\\"material_ids\\\":[6835943666189058055,7195734115467821111,7287516508271902739,7288898498934013989,7339115509332017163,7460345611508400166,7486423450463354916],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355096281, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1826924528725002],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"860279472142000\\\":[1826924528725002]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":860279472142000,\\\"material_ids\\\":[6835939016236974088,6835943666189058055,6963146310271008804,6964375719439941668,7068172283694039044,7070029273935101966,7095922885764481038,7287516508271902739,7460345611508400166,7468515605291237415,7468515631881977895,7492639881920053299,7494871250201378827,7496326127545106495,7496326294793732135,7496327071175966731],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355098313, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1830006218637322],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"1651924366798640\\\":[1830006218637322]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":1651924366798640,\\\"material_ids\\\":[7486513034522279977,7497458504720334899],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355098329, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1826919125465092],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"860279472142000\\\":[1826919125465092]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":860279472142000,\\\"material_ids\\\":[6835943666189058055,7068172283694039044,7482122615370137611,7484826779325448202],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355098345, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1829542348482122],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"3006538590716890\\\":[1829542348482122]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":3006538590716890,\\\"material_ids\\\":[6835943666189058055,7068172283694039044,7095922885764481038,7183941819243479079,7197228400187883577,7199479498529554492,7285274466472411192,7287520523009753148,7288898498934013989,7330390826395582527,7460345611508400166,7481254685140434995,7483732286721245238,7483732329242017811,7483732490555228223,7483732549074337819,7483732554107781131,7483732812127584292,7483733559841751077,7485637630886527015],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355100345, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1829725079985412],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"3076891770360940\\\":[1829725079985412]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":3076891770360940,\\\"material_ids\\\":[7095922885764481038,7287516508271902739,7460345611508400166,7494071407224553498,7494089710206386215,7497467886627586089],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355238649, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1827552053800972],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"860279472142000\\\":[1827552053800972]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":860279472142000,\\\"material_ids\\\":[6835943666189058055,7070029273935101966,7205826127080882236,7496324353900167177,7496324585332916236],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355241642, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1827194307248852],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"455656314253339\\\":[1827194307248852]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":455656314253339,\\\"material_ids\\\":[7205826127080882236,7467449738926260263,7468515631881977895,7480018070268608563],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355241689, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1828999736640522],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"4361121324076297\\\":[1828999736640522]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":4361121324076297,\\\"material_ids\\\":[6835943666189058055,6963146310271008804,7205826127080882236,7285274466472411192,7287516508271902739,7287520523009753148,7288898498934013989,7460345611508400166,7468515631881977895,7491344442487767067,7491344453128388635,7491344465577361418,7491349154326495241,7491349186936799269,7491933245816619027,7492306516395196442,7495600516924686345,7495600965229084698,7495604152301699099],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355241705, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1827823549062282],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"3006538590716890\\\":[1827823549062282]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":3006538590716890,\\\"material_ids\\\":[6835943666189058055,7285274466472411192,7287516508271902739,7287520523009753148,7330390826395582527,7426298099335659557,7426346412462686271,7460345611508400166,7480818741381447706,7486513016608112676,7486513034522279977,7496435916028002323,7496435955768098870,7496769932794724364],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}, {"task_id": 1830531355241721, "data": "{\"message_id\":\"0\",\"advertiser_ids\":[1826920812415232],\"account_relation\":\"{\\\"core_user_ids\\\":{\\\"860279472142000\\\":[1826920812415232]}}\",\"service_label\":\"report.material.activeprogram\",\"data\":\"{\\\"app_id\\\":1821364505845059,\\\"core_user_id\\\":860279472142000,\\\"material_ids\\\":[7486803930811547660],\\\"data\\\":\\\"{\\\\\\\"relation_add_ids\\\\\\\":[-1],\\\\\\\"relation_delete_ids\\\\\\\":[],\\\\\\\"sync_config_rule\\\\\\\":{\\\\\\\"rule_condition\\\\\\\":1,\\\\\\\"rule_detail\\\\\\\":[{\\\\\\\"meta_name\\\\\\\":\\\\\\\"stat_cost\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"show_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"click_cnt\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"},{\\\\\\\"meta_name\\\\\\\":\\\\\\\"active\\\\\\\",\\\\\\\"rule_detail_type\\\\\\\":0,\\\\\\\"content\\\\\\\":\\\\\\\"0\\\\\\\"}],\\\\\\\"param\\\\\\\":{\\\\\\\"monitor_interval\\\\\\\":10,\\\\\\\"metrics\\\\\\\":[\\\\\\\"*\\\\\\\"],\\\\\\\"data_granularity\\\\\\\":1}},\\\\\\\"created_env\\\\\\\":\\\\\\\"prod\\\\\\\"}\\\"}\",\"publish_time\":1745730747,\"subscribe_task_id\":1830361399761290}", "status": "SUCCESS"}]}}
`
}

func (s *TaskGetService) buildRequest() (string, error) {

	//return jsonStr(), nil

	apiURL := "https://ad.oceanengine.com/open_api/2/spi_task/get/"

	// 设置请求头
	req, err := http.NewRequest("GET", apiURL, nil)
	if err != nil {
		fmt.Println("error创建请求失败: " + err.Error())
		return "", err
	}
	req.Header.Set("APP-Access-Token", s.Token)

	// 设置请求参数
	params := url.Values{}
	params.Add("app_id", strconv.FormatInt(s.Req.AppId, 10))
	params.Add("subscribe_id", strconv.FormatInt(s.Req.SubscribeId, 10))
	params.Add("service_label", s.Req.ServiceLabel)
	params.Add("start_date", s.Req.StartDate)
	params.Add("end_date", s.Req.EndDate)
	params.Add("count", strconv.FormatInt(s.Req.Count, 10))
	params.Add("cursor", strconv.FormatInt(s.Req.Cursor, 10))
	req.URL.RawQuery = params.Encode()

	// 发送请求
	// 打印请求信息
	fmt.Println("请求URL:", req.URL.String())
	//fmt.Println("请求方法:", req.Method)
	//fmt.Println("请求头:")
	//for key, values := range req.Header {
	//	for _, value := range values {
	//		fmt.Printf("\t%s: %s\n", key, value)
	//	}
	//}

	qRes := false
	var qerr error
	var resp *http.Response
	for i := 0; i < 3; i++ {
		client := &http.Client{
			Timeout: 20 * time.Second, // 设置20秒超时
		}
		resp, qerr = client.Do(req)
		if qerr == nil && resp.StatusCode == http.StatusOK {
			qRes = true
			break
		} else {
			time.Sleep(2 * time.Second)
		}
	}

	if !qRes {
		return "", qerr
	}

	defer resp.Body.Close()

	// 打印响应信息
	//fmt.Println("\n响应状态:", resp.Status)
	//fmt.Println("响应头:")
	//for key, values := range resp.Header {
	//	for _, value := range values {
	//		fmt.Printf("\t%s: %s\n", key, value)
	//	}
	//}

	// 读取响应内容
	body, err := io.ReadAll(resp.Body)
	fmt.Println("开始时间：", s.StartTime, " 结束时间", s.EndTime, "响应体:", string(body))
	if err != nil {
		fmt.Println("error: 读取响应内容失败: " + err.Error())
	}
	return string(body), err
}

// sdk 一直执行失败，报token缺失，原因是参数拼错了  app_access_token 拼成了  access_token
func (s *TaskGetService) TaskGetTest() {
	accessToken := "a5fd09d66bcd186d37556db3e370be811c11d035"
	subscribeId := int64(1830361399761290)
	serviceLabel := "report.material.activeprogram"

	configuration := config.NewConfiguration()
	apiClient := ad_open_sdk_go.Init(configuration)
	apiClient.SetLogEnable(true)
	sTime, eTime := s.setTimeRange()

	s.Req = &ApiOpenApi2SpiTaskGetGetRequest{
		AppId:        appId,
		StartDate:    sTime,
		EndDate:      eTime,
		SubscribeId:  subscribeId,
		ServiceLabel: serviceLabel,
		Status:       sdk_models.ALL_SpiTaskGetV2Status,

		Count:  20, // 页面数据量
		Cursor: 0,  // 页码游标值，第一次拉取，传入0
		//Page:     1,
		//PageSize: 2,
	}

	request := s.Req
	ctx := context.Background()
	resp, httpRes, err := apiClient.SpiTaskGetV2Api().
		Get(ctx).
		AccessToken(accessToken).
		AppId(request.AppId).Count(request.Count).Cursor(request.Cursor).EndDate(request.EndDate).Page(request.Page).PageSize(request.PageSize).ServiceLabel(request.ServiceLabel).StartDate(request.StartDate).Status(request.Status).SubscribeId(request.SubscribeId).
		Execute()
	fmt.Println(sdk_models.ToJsonString(resp))
	resBytes, _ := io.ReadAll(httpRes.Body)
	fmt.Println(string(resBytes))
	fmt.Println(err)
}

func (t *TaskGetService) GetAppAccessToken() (string, error) {
	return "547edd0dd5bedf511b1535f990f5cb87bbdab17b", nil
	//request := sdk_models.Oauth2AppAccessTokenRequest{
	//	AppId:  appId,
	//	Secret: secret,
	//}
	//ctx := context.Background()
	//configuration := config.NewConfiguration()
	//apiClient := ad_open_sdk_go.Init(configuration)
	//_, httpRes, err := apiClient.Oauth2AppAccessTokenApi().
	//	Post(ctx).
	//	Oauth2AppAccessTokenRequest(request).
	//	Execute()
	//resBytes, _ := io.ReadAll(httpRes.Body)
	////fmt.Println(sdk_models.ToJsonString(resp))
	//fmt.Println(string(resBytes))
	//fmt.Println(err)
	//return string(resBytes), err

}

func (s *TaskGetService) setTimeRange() (string, string) {
	return s.StartTime, s.EndTime
	//return "2025-04-28 00:00:00", "2025-04-28 01:00:00"
	// 获取当前时间
	now := time.Now()

	eTime := now.Add(-30 * time.Minute)
	//eTime := now.Add(-55 * time.Minute)
	// 当前时间减少2小时
	sTime := now.Add(-1 * time.Hour)

	// 格式化为 yyyy-mm-dd hh:mm:ss
	layout := "2006-01-02 15:04:05" // Go 的特定格式时间
	return sTime.Format(layout), eTime.Format(layout)
}
