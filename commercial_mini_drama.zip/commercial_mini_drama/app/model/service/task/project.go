package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	"goserver/app/model/service/project"
)

// SyncProjectInfos 拉取项目数据
func SyncProjectInfos(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("拉取项目数据时间错误, err: %s", err)
	}
	//
	projectService := project.NewInfoProjectService(ctx)
	for _, crontabDate := range crontabDateList {
		err = projectService.SyncProjectInfos(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("拉取项目数据失败, err: %s", err)
		}
	}
	return "拉取项目数据成功"
}
