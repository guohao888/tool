package kuaishou

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/kuaishou"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// SeriesDao 剧目信息
type SeriesDao struct {
	Ctx context.Context
}

func NewSeriesDao(ctx context.Context) *SeriesDao {
	return &SeriesDao{Ctx: ctx}
}

func (s *SeriesDao) GetSeriesInfoByKeywords(keyword string, limit int) ([]kuaishou.SeriesInfoEntity, error) {
	db := dorisdb.DorisClient()
	q := db.Table(kuaishou.SeriesInfoTableName())
	q = q.Select("distinct series_name")
	q = q.Where("series_name<>''")
	if keyword != "" {
		q = q.Where("series_name LIKE ?", "%"+keyword+"%")
	}
	q = q.Order("series_name ASC")
	if limit > 0 {
		q = q.Offset(0).Limit(limit)
	}
	var res []kuaishou.SeriesInfoEntity
	err := q.Find(&res).Error
	if err != nil {
		return nil, err
	}

	return res, nil
}

// InsertBatchSize 插入更新数据
func (s *SeriesDao) InsertBatchSize(data []*kuaishou.SeriesInfoEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = s.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (s *SeriesDao) buildInsertSentence(tx *gorm.DB, data []*kuaishou.SeriesInfoEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + kuaishou.SeriesInfoTableName() + " ( advertiser_id, series_id, series_name, audit_status, sell_status ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.SeriesId,
			v.SeriesName,
			v.AuditStatus,
			v.SellStatus,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
