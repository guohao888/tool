package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const AccountEmptyEntityTable = "account_pull_empty_detail"

type AccountEmptyEntity struct {
	AccountID   string    `gorm:"column:account_id"`
	ProjectID   string    `gorm:"column:project_id"`
	UserID      string    `gorm:"column:user_id"`
	CreatedTime time.Time `gorm:"column:created_time"`
	ResMsg      string    `gorm:"column:res_msg"`
}

func (*AccountEmptyEntity) TableName() string {
	return AccountPullEmptyTableName()
}

func AccountPullEmptyTableName() string {
	if repository.IsDebugTable(AccountEmptyEntityTable) {
		return AccountEmptyEntityTable + "_dev"
	} else {
		return AccountEmptyEntityTable
	}
}
