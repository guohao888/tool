package repository

import "github.com/spf13/viper"

const EnvDev = "dev"

func IsDebugTable(table string) bool {
	if viper.GetString("env") == EnvDev {
		return true
	}
	return false
}

const (
	SourceAPI = 1 // api数据
)

const (
	MediaToutiao        = "今日头条" // 头条
	MediaKuaishou       = "快手"   // 快手
	MediaKuaishouMagnet = "磁力引擎"
)

const (
	DistributorFanqie = "番茄" // 分销商-番茄
)

const (
	FanQieAppType4  = 4  // 微信付费短剧(IAP)
	FanQieAppType7  = 7  // 抖小付费短剧(IAP)
	FanQieAppType10 = 10 // 抖小IAA短剧
	FanQieAppType13 = 13 // 微小IAA短剧
)

// app_id账号授权类型
const (
	AuthTypeZhangGuan = "账管授权"
	AuthTypeXieGuan   = "协管授权"
)
