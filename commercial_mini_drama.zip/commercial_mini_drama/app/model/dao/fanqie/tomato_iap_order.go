package fanqie

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	dto "goserver/app/common/dto/fanqie"
	repo "goserver/app/common/repository/fanqie"
	"goserver/app/library/driver/dorisdb"
	timeUtil "goserver/app/library/utils/time"
	"goserver/app/model/dao"
	"strconv"
	"strings"
	"time"
)

type TomatoIAPOrderDao struct {
	Ctx context.Context
}

func NewTomatoIAPOrderDao(ctx context.Context) *TomatoIAPOrderDao {
	return &TomatoIAPOrderDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (t *TomatoIAPOrderDao) InsertBatchSize(data []*repo.IAPOrderEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 3000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = t.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (t *TomatoIAPOrderDao) buildInsertSentence(tx *gorm.DB, data []*repo.IAPOrderEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.IAPOrderTableName() + " ( out_trade_no, device_id, distributor_id, app_id, app_name, trade_no, trade_no_raw, open_id, pay_amount, promotion_id, pay_timestamp, pay_date, pay_hour, ip, user_agent, register_time, register_date, register_hour, book_id, book_name, book_gender, book_category, external_id, order_type, union_id ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.OutTradeNo,
			v.DeviceId,
			v.DistributorId,
			v.AppId,
			v.AppName,
			v.TradeNo,
			v.TradeNoRaw,
			v.OpenId,
			v.PayAmount,
			v.PromotionId,
			v.PayTimestamp,
			v.PayDate,
			v.PayHour,
			v.Ip,
			v.UserAgent,
			v.RegisterTime,
			v.RegisterDate,
			v.RegisterHour,
			v.BookId,
			v.BookName,
			v.BookGender,
			v.BookCategory,
			v.ExternalId,
			v.OrderType,
			v.UnionId,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// Req2Entity 请求参数结构转化
func (t *TomatoIAPOrderDao) Req2Entity(data []dto.TomatoIAPOrderReq) error {
	var list []*repo.IAPOrderEntity
	for _, v := range data {
		// 时间戳格式化
		payTime, _ := strconv.Atoi(v.PayTimestamp)
		registerTime, _ := strconv.Atoi(v.RegisterTime)
		payDate := timeUtil.StringFromSecond(int64(payTime))
		payDateTime, _ := time.ParseInLocation(time.DateTime, payDate, time.Local)
		registerDate := timeUtil.StringFromSecond(int64(registerTime))
		registerDateTime, _ := time.ParseInLocation(time.DateTime, registerDate, time.Local)
		info := &repo.IAPOrderEntity{
			OutTradeNo:    v.OutTradeNo,
			DeviceId:      v.DeviceId,
			DistributorId: v.DistributorId,
			AppId:         v.AppId,
			AppName:       v.AppName,
			TradeNo:       v.TradeNo,
			TradeNoRaw:    v.TradeNoRaw,
			OpenId:        v.OpenId,
			PayAmount:     v.PayAmount,
			PromotionId:   v.PromotionId,
			PayTimestamp:  v.PayTimestamp,
			PayDate:       payDateTime,
			PayHour:       payDate[11:13],
			Ip:            v.Ip,
			UserAgent:     v.UserAgent,
			RegisterTime:  v.RegisterTime,
			RegisterDate:  registerDateTime,
			RegisterHour:  registerDate[11:13],
			BookId:        v.BookId,
			BookName:      v.BookName,
			BookGender:    v.BookGender,
			BookCategory:  v.BookCategory,
			ExternalId:    v.ExternalId,
			OrderType:     v.OrderType,
			UnionId:       v.UnionId,
		}
		list = append(list, info)
	}
	err := t.InsertBatchSize(list, 3000)
	return err
}
