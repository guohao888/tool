package synctable

import (
	"github.com/shopspring/decimal"
	"goserver/app/common/repository"
	"time"
)

const MediaIncomeEntityTable = "media_income_table"

// MediaIncomeEntity 媒体素材表
type MediaIncomeEntity struct {
	SearchDate    time.Time       `gorm:"column:search_date"`
	SearchHour    string          `gorm:"column:search_hour"`
	MaterialId    string          `gorm:"column:material_id"`
	FileName      string          `gorm:"column:filename"`
	FileCutter    string          `gorm:"column:file_cutter"`
	Url           string          `gorm:"column:url"`
	PromotionId   string          `gorm:"column:promotion_id"`
	AdvertiserId  string          `gorm:"column:advertiser_id"`
	PromotionName string          `gorm:"column:promotion_name"`
	ReferralId    string          `gorm:"column:referral_id"`
	ShowCnt       int             `gorm:"column:show_cnt"`
	Click         int64           `gorm:"column:click"`
	Active        int64           `gorm:"column:active"`
	ActivePay     int64           `gorm:"column:active_pay"`
	Cost          decimal.Decimal `gorm:"column:cost"`
	ConvertCnt    int64           `gorm:"column:convert_cnt"`
	NewIncome     decimal.Decimal `gorm:"column:new_income"`
	Income        decimal.Decimal `gorm:"column:income"`
	NewPayUser    int64           `gorm:"column:new_pay_user"`
	PayUser       int64           `gorm:"column:pay_user"`
	NewUser       int64           `gorm:"column:new_user"`
	AccIncome     decimal.Decimal `gorm:"column:acc_income"`
	Acc2dayIncome decimal.Decimal `gorm:"column:acc_2day_income"`
	Acc3dayIncome decimal.Decimal `gorm:"column:acc_3day_income"`
	Acc4dayIncome decimal.Decimal `gorm:"column:acc_4day_income"`
	Acc5dayIncome decimal.Decimal `gorm:"column:acc_5day_income"`
	Acc6dayIncome decimal.Decimal `gorm:"column:acc_6day_income"`
	Acc7dayIncome decimal.Decimal `gorm:"column:acc_7day_income"`
}

func (*MediaIncomeEntity) TableName() string {
	return MediaIncomeEntityTable
}

func MediaIncomeTableName() string {
	if repository.IsDebugTable(MediaIncomeEntityTable) {
		return MediaIncomeEntityTable + "dev"
	} else {
		return MediaIncomeEntityTable
	}
}
