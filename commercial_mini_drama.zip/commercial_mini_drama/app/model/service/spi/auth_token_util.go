// Package spi X-Open-Signature签名校验
// https://open.oceanengine.com/labels/7/docs/1722481732805646
package spi

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
)

type AuthTokenUtil struct {
	SecretKey string
}

func (u *AuthTokenUtil) IsValidToken(ctx context.Context, body []byte, signature []byte) bool {
	if len(u.SecretKey) == 0 || len(signature) == 0 {
		return false
	}
	reSignature := u.Signature(body)
	return reSignature == string(signature)
}

func (u *AuthTokenUtil) Signature(body []byte) string {
	hash := hmac.New(sha256.New, []byte(u.SecretKey))
	hash.Write(body)
	hashSum := hash.Sum(nil)
	hashString := hex.EncodeToString(hashSum)
	return hashString
}
