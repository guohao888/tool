package distinct

type IdDistinctMap map[int64]struct{}

func (m IdDistinctMap) DistinctIds() []int64 {
	ids := make([]int64, 0, len(m))
	for k, _ := range m {
		ids = append(ids, k)
	}
	return ids
}

type KeyDistinctMap[K comparable] map[K]struct{}

func (m KeyDistinctMap[K]) KeyDistinct() []K {
	ids := make([]K, 0, len(m))

	for k, _ := range m {
		ids = append(ids, k)
	}

	return ids
}
