package synctable

import (
	"context"
	"goserver/app/model/dao/roi"
	"goserver/app/model/dao/synctable"
	"time"
)

type CostIncomeService struct {
	Ctx context.Context
}

func NewCostIncomeService(ctx context.Context) *CostIncomeService {
	return &CostIncomeService{Ctx: ctx}
}

// QueryAndSaveCostInfos 查询保存消耗数据
func (t *CostIncomeService) QueryAndSaveCostInfos(isHistory int) map[string]string {
	costIncomeDao := synctable.NewCostIncomeDao(t.Ctx)
	var execTime string
	errList := make(map[string]string)
	startDate := time.Date(time.Now().Year(), time.Now().Month(), time.Now().AddDate(0, 0, -3).Day(), 0, 0, 0, 0, time.UTC)
	endDate := time.Date(time.Now().Year(), time.Now().Month(), time.Now().AddDate(0, 0, -1).Day(), 0, 0, 0, 0, time.UTC)
	// isHistory = 1 刷新历史数据记录
	if isHistory == 1 {
		for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
			execTime = currentDate.Format(time.DateOnly)
			errHasCost := costIncomeDao.BuildAggHasCostEntityDate(execTime)
			if errHasCost != nil {
				errList[execTime] = errHasCost.Error()
				continue
			}
			errNoCost := costIncomeDao.BuildAggNoCostEntityDate(execTime)
			if errNoCost != nil {
				errList[execTime] = errNoCost.Error()
				continue
			}
		}
	} else {
		execTime = time.Now().Format(time.DateOnly)
		errHasCost := costIncomeDao.BuildAggHasCostEntityDate(execTime)
		if errHasCost != nil {
			errList[execTime] = errHasCost.Error()
		}
		errNoCost := costIncomeDao.BuildAggNoCostEntityDate(execTime)
		if errNoCost != nil {
			errList[execTime] = errNoCost.Error()
		}
	}
	return errList

}

// QueryAndSaveFinalInfos 查询保存最终数据
func (t *CostIncomeService) QueryAndSaveFinalInfos(isHistory int) map[string]string {
	finalDao := roi.NewReportDataDao(t.Ctx)

	var execTime string
	errList := make(map[string]string)
	startDate := time.Date(time.Now().Year(), time.Now().Month(), time.Now().AddDate(0, 0, -3).Day(), 0, 0, 0, 0, time.UTC)
	endDate := time.Date(time.Now().Year(), time.Now().Month(), time.Now().AddDate(0, 0, -1).Day(), 0, 0, 0, 0, time.UTC)

	if isHistory == 1 {
		for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
			execTime = currentDate.Format(time.DateOnly)
			errHasCostAndIncome := finalDao.BuildAggHasCostAndIncomeFinalEntityData(execTime)
			if errHasCostAndIncome != nil {
				errList[execTime] = errHasCostAndIncome.Error()
				continue
			}
			errHasCostNoIncome := finalDao.BuildAggHasCostNoIncomeFinalEntityData(execTime)
			if errHasCostNoIncome != nil {
				errList[execTime] = errHasCostNoIncome.Error()
				continue
			}
			errNoCost := finalDao.BuildAggNoCostFinalEntityData(execTime)
			if errNoCost != nil {
				errList[execTime] = errNoCost.Error()
				continue
			}
		}
		// 执行账单数据
		err := finalDao.BuildAggFinalBillEntity()
		if err != nil {
			errList[time.Now().Format(time.DateOnly)] = err.Error()
		}
	} else {
		execTime = time.Now().Format(time.DateOnly)
		errHasCostAndIncome := finalDao.BuildAggHasCostAndIncomeFinalEntityData(execTime)
		if errHasCostAndIncome != nil {
			errList[execTime] = errHasCostAndIncome.Error()
		}
		errHasCostNoIncome := finalDao.BuildAggHasCostNoIncomeFinalEntityData(execTime)
		if errHasCostNoIncome != nil {
			errList[execTime] = errHasCostNoIncome.Error()
		}
		errNoCost := finalDao.BuildAggNoCostFinalEntityData(execTime)
		if errNoCost != nil {
			errList[execTime] = errNoCost.Error()
		}
	}
	return errList
}

/********************************        当日/历史 ROI 分离       ********************************/

// QueryAndSaveFinalInfosToday 查询保存最终数据
func (t *CostIncomeService) QueryAndSaveFinalInfosToday(isHistory int) map[string]string {
	finalDao := roi.NewReportDataDao(t.Ctx)

	var execTime string
	errList := make(map[string]string)
	startDate := time.Date(time.Now().Year(), time.Now().Month(), time.Now().AddDate(0, 0, -3).Day(), 0, 0, 0, 0, time.UTC)
	endDate := time.Date(time.Now().Year(), time.Now().Month(), time.Now().AddDate(0, 0, -1).Day(), 0, 0, 0, 0, time.UTC)

	if isHistory == 1 {
		for currentDate := endDate; !currentDate.Before(startDate); currentDate = currentDate.AddDate(0, 0, -1) {
			execTime = currentDate.Format(time.DateOnly)
			errHasCostAndIncome := finalDao.BuildAggHasCostAndIncomeFinalEntityData(execTime)
			if errHasCostAndIncome != nil {
				errList[execTime] = errHasCostAndIncome.Error()
				continue
			}
			errHasCostNoIncome := finalDao.BuildAggHasCostNoIncomeFinalEntityData(execTime)
			if errHasCostNoIncome != nil {
				errList[execTime] = errHasCostNoIncome.Error()
				continue
			}
			errNoCost := finalDao.BuildAggNoCostFinalEntityData(execTime)
			if errNoCost != nil {
				errList[execTime] = errNoCost.Error()
				continue
			}
		}
		// 执行账单数据
		err := finalDao.BuildAggFinalBillEntity()
		if err != nil {
			errList[time.Now().Format(time.DateOnly)] = err.Error()
		}
	} else {
		execTime = time.Now().Format(time.DateOnly)
		errHasCostAndIncome := finalDao.BuildAggHasCostAndIncomeFinalEntityDataToday(execTime)
		if errHasCostAndIncome != nil {
			errList[execTime] = errHasCostAndIncome.Error()
		}
		errHasCostNoIncome := finalDao.BuildAggHasCostNoIncomeFinalEntityDataToday(execTime)
		if errHasCostNoIncome != nil {
			errList[execTime] = errHasCostNoIncome.Error()
		}
		errNoCost := finalDao.BuildAggNoCostFinalEntityDataToday(execTime)
		if errNoCost != nil {
			errList[execTime] = errNoCost.Error()
		}
	}
	return errList
}

// SwapTable 原子交换表
func (t *CostIncomeService) SwapTable() error {
	finalDao := roi.NewReportDataDao(t.Ctx)
	err := finalDao.SwapTable()
	if err != nil {
		return err
	}
	return nil
}

// InsertExecTime 保存有效数据时间
func (t *CostIncomeService) InsertExecTime(time string) error {
	finalDao := roi.NewReportDataDao(t.Ctx)
	err := finalDao.ExecTimetable(time)
	if err != nil {
		return err
	}
	return nil
}
