package middleware

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"goserver/app/common"
	"goserver/app/library/driver/redisdb"
	"goserver/app/library/log"
	"goserver/app/library/myerror"
)

func AntiReplayMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		project := viper.GetString("name")
		reqUri := c.Request.URL.Path
		req := common.GetRequest(c)
		sign := req.Sign
		redisKey := fmt.Sprintf("%s:%s:%s", project, reqUri, sign)

		invalid, _ := redisdb.CheckKey(redisKey)
		if invalid {
			log.Debug("[antiReplay] sign used: " + redisKey)
			panic(myerror.ReplayError)
		} else {
			redisdb.Set(redisKey, "true")
			redisdb.SetKeyExpire(redisKey, 10*60)
		}
	}
}
