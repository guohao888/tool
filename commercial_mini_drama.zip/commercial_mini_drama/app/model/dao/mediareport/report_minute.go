package mediareport

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	repo "goserver/app/common/repository/mediareport"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// ReportMinuteDao DAO
type ReportMinuteDao struct {
	Ctx context.Context
}

//func NewReportMinuteDao(ctx context.Context) *ReportMinuteDao {
//	return &ReportMinuteDao{Ctx: ctx}
//}

// InsertBatchSize 插入更新数据
func (r *ReportMinuteDao) InsertBatchSize(data []*repo.ReportMinuteEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = r.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *ReportMinuteDao) buildInsertSentence(tx *gorm.DB, data []*repo.ReportMinuteEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.ReportMinuteEntityTableName() + " ( search_date, promotion_id , promotion_name, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt, created_time , updated_time ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.SearchDate,
			v.PromotionId,
			v.PromotionName,
			v.AdvertiserId,
			v.ProjectId,
			v.ProjectName,
			v.ShowCnt,
			v.Click,
			v.Active,
			v.ActivePay,
			v.Cost,
			v.ConvertCnt,
			v.CreatedTime,
			v.UpdatedTime,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
