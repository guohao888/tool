package middleware

import (
	"goserver/app/library/log"
	"resty.dev/v3"
)

var (
	ContextEnableLog = "enable_log"
)

func ResponseLogMiddleware(c *resty.Client, r *resty.Response) error {
	ctx := r.Request.Context()
	enableLog := ctx.Value(ContextEnableLog)
	if enableLog != nil || r.Request.Debug {
		curlCmd := r.Request.CurlCmd()
		log.Debug("curl_cmd " + curlCmd)
	}

	if enableLog != nil || r.Request.Debug {
		log.Debug("resp_body " + string(r.Bytes()))
	}
	return nil
}
