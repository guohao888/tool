package accounts

import (
	"context"
	"fmt"
	"github.com/alitto/pond"
	"github.com/duke-git/lancet/v2/slice"
	"github.com/go-redsync/redsync/v4"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"golang.org/x/sync/errgroup"
	accountdto "goserver/app/common/dto/accounts"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/redisdb"
	"goserver/app/library/log"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
	"math/rand"
	"net/url"
	"strconv"
	"time"
)

type AccountPromotionUrlService struct {
	Ctx context.Context
}

func NewAccountPromotionUrlService(ctx context.Context) *AccountPromotionUrlService {
	return &AccountPromotionUrlService{Ctx: ctx}
}

type syncToutiaoBiz struct {
	AppId                 string
	Media                 string
	OauthId               string
	AccessToken           string
	AdvertiserId          int64
	AdvertiserName        string
	StartTime             string
	EndTime               string
	IsSyncAll             bool
	PrevDays              int
	IsBackgroundOperation bool // 是否是后台操作
}

func (p *syncToutiaoBiz) GetToolsWechatAppletListV30Filtering(st string) *models.ToolsWechatAppletListV30FilteringSearchType {
	searchType := models.ToolsWechatAppletListV30FilteringSearchType(st)
	return &searchType
}

func toolsMicroAppListV30FilteringSearchType(st string) *models.ToolsMicroAppListV30FilteringSearchType {
	searchType := models.ToolsMicroAppListV30FilteringSearchType(st)
	return &searchType
}

func (p *syncToutiaoBiz) SyncToutiaoWechatApp(ctx context.Context) ([]accountrepo.AccountPromotionUrlEntity, error) {
	ctx = context.WithValue(ctx, toutiao.CtxAppIdKey, p.AppId)
	var data []accountrepo.AccountPromotionUrlEntity

	searchTypeCreateOnly := accountrepo.SearchTypeCreateOnly
	searchTypeShareOnly := accountrepo.SearchTypeShareOnly

	data1, _ := p.SyncToutiaoWechatAppBySearchType(ctx, searchTypeCreateOnly)
	if len(data1) > 0 {
		data = append(data, data1...)
	}
	data2, _ := p.SyncToutiaoWechatAppBySearchType(ctx, searchTypeShareOnly)
	if len(data2) > 0 {
		data = append(data, data2...)
	}

	return data, nil
}

func (p *syncToutiaoBiz) SyncToutiaoWechatAppBySearchType(ctx context.Context, searchType string) ([]accountrepo.AccountPromotionUrlEntity, error) {
	var data []accountrepo.AccountPromotionUrlEntity

	// 获取微信小程序列表 (可以全量/增量)
	wechatAppletList, err := toutiao.AllToolsWechatAppletList(ctx, toutiao.AllToolsWechatAppletListReq{
		AccessToken:  p.AccessToken,
		AdvertiserId: p.AdvertiserId,
		Filtering: func() *models.ToolsWechatAppletListV30Filtering {
			filtering := &models.ToolsWechatAppletListV30Filtering{
				SearchType: p.GetToolsWechatAppletListV30Filtering(searchType),
			}
			if p.IsSyncAll {
				return filtering
			}

			if p.PrevDays > 0 {
				filtering.CreateTime = &models.ToolsWechatAppletListV30FilteringCreateTime{
					EndTime:   &p.EndTime,
					StartTime: &p.StartTime,
				}
			}
			return filtering
		}(),
	})
	if err != nil {
		log.Errorf("syncToutiaoBiz.SyncToutiaoBySearchType 获取微信小程序列表错误, err: %s, %#v", err, p)
	}

	for _, vv := range wechatAppletList {
		if vv.RemarkMessage != nil && *vv.RemarkMessage == "重复删除" {
			continue
		}

		data = append(data, accountrepo.AccountPromotionUrlEntity{
			Media:          p.Media,
			AdvertiserId:   strconv.FormatInt(p.AdvertiserId, 10),
			AdvertiserName: p.AdvertiserName,
			PromotionUrl:   *vv.Path,
			OauthId:        p.OauthId,
			Name:           *vv.Name,
			InstanceId:     *vv.InstanceId,
			AppType:        accountrepo.AppTypeWechatApplet,
			SearchType:     searchType,
			Ext:            "",
			CreateTime:     *vv.CreateTime,
			ModifyTime:     *vv.ModifyTime,
		})
	}

	return data, nil
}

func (p *syncToutiaoBiz) SyncToutiaoMicroApp(ctx context.Context) ([]accountrepo.AccountPromotionUrlEntity, error) {
	ctx = context.WithValue(ctx, toutiao.CtxAppIdKey, p.AppId)
	var data []accountrepo.AccountPromotionUrlEntity

	searchTypeCreateOnly := accountrepo.SearchTypeCreateOnly
	searchTypeShareOnly := accountrepo.SearchTypeShareOnly

	data1, _ := p.SyncToutiaoBySearchType(ctx, searchTypeCreateOnly)
	if len(data1) > 0 {
		data = append(data, data1...)
	}
	data2, _ := p.SyncToutiaoBySearchType(ctx, searchTypeShareOnly)
	if len(data2) > 0 {
		data = append(data, data2...)
	}

	return data, nil
}

func (p *syncToutiaoBiz) SyncToutiaoMicroAppBySearchType(ctx context.Context, searchType string) ([]accountrepo.AccountPromotionUrlEntity, error) {
	var data []accountrepo.AccountPromotionUrlEntity

	var instanceIds []int64
	//if !p.IsBackgroundOperation {
	//	instanceIds, _ = p.AdvertiserIdAccountInstanceIdMap.GetInstanceIds(strconv.FormatInt(p.AdvertiserId, 10), searchType)
	if false {
	} else {
		microAppList, err := toutiao.AllToolsMicroAppList(ctx, toutiao.AllToolsMicroAppListReq{
			AccessToken:  p.AccessToken,
			AdvertiserId: p.AdvertiserId,
			Filtering: func() *models.ToolsMicroAppListV30Filtering {
				filtering := &models.ToolsMicroAppListV30Filtering{
					SearchType: toolsMicroAppListV30FilteringSearchType(searchType),
				}
				return filtering
			}(),
		})
		if err != nil {
			log.Errorf("syncToutiaoBiz.SyncToutiaoBySearchType 获取字节小程序错误, err: %s, %#v", err, p)
		} else {
			for _, v := range microAppList {
				instanceIds = append(instanceIds, *v.InstanceId)
			}
		}
	}

	if len(instanceIds) > 0 {
		// 获取字节小程序/小游戏详情内容 (可以全量/增量)
		assetLinkList, err := toutiao.AllToolsAssetLinkListByInstanceIds(ctx, toutiao.AllToolsAssetLinkListInstanceIdsReq{
			AccessToken:  p.AccessToken,
			AdvertiserId: p.AdvertiserId,
			InstanceIds:  instanceIds,
			Filtering: func() *models.ToolsAssetLinkListV30Filtering {
				filtering := new(models.ToolsAssetLinkListV30Filtering)
				if p.IsSyncAll {
					return filtering
				}

				if p.PrevDays > 0 {
					filtering.CreateTime = &models.ToolsAssetLinkListV30FilteringCreateTime{
						EndTime:   &p.EndTime,
						StartTime: &p.StartTime,
					}
				}
				return filtering
			}(),
		})
		if err != nil {
			log.Errorf("syncToutiaoBiz.SyncToutiaoBySearchType 获取字节小程序/小游戏详情内容, err: %s, %#v", err, p)
			return nil, err
		}
		for _, vv := range assetLinkList {
			if vv.LinkRemark != nil && *vv.LinkRemark == "重复删除" {
				continue
			}
			if vv.StartParam == nil || *vv.StartParam == "" {
				continue
			}
			query, err := url.ParseQuery(*vv.StartParam)
			if err != nil {
				continue
			}
			code := query.Get("code")
			if code == "" {
				continue
			}

			data = append(data, accountrepo.AccountPromotionUrlEntity{
				Media:          p.Media,
				AdvertiserId:   strconv.FormatInt(p.AdvertiserId, 10),
				AdvertiserName: p.AdvertiserName,
				PromotionUrl:   code,
				OauthId:        p.OauthId,
				Name:           "",
				InstanceId:     *vv.InstanceId,
				AppType:        accountrepo.AppTypeByteMicroApp,
				SearchType:     searchType,
				Ext:            "",
				CreateTime:     *vv.CreateTime,
				ModifyTime:     *vv.ModifyTime,
			})
		}
	} else {
		log.Infof("syncToutiaoBiz.SyncToutiaoBySearchType 不存在字节小程序资产id, %d", p.AdvertiserId)
	}

	return data, nil
}

func (p *syncToutiaoBiz) SyncToutiaoBySearchType(ctx context.Context, searchType string) ([]accountrepo.AccountPromotionUrlEntity, error) {
	var data []accountrepo.AccountPromotionUrlEntity

	var instanceIds []int64
	//if !p.IsBackgroundOperation {
	//	instanceIds, _ = p.AdvertiserIdAccountInstanceIdMap.GetInstanceIds(strconv.FormatInt(p.AdvertiserId, 10), searchType)
	if false {
	} else {
		microAppList, err := toutiao.AllToolsMicroAppList(ctx, toutiao.AllToolsMicroAppListReq{
			AccessToken:  p.AccessToken,
			AdvertiserId: p.AdvertiserId,
			Filtering: func() *models.ToolsMicroAppListV30Filtering {
				filtering := &models.ToolsMicroAppListV30Filtering{
					SearchType: toolsMicroAppListV30FilteringSearchType(searchType),
				}
				return filtering
			}(),
		})
		if err != nil {
			log.Errorf("syncToutiaoBiz.SyncToutiaoBySearchType 获取字节小程序错误, err: %s, %#v", err, p)
		} else {
			for _, v := range microAppList {
				instanceIds = append(instanceIds, *v.InstanceId)
			}
		}
	}
	if len(instanceIds) > 0 {
		// 获取字节小程序/小游戏详情内容 (可以全量/增量)
		assetLinkList, err := toutiao.AllToolsAssetLinkListByInstanceIds(ctx, toutiao.AllToolsAssetLinkListInstanceIdsReq{
			AccessToken:  p.AccessToken,
			AdvertiserId: p.AdvertiserId,
			InstanceIds:  instanceIds,
			Filtering: func() *models.ToolsAssetLinkListV30Filtering {
				filtering := new(models.ToolsAssetLinkListV30Filtering)
				if p.IsSyncAll {
					return filtering
				}

				if p.PrevDays > 0 {
					filtering.CreateTime = &models.ToolsAssetLinkListV30FilteringCreateTime{
						EndTime:   &p.EndTime,
						StartTime: &p.StartTime,
					}
				}
				return filtering
			}(),
		})
		if err != nil {
			log.Errorf("syncToutiaoBiz.SyncToutiaoBySearchType 获取字节小程序/小游戏详情内容, err: %s, %#v", err, p)
			return nil, err
		}
		for _, vv := range assetLinkList {
			if vv.LinkRemark != nil && *vv.LinkRemark == "重复删除" {
				continue
			}
			if vv.StartParam == nil || *vv.StartParam == "" {
				continue
			}
			query, err := url.ParseQuery(*vv.StartParam)
			if err != nil {
				continue
			}
			code := query.Get("code")
			if code == "" {
				continue
			}

			data = append(data, accountrepo.AccountPromotionUrlEntity{
				Media:          p.Media,
				AdvertiserId:   strconv.FormatInt(p.AdvertiserId, 10),
				AdvertiserName: p.AdvertiserName,
				PromotionUrl:   code,
				OauthId:        p.OauthId,
				Name:           "",
				InstanceId:     *vv.InstanceId,
				AppType:        accountrepo.AppTypeByteMicroApp,
				SearchType:     searchType,
				Ext:            "",
				CreateTime:     *vv.CreateTime,
				ModifyTime:     *vv.ModifyTime,
			})
		}
	} else {
		log.Infof("syncToutiaoBiz.SyncToutiaoBySearchType 不存在字节小程序资产id, %d", p.AdvertiserId)
	}

	return data, nil
}

func (s *AccountPromotionUrlService) AppIdSyncToutiao(
	appId string,
	oauthMap map[string]accountrepo.OauthEntity,
	appIdActiveAccountList []accountrepo.OauthActiveAccountEntity,
	params accountdto.AccountPromotionUrlSyncExecutorParams,
) error {
	now := time.Now()
	endTime := now.Format(time.DateOnly)
	startTime := now.AddDate(0, 0, -1*params.PrevDays).Format(time.DateOnly)

	resChan := make(chan accountrepo.AccountPromotionUrlEntity)
	errChan := make(chan error)

	mutexName := fmt.Sprintf("account_promotion_url_app_id:%s:app_type:%s", appId, params.AppType)
	lockTime := time.Second * 6

	// 上锁保证，后台的和高优的优先执行
	if params.IsBackgroundOperation || params.Priority == accountrepo.PriorityHigh { // 如果是金牛座后台调用获取锁失败了，就直接返回
		// 任务锁，按照应用id和小程序类型的锁
		mutex := redisdb.RedSync.NewMutex(
			mutexName,
			redsync.WithValue(appId),
			redsync.WithSetNXOnExtend(),
			redsync.WithExpiry(lockTime),
			redsync.WithTries(1000),
			redsync.WithRetryDelayFunc(func(tries int) time.Duration {
				// 基础退避时间（例如200毫秒）
				return 200 * time.Millisecond
			}),
		)
		err := mutex.Lock()
		if err != nil {
			log.Errorf("金牛后台拉取广告主推广链获取分布式锁错误, params: %#v, err: %s", params, err)
			return err
		}
		defer func() {
			_, _ = mutex.Unlock()
		}()

		// 续期
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		go func() {
			redisdb.MutexExtend(ctx, mutex, time.Second*3)
		}()
	}

	ctx := context.Background()
	go func() {
		pool := pond.New(params.PoolWorkers, 1000)
		defer pool.StopAndWait()
		group, _ := pool.GroupContext(context.Background())

		for k, v := range appIdActiveAccountList {
			i := k
			activeAccount := v

			group.Submit(func() error {
				if !params.IsBackgroundOperation && params.Priority != accountrepo.PriorityHigh {
					// 任务锁，按照应用id和小程序类型的锁
					mutex := redisdb.RedSync.NewMutex(
						mutexName,
						redsync.WithValue(appId),
						redsync.WithSetNXOnExtend(),
						redsync.WithExpiry(lockTime),
						redsync.WithTries(1000),
						redsync.WithRetryDelayFunc(func(tries int) time.Duration {
							// 基础退避时间（例如200毫秒）
							baseDelay := 300 * time.Millisecond
							// 最大退避时间（例如10秒）
							maxDelay := 10 * time.Second

							// 计算退避时间
							delay := time.Duration(rand.Int63n(int64(baseDelay))) * time.Duration(1<<uint(tries))
							if delay > maxDelay {
								delay = maxDelay
							}
							return delay
						}),
					)
					err := mutex.Lock() // 这个锁获到就马上释放，使其他的广告主账户可以获取到锁执行程序
					if err != nil {
						log.Errorf("xxl-job拉取广告主推广链获取分布式锁错误, params: %#v, err: %s", params, err)
					} else {
						_, _ = mutex.Unlock()
					}
				}

				log.Infof("AccountPromotionUrlService.SyncToutiao 开始执行, %d, %s, %s", i, activeAccount.OauthId, activeAccount.AdvertiserId)
				oauth, ok := oauthMap[activeAccount.OauthId]
				if !ok {
					log.Infof("AccountPromotionUrlService.SyncToutiao 没有获取到对应的oauth信息, %s, %s", activeAccount.OauthId, activeAccount.AdvertiserId)
					return nil
				}

				advertiserId, err := activeAccount.GetAdvertiserId()
				if err != nil {
					return err
				}

				syncToutiaoBiz := syncToutiaoBiz{
					AppId:                 appId,
					Media:                 params.Media,
					OauthId:               oauth.OauthId,
					AccessToken:           oauth.AccessToken,
					AdvertiserId:          advertiserId,
					AdvertiserName:        activeAccount.AdvertiserName,
					StartTime:             startTime,
					EndTime:               endTime,
					IsSyncAll:             params.IsSyncAll,
					PrevDays:              params.PrevDays,
					IsBackgroundOperation: params.IsBackgroundOperation,
				}

				if params.IsSyncWechatApplet() {
					data1, err := syncToutiaoBiz.SyncToutiaoWechatApp(ctx)
					if err != nil {
						log.Errorf("AccountPromotionUrlService.SyncToutiao 微信小程序拉取数据错误, oauth_id: %s, advertiser_id: %s", activeAccount.OauthId, activeAccount.AdvertiserId)
					}
					for _, v := range data1 {
						resChan <- v
					}
				}

				if params.IsSyncByteMicroApp() {
					data2, err := syncToutiaoBiz.SyncToutiaoMicroApp(ctx)
					if err != nil {
						log.Errorf("AccountPromotionUrlService.SyncToutiao 字节小程序取数据错误, oauth_id: %s, advertiser_id: %s", activeAccount.OauthId, activeAccount.AdvertiserId)
					}
					for _, v := range data2 {
						resChan <- v
					}
				}

				return nil
			})
		}

		e := group.Wait()
		if e != nil {
			errChan <- e
			close(errChan)
		}
		close(resChan)
	}()

	accountPromotionUrlDao := accountdao.NewAccountPromotionUrlDao(s.Ctx)

	batchSize := params.InsertBatchSize
	var data []accountrepo.AccountPromotionUrlEntity
	for {
		var breakFlag bool

		select {
		case err, ok := <-errChan:
			if ok {
				return err
			}
		case res, ok := <-resChan:
			if ok {
				data = append(data, res)
				if len(data) >= batchSize {
					err := accountPromotionUrlDao.InsertBatchSize(data, batchSize)
					if err != nil {
						log.Errorf("AccountPromotionUrlService.AppIdSyncToutiao 数据插入失败, err: %s", err)
						return err
					}
					data = data[:0]
				}
			} else {
				breakFlag = true
			}
		}

		if breakFlag {
			break
		}
	}
	if len(data) > 0 {
		err := accountPromotionUrlDao.InsertBatchSize(data, batchSize)
		if err != nil {
			log.Errorf("AccountPromotionUrlService.AppIdSyncToutiao 数据插入失败, err: %s", err)
			return err
		}
	}

	return nil
}

func (s *AccountPromotionUrlService) SyncToutiao(params accountdto.AccountPromotionUrlSyncExecutorParams) error {
	oauthDao := accountdao.NewOauthDao(s.Ctx)
	oauthList, err := oauthDao.ListOauthByMediaAppIds(params.Media, params.AppIds)
	if err != nil {
		log.Errorf("[AccountPromotionUrlService.SyncToutiao] 根据媒体获取oauth授权列表错误, err: %s", err)
		return err
	}
	oauthMap := slice.KeyBy(oauthList, func(item accountrepo.OauthEntity) string {
		return item.OauthId
	})

	oauthActiveAccountDao := accountdao.NewOauthActiveAccountDao(s.Ctx)
	var activeAccountList []accountrepo.OauthActiveAccountEntity
	if params.Priority == accountrepo.PriorityHigh {
		// 高优先级
		activeAccountList, err = oauthActiveAccountDao.ListHighHasReportData(params.Media, params.AppIds, params.AdvertiserIds)
	} else if params.Priority == accountrepo.PriorityLow {
		// 低优先级
		activeAccountList, err = oauthActiveAccountDao.ListLowNoReportData(params.Media, params.AppIds, params.AdvertiserIds)
	} else {
		// 默认全量
		activeAccountList, err = oauthActiveAccountDao.ListByMediaAndAppIds(params.Media, params.AppIds, params.AdvertiserIds)
	}
	if err != nil {
		log.Errorf("[AccountPromotionUrlService.SyncToutiao] 根据媒体获取再投账户列表错误, err: %s", err)
		return err
	}

	m := make(map[string]accountrepo.OauthActiveAccountEntityList)
	for _, v := range activeAccountList {
		o, ok := oauthMap[v.OauthId]
		if !ok {
			continue
		}
		m[o.AppId] = append(m[o.AppId], v)
	}

	var eg errgroup.Group
	for k, v := range m {
		appIdActiveAccountList := v
		appId := k

		eg.Go(func() error {
			err := s.AppIdSyncToutiao(appId, oauthMap, appIdActiveAccountList, params)
			if err != nil {
				log.Errorf("[AccountPromotionUrlService.SyncToutiao] 根据头条应用id拉取广告主错误, err: %s", err)
			}
			return err
		})
	}
	err = eg.Wait()
	if err != nil {
		log.Errorf("[AccountPromotionUrlService.SyncToutiao] 根据头条应用id并行拉取广告主错误, err: %s", err)
	}
	return err
}
