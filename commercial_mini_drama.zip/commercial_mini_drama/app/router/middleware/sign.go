package middleware

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/spf13/viper"
	"goserver/app/common"
	"goserver/app/library/log"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/md5"
	"time"
)

func SignMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		req := common.GetRequest(c)
		serverSign := createSign(req)
		clientSign := req.Sign

		// 验证签名
		if clientSign == "" || clientSign != serverSign {
			log.Errorf("[sign] server sign mis match, server sign: %s, client sign: %s", serverSign, clientSign)
			panic(myerror.SignError)
		}
		log.Debugf("sign校验结束时间：%v", time.Now().UnixNano()/1e6)
	}
}

func createSign(req *common.Request) string {
	secKey := viper.GetString("aes_sec_key")
	signStr := fmt.Sprintf("timestamp=%d|secret=%s", req.Timestamp, secKey)

	//3.计算签名的MD5值
	sign := md5.GetStringMd5(signStr)
	log.Debugf("[sign] sign raw str: %s, sign result: %s", signStr, sign)

	return sign
}
