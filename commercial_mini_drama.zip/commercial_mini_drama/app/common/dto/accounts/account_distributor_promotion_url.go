package accounts

import "time"

type PromotionUrlMergeExecutorParams struct {
	Now        *time.Time `json:"-"`
	IsAll      bool       `json:"is_all"`
	PreSeconds int64      `json:"pre_seconds"` // 秒
}

func (p *PromotionUrlMergeExecutorParams) GetStartTime() string {
	if p.IsAll {
		return ""
	}

	if p.Now == nil {
		now := time.Now()
		p.Now = &now
	}

	if p.PreSeconds == 0 {
		p.PreSeconds = 86400 // 1天
	}

	startTime := p.Now.Add(-1 * time.Duration(p.PreSeconds) * time.Second).Format(time.DateTime)
	return startTime
}
