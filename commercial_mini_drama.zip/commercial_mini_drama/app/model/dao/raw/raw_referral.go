package raw

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/raw"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// ReferralDao 端元生配置表
type ReferralDao struct {
	Ctx context.Context
}

func NewReferralDao(ctx context.Context) *ReferralDao {
	return &ReferralDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (r *ReferralDao) InsertBatchSize(data []raw.ReferralEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 1000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = r.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *ReferralDao) buildInsertSentence(tx *gorm.DB, data []raw.ReferralEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + raw.MaterialDayTableName() + " ( hash_id, referral_url, book_name, copyright_owner, created_time ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?),"
		vals = append(vals,
			v.HashId,
			v.ReferralUrl,
			v.BookName,
			v.CopyrightOwner,
			v.CreatedTime,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")
	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func (r *ReferralDao) QueryDataByTime(startTime, endTime string) (data []raw.ReferralEntity, err error) {

	db := dorisdb.DorisClient()
	err = db.Table(raw.MaterialDayTableName()).Where("created_time >= ? and created_time <= ?", startTime, endTime).Find(&data).Error
	return data, err
}
