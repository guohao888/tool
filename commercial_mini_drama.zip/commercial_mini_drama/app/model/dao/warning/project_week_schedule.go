package warning

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/warning"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
	"time"
)

type WeekScheduleDao struct {
	Ctx context.Context
}

func NewWeekScheduleDao(ctx context.Context) *WeekScheduleDao {
	return &WeekScheduleDao{Ctx: ctx}
}

// InsertBatchWeekSchedule 插入更新数据
func (w *WeekScheduleDao) InsertBatchWeekSchedule(data []*warning.ProjectWeekScheduleEntity, media string, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = w.batchInsertWarning(tx, data[start:end], media)
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (w *WeekScheduleDao) batchInsertWarning(tx *gorm.DB, data []*warning.ProjectWeekScheduleEntity, media string) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + warning.ProjectWeekScheduleEntityTableName() + " ( media, advertiser_id, project_id, operation, schedule_time, error_msg, status, reverse_status, created_time  ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			media,
			v.AdvertiserId,
			v.ProjectId,
			v.Operation,
			v.ScheduleTime,
			v.ErrorMsg,
			v.Status,
			v.ReverseStatus,
			time.Now(),
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func (w *WeekScheduleDao) FindSchedule(media string) (res []warning.WeekSchedule, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT sc.advertiser_id, account_name as advertiser_name, sc.project_id, project_name, cost, roi, operation, '今日投放时段拉空（23:30后自动开启）' as result, error_msg as err_msg, optimizer_nickname as nick_name FROM ( SELECT advertiser_id, project_id, operation, schedule_time, error_msg FROM project_week_schedule WHERE date(created_time) = CURRENT_DATE  AND `status` = 0 AND media = '" + media + "') sc LEFT JOIN ( SELECT account_id,  account_name, project_id, project_name, sum(media_cost) as cost, round(sum(income)/sum(media_cost), 2) as roi, optimizer_nickname FROM roi_project_hourly_today GROUP BY account_id,  account_name, project_id, project_name, optimizer_nickname ) rep ON sc.advertiser_id = rep.account_id AND sc.project_id = rep.project_id "
	err = db.Raw(sql).Scan(&res).Error
	return
}

func (w *WeekScheduleDao) FindScheduleKuaishou(media string) (res []warning.WeekSchedule, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT sc.advertiser_id, account_name as advertiser_name, '' as project_id, '' as project_name, cost, roi, operation, '今日投放时段拉空（23:00后自动开启）' as result, error_msg as err_msg, nick_name as nick_name FROM ( SELECT advertiser_id, project_id, operation, schedule_time, error_msg FROM project_week_schedule WHERE date(created_time) = CURRENT_DATE  AND `status` = 0 AND media = '" + media + "') sc LEFT JOIN ( SELECT ac.account_id, account_name, cost, roi, nick_name FROM ( SELECT account_id, sum(total_charge/1000) as cost, round(sum(event_pay_purchase_amount+mini_game_iaa_purchase_amount)/sum(total_charge/1000), 2) as roi FROM kuaishou_ad_detail WHERE is_today = 1 GROUP BY account_id ) ac LEFT JOIN ( SELECT account_id, account_name, SUBSTRING_INDEX(account_name,'-',1) as nick_name FROM kuaishou_account_info ) inf ON ac.account_id = inf.account_id ) rep ON sc.advertiser_id = rep.account_id "
	err = db.Raw(sql).Scan(&res).Error
	return
}

func (w *WeekScheduleDao) UpdateScheduleStatus(advertiserIds string) error {
	db := dorisdb.DorisClient()
	sql := "UPDATE project_week_schedule SET `status` = 1 WHERE advertiser_id in ( " + advertiserIds + ")"
	err := db.Exec(sql).Error
	return err
}

func (w *WeekScheduleDao) FindScheduleT1(media string) (res []warning.WeekSchedule, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT sc.advertiser_id, account_name as advertiser_name, sc.project_id, project_name, cost, roi, operation, '' as result, error_msg as err_msg, optimizer_nickname as nick_name FROM ( SELECT advertiser_id, project_id, operation, schedule_time, error_msg FROM project_week_schedule WHERE date(created_time) = CURRENT_DATE -1  AND `reverse_status` = 0 AND media = '" + media + "') sc LEFT JOIN ( SELECT account_id,  account_name, project_id, project_name, sum(media_cost) as cost, round(sum(income)/sum(media_cost), 2) as roi, optimizer_nickname FROM roi_project_hourly_today GROUP BY account_id,  account_name, project_id, project_name, optimizer_nickname ) rep ON sc.advertiser_id = rep.account_id AND sc.project_id = rep.project_id "
	err = db.Raw(sql).Scan(&res).Error
	return
}

func (w *WeekScheduleDao) FindKuaishouScheduleT1(media string) (res []warning.WeekSchedule, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT sc.advertiser_id, account_name as advertiser_name, '' as project_id,  '' as project_name, cost, roi, operation, '' as result, error_msg as err_msg, nick_name as nick_name FROM ( SELECT advertiser_id, project_id, operation, schedule_time, error_msg FROM project_week_schedule WHERE date(created_time) = CURRENT_DATE -1  AND `reverse_status` = 0 AND media = '" + media + "') sc LEFT JOIN ( SELECT ac.account_id, account_name, cost, roi, nick_name FROM ( SELECT account_id, sum(total_charge/1000) as cost, round(sum(event_pay_purchase_amount+mini_game_iaa_purchase_amount)/sum(total_charge/1000), 2) as roi FROM kuaishou_ad_detail WHERE is_today = 1 GROUP BY account_id ) ac LEFT JOIN ( SELECT account_id, account_name, SUBSTRING_INDEX(account_name,'-',1) as nick_name FROM kuaishou_account_info ) inf ON ac.account_id = inf.account_id ) rep ON sc.advertiser_id = rep.account_id "
	err = db.Raw(sql).Scan(&res).Error
	return
}
