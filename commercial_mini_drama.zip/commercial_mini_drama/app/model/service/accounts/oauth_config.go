package accounts

import (
	"context"
	"encoding/json"
	"fmt"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/dto/page"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/model/dao/accounts"
	accountdao "goserver/app/model/dao/accounts"
	"net/url"
	"strings"
)

type OauthConfigService struct {
	Ctx context.Context
}

func NewOauthConfigService(ctx context.Context) *OauthConfigService {
	return &OauthConfigService{Ctx: ctx}
}

func (s *OauthConfigService) OneByMediaAppId(media string, appId string) (*accountrepo.OauthConfigEntity, error) {
	oauthConfigDao := accounts.NewOauthConfigDao(s.Ctx)
	return oauthConfigDao.OneByMediaAppId(media, appId)
}

func (s *OauthConfigService) AddConfig() error {
	return nil
}

func (s *OauthConfigService) AddAppId(req *accountdto.SingleAppIdReq) error {
	oauthConfigDao := accountdao.NewOauthConfigDao(s.Ctx)
	data := &accountrepo.OauthConfigEntity{
		Media:     strings.TrimSpace(req.Media),
		AppID:     strings.TrimSpace(req.AppId),
		AppSecret: strings.TrimSpace(req.Key),
		AuthType:  strings.TrimSpace(req.AuthType),
	}
	return oauthConfigDao.Create(data)
}

func (s *OauthConfigService) EditAppId(req *accountdto.SingleAppIdReq) error {
	oauthConfigDao := accountdao.NewOauthConfigDao(s.Ctx)
	data := &accountrepo.OauthConfigEntity{
		Media:     strings.TrimSpace(req.Media),
		AppID:     strings.TrimSpace(req.AppId),
		AppSecret: strings.TrimSpace(req.Key),
		AuthType:  strings.TrimSpace(req.AuthType),
	}
	return oauthConfigDao.Update(data)
}

func (s *OauthConfigService) ConfigList(params *accountdto.ConfigListParams) (*page.Paginator, error) {
	oauthConfigDao := accountdao.NewOauthConfigDao(s.Ctx)
	paginator, err := oauthConfigDao.ConfigList(params)
	if err != nil {
		return nil, err
	}

	list, _ := paginator.List.([]accountrepo.OauthConfigEntity)
	var res []accountdto.OauthConfigList

	baseNo := (params.Page - 1) * params.PageSize
	for k, v := range list {
		res = append(res, accountdto.OauthConfigList{
			No:        baseNo + int64(k) + 1,
			Media:     v.Media,
			AppID:     v.AppID,
			AppSecret: v.AppSecret,
			AuthType:  v.AuthType,
			CreatedAt: v.CreatedAt,
			UpdatedAt: v.UpdatedAt,
			OauthUrl:  s.GetOauthUrl(v),
		})
	}
	paginator.List = res

	return paginator, err
}

func (s *OauthConfigService) GetOauthUrl(oc accountrepo.OauthConfigEntity) string {
	switch oc.Media {
	case repo.MediaToutiao:
		// 接口文档: https://open.oceanengine.com/labels/7/docs/1803016515293203?origin=left_nav
		oauthUrl := "https://open.oceanengine.com/audit/oauth.html?app_id=%s&state=%s&scope=[]&material_auth=1&redirect_uri=%s"
		callbackUrl := "https://minidrama.shouji.360.cn/api/oauth2/callback/toutiao"
		if oc.AuthType == repo.AuthTypeXieGuan {
			callbackUrl = "https://minidrama.shouji.360.cn/api/oauth2/callback/assist"
		}
		return fmt.Sprintf(oauthUrl,
			oc.AppID,
			"abcd",
			callbackUrl,
		)
	case repo.MediaKuaishou:
		// 接口文档: https://developers.e.kuaishou.com/docs?docType=DSP&documentId=2539&menuId=3765
		oauthUrl := "https://developers.e.kuaishou.com/tools/authorize?%s"
		callbackUrl := "https://minidrama.shouji.360.cn/api/oauth2/callback/kuaishou"

		scope := []string{"ad_series"}
		scopeBytes, _ := json.Marshal(scope)
		state := accountrepo.CallbackKuaishouState{
			AppId: json.Number(oc.AppID),
		}
		params := url.Values{}
		params.Add("app_id", oc.AppID)
		params.Add("scope", string(scopeBytes))
		params.Add("redirect_uri", callbackUrl)
		stateBytes, _ := json.Marshal(state)
		params.Add("state", string(stateBytes))
		params.Add("oauth_type", "series")
		encode := params.Encode()

		return fmt.Sprintf(oauthUrl, encode)
	default:
		return ""
	}
}

func (s *OauthConfigService) DistinctAppIds(media string) ([]string, error) {
	oauthConfigDao := accountdao.NewOauthConfigDao(s.Ctx)
	return oauthConfigDao.DistinctAppIds(media)
}
