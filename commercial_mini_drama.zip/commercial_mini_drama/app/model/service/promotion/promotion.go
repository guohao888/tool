package promotion

import (
	"context"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"github.com/panjf2000/ants/v2"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/common/repository/promotion"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
	pDao "goserver/app/model/dao/promotion"
	"goserver/app/model/dao/subscribe"
	"goserver/app/model/service/mediareport"
	"strconv"
	"sync"
	"time"
)

// InfoPromotionService 账号项目Service
type InfoPromotionService struct {
	Ctx context.Context
}

func NewInfoPromotion(ctx context.Context) *InfoPromotionService {
	return &InfoPromotionService{Ctx: ctx}
}

func isReplenish(ctx context.Context, date string, replenish int, accountIds []string) (activeList []accountrepo.OauthAccountEntity, err error) {
	todayDao := subscribe.NewTodaySubscribeDao(ctx)
	if replenish == 0 {
		activeList, err = todayDao.ActiveAdvertiserListByDate(date)
	} else if replenish == 1 {
		activeList, err = todayDao.ActiveAdvertiserListByDateReplenish(date)
	} else if replenish == 2 {
		activeList, err = todayDao.ActiveAdvertiserListByDateCost(date)
	} else if replenish == 3 {
		activeList, err = todayDao.ActiveAdvertiserListByDateReplenishCost(date)
	} else if replenish == 4 {
		activeList, err = todayDao.ActiveAdvertiserListByDateReplenishById(accountIds)
	}
	return
}

func (i *InfoPromotionService) DistributePromotionAccounts(crontabTime time.Time, ctx context.Context, replenish int) error {
	// 获取执行时间
	startDate, _ := mediareport.GetExecTime(crontabTime)
	fmt.Println(startDate)
	// 按快慢队列查询出所有活跃账号
	activeList, err := isReplenish(ctx, startDate, replenish, nil)
	if err != nil {
		return fmt.Errorf("查询活跃账号失败, err: %v", err)
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return fmt.Errorf("查询活跃账号为空")
	}

	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncPromotionLimit(startDate, activeList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

// SyncPromotionLimit  令牌桶请求头条数据
func SyncPromotionLimit(start string, activeList []accountrepo.OauthAccountEntity, oauth map[string]string, appId string) {

	resChan := make(chan *promotion.InfoPromotionEntity) // 结果缓存通道
	errChan := make(chan error, len(activeList))         // 缓冲通道避免阻塞

	// 开辟10个协程池
	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	// DB 只执行一次
	once.Do(func() {
		go func() {
			dbErr := execPromotionDB(context.Background(), resChan)
			if dbErr != nil {
				errChan <- dbErr
			}
		}()
	})
	// 获取所有活跃账号及token 请求接口数据
	for _, v := range activeList {
		// copy变量 防止闭包重复执行数据
		currentItem := v
		wg.Add(1)

		task := func() {
			defer wg.Done()
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("panic recovered: %v", x)
				}
			}()
			advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
			advertiserIdStr := currentItem.AdvertiserId
			userId := currentItem.UserId
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			// 按账号获取消耗报表
			allReport, execErr := execQueryPromotionInfos(context.Background(), oauth[userId], int64(advertiserId), start, appId)
			if execErr != nil {
				errChan <- fmt.Errorf("执行查询失败 advertiser_id: %s, token: %s, appId: %s, error: %s", advertiserIdStr, oauth[userId], appId, execErr.Error())
				return
			}
			// 查询无数据直接返回
			if len(allReport) == 0 {
				return
			}

			for _, row := range toutiao.DataRows2Inner(allReport) {
				info := &promotion.InfoPromotionEntity{
					AdvertiserId:        row.AdvertiserId,
					ProjectId:           row.ProjectId,
					PromotionId:         row.PromotionId,
					PromotionModifyDate: row.PromotionModifyDate,
					PromotionCreateTime: row.PromotionCreateTime,
					PromotionModifyTime: row.PromotionModifyTime,
					AppId:               row.AppId,
					StartPath:           row.StartPath,
					Params:              row.Params,
					Url:                 row.Url,
					Code:                row.Code,
					ScheduleTime:        row.ScheduleTime,
					StatusFirst:         row.StatusFirst,
					//PlayletSeriesUrl:    row.PlayletSeriesUrlList,
					HashRes: row.HashRes,
				}
				resChan <- info
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done() // 提交失败，减少计数器
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待所有任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan) // 确保所有任务完成后关闭通道
	}()
	// 收集所有错误
	var errs []error
	for errL := range errChan {
		fmt.Println(errL.Error())
		errs = append(errs, errL)
	}
	//if len(errs) > 0 {
	//	_ = sendMsg(errs, "同步消耗报表\n")
	//}
	return
}

// execPromotionDB 广告信息
func execPromotionDB(ctx context.Context, resChan <-chan *promotion.InfoPromotionEntity) (err error) {
	promotionDao := pDao.NewInfoPromotionDao(ctx)
	// 将数据写入 report_hour
	var data = make([]*promotion.InfoPromotionEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			if dbErr := promotionDao.InsertBatchSize(data, 5000); dbErr != nil {
				errs = append(errs, dbErr) // 收集错误，不退出
			}
			data = data[:0]
		}

	}
	if len(data) > 0 {
		dbErr := promotionDao.InsertBatchSize(data, 5000)
		if dbErr != nil {
			errs = append(errs, dbErr)
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execProjectDB errors: %v", errs)
	}
	return nil
}

// execQueryPromotionInfos 执行database数据查询
func execQueryPromotionInfos(ctx context.Context, accessToken string, advertiserId int64,
	startDate string, appId string) (allReport []*models.PromotionListV30ResponseDataListInner, err error) {

	// 获取BASE_DATE数据
	allReport, err = toutiao.AllPromotionList(ctx, toutiao.AllPromotionListReq{
		AccessToken:  accessToken,
		AdvertiserId: advertiserId,
		ModifyTime:   startDate,
	}, appId)

	return
}

func (i *InfoPromotionService) DistributePromotionAccountsRe(crontabTime time.Time, ctx context.Context, replenish int, accountIds []string) error {
	// 获取执行时间
	startDate, _ := mediareport.GetExecTime(crontabTime)
	fmt.Println(startDate)
	// 按快慢队列查询出所有活跃账号
	activeList, err := isReplenish(ctx, startDate, replenish, accountIds)
	if err != nil {
		return fmt.Errorf("查询活跃账号失败, err: %v", err)
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return fmt.Errorf("查询活跃账号为空")
	}

	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncPromotionLimit(startDate, activeList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}
