package accounts

import (
	"encoding/base64"
	"github.com/gin-gonic/gin"
	"github.com/go-playground/validator/v10"
	"goserver/app/common"
	"goserver/app/common/dto/page"
	"goserver/app/library/myerror"
	timeUtil "goserver/app/library/utils/time"
	"time"
)

type FilterReq struct {
	common.CommonParams
}

func NewFilterReq(c *gin.Context) *FilterReq {
	req := &FilterReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

type GeneralOption struct {
	Key string `json:"key"`
	Val int    `json:"val"`
}

// FilterOptionResp 筛选项返回数据
type FilterOptionResp struct {
	AppName        []string        `json:"app_name"`
	AdvertiserId   []string        `json:"advertiser_id"`
	AdvertiserName []string        `json:"advertiser_name"`
	NickName       []string        `json:"nick_name"`
	Media          []string        `json:"media"`
	AccountStatus  []GeneralOption `json:"account_status"`
}

type OptionSearchReq struct {
	common.CommonParams
	Params *OptionSearchParams `json:"params"`
}

type OptionSearchParams struct {
	SearchColumn string `json:"search_column"` // 搜索字段值 账户ID：advertiser_id 账户名称：advertiser_name 剧目名称：book_name
	Keywords     string `json:"keywords"`      // 模糊搜索关键字
}

// NewOptionSearchReq 筛选项模糊搜索
func NewOptionSearchReq(c *gin.Context) *OptionSearchReq {
	req := &OptionSearchReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

type DataFilter struct {
	Start          string   `json:"start"`           // 起始时间
	End            string   `json:"end"`             // 结束时间
	AppName        []string `json:"app_name"`        // 小程序应用包名 // omitempty
	AdvertiserId   []string `json:"advertiser_id"`   // 账户ID
	AdvertiserName []string `json:"advertiser_name"` // 账户名称
	BookId         []int64  `json:"book_id"`         // 剧目ID
	BookName       []string `json:"book_name"`       // 剧目名称
	NickName       []string `json:"nick_name"`       // 优化师昵称
	Media          []string `json:"media"`           // 媒体名称 今日头条、快手
	Status         int      `json:"status"`          // 启用状态 0:开启 1:关停 -1:全部
}

type DataListParams struct {
	page.Pagination            // 分页
	Filter          DataFilter `json:"filter"`    // 筛选
	ListType        string     `json:"list_type"` // 列表类型 account:账户列表 promotion: 推广连接列表
	//IsExport        int        `json:"is_export"` // 是否为导出 0:否 1:是
}

// DataListReq 列表请求参数
type DataListReq struct {
	common.CommonParams
	Params *DataListParams `json:"params"`
}

func NewAccountDataListReq(c *gin.Context) *DataListReq {
	req := &DataListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	// 对时间进行强制格式化
	var err error
	req.Params.Filter.Start, err = timeUtil.Reformat(req.Params.Filter.Start, "2006-01-02", time.DateTime)
	if err != nil {
		panic(myerror.ParamsError)
	}
	end, err := time.ParseInLocation("2006-01-02", req.Params.Filter.End, time.Local)
	if err != nil {
		panic(myerror.ParamsError)
	}
	req.Params.Filter.End = end.AddDate(0, 0, 1).Format(time.DateTime)
	return req
}

func NewAccountDataExportReq(c *gin.Context) *DataListReq {
	req := &DataListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	// 对时间进行强制格式化
	var err error
	req.Params.Filter.Start, err = timeUtil.Reformat(req.Params.Filter.Start, "2006-01-02", time.DateTime)
	if err != nil {
		panic(myerror.ParamsError)
	}
	end, err := time.ParseInLocation("2006-01-02", req.Params.Filter.End, time.Local)
	if err != nil {
		panic(myerror.ParamsError)
	}
	req.Params.Filter.End = end.AddDate(0, 0, 1).Format(time.DateTime)
	req.Params.PageSize = 99999
	return req
}

// DataInfoResp 列表返回结构
type DataInfoResp struct {
	Module           string `json:"module"`            // 模型
	AppName          string `json:"app_name"`          // 应用包名
	BookId           int64  `json:"book_id"`           // 剧目ID
	BookName         string `json:"book_name"`         //剧目名称
	Media            string `json:"media"`             // 媒体名称
	Distributor      string `json:"distributor"`       // 分销商
	Region           string `json:"region"`            // 地区
	OptimizerId      int64  `json:"optimizer_id"`      // 优化师ID
	OptimizerName    string `json:"optimizer_name"`    // 优化师
	AdvertiserId     string `json:"advertiser_id"`     // 账户ID
	AdvertiserName   string `json:"advertiser_name"`   // 账户名称
	AdvertiserStatus string `json:"advertiser_status"` // 启用状态中文 0:正常 1:关停
	Status           int64  `json:"status"`            // 启用状态 0:正常 1:关停
	AdvertiserPoint  string `json:"advertiser_point"`  // 账户返点
	CreatedAt        string `json:"created_at"`        //创建时间
	UpdatedAt        string `json:"updated_at"`        //更新时间

	PromotionUrl  string `json:"promotion_url"`  // 推广链接
	PromotionId   int64  `json:"promotion_id"`   // 推广链接ID
	PromotionName string `json:"promotion_name"` // 推广链接名称
}

// AddReq 添加账户参数
type AddReq struct {
	common.CommonParams
	Params *AddParams `json:"params"`
}

type AddParams struct {
	AppName        string `json:"app_name" validate:"required"`        // 应用包名
	BookId         int64  `json:"book_id" validate:"required"`         // 剧目ID
	BookName       string `json:"book_name" validate:"required"`       //剧目名称
	Media          string `json:"media" validate:"required"`           // 媒体名称
	Distributor    string `json:"distributor" validate:"required"`     // 分销商
	OptimizerId    int64  `json:"optimizer_id" validate:"required"`    // 优化师ID
	OptimizerName  string `json:"optimizer_name" validate:"required"`  // 优化师
	AdvertiserId   string `json:"advertiser_id" validate:"required"`   // 账户ID
	AdvertiserName string `json:"advertiser_name" validate:"required"` // 账户名称
	Region         string `json:"region" validate:"required"`          // 城市
	ApuCreateTime  string `json:"apu_create_time" validate:"required"` // 创建时间 格式 2025-01-16 00:00:00
}

func NewAccountAddReq(c *gin.Context) *AddReq {
	req := &AddReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	validate := validator.New()
	err := validate.Struct(req.Params)
	if err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

type OptimizerInfo struct {
	NickName string `json:"nick_name"`
	Region   string `json:"region"`
}

type AddFilterOptions struct {
	AppName       []string         `json:"app_name"`
	Media         []string         `json:"media"`
	OptimizerList []*OptimizerInfo `json:"optimizer_list"`
}

type BatchActionReq struct {
	common.CommonParams
	Params *BatchActionParams `json:"params"`
}

type BatchActionParams struct {
	AdvertiserId []string `json:"advertiser_id" validate:"required"`
	ActionType   int      `json:"action_type" validate:"oneof=0 1"` // 操作类型 0:正常 1:关停
}

func NewBatchActionReq(c *gin.Context) *BatchActionReq {
	req := &BatchActionReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	validate := validator.New()
	err := validate.Struct(req.Params)
	if err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

type UpdateReq struct {
	common.CommonParams
	Params *UpdateParams `json:"params"`
}

type UpdateParams struct {
	Media            string `json:"media" validate:"required"`
	AdvertiserId     string `json:"advertiser_id" validate:"required"`
	AdvertiserStatus int64  `json:"advertiser_status" validate:"oneof=0 1"` // 启用状态 0:正常 1:关停
}

func NewUpdateReq(c *gin.Context) *UpdateReq {
	req := &UpdateReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	validate := validator.New()
	err := validate.Struct(req.Params)
	if err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

type ImportReq struct {
	common.CommonParams
	Params *ImportParams `json:"params"`
}

type ImportParams struct {
	File     string `json:"file" validate:"required"`
	FileInfo []byte
}

type ImportResp struct {
	SuccessAdvertiserId []string `json:"success_advertiser_id"` // 成功插入账户id
}

func NewImportReq(c *gin.Context) *ImportReq {
	req := &ImportReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	validate := validator.New()
	err := validate.Struct(req.Params)
	if err != nil {
		panic(myerror.ParamsError)
	}
	fileText, err := base64.StdEncoding.DecodeString(req.Params.File)
	if err != nil {
		panic(myerror.ParamsError)
	}
	req.Params.FileInfo = fileText
	return req
}
