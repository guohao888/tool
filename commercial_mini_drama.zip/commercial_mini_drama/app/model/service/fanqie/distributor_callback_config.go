package fanqie

import (
	"context"
	"github.com/alitto/pond"
	accountdto "goserver/app/common/dto/accounts"
	repo "goserver/app/common/repository"
	"goserver/app/common/repository/fanqie"
	"goserver/app/library/log"
	"goserver/app/library/playlet/novelsale"
	accountdao "goserver/app/model/dao/accounts"
	fanqiedao "goserver/app/model/dao/fanqie"
	"strconv"
)

type DistributorCallbackConfigService struct {
	Ctx context.Context
}

func NewDistributorCallbackConfigService(ctx context.Context) *DistributorCallbackConfigService {
	return &DistributorCallbackConfigService{Ctx: ctx}
}

func (d *DistributorCallbackConfigService) SyncCallbackConfig(params accountdto.DistributorPromotionUrlSyncExecutorParams) error {

	// 获取番茄秘钥配置
	distributorConfigDao := accountdao.NewDistributorConfigDao(d.Ctx)
	configs, err := distributorConfigDao.ListByDistributor(repo.DistributorFanqie, params.ApiIds)
	if err != nil {
		log.Errorf("DistributorCallbackConfigService.SyncCallbackConfig 获取番茄密钥配置错误, err: %s", err)
		return err
	}

	resChan := make(chan *fanqie.CallbackConfigEntity)
	errChan := make(chan error)
	go func() {
		pool := pond.New(params.PoolWorkers, 500)
		defer pool.StopAndWait()
		group, _ := pool.GroupContext(context.Background())

		for _, v1 := range configs {
			config := v1

			apiId, err := strconv.ParseInt(config.ApiId, 10, 64)
			if err != nil {
				continue
			}
			wxGetPackageListV2List, err := novelsale.AllWxGetPackageListV2(novelsale.AllWxGetPackageListV2Req{
				DistributorId: apiId,
				SecretKey:     config.ApiSecret,
				AppType:       config.AppType,
			})
			if err != nil {
				log.Errorf("DistributorCallbackConfigService.SyncCallbackConfig 获取账户下分包信息错误, err: %s, api_id: %d, app_type: %d", err, apiId, config.AppType)
			}

			for _, v2 := range wxGetPackageListV2List {
				p := v2

				group.Submit(func() error {
					wxGetBoundPackageList, err := novelsale.AllWxGetBoundPackageListV1(novelsale.AllWxGetBoundPackageListV1Req{
						DistributorId: apiId,
						SecretKey:     config.ApiSecret,
						AppId:         p.AppId,
					})
					if err != nil {
						log.Errorf("DistributorCallbackConfigService.SyncCallbackConfig 获取小程序渠道信息错误, err: %s, api_id: %d, app_id: %d", err, apiId, p.AppId)
						return err
					}

					for _, bp := range wxGetBoundPackageList {
						adCallbackConfigList, err := novelsale.GetAdCallbackConfigListV1(novelsale.GetAdCallbackConfigListV1Req{
							DistributorId: bp.DistributorId,
							SecretKey:     config.ApiSecret,
							MediaSource:   1,
						})
						if err != nil {
							log.Errorf("DistributorCallbackConfigService.SyncCallbackConfig 回传规则错误, err: %s, distributorId: %d", err, bp.DistributorId)
							continue
						}

						for _, v := range adCallbackConfigList {
							info := &fanqie.CallbackConfigEntity{
								ConfigId:   int64(v.ConfigId),
								ConfigName: v.ConfigName,
							}
							resChan <- info
						}
					}

					return nil
				})
			}
		}

		e := group.Wait()
		if e != nil {
			errChan <- e
			close(errChan)
		}
		close(resChan)
	}()
	callbackDao := fanqiedao.NewCallbackConfigDao(d.Ctx)

	batchSize := 3000
	var data []*fanqie.CallbackConfigEntity
	for {
		var breakFlag bool
		select {
		case err, ok := <-errChan:
			if ok {
				return err
			}
		case res, ok := <-resChan:
			if ok {
				data = append(data, res)
				if len(data) > batchSize {
					err := callbackDao.InsertBatchSize(data, batchSize)
					if err != nil {
						log.Errorf("DistributorCallbackConfigService.SyncCallbackConfig 数据插入失败, err: %s", err)
						return err
					}
					data = data[:0]
				}
			} else {
				breakFlag = true
			}
		}
		if breakFlag {
			break
		}
	}
	if len(data) > 0 {
		err := callbackDao.InsertBatchSize(data, batchSize)
		if err != nil {
			log.Errorf("DistributorCallbackConfigService.SyncCallbackConfig 数据插入失败, err: %s", err)
			return err
		}
		data = data[:0]
	}

	return nil
}
