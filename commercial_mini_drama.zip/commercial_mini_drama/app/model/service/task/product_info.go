package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	"goserver/app/model/service/product"
)

// SyncProductInfos 拉取商品列表
func SyncProductInfos(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("拉取商品列表时间错误, err: %s", err)
	}
	//
	productService := product.NewInfoProductService(ctx)
	for _, crontabDate := range crontabDateList {
		err = productService.SyncProductInfos(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("拉取商品列表失败, err: %s", err)
		}
	}
	return "拉取商品列表数据成功"
}
