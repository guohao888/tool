package optimizer

import (
	"context"
	"github.com/jinzhu/gorm"
	"goserver/app/common/dto/optimizerdto"
	"goserver/app/common/dto/page"
	repoOptimizer "goserver/app/common/repository/optimizer"
	"goserver/app/model/dao/optimizer"
	"strings"
	"time"
)

type OptimizerService struct {
	Ctx context.Context
}

func NewOptimizerService(ctx context.Context) *OptimizerService {
	return &OptimizerService{Ctx: ctx}
}

// UpdateOptimizerInfo 新增、编辑优化师
func (m *OptimizerService) UpdateOptimizerInfo(params *optimizerdto.OptimizerInfoParams) error {
	var err error

	optimizerDao := optimizer.NewOptimizerDao(m.Ctx)
	if params.SignUpdate == optimizerdto.SignAdd {
		err = optimizerDao.AddOptimizer(params)
	} else {
		err = optimizerDao.UpdateOptimizer(params)
	}

	if err != nil {
		return err
	}
	return nil
}

// OptimizerInfoList 优化师列表
func (m *OptimizerService) OptimizerInfoList(params *optimizerdto.OptimizerInfoListParams) (*page.Paginator, error) {

	optimizerDao := optimizer.NewOptimizerDao(m.Ctx)
	paginator, err := optimizerDao.OptimizerInfoList(params)

	var list []*optimizerdto.OptimizerListInfoResp
	for _, v := range paginator.List.([]*repoOptimizer.OptimizerEntity) {
		info := &optimizerdto.OptimizerListInfoResp{
			OptimizerId:   v.OptimizerId,
			OptimizerName: v.OptimizerName,
			UpdatedAt:     v.UpdatedAt.Format(time.DateTime),
			CreatedAt:     v.CreatedAt.Format(time.DateTime),
		}
		list = append(list, info)
	}
	paginator.List = list

	if err != nil {
		return paginator, err
	}
	return paginator, nil
}

// AddOptimizerCityInfo 添加优化师地区
func (m *OptimizerService) AddOptimizerCityInfo(params *optimizerdto.OptimizerCityInfoParams) error {
	// 验证请求字段

	optimizerCityDao := optimizer.NewOptimizerCityDao(m.Ctx)
	err := optimizerCityDao.AddOptimizerCity(params)

	if err != nil {
		return err
	}
	return nil
}

// UpdateOptimizerCityInfo 编辑优化师地区
func (m *OptimizerService) UpdateOptimizerCityInfo(params *optimizerdto.OptimizerCityInfoParams) error {
	// 验证请求字段
	var err error

	optimizerCityDao := optimizer.NewOptimizerCityDao(m.Ctx)
	if params.SignUpdate == optimizerdto.SignAdd {
		err = optimizerCityDao.AddOptimizerCity(params)
	} else {
		err = optimizerCityDao.UpdateOptimizerCity(params)
	}

	if err != nil {
		return err
	}
	return nil
}

// OptimizerCityInfoList 优化师地区列表
func (m *OptimizerService) OptimizerCityInfoList(params *optimizerdto.OptimizerCityInfoListParams) (*page.Paginator, error) {

	optimizerDao := optimizer.NewOptimizerCityDao(m.Ctx)
	paginator, err := optimizerDao.OptimizerCityInfoList(params)

	var list []*optimizerdto.OptimizerCityListInfoResp
	for _, v := range paginator.List.([]*repoOptimizer.OptimizerCityEntity) {
		info := &optimizerdto.OptimizerCityListInfoResp{
			OptimizerCityId:   v.OptimizerCityId,
			OptimizerCityName: v.OptimizerCityName,
			UpdatedAt:         v.UpdatedAt.Format(time.DateTime),
			CreatedAt:         v.CreatedAt.Format(time.DateTime),
		}
		list = append(list, info)
	}
	paginator.List = list

	if err != nil {
		return paginator, err
	}
	return paginator, nil
}

// UpdateOptimizerCityRelationInfo 编辑优化师地区关联
func (m *OptimizerService) UpdateOptimizerCityRelationInfo(params *optimizerdto.OptimizerCityRelationInfoParams) error {
	// 验证请求字段
	var err error

	optimizerCityDao := optimizer.NewOptimizerCityRelationDao(m.Ctx)
	if params.SignUpdate == optimizerdto.SignAdd {
		err = optimizerCityDao.AddOptimizerCityRelation(params)
	} else {
		err = optimizerCityDao.UpdateOptimizerCityRelation(params)
	}

	if err != nil {
		return err
	}
	return nil
}

// GetRelationByOptimizerName 通过优化师名称获取数据
func (m *OptimizerService) GetRelationByOptimizerName(params *optimizerdto.GetRelationByOptimizerNameInfoParams) (*optimizerdto.OptimizerCityRelationListInfoResp, error) {

	optimizerDao := optimizer.NewOptimizerCityDao(m.Ctx)
	res, err := optimizerDao.GetRelationByOptimizerName(params)
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	if err != nil && gorm.IsRecordNotFoundError(err) {
		return nil, nil
	}

	info := &optimizerdto.OptimizerCityRelationListInfoResp{
		OptimizerCityRelationId: res.OptimizerCityRelationId,
		OptimizerId:             res.OptimizerId,
		OptimizerCityId:         res.OptimizerCityId,
		Status:                  res.Status,
		OptimizerName:           res.OptimizerName,
		Phone:                   res.Phone,
		OptimizerCityName:       res.OptimizerCityName,
		UpdatedAt:               res.UpdatedAt.Format(time.DateTime),
		CreatedAt:               res.CreatedAt.Format(time.DateTime),
	}

	return info, nil
}

// RefreshData 通过优化师刷新手机号和地区
func (m *OptimizerService) RefreshData(params *optimizerdto.GetOptimizerRefreshDataParams) (string, error) {
	var msgData string
	optimizerDao := optimizer.NewOptimizerDao(m.Ctx)
	for _, item := range params.GetOptimizerRefreshData {
		msg, err := optimizerDao.RefreshData(item)
		msgData += msg
		if err != nil {
			return msgData, err
		}
	}
	msgData = strings.TrimRight(msgData, ",")
	return msgData, nil
}

// OptimizerCityRelationInfoList 优化师地区关联列表
func (m *OptimizerService) OptimizerCityRelationInfoList(params *optimizerdto.OptimizerCityRelationInfoListParams) (*page.Paginator, error) {

	optimizerDao := optimizer.NewOptimizerCityDao(m.Ctx)
	paginator, err := optimizerDao.OptimizerCityRelationInfoList(params)

	var list []*optimizerdto.OptimizerCityRelationListInfoResp
	for _, v := range paginator.List.([]*repoOptimizer.OptimizerCityRelationViewEntity) {
		info := &optimizerdto.OptimizerCityRelationListInfoResp{
			OptimizerCityRelationId: v.OptimizerCityRelationId,
			OptimizerId:             v.OptimizerId,
			OptimizerCityId:         v.OptimizerCityId,
			Status:                  v.Status,
			OptimizerName:           v.OptimizerName,
			Phone:                   v.Phone,
			OptimizerCityName:       v.OptimizerCityName,
			UpdatedAt:               v.UpdatedAt.Format(time.DateTime),
			CreatedAt:               v.CreatedAt.Format(time.DateTime),
		}
		list = append(list, info)
	}
	paginator.List = list

	if err != nil {
		return paginator, err
	}
	return paginator, nil
}
