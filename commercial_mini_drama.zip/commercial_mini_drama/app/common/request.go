package common

import (
	"bytes"
	"encoding/json"
	"github.com/gin-gonic/gin"
	"goserver/app/library/log"
	"goserver/app/library/myerror"
	"io/ioutil"
)

// Binding from JSON
type Request struct {
	CommonParams
}

type CommonParams struct {
	Timestamp int64     `json:"timestamp" form:"timestamp"`
	Sign      string    `json:"sign" form:"sign"`
	Token     string    `json:"token" form:"token"`
	UserInfo  *UserInfo `json:"user_info"`
}

type UserInfo struct {
	Name              string
	Role              int
	Permission        []string
	Products          []string
	Source            string
	LaunchManageLimit int
	PowerMedia        []string // 媒体权限
}

func (u *UserInfo) userProductMap() map[string]struct{} {
	m := make(map[string]struct{}, len(u.Products))
	for _, v := range u.Products {
		m[v] = struct{}{}
	}
	return m
}

func (u *UserInfo) AuthFilterProducts(products []string) []string {
	m := u.userProductMap()

	var res []string
	for _, v := range products {
		if _, ok := m[v]; ok {
			res = append(res, v)
		}
	}
	return res
}

func GetRequest(c *gin.Context) (req *Request) {
	v, ok := c.Get("request")
	if !ok {
		req = initReq(c)
		c.Set("request", req)
		return
	}
	req = v.(*Request)

	return req
}

func initReq(c *gin.Context) *Request {
	req := &Request{}

	if c.Request.Method == "POST" {
		reqBody, _ := ioutil.ReadAll(c.Request.Body)
		c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(reqBody))
		if err := json.Unmarshal(reqBody, req); err != nil {
			log.Error(err)
			panic(myerror.ParamsError)
		}
	}

	if c.Request.Method == "GET" {
		if err := c.ShouldBindQuery(req); err != nil {
			log.Error(err)
			panic(myerror.ParamsError)
		}
	}

	return req
}

func GetUserInfo(c *gin.Context) *UserInfo {
	req := GetRequest(c)
	return req.UserInfo
}
