package optimizerdto

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common"
	"goserver/app/library/myerror"
	"unicode/utf8"
)

const (
	SignAdd    = "add"    // 添加标识
	SignUpdate = "update" // 更新标识
)

// UpdateOptimizerReq 新增、编辑优化师请求
func UpdateOptimizerReq(c *gin.Context) *OptimizerInfo {
	req := &OptimizerInfo{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)

	// 验证数据
	if req.Params.SignUpdate == "" {
		panic(myerror.OptimizerSignEmptyError)
	}

	if req.Params.OptimizerId == 0 {
		panic(myerror.OptimizerIdEmptyError)
	}

	if len(req.Params.OptimizerName) == 0 {
		panic(myerror.OptimizerNameEmptyError)
	}

	return req
}

// OptimizerListReq 优化师列表请求
func OptimizerListReq(c *gin.Context) *OptimizerInfoListReq {
	req := &OptimizerInfoListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)

	return req
}

// OptimizerInfo 新增/编辑优化师
type OptimizerInfo struct {
	common.CommonParams
	Params *OptimizerInfoParams `json:"params"`
}

// OptimizerInfoParams 新增/编辑优化师
type OptimizerInfoParams struct {
	SignUpdate    string `json:"sign_update" form:"sign_update"`       // 编辑标识 add:添加 update:修改
	OptimizerId   int64  `json:"optimizer_id" form:"optimizer_id"`     // 优化师ID
	OptimizerName string `json:"optimizer_name" form:"optimizer_name"` // 优化师名称
}

// OptimizerInfoListReq 优化师列表
type OptimizerInfoListReq struct {
	common.CommonParams
	Params *OptimizerInfoListParams `json:"params"`
}

type OptimizerInfoListParams struct {
	common.Pagination        // 分页
	OptimizerName     string `json:"optimizer_name" form:"optimizer_name"` // 优化师名称
}

// OptimizerListInfoResp 优化师列表响应数据
type OptimizerListInfoResp struct {
	OptimizerId   int64  `json:"optimizer_id"`   // 优化师ID
	OptimizerName string `json:"optimizer_name"` // 优化师名称
	UpdatedAt     string `json:"updated_at"`     // 优化师更行时间
	CreatedAt     string `json:"created_at"`     // 优化师创建时间
}

// AddOptimizerCityReq 新增优化师地区请求
func AddOptimizerCityReq(c *gin.Context) *OptimizerCityInfo {
	req := &OptimizerCityInfo{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	if len(req.Params.OptimizerCityName) == 0 {
		panic(myerror.OptimizerCityNameEmptyError)
	}

	if len(req.Params.OptimizerCityName) > 10 {
		panic(myerror.OptimizerCityNameMaxError)
	}

	return req
}

// OptimizerCityInfo 新增/编辑优化师地区
type OptimizerCityInfo struct {
	common.CommonParams
	Params *OptimizerCityInfoParams `json:"params"`
}

type OptimizerCityInfoParams struct {
	SignUpdate        string `json:"sign_update" form:"sign_update"`                 // 编辑标识 add:添加 update:修改
	OptimizerCityId   int64  `json:"optimizer_city_id" form:"optimizer_city_id"`     // 优化师主键ID (修改必传)
	OptimizerCityName string `json:"optimizer_city_name" form:"optimizer_city_name"` // 优化师地区名称
}

// UpdateOptimizerCityReq 编辑优化师请求
func UpdateOptimizerCityReq(c *gin.Context) *OptimizerCityInfo {
	req := &OptimizerCityInfo{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	// 验证数据
	if req.Params.SignUpdate == "" {
		panic(myerror.OptimizerCitySignEmptyError)
	}

	// 编辑逻辑验证
	if req.Params.SignUpdate == SignUpdate {
		if req.Params.OptimizerCityId == 0 {
			panic(myerror.OptimizerCityIdEmptyError)
		}
	}

	if utf8.RuneCountInString(req.Params.OptimizerCityName) == 0 {
		panic(myerror.OptimizerCityNameEmptyError)
	}

	if utf8.RuneCountInString(req.Params.OptimizerCityName) > 10 {
		panic(myerror.OptimizerCityNameMaxError)
	}

	return req
}

// OptimizerCityListReq 优化师地区列表请求
func OptimizerCityListReq(c *gin.Context) *OptimizerCityInfoListReq {
	req := &OptimizerCityInfoListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)

	return req
}

// OptimizerCityInfoListReq 优化师地区详情列表
type OptimizerCityInfoListReq struct {
	common.CommonParams
	Params *OptimizerCityInfoListParams `json:"params"`
}
type OptimizerCityInfoListParams struct {
	common.Pagination        // 分页
	OptimizerCityName string `json:"optimizer_city_name" form:"optimizer_city_name"` // 优化师地区名称
}

// OptimizerCityListInfoResp 优化师地区列表响应数据
type OptimizerCityListInfoResp struct {
	OptimizerCityId   int64  `json:"optimizer_city_id"`   // 优化师地区ID
	OptimizerCityName string `json:"optimizer_city_name"` // 优化师地区名称
	UpdatedAt         string `json:"updated_at"`          // 优化师更新时间
	CreatedAt         string `json:"created_at"`          // 优化师创建时间
}

// UpdateOptimizerCityRelationReq 编辑优化师地区绑定请求
func UpdateOptimizerCityRelationReq(c *gin.Context) *OptimizerCityRelationInfo {
	req := &OptimizerCityRelationInfo{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)

	// 验证数据
	if req.Params.SignUpdate == "" {
		panic(myerror.OptimizerCityRelationSignEmptyError)
	}

	// 编辑逻辑验证
	if req.Params.SignUpdate == SignUpdate {
		if req.Params.OptimizerCityRelationId == 0 {
			panic(myerror.OptimizerCityRelationIdEmptyError)
		}
	}

	if req.Params.OptimizerCityId == 0 {
		panic(myerror.OptimizerCityIdEmptyError)
	}

	if req.Params.Status == 0 {
		panic(myerror.OptimizerCityRelationStatusEmptyError)
	}

	if utf8.RuneCountInString(req.Params.Phone) > 20 {
		panic(myerror.OptimizerPhoneMaxError)
	}

	return req
}

// OptimizerCityRelationInfo 编辑优化师地区绑定参数
type OptimizerCityRelationInfo struct {
	common.CommonParams
	Params *OptimizerCityRelationInfoParams `json:"params"`
}

type OptimizerCityRelationInfoParams struct {
	SignUpdate              string `json:"sign_update" form:"sign_update"`                               // 编辑标识 add:添加 update:修改
	OptimizerCityRelationId int64  `json:"optimizer_city_relation_id" form:"optimizer_city_relation_id"` // 关联ID
	OptimizerName           string `json:"optimizer_name" form:"optimizer_name"`                         // 优化师姓名 (添加必传)
	OptimizerCityId         int64  `json:"optimizer_city_id" form:"optimizer_city_id"`                   // 优化师地区主键ID (修改必传)
	Status                  int64  `json:"status" form:"status"`                                         // 状态 1=启用 2=停用
	Phone                   string `json:"phone" form:"phone"`                                           // 手机号

}

// OptimizerCityRelationListReq 优化师地区关联列表请求
func OptimizerCityRelationListReq(c *gin.Context) *OptimizerCityRelationInfoListReq {
	req := &OptimizerCityRelationInfoListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)

	return req
}

// OptimizerCityRelationInfoListReq 优化师地区关联详情列表
type OptimizerCityRelationInfoListReq struct {
	common.CommonParams
	Params *OptimizerCityRelationInfoListParams `json:"params" form:"params"`
}

type OptimizerCityRelationInfoListParams struct {
	common.Pagination        // 分页
	OptimizerId       string `json:"optimizer_id" form:"optimizer_id"`               // 优化师ID
	OptimizerName     string `json:"optimizer_name" form:"optimizer_name"`           // 优化师名称
	OptimizerCityId   int64  `json:"optimizer_city_id" form:"optimizer_city_id"`     // 优化师地区ID
	OptimizerCityName string `json:"optimizer_city_name" form:"optimizer_city_name"` // 优化师地区名称
}

// OptimizerCityRelationListInfoResp 优化师地区关联列表响应数据
type OptimizerCityRelationListInfoResp struct {
	OptimizerCityRelationId int64  `json:"optimizer_city_relation_id"` // 优化师地区关联主键
	OptimizerId             string `json:"optimizer_id"`               // 优化师主键
	OptimizerCityId         int64  `json:"optimizer_city_id"`          // 优化师地区主键
	Status                  int64  `json:"status"`                     // 状态 1=启用 2停用
	OptimizerName           string `json:"optimizer_name"`             // 优化师名称
	Phone                   string `json:"phone"`                      // 手机号
	OptimizerCityName       string `json:"optimizer_city_name"`        // 优化师地区名称
	UpdatedAt               string `json:"updated_at"`                 // 更新时间
	CreatedAt               string `json:"created_at"`                 // 创建时间
}

// GetRelationByOptimizerNameReq 通过优化师名称获取关联列表请求
func GetRelationByOptimizerNameReq(c *gin.Context) *GetRelationByOptimizerNameInfoReq {
	req := &GetRelationByOptimizerNameInfoReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}

	req.UserInfo = common.GetUserInfo(c)

	return req
}

// GetRelationByOptimizerNameInfoReq 优化师地区关联详情
type GetRelationByOptimizerNameInfoReq struct {
	common.CommonParams
	Params *GetRelationByOptimizerNameInfoParams `json:"params" form:"params"`
}

type GetRelationByOptimizerNameInfoParams struct {
	OptimizerName string `json:"optimizer_name" form:"optimizer_name"` // 优化师名称
}

// OptimizerRefreshDataReq 根据优化师刷新手机号和地区
func OptimizerRefreshDataReq(c *gin.Context) *GetOptimizerRefreshDataReq {
	req := &GetOptimizerRefreshDataReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}

	req.UserInfo = common.GetUserInfo(c)

	return req
}

// GetOptimizerRefreshDataReq 根据优化师刷新手机号结构体
type GetOptimizerRefreshDataReq struct {
	common.CommonParams
	Params *GetOptimizerRefreshDataParams `json:"params" form:"params"`
}
type GetOptimizerRefreshDataParams struct {
	GetOptimizerRefreshData []GetOptimizerRefresh `json:"get_optimizer_refresh_data" form:"get_optimizer_refresh_data"`
}
type GetOptimizerRefresh struct {
	OptimizerName     string `json:"optimizer_name" form:"optimizer_name"`      // 优化师名称
	Phone             string `json:"phone" form:"phone"`                        // 手机号
	OptimizerCityName string `json:"optimizer_city_name" form:"optimizer_name"` // 优化师名称
}
