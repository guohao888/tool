package mediareport

import (
	"errors"
	timeUtil "goserver/app/library/utils/time"
	"time"
)

type AccountBillSyncExecutorParams struct {
	AccountIds []string `json:"account_id"` // 账户id
	Start      string   `json:"start"`      // 起始时间，格式: 2024-05-16
	End        string   `json:"end"`        // 结束时间，格式: 2024-05-17 (左闭、右闭)
	PointDate  string   `json:"point_date"` // 指定日期 格式: 2024-05-17
	AppIds     []string `json:"app_ids"`    // 应用Id
}

func (a *AccountBillSyncExecutorParams) CrontabDateList() ([]time.Time, error) {
	if (a.Start != "" && a.End == "") || (a.Start == "" && a.End != "") {
		return nil, errors.New("start date and end date must exist simultaneously")
	}

	var crontabTimeList []time.Time
	if a.PointDate != "" {
		pointDate, err := time.ParseInLocation(time.DateOnly, a.PointDate, time.Local)
		if err != nil {
			return nil, err
		}
		crontabTimeList = append(crontabTimeList, pointDate)
	} else if a.Start != "" && a.End != "" {
		s, err := time.ParseInLocation(time.DateOnly, a.Start, time.Local)
		if err != nil {
			return nil, err
		}
		e, err := time.ParseInLocation(time.DateOnly, a.End, time.Local)
		if err != nil {
			return nil, err
		}
		for s.Before(e.Add(1 * time.Hour)) {
			crontabTimeList = append(crontabTimeList, s)
			s = s.Add(24 * time.Hour)
		}
	} else {
		dateTime, _ := timeUtil.GetDayTime(time.Now().AddDate(0, 0, -1))
		crontabTimeList = append(crontabTimeList, dateTime)
	}

	return crontabTimeList, nil
}
