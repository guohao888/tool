package accounts

type DistributorPromotionUrlSyncExecutorParams struct {
	Distributor string   `json:"-"`
	ApiIds      []string `json:"api_ids"`
	PoolWorkers int      `json:"pool_workers"` // 并发数量
}
