package middleware

import (
	"context"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	"time"
)

// ResultMiddleware 包装执行结果
func ResultMiddleware(tf xxl.TaskFunc) xxl.TaskFunc {

	return func(ctx context.Context, param *xxl.RunReq) string {
		st := time.Now()
		res := tf(ctx, param)
		duration := time.Since(st)

		result := fmt.Sprintf("执行结果: %s, 执行时间: %s", res, duration)

		return result
	}
}
