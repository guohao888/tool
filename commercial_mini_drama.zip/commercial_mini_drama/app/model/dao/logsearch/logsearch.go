package logsearch

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/logsearch"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// SearchLogDao 巨量项目小时DAO
type SearchLogDao struct {
	Ctx context.Context
}

func NewSearchLogDao(ctx context.Context) *SearchLogDao {
	return &SearchLogDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (s *SearchLogDao) InsertBatchSize(data []*logsearch.SearchLogEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 2000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = s.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (s *SearchLogDao) buildInsertSentence(tx *gorm.DB, data []*logsearch.SearchLogEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + logsearch.SearchLogTableName() + " ( search_date, advertiser_id, content_title, object_type, object_id, create_time, content_log ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?),"
		vals = append(vals,
			v.SearchDate,
			v.AdvertiserId,
			v.ContentTitle,
			v.ObjectType,
			v.ObjectId,
			v.CreateTime,
			v.ContentLog,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")
	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
