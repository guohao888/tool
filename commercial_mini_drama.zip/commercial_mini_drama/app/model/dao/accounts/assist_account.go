package accounts

import (
	"context"
	"fmt"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/library/playlet"
	"goserver/app/model/dao"
	"strings"

	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
)

type AssistAccountDao struct {
	Ctx context.Context
}

func NewAssistAccountDao(ctx context.Context) *AssistAccountDao {
	return &AssistAccountDao{Ctx: ctx}
}

func (d *AssistAccountDao) InsertBatchSize(media string, oauthId string, userId string, data []playlet.AdvertiserInfo, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsert(tx, media, oauthId, userId, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		// 如果出现错误，回滚事务
		tx.Rollback()
		return err
	}

	tx.Commit()

	return nil
}

func (d *AssistAccountDao) batchInsert(tx *gorm.DB, media string, oauthId string, userId string, data []playlet.AdvertiserInfo) error {

	insertColumns := []string{"media", "advertiser_id", "advertiser_name", "oauth_id", "user_id"}
	sqlStr := fmt.Sprintf("INSERT INTO "+accountrepo.AssistAccountTableName()+" (%s) VALUES ", strings.Join(insertColumns, ","))
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?),"
		vals = append(vals,
			media,
			v.AdvertiserId,
			v.AdvertiserName,
			oauthId,
			userId,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func (d *AssistAccountDao) FindAccountByAds(ids []string) ([]accountrepo.AssistAccountEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.AssistAccountTableName())
	var list []accountrepo.AssistAccountEntity
	err := q.Debug().Where("advertiser_id in (?) ", ids).Find(&list).Error
	if err != nil {
		return nil, err
	}
	return list, err
}

// FindUserNameByAdvertiserId 根据账户id获取所属投手名
func (d *AssistAccountDao) FindUserNameByAdvertiserId(advIds []string) (map[string]string, error) {
	db := dorisdb.DorisClient()
	var results []accountrepo.AdvIdAndUserName

	sql := fmt.Sprintf(`
		SELECT 
			aa.advertiser_id,
			aac.user_name
		FROM %s aa
		LEFT JOIN assist_account_config aac ON aa.user_id = aac.user_id
		WHERE aa.advertiser_id IN (?)
	`, accountrepo.AssistAccountTableName())

	err := db.Raw(sql, advIds).Scan(&results).Error
	if err != nil {
		return nil, err
	}

	resp := make(map[string]string)
	if len(results) > 0 {
		for _, v := range results {
			resp[v.AdvertiserID] = v.UserName
		}
	}
	return resp, nil
}
