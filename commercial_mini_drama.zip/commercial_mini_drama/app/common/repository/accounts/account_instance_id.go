package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const AccountInstanceIdTable = "account_instance_id"

type AccountInstanceIdEntity struct {
	Media        string    `gorm:"column:media"`         // 媒体
	AdvertiserId string    `gorm:"column:advertiser_id"` // 广告主id
	InstanceId   int64     `gorm:"column:instance_id"`   // 资产id
	SearchType   string    `gorm:"column:search_type"`   // 搜索类型
	CreateTime   string    `gorm:"column:create_time"`   // 数据创建时间
	ModifyTime   string    `gorm:"column:modify_time"`   // 数据更新时间
	CreatedAt    time.Time `gorm:"column:created_at"`    // 创建时间
	UpdatedAt    time.Time `gorm:"column:updated_at"`    // 更新时间
}

func (*AccountInstanceIdEntity) TableName() string {
	return AccountPromotionUrlTableName()
}

func AccountInstanceIdTableName() string {
	if repository.IsDebugTable(AccountInstanceIdTable) {
		return AccountInstanceIdTable + "_dev"
	} else {
		return AccountInstanceIdTable
	}
}
