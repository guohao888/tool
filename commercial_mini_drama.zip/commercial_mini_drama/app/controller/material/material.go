package material

import (
	"encoding/json"
	"github.com/gin-gonic/gin"
	"github.com/tealeg/xlsx"
	"goserver/app/common/dto/materialdto"
	repo "goserver/app/common/repository/material"
	"goserver/app/library/myerror"
	"goserver/app/library/utils"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/material"
	"net/http"
	"net/url"
	"strings"
	"time"
)

func Params(c *gin.Context) {
	r := response.Gin{Ctx: c}

	reportService := material.NewReportService(c)
	params, err := reportService.ReportParams()
	if err != nil { //查询失败，返回数据库查询错误
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, params)
}

func OptionSearch(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := materialdto.NewReportOptionSearchReq(c)

	reportService := material.NewReportService(c)
	options, err := reportService.ReportOptionSearch(req.Keywords, req.SearchType)
	if err != nil {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, options)
}

func ReportData(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := materialdto.NewReportDataReq(c, "view")

	reportService := material.NewReportService(c)
	paginator, err := reportService.ReportData(req)
	if err != nil {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, paginator)
}

func Export(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := materialdto.NewReportDataReq(c, "export")

	reportService := material.NewReportService(c)
	exportData, err := reportService.Export(req)
	if err != nil && err.Error() != "record not found" {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	//excel导出
	file := xlsx.NewFile()
	sheet, _ := file.AddSheet("sheet1")
	var row *xlsx.Row
	var cell *xlsx.Cell
	var style *xlsx.Style
	var col *xlsx.Col

	//标题行
	var title []string
	var keys []string //导出的字段名列表
	title = append(title, "日期")
	title = append(title, "素材封面")
	title = append(title, "素材名称")
	title = append(title, "素材ID")
	keys = append(keys, "date")
	keys = append(keys, "material_cover")
	keys = append(keys, "material_name")
	keys = append(keys, "mid_id")
	for _, key := range req.GroupBy {
		if val, ok := materialdto.GroupByMapping[key]; ok {
			title = append(title, val)
			keys = append(keys, key)
			// 如果聚合维度包含了 account_name, 则自动把 account_id 加进去
			if key == "account_name" {
				title = append(title, "账户ID")
				keys = append(keys, "account_id")
			}
		}
	}
	for _, key := range req.Kpi {
		if val, ok := materialdto.KpiMapping[key]; ok {
			title = append(title, val)
			keys = append(keys, key)
		}
	}
	row = sheet.AddRow()
	for _, v := range title {
		cell = row.AddCell()
		// 设置单元格样式
		style = cell.GetStyle()
		style.Alignment = xlsx.Alignment{
			Horizontal: "center", // 水平居中
			Vertical:   "center", // 垂直居中
		}
		// 设置字体加粗
		style.Font = xlsx.Font{
			Bold: true,
		}
		cell.Value = v
	}
	for idx, v := range keys {
		col = sheet.Col(idx)
		if v == "date" && req.GroupType == "h" {
			col.Width = 20
		} else {
			col.Width = 15
		}
	}

	//内容行
	zhTZ, _ := time.LoadLocation("Asia/Shanghai")
	for _, v := range *exportData {
		row = sheet.AddRow()
		data, _ := json.Marshal(v)
		var m = make(map[string]interface{})
		_ = json.Unmarshal(data, &m)
		for _, key := range keys {
			cell = row.AddCell()
			if val, ok := m[key]; ok {
				if utils.InArray(key, repo.ExcelNumColumn) {
					v := utils.Convert2Int64(val)
					cell.SetInt64(v)
					cell.SetFormat("#,##0")
				} else if utils.InArray(key, repo.ExcelStringColumn) {
					v := utils.Convert2String(val)
					if (key == "pay_type" || key == "mid_id") && v == "0" {
						v = ""
					}
					cell.SetString(v)
				} else if key == "date" {
					t := val.(string)
					if req.GroupType == "h" && t != "汇总" {
						td, _ := time.ParseInLocation(time.DateTime, t, time.Local)
						cell.SetDateWithOptions(td, xlsx.DateTimeOptions{
							ExcelTimeFormat: "yyyy-mm-dd hh:mm:ss",
							Location:        zhTZ,
						})
					} else if req.GroupType == "d" && t != "汇总" {
						td, _ := time.ParseInLocation(time.DateOnly, t, time.Local)
						cell.SetDateWithOptions(td, xlsx.DateTimeOptions{
							ExcelTimeFormat: "yyyy-mm-dd",
							Location:        zhTZ,
						})
					} else {
						cell.SetString(t)
					}
					// 设置单元格样式
					style = cell.GetStyle()
					style.Alignment = xlsx.Alignment{
						Horizontal: "center", // 水平居中
						Vertical:   "center", // 垂直居中
					}
				} else {
					v := utils.Convert2Float64(val)
					cell.SetFloat(v)
					cell.SetFormat("#,##0.00")
				}
			} else {
				cell.SetValue("")
			}
		}
	}

	//导出文件
	ua := c.Request.UserAgent()
	fileName := "投放素材数据报表_" + req.StartDate + "~" + req.EndDate + ".xlsx"
	encodedFileName := strings.Replace(url.QueryEscape(fileName), "+", "20%", -1)
	if strings.Contains(ua, "MSIE") || strings.Contains(ua, "Trident") { // for IE
		c.Header("Content-Disposition", "attachment; filename=\""+url.PathEscape(fileName)+"\"")
	} else if strings.Contains(ua, "Firefox") { // for Firefox
		c.Header("Content-Disposition", "attachment; filename*=UTF-8''"+encodedFileName)
	} else if strings.Contains(ua, "Chrome") || strings.Contains(ua, "Safari") { // for Chrome and Safari
		c.Header("Content-Disposition", "attachment; filename=\""+fileName+"\"; filename*=UTF-8''"+encodedFileName)
	} else { // for other browsers
		c.Header("Content-Disposition", "attachment; filename=\""+fileName+"\"")
	}
	c.Header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Header("Content-Transfer-Encoding", "binary")
	c.Header("Cache-Control", "max-age=0")
	c.Header("Pragma", "no-cache")
	//文件内容写入返回体
	if err := file.Write(c.Writer); err != nil {
		r.Response(myerror.ExportExcelError.Code, err.Error(), nil)
		return
	}
	c.Status(http.StatusOK)
	c.Abort()
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}
