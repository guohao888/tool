package warning

import (
	"encoding/json"
	"github.com/gin-gonic/gin"
	"github.com/tealeg/xlsx"
	"goserver/app/common/dto/warningdto"
	"goserver/app/library/myerror"
	"goserver/app/library/utils"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/warning"
	"net/url"
	"strings"
)

func Export(c *gin.Context) {
	r := response.Gin{Ctx: c}

	req := warningdto.NewAlbumsReq(c)

	albumService := warning.NewAlbumService(c)
	list, err := albumService.Export(req)
	if err != nil && err.Error() != "record not found" {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	//excel导出
	file := xlsx.NewFile()
	sheet, _ := file.AddSheet("sheet1")
	var row *xlsx.Row
	var cell *xlsx.Cell
	var style *xlsx.Style

	//标题行
	var title []string
	var keys = []string{"AlbumId", "AlbumName", "MediaCost", "HourCost", "ROI"}
	for _, v := range keys {
		title = append(title, titleMap[v])
	}
	row = sheet.AddRow()
	for _, v := range title {
		cell = row.AddCell()
		// 设置单元格样式
		style = cell.GetStyle()
		style.Alignment = xlsx.Alignment{
			Horizontal: "center", // 水平居中
			Vertical:   "center", // 垂直居中
		}
		// 设置字体加粗
		style.Font = xlsx.Font{
			Bold: true,
		}
		cell.Value = v
	}
	//内容行
	for _, v := range list {
		row = sheet.AddRow()
		data, _ := json.Marshal(v)
		var m = make(map[string]interface{})
		_ = json.Unmarshal(data, &m)
		for _, key := range keys {
			cell := row.AddCell() // 为每个字段创建新的单元格
			style := cell.GetStyle()
			style.Alignment = xlsx.Alignment{
				Horizontal: "center",
				Vertical:   "center",
			}
			if val, ok := m[key]; ok {
				switch {
				case key == "AlbumId" || key == "AlbumName":
					cv := utils.Convert2String(val)
					cell.SetString(cv)
				default:
					cv := utils.Convert2Float64(val)
					cell.SetFloat(cv)
				}
			}
		}
	}
	//导出文件
	ua := c.Request.UserAgent()
	fileName := "剧目消耗.xlsx"
	encodedFileName := strings.Replace(url.QueryEscape(fileName), "+", "20%", -1)
	if strings.Contains(ua, "MSIE") || strings.Contains(ua, "Trident") { // for IE
		c.Header("Content-Disposition", "attachment; filename=\""+url.PathEscape(fileName)+"\"")
	} else if strings.Contains(ua, "Firefox") { // for Firefox
		c.Header("Content-Disposition", "attachment; filename*=UTF-8''"+encodedFileName)
	} else if strings.Contains(ua, "Chrome") || strings.Contains(ua, "Safari") { // for Chrome and Safari
		c.Header("Content-Disposition", "attachment; filename=\""+fileName+"\"; filename*=UTF-8''"+encodedFileName)
	} else { // for other browsers
		c.Header("Content-Disposition", "attachment; filename=\""+fileName+"\"")
	}
	c.Header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Header("Content-Transfer-Encoding", "binary")
	c.Header("Cache-Control", "max-age=0")
	c.Header("Pragma", "no-cache")
	//文件内容写入返回体
	if err := file.Write(c.Writer); err != nil {
		r.Response(myerror.ExportExcelError.Code, err.Error(), nil)
		return
	}
}

var titleMap = map[string]string{
	"AlbumId":   "剧目ID",
	"AlbumName": "剧目名称",
	"MediaCost": "当日消耗",
	"HourCost":  "近1小时消耗",
	"ROI":       "当日ROI",
}
