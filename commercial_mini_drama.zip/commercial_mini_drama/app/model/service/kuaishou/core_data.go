package kuaishou

import (
	"context"
	"fmt"
	"goserver/app/common"
	ksdto "goserver/app/common/dto/kuaishoudto"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	kuaishouEntity "goserver/app/common/repository/kuaishou"
	"goserver/app/library/playlet/kuaishou"
	accountdao "goserver/app/model/dao/accounts"
	kuaishoudao "goserver/app/model/dao/kuaishou"
	"goserver/app/model/service/mediareport"
	"strconv"
	"sync"
	"time"

	"github.com/panjf2000/ants/v2"
)

type CoreDataService struct {
	Ctx context.Context
}

func NewCoreDataService(ctx context.Context) *CoreDataService {
	return &CoreDataService{Ctx: ctx}
}

type CoreDataItem struct {
	Date                            string  `json:"date"`                                  // 日期（yyyy-MM-dd hh:mm:ss）
	ResourceType                    string  `json:"resource_type"`                         // 流量来源
	SeriesType                      string  `json:"series_type"`                           // 短剧类型
	SeriesID                        string  `json:"series_id"`                             // 剧目ID
	TotalCharge                     float64 `json:"total_charge"`                          // 消耗
	AccuFansUserNum                 int64   `json:"accu_fans_user_num"`                    // 粉丝峰值量
	FansUserNum                     int64   `json:"fans_user_num"`                         // 粉丝净增量
	EventPayRoi                     float64 `json:"event_pay_roi"`                         // 商业化ROI
	EventPayRoiAll                  float64 `json:"event_pay_roi_all"`                     // 全域ROI
	PayUserCount                    int64   `json:"pay_user_count"`                        // 付费人数
	PayCount                        int64   `json:"pay_count"`                             // 付费订单数
	PayAmt                          float64 `json:"pay_amt"`                               // 付费金额
	IsFansUser                      int     `json:"is_fans_user"`                          // 是否粉丝
	DisplayPlayCnt                  int64   `json:"display_play_cnt"`                      // 播放数
	DisplayLikeCnt                  int64   `json:"display_like_cnt"`                      // 点赞数
	DisplayCommentCnt               int64   `json:"display_comment_cnt"`                   // 评论数
	DisplayCollectCnt               int64   `json:"display_collect_cnt"`                   // 收藏数
	MiniGameIaaPurchaseAmountDivide float64 `json:"mini_game_iaa_purchase_amount_divided"` // IAA广告变现LTV（不含返货，元）
	MiniGameIaaDividedRoi           float64 `json:"mini_game_iaa_divided_roi"`             // IAA广告变现ROI（不含返货）
	MiniGameIaaRoi                  float64 `json:"mini_game_iaa_roi"`                     // IAA广告变现ROI（含返货）
	MiniGameIaaPurchaseAmount       float64 `json:"mini_game_iaa_purchase_amount"`         // IAA广告变现LTV（含返货，元）
	ActualMiniGameIaaPurchaseAmount float64 `json:"actual_mini_game_iaa_purchase_amount"`  // 实际IAA广告变现LTV（含返货）
	ActualMiniGameIaaRoi            float64 `json:"actual_mini_game_iaa_roi"`              // 实际IAA广告变现ROI（含返货）

	Media             string  `json:"media"`                // 媒体
	SeriesName        string  `json:"series_name"`          // 剧目名称
	ActualCharge      float64 `json:"actual_charge"`        // 实际消耗
	ActualEventPayRoi float64 `json:"actual_event_pay_roi"` // 商业化实际ROI
	ActualPayAmt      float64 `json:"actual_pay_amt"`       // 实际付费金额
}

func (r *CoreDataService) formatList(dbList []kuaishouEntity.CoreDataEntity, req *ksdto.CoreDataListReq) []CoreDataItem {
	var list []CoreDataItem
	for k, item := range dbList {
		// 处理日期格式
		var dateStr, media, resourceType, seriesType, seriesId string
		if k == 0 && item.Date.Year() == 1970 && item.Date.Month() == 1 && item.Date.Day() == 1 {
			dateStr = "汇总"
		} else {
			dateStr = item.DateStr
			media = "快手"
			resourceType = getResourceTypeStr(req.ResourceType)
			seriesType = getSeriesTypeStr(req.SeriesType)
			seriesId = strconv.FormatInt(item.SeriesId, 10)
		}

		coreDataItem := CoreDataItem{
			Date:                            dateStr,
			ResourceType:                    resourceType,
			SeriesType:                      seriesType,
			TotalCharge:                     float64(item.TotalCharge) / 1000.0,
			AccuFansUserNum:                 item.AccuFansUserNum,
			FansUserNum:                     item.FansUserNum,
			EventPayRoi:                     item.EventPayRoi,
			EventPayRoiAll:                  item.EventPayRoiAll,
			PayUserCount:                    item.PayUserCount,
			PayCount:                        item.PayCount,
			PayAmt:                          item.PayAmt,
			IsFansUser:                      item.IsFansUser,
			DisplayPlayCnt:                  item.DisplayPlayCnt,
			DisplayLikeCnt:                  item.DisplayLikeCnt,
			DisplayCommentCnt:               item.DisplayCommentCnt,
			DisplayCollectCnt:               item.DisplayCollectCnt,
			MiniGameIaaPurchaseAmount:       item.MiniGameIaaPurchaseAmount,
			MiniGameIaaRoi:                  item.MiniGameIaaRoi,
			MiniGameIaaPurchaseAmountDivide: item.MiniGameIaaPurchaseAmountDivide,
			MiniGameIaaDividedRoi:           item.MiniGameIaaDividedRoi,
			ActualMiniGameIaaPurchaseAmount: item.ActualMiniGameIaaPurchaseAmount,
			ActualMiniGameIaaRoi:            item.ActualMiniGameIaaRoi,
			Media:                           media,
			SeriesID:                        seriesId,
			SeriesName:                      item.SeriesName,
			ActualCharge:                    item.ActualCharge / 1000.0,
			ActualEventPayRoi:               item.ActualEventPayRoi,
			ActualPayAmt:                    item.ActualPayAmt,
		}
		list = append(list, coreDataItem)
	}
	return list
}

func (r *CoreDataService) CoreDataList(req *ksdto.CoreDataListReq) (*ksdto.CoreDataListResp, error) {
	reportDataDao := kuaishoudao.NewCoreDataDao(r.Ctx)
	// 分页数据
	dbList, cnt, err := reportDataDao.List(req)
	if err != nil {
		return nil, err
	}
	// service层格式化
	list := r.formatList(dbList, req)
	pullTimeDao := kuaishoudao.NewPullTimeDao(r.Ctx)
	lastPullTime, err := pullTimeDao.GetMaxPullTime(2)
	if err != nil {
		return nil, err
	}

	pagination := req.Pagination
	paginator := common.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), cnt, list)

	return &ksdto.CoreDataListResp{
		Paginator:      &paginator,
		LastModifyTime: lastPullTime.Format("2006-01-02 15:04:05"),
	}, nil
}

// getResourceTypeStr 获取资源类型字符串
func getResourceTypeStr(resourceType int64) string {
	if resourceType == 1 {
		return "自然流量"
	}
	if resourceType == 2 {
		return "商业流量"
	}
	return "全部"
}

// getSeriesTypeStr 获取系列类型字符串
func getSeriesTypeStr(seriesType int64) string {
	if seriesType == 1 {
		return "IAA"
	}
	if seriesType == 2 {
		return "IAP"
	}
	return "全部"
}

func (r *CoreDataService) CoreDataExport(req *ksdto.CoreDataListReq) (*[]CoreDataItem, error) {
	reportDataDao := kuaishoudao.NewCoreDataDao(r.Ctx)
	dbList, err := reportDataDao.Export(req)
	if err != nil {
		return nil, err
	}
	list := r.formatList(dbList, req)
	return &list, nil
}

type SeriesInfos struct {
	SeriesId   int64
	SeriesType int
}

// DistributeCoreDataHistory 拉取广告核心数据
func (r *CoreDataService) DistributeCoreDataHistory(crontabTime time.Time, ctx context.Context) error {
	// 获取执行时间
	startDate, endDate := mediareport.GetExecTime(crontabTime)
	start, _ := time.ParseInLocation(time.DateTime, startDate+" 00:00:00", time.Local)
	end, _ := time.ParseInLocation(time.DateTime, endDate+" 23:59:59", time.Local)
	startTime := start.UnixNano() / 1e6
	endTime := end.UnixNano() / 1e6
	adDetailDao := kuaishoudao.NewAdDetailDao(ctx)
	seriesInfo, err := adDetailDao.GetSeriesIdsAndType(startDate)
	if err != nil {
		return fmt.Errorf("查询快手剧目列表失败, err: %v", err)
	}
	seriesMap := make(map[int64][]SeriesInfos)
	for _, v := range seriesInfo {
		seriesMap[v.AdvertiserId] = append(seriesMap[v.AdvertiserId], SeriesInfos{SeriesId: v.SeriesId, SeriesType: v.SeriesType})
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用appid
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaKuaishou)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaKuaishou, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		oauthMap[v.AppId][v.UserId] = v.AccessToken
	}

	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(oauthList) / len(appIds)
	remainder := len(oauthList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		// 为每个goroutine创建局部变量
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncKuaishouCoreDataHistory(startTime, endTime, oauthList[start:end], oauth, seriesMap)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func SyncKuaishouCoreDataHistory(start, end int64, userIds []accountrepo.OauthEntity, oauth map[string]string, seriesMap map[int64][]SeriesInfos) {

	resChan := make(chan *kuaishouEntity.CoreDataEntity)
	errChan := make(chan error, len(userIds))

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	once.Do(func() {
		go func() {
			dbErr := execCoreDataDB(context.Background(), resChan)
			if dbErr != nil {
				errChan <- fmt.Errorf("execCoreDataDB err: %s", dbErr.Error())
			}
		}()
	})
	for _, v := range userIds {
		wg.Add(1)
		currentItem := v
		advertiserId, _ := strconv.Atoi(currentItem.UserId)

		task := func() {
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()
			_, exists := oauth[currentItem.UserId]
			if !exists {
				return
			}
			for _, series := range seriesMap[int64(advertiserId)] {
				for _, resType := range []int{1, 2} {
					if resType == 2 {
						resType = 0
					}
					allReq, getErr := kuaishou.AllCoreDate(context.Background(), kuaishou.ReportQueryCoreReq{
						AdvertiserId: int64(advertiserId),
						AccessToken:  oauth[currentItem.UserId],
						StartTime:    start,
						EndTime:      end,
						SeriesIds:    []int64{series.SeriesId},
						ResourceType: resType,
						Source:       1,
						SeriesType:   series.SeriesType,
					})
					if getErr != nil {
						errChan <- fmt.Errorf("短剧核心总览数据, advertiserId: %d, token: %s,  err: %s", advertiserId, oauth[currentItem.UserId], getErr.Error())
						return
					}
					for _, row := range allReq {
						info := trans2CoreEntity(row, int64(advertiserId), series.SeriesId, series.SeriesType, int64(resType), 1)
						resChan <- info
					}
				}
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		fmt.Println(errL.Error())
		errs = append(errs, errL)
	}
}

func execCoreDataDB(ctx context.Context, resChan <-chan *kuaishouEntity.CoreDataEntity) (err error) {
	// 保存数据DAO
	coreDataDao := kuaishoudao.NewCoreDataDao(ctx)
	var data = make([]*kuaishouEntity.CoreDataEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			err = coreDataDao.InsertBatchSize(data, 5000)
			if err != nil {
				errs = append(errs, err) // 收集错误，不退出
			}
			data = data[:0]
		}
	}
	if len(data) > 0 {
		err = coreDataDao.InsertBatchSize(data, 5000)
		if err != nil {
			errs = append(errs, err) // 收集错误，不退出
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execCoreDataDB errors: %v", errs)
	}
	return nil
}

func trans2CoreEntity(v kuaishou.CoreData, advertiserId int64, seriesId int64, seriesType int, resourceType, source int64) *kuaishouEntity.CoreDataEntity {
	date, _ := time.ParseInLocation(time.DateTime, v.Date+":00", time.Local)
	var isFansUser int
	if v.IsFansUser {
		isFansUser = 1
	} else {
		isFansUser = 2
	}
	if resourceType == 0 {
		resourceType = 2
	}
	info := &kuaishouEntity.CoreDataEntity{
		AdvertiserId:                    advertiserId,
		Date:                            date,
		ResourceType:                    resourceType,
		Source:                          source,
		SeriesId:                        seriesId,
		SeriesType:                      seriesType,
		TotalCharge:                     v.TotalCharge,
		AccuFansUserNum:                 v.AccuFansUserNum,
		FansUserNum:                     v.FansUserNum,
		EventPayRoi:                     v.EventPayRoi,
		EventPayRoiAll:                  v.EventPayRoiAll,
		PayUserCount:                    v.PayUserCount,
		PayCount:                        v.PayCount,
		PayAmt:                          v.PayAmt,
		IsFansUser:                      isFansUser,
		DisplayPlayCnt:                  v.DisplayPlayCnt,
		DisplayLikeCnt:                  v.DisplayLikeCnt,
		DisplayCommentCnt:               v.DisplayCommentCnt,
		DisplayCollectCnt:               v.DisplayCollectCnt,
		MiniGameIaaRoi:                  v.MiniGameIaaRoi,
		MiniGameIaaPurchaseAmount:       v.MiniGameIaaPurchaseAmount,
		MiniGameIaaPurchaseAmountDivide: v.MiniGameIaaPurchaseAmountDivide,
		MiniGameIaaDividedRoi:           v.MiniGameIaaDividedRoi,
	}
	return info
}

// DistributeCoreDataTodayIAA 拉取广告核心数据 实时数据 IAA
func (r *CoreDataService) DistributeCoreDataTodayIAA(crontabTime time.Time, ctx context.Context) error {
	// 获取执行时间
	startDate, endDate := mediareport.GetExecTime(crontabTime)
	start, _ := time.ParseInLocation(time.DateTime, startDate+" 00:00:00", time.Local)
	end, _ := time.ParseInLocation(time.DateTime, endDate+" 23:59:59", time.Local)
	startTime := start.UnixNano() / 1e6
	endTime := end.UnixNano() / 1e6
	adDetailDao := kuaishoudao.NewAdDetailDao(ctx)
	seriesInfo, err := adDetailDao.DistinctSeriesIds()
	if err != nil {
		return fmt.Errorf("查询快手剧目列表失败, err: %v", err)
	}
	seriesMap := make(map[int64][]int64)
	for _, v := range seriesInfo {
		seriesMap[v.AdvertiserId] = append(seriesMap[v.AdvertiserId], v.SeriesId)
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用appid
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaKuaishou)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaKuaishou, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		oauthMap[v.AppId][v.UserId] = v.AccessToken
	}

	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(oauthList) / len(appIds)
	remainder := len(oauthList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		// 为每个goroutine创建局部变量
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncKuaishouCoreDataTodayIAA(startTime, endTime, oauthList[start:end], oauth, seriesMap)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func SyncKuaishouCoreDataTodayIAA(start, end int64, userIds []accountrepo.OauthEntity, oauth map[string]string, seriesMap map[int64][]int64) {

	resChan := make(chan *kuaishouEntity.CoreDataEntity)
	errChan := make(chan error, len(userIds))

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	once.Do(func() {
		go func() {
			dbErr := execCoreDataDB(context.Background(), resChan)
			if dbErr != nil {
				errChan <- fmt.Errorf("execCoreDataDB err: %s", dbErr.Error())
			}
		}()
	})
	for _, v := range userIds {
		wg.Add(1)
		currentItem := v
		advertiserId, _ := strconv.Atoi(currentItem.UserId)

		task := func() {
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()
			_, exists := oauth[currentItem.UserId]
			if !exists {
				return
			}
			for _, seriesId := range seriesMap[int64(advertiserId)] {
				for _, resType := range []int{1, 2} {
					if resType == 2 {
						resType = 0
					}
					allReq, getErr := kuaishou.AllCoreDate(context.Background(), kuaishou.ReportQueryCoreReq{
						AdvertiserId: int64(advertiserId),
						AccessToken:  oauth[currentItem.UserId],
						StartTime:    start,
						EndTime:      end,
						SeriesIds:    []int64{seriesId},
						ResourceType: resType,
						Source:       0,
					})
					if getErr != nil {
						errChan <- fmt.Errorf("短剧核心总览数据, advertiserId: %d, token: %s,  err: %s", advertiserId, oauth[currentItem.UserId], getErr.Error())
						return
					}
					for _, row := range allReq {
						info := trans2CoreEntity(row, int64(advertiserId), seriesId, 0, int64(resType), 0)
						resChan <- info
					}
				}
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		fmt.Println(errL.Error())
		errs = append(errs, errL)
	}

	//if len(errs) > 0 {
	//	_ = sendMsg(errs, "同步账单数据\n")
	//}
	//return
}

// DistributeCoreDataTodayIAP 拉取广告核心数据 实时数据 IAP
func (r *CoreDataService) DistributeCoreDataTodayIAP(crontabTime time.Time, ctx context.Context) error {
	// 获取执行时间
	startDate, endDate := mediareport.GetExecTime(crontabTime)
	start, _ := time.ParseInLocation(time.DateTime, startDate+" 00:00:00", time.Local)
	end, _ := time.ParseInLocation(time.DateTime, endDate+" 23:59:59", time.Local)
	startTime := start.UnixNano() / 1e6
	endTime := end.UnixNano() / 1e6
	adDetailDao := kuaishoudao.NewAdDetailDao(ctx)
	seriesInfo, err := adDetailDao.DistinctSeriesIds()
	if err != nil {
		return fmt.Errorf("查询快手剧目列表失败, err: %v", err)
	}
	seriesMap := make(map[int64][]int64)
	for _, v := range seriesInfo {
		seriesMap[v.AdvertiserId] = append(seriesMap[v.AdvertiserId], v.SeriesId)
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用appid
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaKuaishou)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaKuaishou, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		oauthMap[v.AppId][v.UserId] = v.AccessToken
	}

	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(oauthList) / len(appIds)
	remainder := len(oauthList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		// 为每个goroutine创建局部变量
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncKuaishouCoreDataTodayIAP(startTime, endTime, oauthList[start:end], oauth, seriesMap)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func SyncKuaishouCoreDataTodayIAP(start, end int64, userIds []accountrepo.OauthEntity, oauth map[string]string, seriesMap map[int64][]int64) {

	resChan := make(chan *kuaishouEntity.CoreDataEntity)
	errChan := make(chan error, len(userIds))

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	once.Do(func() {
		go func() {
			dbErr := execCoreDataDB(context.Background(), resChan)
			if dbErr != nil {
				errChan <- fmt.Errorf("execCoreDataDB err: %s", dbErr.Error())
			}
		}()
	})
	for _, v := range userIds {
		wg.Add(1)
		currentItem := v
		advertiserId, _ := strconv.Atoi(currentItem.UserId)

		task := func() {
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()
			_, exists := oauth[currentItem.UserId]
			if !exists {
				return
			}
			for _, seriesId := range seriesMap[int64(advertiserId)] {
				for _, resType := range []int{1, 2} {
					if resType == 2 {
						resType = 0
					}
					allReq, getErr := kuaishou.AllCoreDate(context.Background(), kuaishou.ReportQueryCoreReq{
						AdvertiserId: int64(advertiserId),
						AccessToken:  oauth[currentItem.UserId],
						StartTime:    start,
						EndTime:      end,
						SeriesIds:    []int64{seriesId},
						ResourceType: resType,
						Source:       0,
					})
					if getErr != nil {
						errChan <- fmt.Errorf("短剧核心总览数据, advertiserId: %d, token: %s,  err: %s", advertiserId, oauth[currentItem.UserId], getErr.Error())
						return
					}
					for _, row := range allReq {
						info := trans2CoreEntity(row, int64(advertiserId), seriesId, 0, int64(resType), 0)
						resChan <- info
					}
				}
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		fmt.Println(errL.Error())
		errs = append(errs, errL)
	}

	//if len(errs) > 0 {
	//	_ = sendMsg(errs, "同步账单数据\n")
	//}
	//return
}
