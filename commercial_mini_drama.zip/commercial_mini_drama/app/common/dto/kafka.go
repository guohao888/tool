package dto

import "encoding/json"

// KafkaMessage Kafka消息通用结构体
type KafkaMessage struct {
	Type    string          `json:"type"`    // 消息类型：user/iaa_order/iap_order
	Payload json.RawMessage `json:"payload"` // 实际数据,使用RawMessage可以保持json数据的原始格式,避免二次序列化和反序列化带来的性能开销
}

// KafkaMessageType Kafka消息类型常量
const (
	KafkaMessageSpiMaterial = "spi_material" // spi素材更新
)
