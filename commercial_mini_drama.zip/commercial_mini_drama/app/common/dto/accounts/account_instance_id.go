package accounts

type AccountInstanceIdSyncExecutorParams struct {
	Media           string   `json:"-"`
	AdvertiserIds   []string `json:"advertiser_ids"`
	PoolWorkers     int      `json:"pool_workers"`      // 并发数量
	AppIds          []string `json:"app_ids"`           // 应用Id
	SearchType      string   `json:"search_type"`       // 搜索类型: 自建的、分享的
	InsertBatchSize int      `json:"insert_batch_size"` // 数据库分批数量
	Priority        string   `json:"priority"`          // 优先级
}
