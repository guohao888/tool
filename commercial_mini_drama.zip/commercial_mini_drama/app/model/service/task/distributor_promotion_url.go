package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	"goserver/app/library/log"
	"goserver/app/model/service/accounts"
)

func DistributorPromotionUrlSyncFanqie(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.DistributorPromotionUrlSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
	}

	params.Distributor = repository.DistributorFanqie
	if params.PoolWorkers == 0 {
		params.PoolWorkers = 10
	}

	distributorPromotionUrlService := accounts.NewDistributorPromotionUrlService(ctx)
	err := distributorPromotionUrlService.SyncFanqie(params)
	if err != nil {
		log.Errorf("同步番茄分销商的推广链数据错误, err: %s", err)
		panic(fmt.Errorf("同步番茄分销商的推广链数据错误, err: %w", err))
	}

	return "同步番茄分销商的推广链数据成功"
}
