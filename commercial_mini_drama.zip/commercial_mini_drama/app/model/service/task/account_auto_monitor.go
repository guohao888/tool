package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/widthtable"
	noticeCommon "goserver/app/library/utils/notice/common"
	accountsService "goserver/app/model/service/accounts"
	"time"
)

func ExecAccountMonitor1(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	pullEmptyService := accountsService.NewAccountPullEmptyService(ctx)

	// 查找需要监控的账户
	accountList, err := pullEmptyService.FindAccountMonitor(accountsService.MapOne)
	if err != nil {
		return fmt.Sprintf("查询拉空账户失败, err: %s", err)
	}
	if len(accountList) == 0 {
		return fmt.Sprintf("没有需要拉空的账户")
	}
	// 拉空操作
	pullRes, err := pullEmptyService.PullEmptyAction(accountList)
	if err != nil {
		return fmt.Sprintf("拉空操作失败, err: %s", err)
	}
	// 发送消息
	SendAndPullEmptyMsg(pullRes, accountsService.TaskOne)
	return "成功"
}

// SendAndPullEmptyMsg 推推发送消息
func SendAndPullEmptyMsg(accountList []accountsService.AccountAccess, taskType int) {
	// 发送消息
	var msgResult noticeCommon.QueryResult
	msgResult.Columns = append(msgResult.Columns, "账户ID", "账户所属账管")
	msgResult.Column2 = append(msgResult.Column2, "账户ID", "项目ID", "结果")
	msgResult.Rows = accountList
	msgResult.Rows2 = accountsService.FilterData(accountList)
	msgResult.GroupNum = "7652669649084640"
	switch taskType {
	case accountsService.TaskOne:
		msgResult.ExcelName = "命中拉空账户明细--时速消耗>1000,当日roi< 30%-" + time.Now().Format("20060102-15")
	case accountsService.TaskTwo:
		msgResult.ExcelName = "命中拉空账户明细--时速消耗>500,当日roi<80%-" + time.Now().Format("20060102-15")

	case accountsService.TaskThree:
		msgResult.ExcelName = "命中拉空账户明细--时速消耗>5000,当日roi<90%-" + time.Now().Format("20060102-15")
	}
	SendProductExcelRepostMsg(&msgResult)
}

// ExecAccountMonitor2 监控指标2  1. 时速消耗>500，当日roi<80% ||     2. 时速消耗>5000，当日roi<90%
func ExecAccountMonitor2(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	pullEmptyService := accountsService.NewAccountPullEmptyService(ctx)
	// 获取拉空的账户
	accountList1, err := pullEmptyService.FindAccountMonitor(accountsService.MapTwo)
	if err != nil {
		return fmt.Sprintf("查询拉空账户失败, err: %s", err)
	}

	// 监控     1. 时速消耗>500，当日roi<80%
	if len(accountList1) > 0 {
		accountInfos, err := pullEmptyService.PullEmptyAction(accountList1)
		if err != nil {
			return fmt.Sprintf("拉空操作失败, err: %s", err)
		}
		SendAndPullEmptyMsg(accountInfos, accountsService.TaskTwo)

	}
	// 监控      2. 时速消耗>5000，当日roi<90%
	accountList2, err := pullEmptyService.FindAccountMonitor(accountsService.MapThree)
	if err != nil {
		return fmt.Sprintf("查询拉空账户失败, err: %s", err)
	}
	if len(accountList2) > 0 {
		accountInfos, err := pullEmptyService.PullEmptyAction(accountList2)
		if err != nil {
			return fmt.Sprintf("拉空操作失败, err: %s", err)
		}
		SendAndPullEmptyMsg(accountInfos, accountsService.TaskThree)
	}
	return "成功"
}
