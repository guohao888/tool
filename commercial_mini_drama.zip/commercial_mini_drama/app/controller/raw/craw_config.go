package raw

import (
	"github.com/gin-gonic/gin"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/raw"
)

func UpdateCookie(c *gin.Context) {

	r := response.Gin{Ctx: c}
	var request raw.Config
	// 1. 绑定 JSON 请求体
	if err := c.ShouldBindJSON(&request); err != nil {
		r.Response(myerror.ReferralImportFileError.Code, myerror.ReferralImportFileError.Message, nil)
		return
	}

	// 更新数据
	service := raw.NewCrawConfigService(c)
	err := service.UpdateData(request)
	if err != nil {
		r.Response(myerror.DBExecError.Code, myerror.DBExecError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)

}
