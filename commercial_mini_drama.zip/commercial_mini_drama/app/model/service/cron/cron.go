package cron

import (
	"fmt"
	"github.com/spf13/viper"
	"github.com/xxl-job/xxl-job-executor-go"
	"go.uber.org/zap"
	repo "goserver/app/common/repository"
	"goserver/app/library/cronlog"
	"goserver/app/library/cronlog/middleware"
	"goserver/app/library/log"
	"goserver/app/library/utils"
	"strings"
)

const xxlToken = "LrVllpMHAY0uknUD" //请求令牌，与调度中心一致

var exec xxl.Executor                           //使用包级变量保存实例，让实例的生命周期和进程相同，最后记得关闭，关闭了里有解注册
var toutiaoAppIdTaskRegister *AppIdTaskRegister // 头条应用任务注册

// InitCron 初始化一个执行器实例
func InitCron() error {
	//获取本进程所在机器的内网ip，做服务注册时候用
	ip, err := utils.ExternalIP()
	if err != nil {
		return err
	}

	//执行器名称建议定义为服务+环境，相同名称的执行器会被分为同一组，调度的时候会在名称相同的执行器内进行调度
	_ = cronlog.InitLogPath()

	runmode := viper.GetString("runmode")

	if strings.Contains(runmode, "debug") {
		executorName += "-" + runmode
	}
	executorName += viper.GetString("cron_suffix")

	exec = xxl.NewExecutor(
		xxl.ServerAddr("http://cron.shouji.qihoo.net/xxl-job-admin"), //调度中心的地址
		xxl.AccessToken(xxlToken),                                    //请求令牌，与调度中心一致
		xxl.ExecutorIp(ip.String()),                                  //本进程所在机器ip，用于服务注册
		xxl.ExecutorPort("9999"),                                     //默认9999（非必填）
		xxl.RegistryKey(executorName),                                //执行器名称
		xxl.SetLogger(&executorLogger{}),                             //自定义日志，指的是执行器的日志
	)
	exec.Init()

	//设置日志查看handler，这个日志handler是自己的实现的业务用日志处理，用于上报执行进度等
	exec.LogHandler(cronlog.CronCustomLogHandle)
	exec.Use(middleware.ResultMiddleware)

	//注册任务handler，注册必须要run之前调用，目前不支持动态注册。
	//参数中的pattern唯一标识了一个任务，做配置时候需要用到这个名字
	for name, handler := range handlerMap {
		exec.RegTask(name, handler) //自己实现的需要调度的函数
	}

	// 头条分应用注册任务
	toutiaoAppIdTaskRegister, err = NewAppIdTaskRegister(repo.MediaToutiao, exec)
	if err != nil {
		return err
	}

	// 服务注册任务
	appIds, err := toutiaoAppIdTaskRegister.GetToutiaoAppIds()
	if err != nil {
		return err
	}
	toutiaoAppIdTaskRegister.ToutiaoAppIdRegTask(appIds)
	// xxl-job admin 新增任务
	//toutiaoAppIdTaskRegister.ToutiaoAppIdJobInfoAdd(appIds)

	//exec.Run()是阻塞的，使用协程来启动执行器服务
	go func() {
		if err := exec.Run(); err != nil {
			log.Error("Run failed", zap.Error(err))
		}
		log.Info("启动完成，按理来说应该看不到这条日志，因为是阻塞的")
	}()

	return nil
}

// CloseExecutor 关闭执行器实例，请在main函数使用defer调用该函数，执行器的生命周期应和进程相同
func CloseExecutor() {
	if exec != nil {
		exec.Stop()
	}
}

// xxl.Logger 接口实现，这个日志是xxl-job-executor-go插件运行所落的日志，不是业务日志
type executorLogger struct{}

// Info 自定义格式：id-内容
func (l *executorLogger) Info(format string, a ...interface{}) {
	s := fmt.Sprintf(format, a...)
	log.Info(s)
}

func (l *executorLogger) Error(format string, a ...interface{}) {
	s := fmt.Sprintf(format, a...)
	log.Error(s)
}
