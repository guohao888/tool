package warning

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/dto/page"
	"goserver/app/common/dto/warningdto"
	repo "goserver/app/common/repository/material"
	"goserver/app/common/repository/warning"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

type MsgWarningDao struct {
	Ctx context.Context
}

func NewMsgWarningDao(ctx context.Context) *MsgWarningDao {
	return &MsgWarningDao{Ctx: ctx}
}

// InsertBatchSizeWarningTask 插入更新数据
func (m *MsgWarningDao) InsertBatchSizeWarningTask(data []*warning.TaskWarningEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = m.batchInsertWarning(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (m *MsgWarningDao) batchInsertWarning(tx *gorm.DB, data []*warning.TaskWarningEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + warning.TaskWarningTableName() + " ( foreign_key, created_time, task_name, media, create_by, warning_tag, dimension, metrics, interval, condition, numerical, state, msg_to ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.ForeignKey,
			v.CreatedTime,
			v.TaskName,
			v.Media,
			v.CreateBy,
			v.WarningTag,
			v.Dimension,
			v.Metrics,
			v.Interval,
			v.Condition,
			v.Numerical,
			v.State,
			v.MsgTo,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// InsertBatchSizeTaskInfos 插入更新数据
func (m *MsgWarningDao) InsertBatchSizeTaskInfos(data []*warning.TaskInfoEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = m.batchInsertTaskInfo(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (m *MsgWarningDao) batchInsertTaskInfo(tx *gorm.DB, data []*warning.TaskInfoEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + warning.TaskInfoEntityTableName() + " ( primary_key, content ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?),"
		vals = append(vals,
			v.PrimaryKey,
			v.Content,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// FindTaskInfo 查询任务列表
func (m *MsgWarningDao) FindTaskInfo(params *warningdto.SearchFilter) (*page.Paginator, error) {
	db := dorisdb.DorisClient()
	q := db.Table(warning.TaskInfoEntityTableName())  // 分页
	q2 := db.Table(warning.TaskInfoEntityTableName()) // 总数

	if params.StartDate != "" && params.EndDate != "" {
		q = q.Where("created_time BETWEEN ? AND ?", params.StartDate, params.EndDate)
		q2 = q2.Where("created_time BETWEEN ? AND ?", params.StartDate, params.EndDate)
	}
	if params.Media != "" {
		q = q.Where("media = ?", params.Media)
		q2 = q2.Where("media = ?", params.Media)
	}
	if params.TaskId != "" {
		q = q.Where("foreign_key = ?", params.TaskId)
		q2 = q2.Where("foreign_key = ?", params.TaskId)
	}
	if params.CreateBy != "" {
		q = q.Where("create_by = ?", params.CreateBy)
		q2 = q2.Where("create_by = ?", params.CreateBy)
	}
	var total int64
	err := q2.Count(&total).Error
	// 分页数据
	pagination := params.Pagination
	var res []*warning.TaskInfoEntity
	err = q.Offset(pagination.GetOffset()).Limit(pagination.GetLimit()).Find(&res).Error
	if err != nil {
		return nil, err
	}
	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)

	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return &paginator, nil
}

// DiffCost 数据问题监控
func (m *MsgWarningDao) DiffCost() (res repo.ReportHourlyMaterialEntity, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT a.cost as cost, b.roi_cost as media_cost FROM ( SELECT sum(cost) as cost FROM report_project_hour WHERE date(search_date) = CURRENT_DATE ) a, ( SELECT sum(media_cost) as roi_cost FROM roi_project_hourly_today WHERE date(date) = CURRENT_DATE ) b "
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	return
}
