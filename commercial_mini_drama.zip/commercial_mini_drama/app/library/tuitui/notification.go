package tuitui

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/pkg/errors"
	"goserver/app/library/log"
	"goserver/app/library/utils/httplib"
	"strings"
)

type NotificationReq struct {
	AccessToken string   `json:"access_token"`
	VersionType string   `json:"version_type,omitempty"`
	Path        string   `json:"path,omitempty"`
	Title       string   `json:"title"`
	ImgFid      string   `json:"img_fid,omitempty"`
	Desc        string   `json:"desc,omitempty"`
	ToUsers     []string `json:"to_users"`
}

type NotificationRes struct {
	TransId   string `json:"trans_id"`
	ErrCode   string `json:"err_code"`
	ErrMsg    string `json:"err_msg"`
	Timestamp string `json:"timestamp"`
	TimeCost  string `json:"time_cost"`
}

/**
@desc 推送推推消息
*/
func (c *client) SendNotificationMsg(request *NotificationReq) (*NotificationRes, error) {
	if request.Title == "" || len(request.ToUsers) == 0 {
		errMsg := fmt.Sprintf("[tuitui] send msg params err, msg title: %s, to user: %s", request.Title, strings.Join(request.ToUsers, ","))
		log.Error(errMsg)
		return nil, errors.New(errMsg)
	}
	req, err := json.Marshal(request)
	if err != nil {
		log.Error("[tuitui] send msg json encode error, err: " + err.Error())
		return nil, err
	}
	cli := httplib.NewHttpRequest(SendNotificationMsgUrl)
	bodybuffer := bytes.NewBuffer(req)
	cli.SetBody(bodybuffer)
	res, err := cli.Post()
	if err != nil {
		log.Error("[tuitui] send msg error, str: " + res + ", err: " + err.Error())
		return nil, err
	}

	response := &NotificationRes{}
	err = json.Unmarshal([]byte(res), response)
	if err != nil {
		log.Error("[tuitui] send msg json parse error, str: " + res + ", err: " + err.Error())
		return nil, err
	}

	if response.ErrCode != "0" {
		log.Error("[tuitui] send msg error, str: " + res + ", err: " + err.Error())
		return response, err
	}

	return response, nil
}
