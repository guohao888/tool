package account

import (
	"github.com/gin-gonic/gin"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	"goserver/app/common/repository/accounts"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	accountsService "goserver/app/model/service/accounts"
)

func SyncPromotionUrl(c *gin.Context) {
	r := response.Gin{Ctx: c}

	req := accountdto.NewSyncPromotionUrlReq(c)
	req.Params.Media = repository.MediaToutiao

	accountPromotionUrlService := accountsService.NewAccountPromotionUrlService(c)
	err := accountPromotionUrlService.SyncToutiao(accountdto.AccountPromotionUrlSyncExecutorParams{
		Media:                 req.Params.Media,
		AdvertiserIds:         req.Params.AdvertiserId,
		IsSyncAll:             true,
		PoolWorkers:           2,
		InsertBatchSize:       10,
		AppType:               accounts.AppTypeByteMicroApp,
		IsBackgroundOperation: true,
	})
	if err != nil {
		r.Response(myerror.AccountSyncPromotionUrl.Code, myerror.AccountSyncPromotionUrl.Message, nil)
		return
	}

	err = accountPromotionUrlService.SyncToutiao(accountdto.AccountPromotionUrlSyncExecutorParams{
		Media:                 req.Params.Media,
		AdvertiserIds:         req.Params.AdvertiserId,
		IsSyncAll:             true,
		PoolWorkers:           2,
		InsertBatchSize:       10,
		AppType:               accounts.AppTypeWechatApplet,
		IsBackgroundOperation: true,
	})
	if err != nil {
		r.Response(myerror.AccountSyncPromotionUrl.Code, myerror.AccountSyncPromotionUrl.Message, nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}
