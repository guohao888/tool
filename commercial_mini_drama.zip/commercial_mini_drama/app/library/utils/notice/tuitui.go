package notice

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"
)

func SendTuiTuiMessage(apiUrl, accountId string, toList []string, body string) (string, error) {
	params := map[string]interface{}{
		"account_id":   accountId,
		"to":           toList,
		"message":      body,
		"message_type": "",
	}
	postargs, _ := json.Marshal(params)
	resp, err := http.Post(apiUrl, "application/json", bytes.NewReader(postargs))
	if err != nil {
		return "", err
	}
	bodybuf, err := ioutil.ReadAll(resp.Body)
	return string(bodybuf), err
}
