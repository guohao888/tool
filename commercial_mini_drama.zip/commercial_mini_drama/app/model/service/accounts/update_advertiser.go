package accounts

import (
	"context"
	"fmt"
	"github.com/panjf2000/ants/v2"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
	"strconv"
	"sync"
)

type AdvertiserUpdateService struct {
	Ctx context.Context
}

func NewAdvertiserUpdateService(ctx context.Context) *AdvertiserUpdateService {
	return &AdvertiserUpdateService{Ctx: ctx}
}

func (a *AdvertiserUpdateService) UpdateAdvertiser() error {
	// 查询出所有需要修改的账号
	oaDao := accountdao.NewOauthAccountDao(a.Ctx)
	updateList, err := oaDao.FindAccountByConfig()
	if err != nil {
		return fmt.Errorf("查询需要更改的账号失败, err: %v", err)
	}

	oauthDao := accountdao.NewOauthDao(a.Ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(updateList) / len(appIds)
	remainder := len(updateList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			UpdateAdvertiserLimit(updateList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func UpdateAdvertiserLimit(activeList []accountrepo.OauthAccountEntity, oauth map[string]string, appId string) {

	// 开辟10个协程池
	p, _ := ants.NewPool(10)
	defer p.Release()
	wg := new(sync.WaitGroup)

	// 获取所有活跃账号及token 请求接口数据
	for _, v := range activeList {
		// copy变量 防止闭包重复执行数据
		currentItem := v
		wg.Add(1)

		task := func() {
			defer wg.Done()
			defer func() {
				if x := recover(); x != nil {
					fmt.Println("recover")
				}
			}()
			advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
			advertiserName := "" + currentItem.AdvertiserName
			userId := currentItem.UserId
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			// 按账号获取消耗报表
			_, execErr := toutiao.UpdateAdvertiser(context.Background(), int64(advertiserId), advertiserName, oauth[userId], appId)
			if execErr != nil {
				return
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done() // 提交失败，减少计数器
			fmt.Println("submit task failed: %w", submitErr)
		}
	}
	// 等待所有任务完成并关闭通道
	go func() {
		wg.Wait()
	}()
	return
}
