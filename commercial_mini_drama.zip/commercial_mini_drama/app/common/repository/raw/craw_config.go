package raw

import (
	"goserver/app/common/repository"
	"time"
)

const CrawConfigTable = "craw_config"

// ReferralEntity 端原生配置表
type CrawConfigEntity struct {
	BusinessType int       `gorm:"column:business_type"` // 平台类型
	ReqCurl      *string   `gorm:"column:req_curl"`      // cookie信息
	CreateTime   time.Time `gorm:"column:create_time"`   // 创建时间
	UpdateTime   time.Time `gorm:"column:update_time"`
}

func (*CrawConfigEntity) TableName() string {
	return CrawConfigTable
}

// 不需要线下库
func CrawConfigTableName() string {
	if repository.IsDebugTable(ReferralEntityTable) {
		return CrawConfigTable
	} else {
		return CrawConfigTable
	}
}
