package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/library/log"
	"goserver/app/model/service/accounts"
)

func PromotionUrlMerge(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.PromotionUrlMergeExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
	}

	accountDistributorPromotionUrlService := accounts.NewAccountDistributorPromotionUrlService(ctx)
	err := accountDistributorPromotionUrlService.JoinMerge(params)
	if err != nil {
		log.Errorf("账户推广链表关联分销商推广链表合并到账户分销推广链表错误, err: %s", err)
		panic(fmt.Errorf("账户推广链表关联分销商推广链表合并到账户分销推广链表错误, err: %w", err))
	}

	return "账户推广链表关联分销商推广链表合并到账户分销推广链表成功"
}
