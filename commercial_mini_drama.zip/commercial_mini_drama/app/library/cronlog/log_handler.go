package cronlog

import (
	"github.com/xxl-job/xxl-job-executor-go"
)

func CronCustomLogHandle(req *xxl.LogReq) *xxl.LogRes {
	totalLine, logContent, isEnd := ReadLog(req.LogDateTim, req.LogID,
		int32(req.FromLineNum), ReadLogLinesPerTime)
	return &xxl.LogRes{Code: xxl.SuccessCode, Msg: "", Content: xxl.LogResContent{
		FromLineNum: req.FromLineNum,
		ToLineNum:   int(totalLine),
		LogContent:  logContent,
		IsEnd:       isEnd,
	}}
}
