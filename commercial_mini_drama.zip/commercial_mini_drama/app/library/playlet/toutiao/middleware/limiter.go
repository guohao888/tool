package middleware

import (
	"context"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/api"
	"golang.org/x/time/rate"
	"goserver/app/library/log"
	"net/http"
	"sync"
)

type RateConfig struct {
	Rate  rate.Limit // 每秒多少令牌
	Burst int        // 令牌桶的容量
}

type PathAppIdLimiter struct {
	config      map[string]RateConfig
	limiter     map[string]*rate.Limiter
	mu          sync.RWMutex
	ctxPathKey  string
	ctxAppIdKey string
}

func NewPathAppIdLimiter(config map[string]RateConfig, ctxPathKey string, ctxAppIdKey string) *PathAppIdLimiter {
	return &PathAppIdLimiter{
		config:      config,
		limiter: make(map[string]*rate.Limiter),
		mu:          sync.RWMutex{},
		ctxPathKey:  ctxPathKey,
		ctxAppIdKey: ctxAppIdKey,
	}
}

func (lc *PathAppIdLimiter) GetLimiter(key string) (*rate.Limiter, bool) {
	lc.mu.RLock()
	defer lc.mu.RUnlock()

	v, ok := lc.limiter[key]
	return v, ok
}

func (lc *PathAppIdLimiter) GetPathConfig(key string) (RateConfig, bool) {
	v, ok := lc.config[key]
	return v, ok
}

func (lc *PathAppIdLimiter) AddLimiter(key string, config RateConfig) *rate.Limiter {
	lc.mu.Lock()
	defer lc.mu.Unlock()

	l := rate.NewLimiter(config.Rate, config.Burst)
	lc.limiter[key] = l
	return l
}

func (lc *PathAppIdLimiter) LimiterMiddleware() func(next api.Endpoint) api.Endpoint {

	return func(next api.Endpoint) api.Endpoint {

		return func(ctx context.Context, req *http.Request) (resp *http.Response, err error) {
			path, o1 := ctx.Value(lc.ctxPathKey).(string)
			appId, o2 := ctx.Value(lc.ctxAppIdKey).(string)

			if o1 && o2 {
				key := fmt.Sprintf("path:%s:app_id:%s", path, appId)
				pathAppIdLimiter, ok1 := lc.GetLimiter(key)
				if !ok1 {
					if pathConfig, ok2 := lc.GetPathConfig(path); ok2 {
						pathAppIdLimiter = lc.AddLimiter(key, pathConfig)
					}
				}

				if pathAppIdLimiter != nil { // 如果存在路径+应用的限流
					err := pathAppIdLimiter.Wait(ctx)
					if err != nil {
						log.Errorf("头条应用接口频率限制, path: %s, app_id: %s, err: %s", path, appId, err)
						// 这里即使错误也不处理，还是正常请求接口，只是为了频率控制
					}
				}
			}

			return next(ctx, req)
		}
	}
}
