package kuaishou

import "context"

type AdDataService struct {
	Ctx context.Context
}

func NewAdDataService(ctx context.Context) *AdDataService {
	return &AdDataService{Ctx: ctx}
}
