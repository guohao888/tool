package middleware

import (
	"context"
	"fmt"
	"golang.org/x/time/rate"
	"goserver/app/library/log"
	"resty.dev/v3"
	"sync"
)

const (
	CtxPathKey      = "ks_path"
	CtxAppIdKey     = "ks_app_id"
	CtxAdvertiserId = "ks_advertiser_id"
)

type RateConfig struct {
	Rate  rate.Limit // 每秒多少令牌
	Burst int        // 令牌桶的容量
}

type KeyRateConfig struct {
	l  int
	m  map[string]*RateConfig
	mu sync.RWMutex
}

func NewKeyRateConfig(m map[string]*RateConfig) *KeyRateConfig {
	if m == nil {
		m = make(map[string]*RateConfig)
	}
	return &KeyRateConfig{
		l:  len(m),
		m:  m,
		mu: sync.RWMutex{},
	}
}

func (c *KeyRateConfig) UnSafeLen() int {
	return c.l
}

func (c *KeyRateConfig) Len() int {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.l
}

func (c *KeyRateConfig) GetConfig(key string) (*RateConfig, bool) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	v, ok := c.m[key]
	return v, ok
}

func (c *KeyRateConfig) SetConfig(m map[string]*RateConfig) {
	c.mu.Lock()
	defer c.mu.Unlock()

	c.m = m
	c.l = len(m)
}

func (c *KeyRateConfig) AddConfig(key string, val *RateConfig) {
	c.mu.Lock()
	defer c.mu.Unlock()

	c.m[key] = val
	c.l = len(c.m)
}

type KeyLimiter struct {
	AppIdConfig        *KeyRateConfig // 应用维度频控
	PathConfig         *KeyRateConfig // 接口维度频控
	AppIdPathConfig    *KeyRateConfig // 接口×应用维度限流提示
	AdvertiserIdConfig *KeyRateConfig // 账号维度频控, 账号维度频控指入参广告账户每分钟被请求次数，触发概率较低。
	limiter            map[string]*rate.Limiter
	mu                 sync.RWMutex
	ctxAppIdKey        string
	ctxPathKey         string
	ctxAdvertiserId    string
}

type Option func(l *KeyLimiter)

func WithAppIdConfig(m map[string]*RateConfig) Option {
	return func(l *KeyLimiter) {
		l.AppIdConfig.SetConfig(m)
	}
}

func WithPathConfig(m map[string]*RateConfig) Option {
	return func(l *KeyLimiter) {
		l.PathConfig.SetConfig(m)
	}
}

func WithAppIdPathConfig(m map[string]*RateConfig) Option {
	return func(l *KeyLimiter) {
		l.AppIdPathConfig.SetConfig(m)
	}
}

func WithAdvertiserIdConfig(m map[string]*RateConfig) Option {
	return func(l *KeyLimiter) {
		l.AdvertiserIdConfig.SetConfig(m)
	}
}

func WithCtxAppIdKey(ctxAppIdKey string) Option {
	return func(l *KeyLimiter) {
		l.ctxAppIdKey = ctxAppIdKey
	}
}

func WithCtxPathKey(ctxPathKey string) Option {
	return func(l *KeyLimiter) {
		l.ctxPathKey = ctxPathKey
	}
}

func WithCtxAdvertiserId(ctxAdvertiserId string) Option {
	return func(l *KeyLimiter) {
		l.ctxAdvertiserId = ctxAdvertiserId
	}
}

func NewKeyLimiter(opts ...Option) *KeyLimiter {
	l := &KeyLimiter{
		AppIdConfig:        NewKeyRateConfig(make(map[string]*RateConfig)),
		PathConfig:         NewKeyRateConfig(make(map[string]*RateConfig)),
		AppIdPathConfig:    NewKeyRateConfig(make(map[string]*RateConfig)),
		AdvertiserIdConfig: NewKeyRateConfig(make(map[string]*RateConfig)),
		limiter:            make(map[string]*rate.Limiter),
		mu:                 sync.RWMutex{},
		ctxAppIdKey:        CtxAppIdKey,
		ctxPathKey:         CtxPathKey,
		ctxAdvertiserId:    CtxAdvertiserId,
	}

	for _, o := range opts {
		o(l)
	}
	return l
}

func (lc *KeyLimiter) GetUnSafeLimiter(key string) (*rate.Limiter, bool) {
	v, ok := lc.limiter[key]
	return v, ok
}

func (lc *KeyLimiter) GetLimiter(key string) (*rate.Limiter, bool) {
	lc.mu.RLock()
	defer lc.mu.RUnlock()

	v, ok := lc.limiter[key]
	return v, ok
}

func (lc *KeyLimiter) AddLimiter(key string, config *RateConfig) *rate.Limiter {
	lc.mu.Lock()
	defer lc.mu.Unlock()

	l := rate.NewLimiter(config.Rate, config.Burst)
	lc.limiter[key] = l
	return l
}

func (lc *KeyLimiter) KeyWait(ctx context.Context, key string, keyRateConfig *KeyRateConfig) error {
	if keyRateConfig == nil {
		return nil
	}

	var keyLimiter *rate.Limiter

	if keyRateConfig.UnSafeLen() > 0 {
		var ok2 bool
		keyLimiter, ok2 = lc.GetUnSafeLimiter(key)
		if !ok2 {
			if config, ok1 := keyRateConfig.GetConfig(key); ok1 {
				keyLimiter = lc.AddLimiter(key, config)
			}
		}
	}

	if keyLimiter != nil { // 如果存在路径+应用的限流
		err := keyLimiter.Wait(ctx)
		if err != nil {
			log.Errorf("头条应用接口频率限制, key: %s, err: %s", key, err)
			// 这里即使错误也不处理，还是正常请求接口，只是为了频率控制
			return err
		}
	}

	return nil
}

func (lc *KeyLimiter) RequestLimiterMiddleware() resty.RequestMiddleware {
	return func(c *resty.Client, r *resty.Request) error {
		ctx := r.Context()

		appId, o1 := ctx.Value(lc.ctxAppIdKey).(string)
		path, o2 := ctx.Value(lc.ctxPathKey).(string)
		advertiserId, o3 := ctx.Value(lc.ctxAdvertiserId).(string)

		if o1 {
			key := appId
			_ = lc.KeyWait(ctx, key, lc.AppIdConfig)
		}
		if o2 {
			key := path
			_ = lc.KeyWait(ctx, key, lc.PathConfig)
		}
		if o1 && o2 {
			key := fmt.Sprintf("%s:%s", appId, path)
			_ = lc.KeyWait(ctx, key, lc.AppIdPathConfig)
		}
		if o3 {
			key := advertiserId
			_ = lc.KeyWait(ctx, key, lc.AdvertiserIdConfig)
		}

		return nil
	}
}

func WithValue(ctx context.Context, kvs ...string) context.Context {
	for i := 0; i < len(kvs); i += 2 {
		ctx = context.WithValue(ctx, kvs[i], kvs[i+1])
	}
	return ctx
}
