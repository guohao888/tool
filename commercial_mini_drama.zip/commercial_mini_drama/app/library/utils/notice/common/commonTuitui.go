package common

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"mime/multipart"
	"net/http"
	"os"
	"path/filepath"
)

type Client struct {
	AppID  string
	Secret string
	Host   string
}

type SingleMessage struct {
	Tousers     []string     `json:"tousers,omitempty"`
	At          []string     `json:"at,omitempty"`
	Msgtype     string       `json:"msgtype"`
	Text        *Text        `json:"text,omitempty"`
	Link        *Link        `json:"link,omitempty"`
	Image       *Image       `json:"image,omitempty"`
	Attachment  *Attachment  `json:"attachment,omitempty"`
	Mixed       *Mixed       `json:"mixed,omitempty"`
	Interactive *Interactive `json:"interactive,omitempty"`
	Page        *Page        `json:"page,omitempty"`
	Voice       *Voice       `json:"voice,omitempty"`
}

type SingleResponse struct {
	TransID   string `json:"trans_id"`
	AppID     string `json:"appid"`
	RobotUID  string `json:"robot_uid"`
	RobotName string `json:"robot_name"`
	RobotDesc string `json:"robot_desc"`
	Errcode   int    `json:"errcode"`
	Errmsg    string `json:"errmsg"`
	Msgids    []struct {
		User  string `json:"user"`
		Msgid string `json:"msgid"`
	} `json:"msgids"`
}

type GroupMessage struct {
	Togroups    []string     `json:"togroups,omitempty"`
	At          []string     `json:"at,omitempty"`
	Msgtype     string       `json:"msgtype"`
	Text        *Text        `json:"text,omitempty"`
	Link        *Link        `json:"link,omitempty"`
	Image       *Image       `json:"image,omitempty"`
	Attachment  *Attachment  `json:"attachment,omitempty"`
	Mixed       *Mixed       `json:"mixed,omitempty"`
	Interactive *Interactive `json:"interactive,omitempty"`
	Page        *Page        `json:"page,omitempty"`
	Voice       *Voice       `json:"voice,omitempty"`
}

type GroupResponse struct {
	TransID   string `json:"trans_id"`
	AppID     string `json:"appid"`
	RobotUID  string `json:"robot_uid"`
	RobotName string `json:"robot_name"`
	RobotDesc string `json:"robot_desc"`
	Errcode   int    `json:"errcode"`
	Errmsg    string `json:"errmsg"`
	Msgids    []struct {
		Group string `json:"group"`
		Msgid string `json:"msgid"`
	} `json:"msgids"`
}

type UserMsgid struct {
	User  string `json:"user"`
	Msgid string `json:"msgid"`
}

type Text struct {
	Content string `json:"content"`
}

type Link struct {
	URL     string `json:"url"`
	Title   string `json:"title"`
	Content string `json:"content"`
	Image   string `json:"image"`
}

type Image struct {
	MediaID string `json:"media_id"`
}

type Attachment struct {
	MediaID string `json:"media_id"`
}
type Mixed struct {
	Items []Item `json:"items"`
}

type Item struct {
	Type  string `json:"type"`
	Value string `json:"value"`
}

type Action struct {
	Text     string   `json:"text,omitempty"`
	Name     string   `json:"name,omitempty"`
	Value    string   `json:"value,omitempty"`
	Color    string   `json:"color,omitempty"`
	Bgcolor  string   `json:"bgcolor,omitempty"`
	Business Business `json:"business,omitempty"`
}
type IData struct {
	Url  string `json:"url,omitempty"`
	MUrl string `json:"mobileurl,omitempty"`
}
type Business struct {
	Name string `json:"name"`
	Data IData  `json:"data"`
}
type Interactive struct {
	Id        string   `json:"id,omitempty"`
	Mobileurl string   `json:"mobileurl,omitempty"`
	Url       string   `json:"url,omitempty"`
	Head      Head     `json:"head,omitempty"`
	Body      Body     `json:"body,omitempty"`
	Footer    []Footer `json:"footer,omitempty"`
	Action    []Action `json:"action,omitempty"`
}

type Head struct {
	Text    string `json:"text"`
	Bgcolor string `json:"bgcolor"`
	Tcolor  string `json:"tcolor"`
}

type Body struct {
	Content string `json:"content"`
	Image   string `json:"image"`
}

type Footer struct {
	Text  string `json:"text"`
	Rtext string `json:"rtext"`
}

type Page struct {
	Title        string                 `json:"title"`
	Summary      string                 `json:"summary"`
	Content      string                 `json:"content"`
	Image        string                 `json:"image"`
	Format       string                 `json:"format"`
	DelimsLeft   string                 `json:"delims_left"`
	DelimsRight  string                 `json:"delims_right"`
	Kv           map[string]interface{} `json:"kv"`
	DefaultValue string                 `json:"default_value"`
	Privilege    string                 `json:"privilege"`
}

type StrongNotice struct {
	Account    string `json:"account"`
	Content    string `json:"content"`
	SmsNotice  bool   `json:"sms_notice"`
	CallNotice bool   `json:"call_notice"`
}

type Response struct {
	TransID   string `json:"trans_id"`
	AppID     string `json:"appid"`
	RobotUID  string `json:"robot_uid"`
	RobotName string `json:"robot_name"`
	RobotDesc string `json:"robot_desc"`
	ErrCode   int    `json:"errcode"`
	ErrMsg    string `json:"errmsg"`
}

type MediaUploadResponse struct {
	Errcode  int    `json:"errcode"`
	Errmsg   string `json:"errmsg"`
	Filename string `json:"filename"`
	MediaID  string `json:"media_id"`
}

type MediaUploadRequest struct {
	Type     string
	TransID  string
	FilePath string
}

type Voice struct {
	Mobiles []string `json:"mobiles"`
	Message string   `json:"message"`
}

type VoiceAlarmResponse struct {
	ErrCode int    `json:"errcode"`
	ErrMsg  string `json:"errmsg"`
	Voice   []struct {
		Mobile  string `json:"mobile"`
		Success bool   `json:"success"`
		CallID  string `json:"call_id"`
	} `json:"voice"`
}

type VoiceAlarmDetail struct {
	CallID  string `json:"call_id"`
	TransID string `json:"trans_id"`
}

type VoiceAlarmDetailResponse struct {
	ErrCode int    `json:"errcode"`
	ErrMsg  string `json:"errmsg"`
	Detail  struct {
		CallID           string `json:"call_id"`
		Callee           string `json:"callee"`
		CalleeShowNumber string `json:"callee_show_number"`
		State            string `json:"state"`
		StateDesc        string `json:"state_desc"`
		GmtCreate        string `json:"gmt_create"`
		StartDate        string `json:"start_date"`
		EndDate          string `json:"end_date"`
		Duration         int    `json:"duration"`
	} `json:"detail"`
}

type ModifyMessage struct {
	ToGroups []struct {
		Group string `json:"group"`
		MsgID string `json:"msgid"`
	} `json:"togroups"`
	ToUsers []struct {
		User  string `json:"user"`
		MsgID string `json:"msgid"`
	} `json:"tousers"`
	At      []string `json:"at,omitempty"`
	MsgType string   `json:"msgtype"`
	Text    Text     `json:"text"`
	Page    *Page    `json:"page,omitempty"`
}

/**
 *  初始化入口
 */
func NewClient(appID, secret, host string) *Client {
	return &Client{
		AppID:  appID,
		Secret: secret,
		Host:   host,
	}
}

func (c *Client) SendMessage(msg *SingleMessage) (*SingleResponse, error) {
	url := fmt.Sprintf("%s/message/custom/send?appid=%s&secret=%s", c.Host, c.AppID, c.Secret)
	data, err := json.Marshal(msg)
	if err != nil {
		return nil, err
	}
	resp, err := http.Post(url, "application/json", bytes.NewBuffer(data))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var response SingleResponse
	err = json.NewDecoder(resp.Body).Decode(&response)
	if err != nil {
		return nil, err
	}
	return &response, nil
}

func (c *Client) ModifyMessage(msg *ModifyMessage) (*http.Response, error) {
	url := fmt.Sprintf("%s/message/custom/modify?appid=%s&secret=%s", c.Host, c.AppID, c.Secret)
	jsonStr, _ := json.Marshal(msg)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func (c *Client) SendGroupMessage(msg *GroupMessage) (*GroupResponse, error) {
	url := fmt.Sprintf("%s/message/custom/send?appid=%s&secret=%s", c.Host, c.AppID, c.Secret)
	data, err := json.Marshal(msg)
	if err != nil {
		return nil, err
	}
	resp, err := http.Post(url, "application/json", bytes.NewBuffer(data))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var response GroupResponse
	err = json.NewDecoder(resp.Body).Decode(&response)
	if err != nil {
		return nil, err
	}
	return &response, nil
}

func (c *Client) ModifyGroupMessage(msg *ModifyMessage) (*http.Response, error) {
	url := fmt.Sprintf("%s/message/custom/modify?appid=%s&secret=%s", c.Host, c.AppID, c.Secret)
	jsonStr, _ := json.Marshal(msg)
	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonStr))
	req.Header.Set("Content-Type", "application/json")
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	return resp, nil
}

func (c *Client) UploadMedia(req *MediaUploadRequest) (*MediaUploadResponse, error) {
	file, err := os.Open(req.FilePath)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, err := writer.CreateFormFile("media", filepath.Base(req.FilePath))
	if err != nil {
		return nil, err
	}
	_, err = io.Copy(part, file)

	err = writer.Close()
	if err != nil {
		return nil, err
	}

	url := fmt.Sprintf("%s/media/upload?appid=%s&secret=%s&type=%s&trans_id=%s", c.Host, c.AppID, c.Secret, req.Type, req.TransID)
	resp, err := http.Post(url, writer.FormDataContentType(), body)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var res MediaUploadResponse
	err = json.NewDecoder(resp.Body).Decode(&res)
	if err != nil {
		return nil, err
	}

	return &res, nil
}

func (c *Client) UploadMediaFile(file *os.File, req *MediaUploadRequest) (*MediaUploadResponse, error) {

	body := &bytes.Buffer{}
	writer := multipart.NewWriter(body)
	part, err := writer.CreateFormFile("media", filepath.Base(req.FilePath))
	if err != nil {
		return nil, err
	}
	_, err = io.Copy(part, file)

	err = writer.Close()
	if err != nil {
		return nil, err
	}

	url := fmt.Sprintf("%s/media/upload?appid=%s&secret=%s&type=%s", c.Host, c.AppID, c.Secret, "file")
	resp, err := http.Post(url, writer.FormDataContentType(), body)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var res MediaUploadResponse
	err = json.NewDecoder(resp.Body).Decode(&res)
	if err != nil {
		return nil, err
	}

	return &res, nil
}

/**
 *  电话报警
 */
func (c *Client) SendVoiceAlarm(alarm *SingleMessage) (*VoiceAlarmResponse, error) {
	data, err := json.Marshal(alarm)
	if err != nil {
		return nil, err
	}
	url := fmt.Sprintf("%s/message/custom/send?appid=%s&secret=%s", c.Host, c.AppID, c.Secret)
	resp, err := http.Post(url, "application/json", bytes.NewBuffer(data))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result VoiceAlarmResponse
	err = json.NewDecoder(resp.Body).Decode(&result)
	if err != nil {
		return nil, err
	}

	return &result, nil
}

/**
 *  电话报警接听状态
 */
func (c *Client) GetVoiceAlarmDetail(detail *VoiceAlarmDetail) (*VoiceAlarmDetailResponse, error) {
	url := fmt.Sprintf("%s/message/voice/detail?appid=%s&secret=%s&call_id=%s&trans_id=%s", c.Host, c.AppID, c.Secret, detail.CallID, detail.TransID)
	resp, err := http.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var result VoiceAlarmDetailResponse
	err = json.NewDecoder(resp.Body).Decode(&result)
	if err != nil {
		return nil, err
	}

	return &result, nil
}

/**
 *  强通知，需要特殊权限
 */
func (c *Client) SendStrongNotice(notice *StrongNotice) (*Response, error) {
	//url := "http://alarm.im.qihoo.net/strongNotice/single/send?appid=123&secret=**&trans_id=12345678"
	url := fmt.Sprintf("%s/strongNotice/single/send?appid=%s&secret=%s", c.Host, c.AppID, c.Secret)
	jsonData, err := json.Marshal(notice)
	if err != nil {
		return nil, err
	}

	resp, err := http.Post(url, "application/json", bytes.NewBuffer(jsonData))
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	var response Response
	err = json.NewDecoder(resp.Body).Decode(&response)
	if err != nil {
		return nil, err
	}

	return &response, nil
}
