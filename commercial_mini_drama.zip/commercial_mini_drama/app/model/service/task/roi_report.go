package task

import (
	"context"
	"errors"
	"fmt"
	repo "goserver/app/common/repository/roi"
	"goserver/app/library/log"
	noticeCommon "goserver/app/library/utils/notice/common"
	"goserver/app/model/dao/roi"
	"math"
	"os"
	"strconv"
	"time"

	"github.com/spf13/viper"

	"github.com/tealeg/xlsx"
	"github.com/xxl-job/xxl-job-executor-go"
)

const (
	managerID     = "2657951213693467" // 管家账号ID
	managerName   = "管家60-商品库-侠客行"     // 管家账号名称
	tuituiGroupId = "7652669649062069" // 推推群组ID
)

// --------------巨量新剧时速消耗推送-----------------

// 巨量消耗推送
func SyncOceanNewBookCostPush(ctx context.Context, _ *xxl.RunReq) string {
	var (
		todayDate, yesterdayDate string
		hour                     int
		todayTime                time.Time
		isToday                  bool
	)

	now := time.Now()
	curHour := now.Hour()
	if curHour == 0 {
		hour = 23
		todayTime = now.Add(-1 * time.Hour)
		isToday = false
	} else {
		hour = curHour - 1
		todayTime = now
		isToday = true
	}
	todayDate = todayTime.Format(time.DateOnly)
	yesterdayDate = todayTime.AddDate(0, 0, -1).Format(time.DateOnly)

	costInfo, err := getCostInfo(ctx, isToday, todayDate, yesterdayDate, hour)
	if err != nil {
		log.Error("[SyncOceanCostPush] GetCostInfo error:" + err.Error())
		return "查询失败" + err.Error()
	}

	file, err := createROICostExcel(costInfo)
	if err != nil {
		log.Error("[SyncOceanCostPush] createROICostExcel error:" + err.Error())
		return "创建excel失败" + err.Error()
	}
	defer file.Close()

	err = sendROICostExcelToTuitui(file, todayDate, hour)
	if err != nil {
		return "发送推推失败" + err.Error()
	}
	return "成功"
}

// 生成 ROI 报表 Excel 文件
func createROICostExcel(costInfo []repo.NewlySpentBooksRoiInfo) (*os.File, error) {
	// 1. 创建新 Excel 文件和工作表
	file := xlsx.NewFile()
	sheet, err := file.AddSheet("Sheet1")
	if err != nil {
		return nil, fmt.Errorf("创建工作表失败: %v", err)
	}
	// 标题行
	title := []string{"日期", "时间", "剧目ID", "剧目名称", "实际消耗", "实际ROI", "实际消耗环比", "实际ROI环比"}
	row := sheet.AddRow()
	for _, v := range title {
		row.AddCell().Value = v
	}
	//zhTZ, _ := time.LoadLocation("Asia/Shanghai")
	// 数据行
	for _, v := range costInfo {
		row := sheet.AddRow()
		//td, _ := time.ParseInLocation(time.DateOnly, v.DateTime, time.Local)
		//row.AddCell().SetDateWithOptions(td, xlsx.DateTimeOptions{
		//	ExcelTimeFormat: "yyyy-mm-dd",
		//	Location:        zhTZ,
		//})

		row.AddCell().SetString(v.Date)
		row.AddCell().SetString(fmt.Sprintf("%02d时", v.Hour))
		row.AddCell().SetString(strconv.FormatInt(v.BookId, 10))
		row.AddCell().SetString(v.BookName)
		row.AddCell().SetFloat(v.MediaCost)
		row.AddCell().SetString(getPercentageRoi(v.ActualROI))
		if v.Hour == 0 {
			row.AddCell().SetString("-")
			row.AddCell().SetString("-")
		} else {
			row.AddCell().SetString(getPercentageRoi(v.MediaCostHb))
			row.AddCell().SetString(getPercentageRoi(v.ActualROIHb))
		}
	}
	// 3. 创建临时文件
	tempFile, err := os.CreateTemp("", "xxxxxxxx_roi_cost_*.xlsx")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close()
	// 4. 写入 Excel
	if fileErr := file.Write(tempFile); fileErr != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("写入 Excel 失败: %v", fileErr)
	}
	// 5. 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}
	return outputFile, nil
}

// 发送 Excel 文件到推推
func sendROICostExcelToTuitui(file *os.File, date string, hour int) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	hourStr := strconv.Itoa(hour)

	filePath := "/drama/巨量新剧消耗时速表" + date + "-" + hourStr + "点.xlsx"
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return err
	}
	msg := &noticeCommon.GroupMessage{
		Togroups:   []string{"7652669649042289"},
		Msgtype:    "attachment",
		Attachment: &noticeCommon.Attachment{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err != nil {
		return err
	}
	if resp.Errcode != 0 {
		return errors.New(resp.Errmsg)
	}
	return nil
}

func getCostInfo(ctx context.Context, isToday bool, todayDate string, yesterdayDate string, hour int) ([]repo.NewlySpentBooksRoiInfo, error) {
	dataDao := roi.NewReportDataDao(ctx)
	bookIds, err := dataDao.GetNewlySpentBooks(todayDate, yesterdayDate)
	if err != nil {
		return nil, err
	}

	bookInfo, err := dataDao.GetLastBookNameByBookId(bookIds, isToday, todayDate)
	if err != nil {
		return nil, err
	}

	roiInfo, err := dataDao.GetNewlySpentBooksRoiInfo(isToday, todayDate, int64(hour), bookIds)

	if err != nil {
		return nil, err
	}
	costCoe := 1.02
	for k, v := range roiInfo {
		parsedTime, _ := time.Parse(time.DateTime, v.DateTime)
		roiInfo[k].Date = parsedTime.Format(time.DateOnly)
		roiInfo[k].Hour = parsedTime.Hour()

		roiInfo[k].BookName = bookInfo[v.BookId]
		roiInfo[k].MediaCost = v.MediaCost / costCoe
		roiInfo[k].HbMediaCost = v.HbMediaCost / costCoe
		roiInfo[k].ActualROI = 0.0
		if v.MediaCost != 0 {
			roiInfo[k].ActualROI = v.Income / (v.MediaCost / costCoe)
		}
		roiInfo[k].HbActualROI = 0.0
		if v.HbMediaCost != 0 {
			roiInfo[k].HbActualROI = v.HbIncome / (v.HbMediaCost / costCoe)
		}

		roiInfo[k].MediaCostHb = 0.0
		if roiInfo[k].HbMediaCost != 0 {
			roiInfo[k].MediaCostHb = (roiInfo[k].MediaCost - roiInfo[k].HbMediaCost) / roiInfo[k].HbMediaCost
		}
		roiInfo[k].ActualROIHb = 0.0
		if roiInfo[k].HbActualROI != 0 {
			roiInfo[k].ActualROIHb = (roiInfo[k].ActualROI - roiInfo[k].HbActualROI) / roiInfo[k].HbActualROI
		}
	}
	return roiInfo, nil

}

// ------------根据管家账号及时间获取消费汇总及剧目top3信息--------------------

// SyncTuituiROIMsgByManagerID 根据管家账号及时间获取消费汇总及剧目top3信息
func SyncTuituiROIMsgByManagerID(ctx context.Context, _ *xxl.RunReq) string {
	msg, err := syncROIReport(ctx)
	if err != nil {
		log.Errorf("[ROI] GetROIReportAndSendToTuitui %s %v", msg, err)
		return "查询报错"
	}
	err = sendMsgToTuitui(msg)
	if err != nil {
		log.Errorf("[ROI] GetROIReportAndSendToTuitui send error %v", err)
		return "发送推推报错"
	}
	return "成功"
}

func syncROIReport(ctx context.Context) (string, error) {
	var (
		todayDate, yesterdayDate string
		hour                     int
		todayTime                time.Time
		isToday                  bool
	)

	now := time.Now()
	curHour := now.Hour()
	if curHour == 0 {
		hour = 23
		todayTime = now.Add(-1 * time.Hour)
		isToday = false
	} else {
		hour = curHour - 1
		todayTime = now
		isToday = true
	}

	todayDate = todayTime.Format(time.DateOnly)
	yesterdayDate = todayTime.AddDate(0, 0, -1).Format(time.DateOnly)
	// 创建ROI报告服务
	dataDao := roi.NewReportDataDao(ctx)

	// 获取今日数据
	todayData, err := dataDao.GetTopBookInfoByManagerId(isToday, managerID, todayDate, int64(hour), 3, []int64{})
	if err != nil {
		return "获取当前时段数据失败", err
	}
	var bookIds []int64
	bookMap := make(map[int64]string)
	for _, v := range todayData.BookRoi {
		bookIds = append(bookIds, v.BookId)
		bookMap[v.BookId] = v.BookName
	}

	// 获取昨天相同时段数据
	yesterdayData, err := dataDao.GetTopBookInfoByManagerId(false, managerID, yesterdayDate, int64(hour), 3, bookIds)
	if err != nil {
		return "获取昨天相同时段数据失败", err
	}

	// 1. 总消耗和ROI
	todayCost := todayData.UserRoi.MediaCost
	yesterdayCost := yesterdayData.UserRoi.MediaCost
	todayIncome := todayData.UserRoi.Income
	yesterdayIncome := yesterdayData.UserRoi.Income

	todayROI := 0.0
	if todayCost > 0 {
		todayROI = todayIncome / todayCost
	}
	yesterdayROI := 0.0
	if yesterdayCost > 0 {
		yesterdayROI = yesterdayIncome / yesterdayCost
	}

	costDelta := todayCost - yesterdayCost
	roiDelta := todayROI - yesterdayROI

	msg := fmt.Sprintf(
		"%s\n%d点\n消耗 %.2f %s %.0f  账面ROI %.2f %s %.2f\n\nTOP3剧目名称\n",
		managerName, hour+1, todayCost, getArrow(costDelta), costDelta, todayROI, getArrow(roiDelta), roiDelta,
	)

	// 2. TOP3剧目
	for i, v := range todayData.BookRoi {
		// 查找昨日对应剧目
		var yCost, yIncome float64
		for _, y := range yesterdayData.BookRoi {
			if y.BookId == v.BookId {
				yCost = y.MediaCost
				yIncome = y.Income
				break
			}
		}
		roi := 0.0
		if v.MediaCost > 0 {
			roi = v.Income / v.MediaCost
		}
		yRoi := 0.0
		if yCost > 0 {
			yRoi = yIncome / yCost
		}
		costDelta := v.MediaCost - yCost
		roiDelta := roi - yRoi

		// 拼接每个剧目字符串
		msg += fmt.Sprintf("%s 消耗%.2f", v.BookName, v.MediaCost)
		if costDelta != 0 {
			msg += fmt.Sprintf(" %s %.0f", getArrow(costDelta), costDelta)
		}
		msg += fmt.Sprintf("，ROI%.2f", roi)
		if roiDelta != 0 {
			msg += fmt.Sprintf(" %s %.2f", getArrow(roiDelta), roiDelta)
		}
		msg += "\n"
		if i == 2 {
			break
		}
	}

	// msg 现在就是你要的完整字符串
	return msg, nil

}

func sendMsgToTuitui(msg string) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	text := &noticeCommon.Text{
		Content: msg,
	}
	msgStruct := &noticeCommon.GroupMessage{
		Togroups: []string{tuituiGroupId},
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(msgStruct)
	if err != nil {
		return err
	}
	if resp.Errcode != 0 {
		return errors.New(resp.Errmsg)
	}
	return nil
}

func getArrow(v float64) string {
	if v < 0 {
		return "↓"
	}
	return "↑"
}

// 小数转百分比 0.2943929432984转为 29.44%
func getPercentageRoi(num float64) string {
	percentage := math.Round(num*100*100) / 100
	return fmt.Sprintf("%.2f%%", percentage)

}
