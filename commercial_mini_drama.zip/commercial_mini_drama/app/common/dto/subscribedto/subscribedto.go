package subscribedto

import (
	"github.com/gin-gonic/gin"
	"goserver/app/library/myerror"
)

type ChallengeResp struct {
	Challenge int64    `json:"challenge"`
	BaseResp  BaseResp `json:"base_resp"`
}
type BaseResp struct {
	StatusCode    int64  `json:"status_code"`
	StatueMessage string `json:"statue_message"`
}

type PostInfoReq struct {
	MessageId       string  `json:"message_id"`        // 消息ID，唯一标识
	SubscribeTaskId int64   `json:"subscribe_task_id"` // 订阅任务ID
	AdvertiserIds   []int64 `json:"advertiser_ids"`    // 消息对应的广告主账号
	ServiceLabel    string  `json:"service_label"`     // report.advertiser.beforeday 广告主报表消息  report.advertiser.activeprogram 广告主报表实时数据
	PublishTime     int64   `json:"publish_time"`      // 消息实际产生时间，毫秒时间戳
	TimeStamp       int64   `json:"timestamp"`         // 毫秒时间戳，本条消息实际推送时间，获取推送数据列表时无该参数数据
	Nonce           int64   `json:"nonce"`             // 随机数，和timestamp组合防重放，获取推送数据列表时无该参数数据
}

type Data struct {
	AdvertiserId int64   `json:"advertiser_id"` // 广告主id
	CoreUserIds  []int64 `json:"core_user_ids"` // 登陆用户ids
}

// NewPostInfoReq 请求数据
func NewPostInfoReq(c *gin.Context) *PostInfoReq {
	req := &PostInfoReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}
