package redisdb

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/spf13/viper"
	"goserver/app/library/log"
	"time"

	"github.com/gomodule/redigo/redis"
)

var RedisSet map[string]*redis.Pool

func NewRedisCluster() {
	RedisSet = map[string]*redis.Pool{}
	domains := viper.GetStringSlice("redis_domain_name")
	for _, name := range domains {
		RedisSet[name] = NewSubRedisPool(name)
	}
}

func initSubRedisConfig(key string) *redisConfig {
	prefix := fmt.Sprintf("redis_cluster.%s", key)
	addr := viper.GetString(prefix + ".addr")
	if addr == "" {
		panic(errors.New(prefix + " redis config empty"))
	}
	maxIdle := viper.GetInt(prefix + ".max_idle")
	idleTimeoutSec := viper.GetInt(prefix + ".idle_timeout_sec")
	password := viper.GetString(prefix + ".password")

	return &redisConfig{
		addr:           addr,
		maxIdle:        maxIdle,
		idleTimeoutSec: idleTimeoutSec,
		password:       password,
	}
}

// NewRedisPool 返回redis连接池
func NewSubRedisPool(key string) *redis.Pool {
	config := initSubRedisConfig(key)
	return &redis.Pool{
		MaxIdle:     config.maxIdle,
		IdleTimeout: time.Duration(config.idleTimeoutSec) * time.Second,
		Dial: func() (redis.Conn, error) {
			c, err := redis.DialURL(config.addr)
			if err != nil {
				return nil, fmt.Errorf("redis connection error: %s", err)
			}
			//验证redis密码
			if _, authErr := c.Do("AUTH", config.password); authErr != nil {
				return nil, fmt.Errorf("redis auth password error: %s", authErr)
			}
			return c, err
		},
		TestOnBorrow: func(c redis.Conn, t time.Time) error {
			_, err := c.Do("PING")
			if err != nil {
				return fmt.Errorf("ping redis error: %s", err)
			}
			return nil
		},
	}
}

func ClusterTest() {
	for name, pool := range RedisSet {
		c := pool.Get()
		defer c.Close()

		_, err := redis.String(c.Do("Ping"))
		if err != nil {
			panic(err)
		}

		log.Debugf("redis: %s init success", name)
	}
}

func ClusterSetJson(k string, data interface{}) error {
	for name, pool := range RedisSet {
		c := pool.Get()
		defer c.Close()

		value, _ := json.Marshal(data)
		n, err := c.Do("set", k, string(value))
		ok, _ := n.(string)
		if ok != "OK" || err != nil {
			return errors.New("set failed")
		}
		log.Debugf("redis: %s set value: %s success", name, value)
	}

	return nil
}
