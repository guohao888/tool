package cron

import (
	"github.com/xxl-job/xxl-job-executor-go"
	"goserver/app/model/service/task"
	"goserver/app/model/service/task/craw"
)

// 定义执行器
var executorName = "commercial-mini-drama" // 短剧执行器

// 注册handler
var handlerMap = map[string]xxl.TaskFunc{
	"app_id_task_auto_register":     AppIdTaskAutoRegister,           // 应用的定时任务自动注册和后台任务自动新增 (每20分钟执行一次)
	"oauth_refresh_toutiao":         task.OauthRefreshToutiao,        // 刷新头条oauth授权
	"oauth_refresh_kuaishou":        task.OauthRefreshKuaishou,       // 刷新快手oauth授权
	"oauth_refresh_kuaishou_magnet": task.OauthRefreshKuaishouMagnet, // 刷新快手磁力引擎oauth授权
	"oauth_check_validity":          task.OauthCheckValidity,         // 校验token是否有效
	"oauth_account_sync_toutiao":    task.OauthAccountSyncToutiao,    // 同步头条oauth授权广告主账号

	"account_instance_id_sync_toutiao":      task.AccountInstanceIdSyncToutiao,      // 同步头条广告主字节小程序资产id
	"account_promotion_url_sync_toutiao":    task.AccountPromotionUrlSyncToutiao,    // 同步头条广告主的推广链数据
	"distributor_promotion_url_sync_fanqie": task.DistributorPromotionUrlSyncFanqie, // 同步番茄分销商的推广链数据

	"promotion_url_merge":      task.PromotionUrlMerge,      // 合并媒体和分销商的推广链数据
	"account_distributor_sync": task.AccountDistributorSync, // 聚合账户分销推广链表到账号分销信息表

	// 获取消耗信息
	//"report_hour_fast": task.SyncReportLimitTodayFast, // 新版消耗分发快队列
	//"report_hour_slow": task.SyncReportLimitTodaySlow, // 新版消耗分发慢队列
	//"report_hour_t1":   task.SyncReportLimitHistory,   // 新版消耗T+1 获取

	// 消耗账单数据
	"report_bill": task.SyncBillInfo, // 新版获取消耗账单

	// ROI数据聚合
	//"sync_final_t1":     task.SyncCostIncomeHistory, // 刷新消耗收入历史聚合数据
	//"sync_final_today":  task.SyncCostIncomeToday,   // 刷新消耗收入历史聚合数据
	//"sync_final_today1": task.SyncCostIncomeToday1,  // 历史当日分离

	// 素材消耗信息
	//"report_media_fast": task.SyncMediaReportFast, // 新版素材分发快队列
	//"report_media_slow": task.SyncMediaReportSlow, // 新版素材分发慢队列
	"report_media_spi": task.SyncMediaReportSpi, // 素材订阅拉取报表

	// 素材视频拉取
	"video_file": task.SyncVideoFile, // 拉取素材信息

	// 素材数据聚合
	"sync_final_media_t1":    task.SyncMediaIncomeHistory, // 刷新历史素材信息
	"sync_final_media_today": task.SyncMediaIncomeToday,   // 刷新当日素材信息

	"sync_iaa_coefficient": task.SyncCoefficientToday, // 刷新IAA 系数

	"monitor_kafka_lag": task.MonitorKafkaLag, // 监控Kafka消费延迟

	// 推推发送消息
	"sync_tuitui_msg_hour":             task.SyncTuituiMsg,                  // 小时推推文本信息推送
	"sync_tuitui_msg_day":              task.SyncTuituiMsgDay,               // 日推推文本信息推送
	"sync_tuitui_msg_substrate_day":    task.SyncTuituiMsgSubtractBillDay,   // 日推推减账单文本信息推送
	"sync_tuitui_excel_hour":           task.SyncTuituiHourMsgExcel,         // 推推小时报表Excel
	"sync_tuitui_excel_day":            task.SyncTuituiDayMsgExcel,          // 推推日报表Excel
	"sync_tuitui_image_roi":            task.SyncTuituiROIImage,             // 推推图片 分剧消耗、ROI预警
	"sync_tuitui_image_album":          task.SyncTuituiAlbumImage,           // 推推图片 剧目
	"sync_tuitui_roi_msg_by_mgr":       task.SyncTuituiROIMsgByManagerID,    // 根据管家id获取ROI数据并发送推推
	"sync_tuitui_image_excel_hour":     task.SyncTuituiHourImageExcel,       // 商品库分时统计Image&Excel
	"sync_tuitui_excel_cost_info":      task.SyncTuituiAccountDataPush,      // 端原生账管数据推送
	"sync_tuitui_excel_cost_yesterday": task.SyncTuituiAccountDataYesterday, // 端原生账管数据推送
	"sync_tuitui_text_manage_today":    task.SyncTuituiTextManageToday,      // 端原生账管数据推送
	"sync_tuitui_new_book_cost":        task.SyncOceanNewBookCostPush,       // 巨量新剧时速消耗推送
	"sync_tuitui_new_series_cost":      task.SyncKuaishouNewSeriesCostPush,  // 快手新剧消耗时速推送
	"sync_tuitui_manager_cost":         task.SyncKuaishouManagerCostPush,    // 快手分管家账户消耗时速明细
	"sync_tuitui_ks_cost_income":       task.SyncKuaishouCostIncomePush,     // 快手今日累计消耗、收入、roi数据

	"sync_media_re": task.SyncMediaIncomeHistoryRe,

	"sync_project_info": task.SyncProjectInfos, // 拉取账号项目明细

	"sync_reject_material": task.SyncToutiaoRejectReason, // 拒审数据拉取

	"monitor_task": task.ExecMonitor, // 盯盘任务监控

	//// 获取消耗信息
	//"report_project_hour_fast": task.SyncReportProjectLimitTodayFast, // 项目维度消耗分发快队列
	//"report_project_hour_slow": task.SyncReportProjectLimitTodaySlow, // 项目维度消耗分发慢队列
	//"report_project_hour_t1":   task.SyncReportProjectLimitHistory,   // 项目维度消耗T+1 获取

	"oauth_refresh_assist": task.OauthRefreshAssist, // 刷新协管oauth授权
	"sync_assist_account":  task.AssistAccount,      // 协管授权账号拉取
	"oauth_refresh_push":   task.OauthRefreshPush,   // 刷新推送应用token

	// ROI数据聚合
	"sync_final_project_t1":    task.SyncProjectIncomeHistory, // 项目级刷新消耗收入历史聚合数据
	"sync_final_project_today": task.SyncProjectIncomeToday,   // 项目级历史当日分离

	"sync_project_report_replenish": task.SyncReportProjectLimitReplenish,   // 补充拉取项目维度消耗
	"sync_final_project_replenish":  task.SyncProjectIncomeHistoryReplenish, // 补充刷新消耗收入历史聚合数据

	"sync_project_hour_subscribe_today":  task.SyncReportProjectLimitTodaySubscribe,  // 按照订阅任务拉取当日项目维度消耗
	"sync_project_hour_subscribe_before": task.SyncReportProjectLimitBeforeSubscribe, // 按照订阅任务拉取稳定项目维度消耗

	"sync_promotion_url_info":           task.SyncPromotionInfoLimit,          // 同步广告信息
	"sync_promotion_url_info_replenish": task.SyncPromotionInfoLimitReplenish, // 广告信息补充拉取

	"sync_kuaishou_account":        task.SyncKuaishouAccount,          // 拉取快手账号信息
	"sync_kuaishou_detail_history": task.SyncKuaishouDetailHistory,    // 拉取快手报表明细查-历史
	"sync_kuaishou_detail_today":   task.SyncKuaishouDetailToday,      // 拉取快手报表明细查-当日
	"syn_kuaishou_series":          task.SyncKuaishouSeries,           // 拉取快手短剧信息
	"sync_kuaishou_core_history":   task.SyncKuaishouCoreDataHistory,  // 拉取快手核心总览数据-历史
	"sync_kuaishou_core_today_iaa": task.SyncKuaishouCoreDataTodayIAA, // 拉取快手核心总览数据-当日-IAA
	"sync_kuaishou_core_today_iap": task.SyncKuaishouCoreDataTodayIAP, // 拉取快手核心总览数据-当日-IAP

	"sync_kuaishou_tuitui_cost_msg":   task.SyncKuaishouTuituiMsg,       // 快手近一小时消耗
	"sync_kuaishou_tuitui_series_msg": task.SyncKuaishouSeriesTuituiMsg, // 快手剧目消耗

	"sync_distributor_callback_config":  task.SyncDistributorCallbackConfig,           // 拉取番茄广告回传规则
	"sync_promotion_bid_info_today":     task.SyncReportPromotionLimitTodaySubscribe,  // 拉取广告维度出价转化 今日
	"sync_promotion_bid_info_before":    task.SyncReportPromotionLimitBeforeSubscribe, // 拉取广告维度出价转化 稳定
	"sync_promotion_bid_info_replenish": task.SyncReportPromotionLimitReplenish,       // 补充拉取广告维度出价转化

	"sync_reverse_schedule":          task.ExecReverseSchedule,         // 反向拉空操作
	"sync_reverse_kuaishou_schedule": task.ExecReverseKuaishouSchedule, // 快手反向拉空
	"sync_account_monitor1":          task.ExecAccountMonitor1,         //时速大于1K，且实时回收低于0.3账户拉空
	"sync_account_monitor2":          task.ExecAccountMonitor2,

	"sync_raw_roi":         task.SyncRawRoiImage,      // 发送端原生ROI图片
	"sync_raw_album":       task.SyncRawAlbumMsg,      // 端原生剧目预警
	"sync_raw_album_speed": task.SyncRawAlbumSpeedMsg, // 端原生时速消耗

	"sync_raw_product_infos": task.SyncProductInfos, // 端原生拉取商品列表

	"sync_log_search": task.SyncLogSearchSubscribe, // 操作日志拉取

	"sync_add_account":        task.SyncAccountAdd,       // 推送spi素材订阅
	"sync_remove_account":     task.SyncAccountRemove,    // 取消推送spi素材订阅
	"sync_add_account_day":    task.SyncAccountAddDay,    // 推送天级spi素材订阅
	"sync_remove_account_day": task.SyncAccountRemoveDay, // 取消推送天级spi素材订阅

	// 抓取掌阅，番茄，点众，常读的数据
	"sync_craw_fanqie_data":    craw.SyncCrawFanqieData,    // 抓取番茄的数据
	"sync_craw_zhangyue_data":  craw.SyncCrawZhangYueData,  // 抓取掌阅的数据
	"sync_craw_dianzhong_data": craw.SyncCrawDianZhongData, // 抓取点众的数据
	"sync_craw_changdu_data":   craw.SyncCrawChangDuData,   // 抓取常读的数据

	"send_diff_cost": task.SendDiffCostMsg, // 差异对比

	"sync_report_lianshan_today":   task.SyncReportPromotionToday,   // 连山云 当日
	"sync_report_lianshan_history": task.SyncReportPromotionHistory, // 连山云 历史
}
