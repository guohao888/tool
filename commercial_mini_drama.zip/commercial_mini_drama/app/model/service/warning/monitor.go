package warning

import (
	"context"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"github.com/panjf2000/ants/v2"
	"goserver/app/common/dto/page"
	"goserver/app/common/dto/warningdto"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	wModel "goserver/app/common/repository/warning"
	"goserver/app/library/log"
	"goserver/app/library/playlet/kuaishou"
	"goserver/app/library/playlet/toutiao"
	"goserver/app/library/utils"
	"goserver/app/model/dao"
	accountdao "goserver/app/model/dao/accounts"
	kuaishoudao "goserver/app/model/dao/kuaishou"
	"goserver/app/model/dao/subscribe"
	"goserver/app/model/dao/warning"
	"strconv"
	"strings"
	"sync"
	"time"
)

type MonitorService struct {
	Ctx context.Context
}

func NewMonitorService(ctx context.Context) *MonitorService {
	return &MonitorService{Ctx: ctx}
}

// GetMonitorList 查询盯盘任务列表
func (m *MonitorService) GetMonitorList(params *warningdto.MonitorListReq) (*page.Paginator, error) {
	monitorDao := warning.NewMonitorDao(m.Ctx)
	paginator, err := monitorDao.FindMonitorList(params)
	var list []*warningdto.MonitorInfos
	for _, v := range paginator.List.([]*wModel.MonitorInfoEntity) {
		var rules []warningdto.Rules
		rules = append(rules, warningdto.Rules{
			Metrics:       v.Metrics,
			DateCondition: v.DateCondition,
			Condition:     v.Condition,
			Numerical:     v.Numerical,
		})
		if v.MetricsTwo != 0 {
			rules = append(rules, warningdto.Rules{
				Metrics:       v.MetricsTwo,
				DateCondition: v.DateConditionTwo,
				Condition:     v.ConditionTwo,
				Numerical:     v.NumericalTwo,
			})
		}
		info := &warningdto.MonitorInfos{
			TaskId:        v.TaskId,
			TaskType:      v.TaskType,
			TaskName:      v.TaskName,
			Media:         v.Media,
			MonitorObject: v.MonitorObject,
			RuleList:      rules,
			Interval: warningdto.Interval{
				IntervalType:  v.IntervalType,
				IntervalValue: v.IntervalValue,
			},
			EffectiveTime: warningdto.Effective{
				EffectiveType:  v.EffectiveType,
				EffectiveValue: v.EffectiveValue,
			},
			MsgTo: strings.Split(v.MsgTo, ","),
			Scope: warningdto.Scope{
				ScopeType:  v.ScopeType,
				ScopeValue: v.ScopeValue,
			},
			Status:     v.Status,
			CreateUser: v.CreateUser,
			CreatedAt:  v.CreatedAt.Format(time.DateOnly),
			Operation:  v.Operation,
		}
		list = append(list, info)
	}
	paginator.List = list
	return paginator, err
}

// SaveOrUpdateMonitorInfo 新建/修改/更改状态 盯盘任务
func (m *MonitorService) SaveOrUpdateMonitorInfo(params *warningdto.MonitorInfoReq) error {
	monitorDao := warning.NewMonitorDao(m.Ctx)
	var key string
	if params.TaskId == "" {
		key = utils.GetUUID()
	} else {
		key = params.TaskId
	}
	// 构建 task_warning 保存实体
	data := buildMonitorStruct(key, params)
	err := monitorDao.InsertMonitorInfo(data)
	if err != nil {
		return err
	}
	return nil
}

func buildMonitorStruct(key string, params *warningdto.MonitorInfoReq) wModel.MonitorInfoEntity {

	var (
		metricsTwo, dateConditionTwo int
		conditionTwo, effectiveValue string
		numericalTwo                 string
	)
	if len(params.RuleList) > 1 {
		metricsTwo = params.RuleList[1].Metrics
		dateConditionTwo = params.RuleList[1].DateCondition
		conditionTwo = params.RuleList[1].Condition
		numericalTwo = params.RuleList[1].Numerical
	} else {
		metricsTwo = 0
		dateConditionTwo = 0
		conditionTwo = ""
		numericalTwo = "0"
	}
	if params.EffectiveTime.EffectiveType == 1 {
		effectiveValue = time.Now().AddDate(-1, -1, -1).Format(time.DateOnly)
	} else {
		effectiveValue = params.EffectiveTime.EffectiveValue
	}
	info := wModel.MonitorInfoEntity{
		TaskId:           key,
		TaskType:         params.TaskType,
		TaskName:         params.TaskName,
		Media:            params.Media,
		MonitorObject:    params.MonitorObject,
		Metrics:          params.RuleList[0].Metrics,
		DateCondition:    params.RuleList[0].DateCondition,
		Condition:        params.RuleList[0].Condition,
		Numerical:        params.RuleList[0].Numerical,
		MetricsTwo:       metricsTwo,
		DateConditionTwo: dateConditionTwo,
		ConditionTwo:     conditionTwo,
		NumericalTwo:     numericalTwo,
		IntervalType:     params.Interval.IntervalType,
		IntervalValue:    params.Interval.IntervalValue,
		EffectiveType:    params.EffectiveTime.EffectiveType,
		EffectiveValue:   effectiveValue,
		MsgTo:            strings.Join(params.MsgTo, ","),
		ScopeType:        params.Scope.ScopeType,
		ScopeValue:       params.Scope.ScopeValue,
		Status:           params.Status,
		CreateUser:       params.UserInfo.Name,
		Operation:        params.Operation,
	}
	return info
}

// DeleteMonitorInfo 删除盯盘任务
func (m *MonitorService) DeleteMonitorInfo(params *warningdto.MonitorInfoReq) error {
	monitorDao := warning.NewMonitorDao(m.Ctx)
	// 构建 task_warning 保存实体
	err := monitorDao.DeleteMonitorInfo(params.TaskId)
	if err != nil {
		return err
	}
	return nil
}

// AccountVerify 验证账号
func (m *MonitorService) AccountVerify(param *warningdto.AdvertiserVerify) (accountIds []accountrepo.OauthAccountEntity, err error) {
	oauthAccountDao := accountdao.NewOauthAccountDao(m.Ctx)
	ads, err := oauthAccountDao.FindAccountByAds(param.AdvertiserList)
	if err != nil {
		return
	}
	accountIds = append(accountIds, ads...)
	kuaishouAccountDao := kuaishoudao.NewAccountDao(m.Ctx)
	list, err := kuaishouAccountDao.GetAccountListByAccountId(param.AdvertiserList)
	if err != nil {
		return
	}
	for _, v := range list {
		info := accountrepo.OauthAccountEntity{
			AdvertiserId: strconv.Itoa(int(v.AccountId)),
		}
		accountIds = append(accountIds, info)
	}
	return
}

func (m *MonitorService) GetExecMonitorList(interval int) ([]*wModel.MonitorInfoEntity, error) {
	monitorDao := warning.NewMonitorDao(m.Ctx)
	// 构建 task_warning 保存实体
	list, err := monitorDao.FindExecMonitorList(interval)
	if err != nil {
		return nil, err
	}
	return list, nil
}

func (m *MonitorService) GetExecRejectTask(sqlInfo wModel.ExecSqlInfo) ([]wModel.RejectInfo, string, error) {
	monitorDao := warning.NewMonitorDao(m.Ctx)
	// 构建 task_warning 保存实体
	resList, msgTo, err := monitorDao.ExecRejectTask(sqlInfo)
	if err != nil {
		return nil, "", err
	}
	return resList, msgTo, nil
}

func (m *MonitorService) GetExecROITask(sqlInfo wModel.ExecSqlInfo) ([]wModel.ROIMonitor, string, error) {
	monitorDao := warning.NewMonitorDao(m.Ctx)
	// 构建 task_warning 保存实体
	resList, msgTo, err := monitorDao.ExecROITask(sqlInfo)
	if err != nil {
		return nil, "", err
	}
	return resList, msgTo, nil
}

func (m *MonitorService) GetExecKuaishouROITask(sqlInfo wModel.ExecSqlInfo) ([]wModel.ROIMonitor, string, error) {
	monitorDao := warning.NewMonitorDao(m.Ctx)
	// 构建 task_warning 保存实体
	resList, msgTo, err := monitorDao.ExecKuaishouROITask(sqlInfo)
	if err != nil {
		return nil, "", err
	}
	return resList, msgTo, nil
}

func (m *MonitorService) GetWeekSchedule(sqlInfo wModel.ExecSqlInfo, operation int) ([]wModel.WeekSchedule, string, error) {
	monitorDao := warning.NewMonitorDao(m.Ctx)
	// 1.查询出符合规则的项目维度列表
	resList, msgTo, err := monitorDao.ExecWeekSchedule(sqlInfo)
	if err != nil {
		return nil, "", err
	}
	if len(resList) == 0 {
		return nil, "", nil
	}
	// 拉空操作
	if operation == 1 {
		execProjectWeekSchedule(context.Background(), resList)
		weekScheduleDao := warning.NewWeekScheduleDao(m.Ctx)
		list, findErr := weekScheduleDao.FindSchedule(repo.MediaToutiao)
		if findErr != nil {
			return nil, "", findErr
		}
		if len(list) == 0 {
			return nil, "", nil
		}
		var ads string
		for k, v := range list {
			if k == len(list)-1 {
				ads += "'" + v.AdvertiserId + "'"
			} else {
				ads += "'" + v.AdvertiserId + "',"
			}
		}
		updateErr := weekScheduleDao.UpdateScheduleStatus(ads)
		if updateErr != nil {
			log.Errorf("更新拉空记录表失败, err: %s", updateErr)
		}
		return list, msgTo, nil
	} else {
		return resList, msgTo, nil
	}

}

func execProjectWeekSchedule(ctx context.Context, infos []wModel.WeekSchedule) {
	var accountStr string
	apMap := buildWeekReq(infos)
	for k, v := range infos {
		if k == len(infos)-1 {
			accountStr += "'" + v.AdvertiserId + "'"
		} else {
			accountStr += "'" + v.AdvertiserId + "'" + ","
		}
	}
	todayDao := subscribe.NewTodaySubscribeDao(ctx)
	activeList, err := todayDao.ProjectActiveAdvertiserList(accountStr)
	if err != nil {
		return
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			PostProjectStatus(activeList[start:end], oauth, currentAppId, apMap)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return
}

// PostProjectStatus  令牌桶请求头条数据
func PostProjectStatus(activeList []accountrepo.OauthAccountEntity, oauth map[string]string, appId string, apMap map[int64][]*models.ProjectWeekScheduleUpdateV30RequestDataInner) {

	resChan := make(chan *wModel.ProjectWeekScheduleEntity) // 结果缓存通道
	errChan := make(chan error, len(activeList))            // 缓冲通道避免阻塞

	// 开辟10个协程池
	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	// DB 只执行一次
	once.Do(func() {
		go func() {
			dbErr := execWeekScheduleDB(context.Background(), resChan, repo.MediaToutiao)
			if dbErr != nil {
				errChan <- dbErr
			}
		}()
	})
	// 获取所有活跃账号及token 请求接口数据
	for _, v := range activeList {
		// copy变量 防止闭包重复执行数据
		currentItem := v
		wg.Add(1)

		task := func() {
			defer wg.Done()
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("panic recovered: %v", x)
				}
			}()
			advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
			advertiserIdStr := currentItem.AdvertiserId
			userId := currentItem.UserId
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			// 按账号获取消耗报表
			batchPage := dao.BatchPage(len(apMap[int64(advertiserId)]), 10)
			for i := 0; i < batchPage; i++ {
				start := i * 10
				end := (i + 1) * 10
				if end > len(apMap[int64(advertiserId)]) {
					end = len(apMap[int64(advertiserId)])
				}
				newReq := toutiao.ProjectWeekScheduleUpdateReq{
					AccessToken: oauth[userId],
					Info: models.ProjectWeekScheduleUpdateV30Request{
						AdvertiserId: int64(advertiserId),
						Data:         apMap[int64(advertiserId)][start:end],
					},
				}
				res, err := toutiao.WeekSchedule(context.Background(), newReq, appId)
				if err != nil {
					errChan <- fmt.Errorf("拉空操作失败 advertiser_id: %s, token: %s, appId: %s, error: %s", advertiserIdStr, oauth[userId], appId, err.Error())
					return
				}
				if len(res.Data.Errors) > 0 {
					for _, errV := range res.Data.Errors {
						// 失败合集
						resInfo := &wModel.ProjectWeekScheduleEntity{
							Media:        repo.MediaToutiao,
							AdvertiserId: advertiserIdStr,
							ProjectId:    strconv.Itoa(int(*errV.ProjectId)),
							Operation:    "schedule",
							ScheduleTime: apMap[int64(advertiserId)][0].ScheduleTime,
							ErrorMsg:     *errV.ErrorMessage,
							CreatedTime:  time.Now(),
						}
						resChan <- resInfo
					}
				}
				if len(res.Data.ProjectIds) > 0 {
					for _, projectId := range res.Data.ProjectIds {
						// 成功合集
						resInfo := &wModel.ProjectWeekScheduleEntity{
							Media:        repo.MediaToutiao,
							AdvertiserId: advertiserIdStr,
							ProjectId:    strconv.Itoa(int(projectId)),
							Operation:    "schedule",
							ScheduleTime: apMap[int64(advertiserId)][0].ScheduleTime,
							ErrorMsg:     "成功",
							CreatedTime:  time.Now(),
						}
						resChan <- resInfo
					}
				}
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done() // 提交失败，减少计数器
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待所有任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan) // 确保所有任务完成后关闭通道
	}()
	// 收集所有错误
	var errs []error
	for errL := range errChan {
		errs = append(errs, errL)
	}

	if len(errs) > 0 {
		//_ = sendMsg(errs, "同步消耗报表\n")
	}
	return
}

func execWeekScheduleDB(ctx context.Context, resChan <-chan *wModel.ProjectWeekScheduleEntity, media string) error {
	weekScheduleDao := warning.NewWeekScheduleDao(ctx)
	// 将数据写入 report_hour
	var data = make([]*wModel.ProjectWeekScheduleEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			if dbErr := weekScheduleDao.InsertBatchWeekSchedule(data, media, 5000); dbErr != nil {
				errs = append(errs, dbErr) // 收集错误，不退出
			}
			data = data[:0]
		}

	}
	if len(data) > 0 {
		dbErr := weekScheduleDao.InsertBatchWeekSchedule(data, media, 5000)
		if dbErr != nil {
			errs = append(errs, dbErr)
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execWeekScheduleDB errors: %v", errs)
	}
	return nil
}

func buildWeekReq(list []wModel.WeekSchedule) (res map[int64][]*models.ProjectWeekScheduleUpdateV30RequestDataInner) {
	m := make(map[int64][]*models.ProjectWeekScheduleUpdateV30RequestDataInner)
	scheduleTime := BuildScheduleTime()
	for _, v := range list {
		advertiserId, _ := strconv.Atoi(v.AdvertiserId)
		projectId, _ := strconv.Atoi(v.ProjectId)
		info := &models.ProjectWeekScheduleUpdateV30RequestDataInner{
			ProjectId:     int64(projectId),
			ScheduleScene: models.REALTIME_ProjectWeekScheduleUpdateV30DataScheduleScene,
			ScheduleTime:  scheduleTime,
		}
		m[int64(advertiserId)] = append(m[int64(advertiserId)], info)
	}
	return m
}

func buildWeekReqT1(list []wModel.WeekSchedule) (res map[int64][]*models.ProjectWeekScheduleUpdateV30RequestDataInner) {
	m := make(map[int64][]*models.ProjectWeekScheduleUpdateV30RequestDataInner)
	scheduleTime := buildScheduleTimeT1()
	for _, v := range list {
		advertiserId, _ := strconv.Atoi(v.AdvertiserId)
		projectId, _ := strconv.Atoi(v.ProjectId)
		info := &models.ProjectWeekScheduleUpdateV30RequestDataInner{
			ProjectId:     int64(projectId),
			ScheduleScene: models.REALTIME_ProjectWeekScheduleUpdateV30DataScheduleScene,
			ScheduleTime:  scheduleTime,
		}
		m[int64(advertiserId)] = append(m[int64(advertiserId)], info)
	}
	return m
}

func BuildScheduleTime() string {
	day := time.Now().Weekday()
	oneList := allOne()
	todaySchedule := generateTodaySchedule()
	var res []string
	for k, v := range oneList {
		if k == int(day)-1 {
			res = append(res, todaySchedule)
			continue
		}
		res = append(res, v)
	}

	return strings.Join(res, "")
}

func buildScheduleTimeT1() string {
	oneList := allOne()
	return strings.Join(oneList, "")
}

func generateTodaySchedule() string {
	hour := time.Now().Hour()
	minute := time.Now().Minute()
	var s string
	for i := 0; i < 23; i++ {
		if hour <= i {
			// 如果当前小时数大于等于索引数且分钟数大于30分钟 则赋值10 否则00
			if hour == i && minute > 30 {
				s += "10"
				continue
			}
			s += "00"
		} else {
			s += "11"
		}
	}
	// 规则23:30分
	return s + "01"
}

func allOne() []string {
	res := make([]string, 0)
	for i := 0; i < 7; i++ {
		s := strings.Repeat("1", 48)
		res = append(res, s)
	}
	return res
}

// GetWeekScheduleT1 拉空的数据修改回来
func (m *MonitorService) GetWeekScheduleT1() ([]wModel.WeekSchedule, string, error) {
	scheduleDao := warning.NewWeekScheduleDao(m.Ctx)

	resList, err := scheduleDao.FindScheduleT1(repo.MediaToutiao)
	if err != nil {
		return nil, "", err
	}
	if len(resList) == 0 {
		return nil, "", nil
	}
	execProjectWeekScheduleT1(context.Background(), resList)
	var msgTo string
	for k, v := range resList {
		if k == len(resList)-1 {
			msgTo += v.NickName
		} else {
			msgTo += v.NickName + ","
		}
	}
	return resList, msgTo, nil
}

func execProjectWeekScheduleT1(ctx context.Context, infos []wModel.WeekSchedule) {
	var accountStr string
	apMap := buildWeekReqT1(infos)
	for k, v := range infos {
		if k == len(infos)-1 {
			accountStr += "'" + v.AdvertiserId + "'"
		} else {
			accountStr += "'" + v.AdvertiserId + "'" + ","
		}
	}
	todayDao := subscribe.NewTodaySubscribeDao(ctx)
	activeList, err := todayDao.ProjectActiveAdvertiserList(accountStr)
	if err != nil {
		return
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			PostProjectStatusT1(activeList[start:end], oauth, currentAppId, apMap)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return
}

// PostProjectStatusT1  令牌桶请求头条数据
func PostProjectStatusT1(activeList []accountrepo.OauthAccountEntity, oauth map[string]string, appId string, apMap map[int64][]*models.ProjectWeekScheduleUpdateV30RequestDataInner) {

	resChan := make(chan *wModel.ProjectWeekScheduleEntity) // 结果缓存通道
	errChan := make(chan error, len(activeList))            // 缓冲通道避免阻塞

	// 开辟10个协程池
	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	// DB 只执行一次
	once.Do(func() {
		go func() {
			dbErr := execWeekScheduleDB(context.Background(), resChan, repo.MediaToutiao)
			if dbErr != nil {
				errChan <- dbErr
			}
		}()
	})
	// 获取所有活跃账号及token 请求接口数据
	for _, v := range activeList {
		// copy变量 防止闭包重复执行数据
		currentItem := v
		wg.Add(1)

		task := func() {
			defer wg.Done()
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("panic recovered: %v", x)
				}
			}()
			advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
			advertiserIdStr := currentItem.AdvertiserId
			userId := currentItem.UserId
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			// 按账号获取消耗报表
			batchPage := dao.BatchPage(len(apMap[int64(advertiserId)]), 10)
			for i := 0; i < batchPage; i++ {
				start := i * 10
				end := (i + 1) * 10
				if end > len(apMap[int64(advertiserId)]) {
					end = len(apMap[int64(advertiserId)])
				}
				newReq := toutiao.ProjectWeekScheduleUpdateReq{
					AccessToken: oauth[userId],
					Info: models.ProjectWeekScheduleUpdateV30Request{
						AdvertiserId: int64(advertiserId),
						Data:         apMap[int64(advertiserId)][start:end],
					},
				}
				res, err := toutiao.WeekSchedule(context.Background(), newReq, appId)
				if err != nil {
					errChan <- fmt.Errorf("拉空操作失败 advertiser_id: %s, token: %s, appId: %s, error: %s", advertiserIdStr, oauth[userId], appId, err.Error())
					return
				}
				if len(res.Data.Errors) > 0 {
					for _, errV := range res.Data.Errors {
						// 失败合集
						resInfo := &wModel.ProjectWeekScheduleEntity{
							AdvertiserId: advertiserIdStr,
							ProjectId:    strconv.Itoa(int(*errV.ProjectId)),
							Operation:    "schedule",
							ScheduleTime: apMap[int64(advertiserId)][0].ScheduleTime,
							ErrorMsg:     *errV.ErrorMessage,
							CreatedTime:  time.Now(),
						}
						resChan <- resInfo
					}
				}
				if len(res.Data.ProjectIds) > 0 {
					for _, projectId := range res.Data.ProjectIds {
						// 成功合集
						resInfo := &wModel.ProjectWeekScheduleEntity{
							AdvertiserId:  advertiserIdStr,
							ProjectId:     strconv.Itoa(int(projectId)),
							Operation:     "schedule",
							ScheduleTime:  apMap[int64(advertiserId)][0].ScheduleTime,
							ErrorMsg:      "成功",
							ReverseStatus: 1,
							CreatedTime:   time.Now(),
						}
						resChan <- resInfo
					}
				}
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done() // 提交失败，减少计数器
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待所有任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan) // 确保所有任务完成后关闭通道
	}()
	// 收集所有错误
	var errs []error
	for errL := range errChan {
		errs = append(errs, errL)
	}

	if len(errs) > 0 {
		//_ = sendMsg(errs, "同步消耗报表\n")
	}
	return
}

func (m *MonitorService) GetKuaishouSchedule(sqlInfo wModel.ExecSqlInfo, operation int) ([]wModel.WeekSchedule, string, error) {
	monitorDao := warning.NewMonitorDao(m.Ctx)
	// 1.查询出符合规则的项目维度列表
	resList, msgTo, err := monitorDao.ExecKuaishouSchedule(sqlInfo)
	if err != nil {
		return nil, "", err
	}
	if len(resList) == 0 {
		return nil, "", nil
	}
	if operation == 2 {
		var accountIds []string
		// 拉空操作
		for _, v := range resList {
			accountIds = append(accountIds, v.AdvertiserId)
		}
		// 查询账号下广告组

		//a2aMap := Advertiser2AccountMap(accountIds)
		ExecKuaishouSchedule(m.Ctx, accountIds)
		// 查询结果
		weekScheduleDao := warning.NewWeekScheduleDao(m.Ctx)
		list, findErr := weekScheduleDao.FindScheduleKuaishou(repo.MediaKuaishou)
		if findErr != nil {
			return nil, "", findErr
		}
		var ads string
		for k, v := range list {
			if k == len(list)-1 {
				ads += "'" + v.AdvertiserId + "'"
			} else {
				ads += "'" + v.AdvertiserId + "',"
			}
		}
		updateErr := weekScheduleDao.UpdateScheduleStatus(ads)
		if updateErr != nil {
			log.Errorf("更新拉空记录表失败, err: %s", updateErr)
		}
		return list, msgTo, nil
	} else {
		return resList, msgTo, nil
	}
}

//func Advertiser2AccountMap(accountIds []string) map[int64][]string {
//	A2AMap := make(map[int64][]string)
//	accountDao := kuaishoudao.NewAccountDao(context.Background())
//	accountList, err := accountDao.GetAccountListByAccountId(accountIds)
//	if err != nil {
//		return nil
//	}
//	for _, v := range accountList {
//		accountId := strconv.Itoa(int(v.AccountId))
//		A2AMap[v.AdvertiserId] = append(A2AMap[v.AdvertiserId], accountId)
//	}
//	return A2AMap
//}

func ExecKuaishouSchedule(ctx context.Context, accountIds []string) {
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用appid
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaKuaishouMagnet)
	if appErr != nil {
		return
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaKuaishouMagnet, []string{})
	if oauthErr != nil {
		return
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		oauthMap[v.AppId][v.UserId] = v.AccessToken
	}

	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(oauthList) / len(appIds)
	remainder := len(oauthList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		// 为每个goroutine创建局部变量
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			QueryKuaishouUnit(oauthList[start:end], oauth, accountIds)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return
}

func QueryKuaishouUnit(userIds []accountrepo.OauthEntity, oauth map[string]string, accountIds []string) {

	resChan := make(chan *wModel.ProjectWeekScheduleEntity) // 结果缓存通道
	errChan := make(chan error, len(userIds))
	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)
	// DB 只执行一次
	once.Do(func() {
		go func() {
			dbErr := execWeekScheduleDB(context.Background(), resChan, repo.MediaKuaishou)
			if dbErr != nil {
				errChan <- dbErr
			}
		}()
	})
	for _, v := range userIds {
		wg.Add(1)
		currentItem := v
		advertiserId, _ := strconv.Atoi(currentItem.UserId)

		task := func() {
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()
			_, exists := oauth[currentItem.UserId]
			if !exists {
				return
			}
			for _, vv := range accountIds {
				accountId, _ := strconv.Atoi(vv)
				allReq, getErr := kuaishou.AllUnitList(context.Background(), kuaishou.UnitReq{
					AdvertiserId: int64(accountId),
					AccessToken:  oauth[currentItem.UserId],
				})
				if getErr != nil {
					errChan <- fmt.Errorf("查询账号下广告失败, advertiserId: %d, token: %s,  err: %s", advertiserId, oauth[currentItem.UserId], getErr.Error())
					return
				}
				for _, row := range allReq {
					res, err := kuaishou.UpdateUnit(context.Background(), kuaishou.UpdateUnitReq{
						AdvertiserId: int64(accountId),
						BidType:      row.BidType,
						UnitId:       row.UnitId,
						UnitName:     row.UnitName,
						ScheduleTime: buildKuaishouScheduleTime(),
					}, oauth[currentItem.UserId])
					if err != nil {
						resInfo := &wModel.ProjectWeekScheduleEntity{
							AdvertiserId: vv,
							ProjectId:    "",
							Operation:    "schedule",
							ScheduleTime: buildKuaishouScheduleTime(),
							ErrorMsg:     res.Message,
							CreatedTime:  time.Now(),
						}
						resChan <- resInfo
						errChan <- fmt.Errorf("执行拉空操作失败, advertiserId: %d, token: %s,  err: %s", advertiserId, oauth[currentItem.UserId], getErr.Error())
						return
					}
					// 成功合集
					resInfo := &wModel.ProjectWeekScheduleEntity{
						AdvertiserId:  vv,
						ProjectId:     "",
						Operation:     "schedule",
						ScheduleTime:  buildKuaishouScheduleTime(),
						ErrorMsg:      "成功",
						ReverseStatus: 0,
						CreatedTime:   time.Now(),
					}
					resChan <- resInfo
				}
			}

		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		fmt.Println(errL.Error())
		errs = append(errs, errL)
	}
}

func generateKuaishouSchedule() string {
	hour := time.Now().Hour()
	var s string
	for i := 0; i < 23; i++ {
		if hour > i {
			s += "1"
		} else {
			s += "0"
		}
	}
	// 规则23
	return s + "1"
}

func allOneKuaishou() []string {
	res := make([]string, 0)
	for i := 0; i < 7; i++ {
		s := strings.Repeat("1", 24)
		res = append(res, s)
	}
	return res
}

func buildKuaishouScheduleTimeT1() string {
	oneList := allOneKuaishou()
	return strings.Join(oneList, "")
}

func buildKuaishouScheduleTime() string {
	day := time.Now().Weekday()
	oneList := allOneKuaishou()
	todaySchedule := generateKuaishouSchedule()
	var res []string
	for k, v := range oneList {
		if k == int(day)-1 {
			res = append(res, todaySchedule)
			continue
		}
		res = append(res, v)
	}

	return strings.Join(res, "")
}

// GetKuaishouWeekScheduleT1 拉空的数据修改回来
func (m *MonitorService) GetKuaishouWeekScheduleT1() ([]wModel.WeekSchedule, string, error) {
	scheduleDao := warning.NewWeekScheduleDao(m.Ctx)
	var accountIds []string
	resList, err := scheduleDao.FindKuaishouScheduleT1(repo.MediaKuaishou)
	if err != nil {
		return nil, "", err
	}
	if len(resList) == 0 {
		return nil, "", nil
	}
	for _, v := range resList {
		accountIds = append(accountIds, v.AdvertiserId)
	}
	//a2aMap := Advertiser2AccountMap(accountIds)
	ExecKuaishouScheduleT1(context.Background(), accountIds)
	var msgTo string
	for k, v := range resList {
		if k == len(resList)-1 {
			msgTo += v.NickName
		} else {
			msgTo += v.NickName + ","
		}
	}
	return resList, msgTo, nil
}

func ExecKuaishouScheduleT1(ctx context.Context, accountIds []string) {
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用appid
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaKuaishouMagnet)
	if appErr != nil {
		return
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaKuaishouMagnet, []string{})
	if oauthErr != nil {
		return
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		oauthMap[v.AppId][v.UserId] = v.AccessToken
	}

	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(oauthList) / len(appIds)
	remainder := len(oauthList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		// 为每个goroutine创建局部变量
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			QueryKuaishouUnitT1(oauthList[start:end], oauth, accountIds)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return
}

func QueryKuaishouUnitT1(userIds []accountrepo.OauthEntity, oauth map[string]string, accountIds []string) {

	resChan := make(chan *wModel.ProjectWeekScheduleEntity) // 结果缓存通道
	errChan := make(chan error, len(userIds))
	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)
	// DB 只执行一次
	once.Do(func() {
		go func() {
			dbErr := execWeekScheduleDB(context.Background(), resChan, repo.MediaKuaishou)
			if dbErr != nil {
				errChan <- dbErr
			}
		}()
	})
	for _, v := range userIds {
		wg.Add(1)
		currentItem := v
		advertiserId, _ := strconv.Atoi(currentItem.UserId)

		task := func() {
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()
			_, exists := oauth[currentItem.UserId]
			if !exists {
				return
			}
			for _, vv := range accountIds {
				accountId, _ := strconv.Atoi(vv)
				allReq, getErr := kuaishou.AllUnitList(context.Background(), kuaishou.UnitReq{
					AdvertiserId: int64(accountId),
					AccessToken:  oauth[currentItem.UserId],
				})
				if getErr != nil {
					errChan <- fmt.Errorf("查询账号下广告失败, advertiserId: %d, token: %s,  err: %s", advertiserId, oauth[currentItem.UserId], getErr.Error())
					return
				}
				for _, row := range allReq {
					res, err := kuaishou.UpdateUnit(context.Background(), kuaishou.UpdateUnitReq{
						AdvertiserId: int64(accountId),
						BidType:      row.BidType,
						UnitId:       row.UnitId,
						UnitName:     row.UnitName,
						ScheduleTime: buildKuaishouScheduleTimeT1(),
					}, oauth[currentItem.UserId])
					if err != nil {
						resInfo := &wModel.ProjectWeekScheduleEntity{
							AdvertiserId: vv,
							ProjectId:    "",
							Operation:    "schedule",
							ScheduleTime: buildKuaishouScheduleTimeT1(),
							ErrorMsg:     res.Message,
							CreatedTime:  time.Now(),
						}
						resChan <- resInfo
						errChan <- fmt.Errorf("执行反拉空失败, advertiserId: %d, token: %s,  err: %s", advertiserId, oauth[currentItem.UserId], getErr.Error())
						return
					}
					// 成功合集
					resInfo := &wModel.ProjectWeekScheduleEntity{
						AdvertiserId:  vv,
						ProjectId:     "",
						Operation:     "schedule",
						ScheduleTime:  buildKuaishouScheduleTimeT1(),
						ErrorMsg:      "成功",
						ReverseStatus: 1,
						CreatedTime:   time.Now(),
					}
					resChan <- resInfo
				}
			}

		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		fmt.Println(errL.Error())
		errs = append(errs, errL)
	}
}
