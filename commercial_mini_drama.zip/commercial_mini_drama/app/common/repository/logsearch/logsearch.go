package logsearch

import (
	"goserver/app/common/repository"
)

const SearchLogEntityTable = "search_log_info"

// SearchLogEntity 巨量小时项目维度消耗
type SearchLogEntity struct {
	SearchDate   string `gorm:"column:search_date"`   // 日期
	AdvertiserId string `gorm:"column:advertiser_id"` // 账号ID
	ContentTitle string `gorm:"column:content_title"` // 操作内容
	ObjectType   string `gorm:"column:object_type"`   // 操作对象类型
	ObjectId     int64  `gorm:"column:object_id"`     // 操作对象ID
	CreateTime   string `gorm:"column:create_time"`   // 操作时间
	ContentLog   string `gorm:"column:content_log"`   // 日志
}

func (*SearchLogEntity) TableName() string {
	return SearchLogEntityTable
}

func SearchLogTableName() string {
	if repository.IsDebugTable(SearchLogEntityTable) {
		return SearchLogEntityTable + "_dev"
	} else {
		return SearchLogEntityTable
	}
}
