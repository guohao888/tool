package accounts

import (
	"context"
	"github.com/alitto/pond"
	accountdto "goserver/app/common/dto/accounts"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/library/playlet/novelsale"
	accountdao "goserver/app/model/dao/accounts"
	"strconv"
	"time"
)

type DistributorPromotionUrlService struct {
	Ctx context.Context
}

func NewDistributorPromotionUrlService(ctx context.Context) *DistributorPromotionUrlService {
	return &DistributorPromotionUrlService{Ctx: ctx}
}

func (s *DistributorPromotionUrlService) SyncFanqie(params accountdto.DistributorPromotionUrlSyncExecutorParams) error {

	// 获取番茄秘钥配置
	distributorConfigDao := accountdao.NewDistributorConfigDao(s.Ctx)
	configs, err := distributorConfigDao.ListByDistributor(repo.DistributorFanqie, params.ApiIds)
	if err != nil {
		log.Errorf("DistributorPromotionUrlService.SyncFanqie 获取番茄密钥配置错误, err: %s", err)
		return err
	}

	resChan := make(chan accountrepo.DistributorPromotionUrlEntity)
	errChan := make(chan error)

	go func() {
		pool := pond.New(params.PoolWorkers, 500)
		defer pool.StopAndWait()
		group, _ := pool.GroupContext(context.Background())

		for _, v1 := range configs {
			config := v1

			apiId, err := strconv.ParseInt(config.ApiId, 10, 64)
			if err != nil {
				continue
			}
			wxGetPackageListV2List, err := novelsale.AllWxGetPackageListV2(novelsale.AllWxGetPackageListV2Req{
				DistributorId: apiId,
				SecretKey:     config.ApiSecret,
				AppType:       config.AppType,
			})
			if err != nil {
				log.Errorf("DistributorPromotionUrlService.SyncFanqie 获取账户下分包信息错误, err: %s, api_id: %d, app_type: %d", err, apiId, config.AppType)
			}

			for _, v2 := range wxGetPackageListV2List {
				p := v2

				group.Submit(func() error {
					wxGetBoundPackageList, err := novelsale.AllWxGetBoundPackageListV1(novelsale.AllWxGetBoundPackageListV1Req{
						DistributorId: apiId,
						SecretKey:     config.ApiSecret,
						AppId:         p.AppId,
					})
					if err != nil {
						log.Errorf("DistributorPromotionUrlService.SyncFanqie 获取小程序渠道信息错误, err: %s, api_id: %d, app_id: %d", err, apiId, p.AppId)
						return err
					}

					for _, bp := range wxGetBoundPackageList {
						promotionList, err := novelsale.AllPromotionListV1(novelsale.AllPromotionListV1Req{
							DistributorId: bp.DistributorId,
							SecretKey:     config.ApiSecret,
						})
						if err != nil {
							log.Errorf("DistributorPromotionUrlService.SyncFanqie 获取推广链错误, err: %s, distributorId: %d", err, bp.DistributorId)
							continue
						}

						for _, v := range promotionList {
							promotionUrl, err := v.GetPromotionUrl(bp.AppType)
							if err != nil {
								log.Errorf("DistributorPromotionUrlService.SyncFanqie 解析推广链错误, err: %s, distributorId: %d, promotion_url: %s", err, bp.DistributorId, v.PromotionUrl)
								continue
							}
							if promotionUrl == "" {
								continue
							}

							d := accountrepo.DistributorPromotionUrlEntity{
								Distributor:        config.Distributor,
								AppId:              bp.AppId,
								OptimizerId:        v.OptimizerId,
								PromotionUrl:       promotionUrl,
								PromotionId:        v.PromotionId,
								PromotionName:      v.PromotionName,
								OptimizerName:      bp.NickName,
								BookId:             v.BookId,
								BookName:           v.BookName,
								AppName:            bp.AppName,
								ApiId:              config.ApiId,
								AppType:            bp.AppType,
								DistributorId:      bp.DistributorId,
								ProfitModel:        config.ProfitModel,
								MediaSource:        v.MediaSource,
								AdCallBackConfigId: v.AdCallbackConfigId,
								CreateTime:         v.CreateTime,
								CreatedAt:          time.Time{},
								UpdatedAt:          time.Time{},
							}
							resChan <- d
						}
					}

					return nil
				})
			}
		}

		e := group.Wait()
		if e != nil {
			errChan <- e
			close(errChan)
		}
		close(resChan)
	}()

	distributorPromotionUrlDao := accountdao.NewDistributorPromotionUrlDao(s.Ctx)

	batchSize := 3000
	var data []accountrepo.DistributorPromotionUrlEntity
	for {
		var breakFlag bool
		select {
		case err, ok := <-errChan:
			if ok {
				return err
			}
		case res, ok := <-resChan:
			if ok {
				data = append(data, res)
				if len(data) > batchSize {
					err := distributorPromotionUrlDao.InsertBatchSize(data, batchSize)
					if err != nil {
						log.Errorf("DistributorPromotionUrlService.SyncFanqie 数据插入失败, err: %s", err)
						return err
					}
					data = data[:0]
				}
			} else {
				breakFlag = true
			}
		}
		if breakFlag {
			break
		}
	}
	if len(data) > 0 {
		err := distributorPromotionUrlDao.InsertBatchSize(data, batchSize)
		if err != nil {
			log.Errorf("DistributorPromotionUrlService.SyncFanqie 数据插入失败, err: %s", err)
			return err
		}
		data = data[:0]
	}

	return nil
}
