package warning

import (
	"context"
	"goserver/app/common/dto/warningdto"
	"goserver/app/common/repository/warning"
	dao "goserver/app/model/dao/warning"
)

type AlbumService struct {
	Ctx context.Context
}

func NewAlbumService(ctx context.Context) *AlbumService {
	return &AlbumService{Ctx: ctx}
}

func (s *AlbumService) Export(params *warningdto.AlbumsReq) (result []warning.Album, err error) {
	albumDao := dao.NewAlbumDao(s.Ctx)
	result, err = albumDao.FindAlbumList(params.AlbumList)
	return
}
