package mediareport

import (
	"errors"
	timeUtil "goserver/app/library/utils/time"
	"time"
)

type AccountReportSyncExecutorParams struct {
	AccountIds  []string `json:"account_id"`   // 账户id
	IsFast      int      `json:"is_fast"`      // 是否是快队列数据  2 fast 1 slow
	Start       string   `json:"start"`        // 起始时间，格式: 2024-05-16
	End         string   `json:"end"`          // 结束时间，格式: 2024-05-17 (左闭、右闭)
	PointDate   string   `json:"point_date"`   // 指定日期 格式: 2024-05-17
	IsHistory   int      `json:"is_history"`   // 是否是刷新次日数据 1 历史  0 实时 2 补充拉取
	AppIds      []string `json:"app_ids"`      // 应用Id
	Coefficient float64  `json:"coefficient"`  // IAA系数
	IsReplenish int      `json:"is_replenish"` // 是否是补充数据 1 补充  0 正常执行
}

func (a *AccountReportSyncExecutorParams) CrontabDateList() ([]time.Time, error) {
	if (a.Start != "" && a.End == "") || (a.Start == "" && a.End != "") {
		return nil, errors.New("start date and end date must exist simultaneously")
	}

	var crontabTimeList []time.Time
	if a.PointDate != "" {
		pointDate, err := time.ParseInLocation(time.DateOnly, a.PointDate, time.Local)
		if err != nil {
			return nil, err
		}
		crontabTimeList = append(crontabTimeList, pointDate)
	} else if a.Start != "" && a.End != "" && a.IsHistory == 2 {
		s, err := time.ParseInLocation(time.DateOnly, a.Start, time.Local)
		if err != nil {
			return nil, err
		}
		e, err := time.ParseInLocation(time.DateOnly, a.End, time.Local)
		if err != nil {
			return nil, err
		}
		for s.Before(e.Add(1 * time.Hour)) {
			crontabTimeList = append(crontabTimeList, s)
			s = s.Add(24 * time.Hour)
		}
	} else if a.IsHistory == 0 {
		dateTime, _ := timeUtil.GetDayTime(time.Now())
		crontabTimeList = append(crontabTimeList, dateTime)
	} else if a.IsHistory == 1 {
		pointDate, _ := timeUtil.GetDayTime(time.Now().AddDate(0, 0, -1))
		crontabTimeList = append(crontabTimeList, pointDate)
	}
	return crontabTimeList, nil
}

type HourReport struct {
	SearchDate string  `gorm:"column:search_date"`
	SearchHour string  `gorm:"column:search_hour"`
	MediaCost  float64 `gorm:"column:media_cost"`
	Income     float64 `gorm:"column:income"`
	RealIncome float64 `gorm:"column:real_income"`
	Manager    string  `gorm:"column:manager"`
}
