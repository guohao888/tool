package kuaishou

import (
	"context"
	"errors"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/kuaishou"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// AccountDao 账号信息
type AccountDao struct {
	Ctx context.Context
}

func NewAccountDao(ctx context.Context) *AccountDao {
	return &AccountDao{Ctx: ctx}
}

type OptimizerNicknameResult struct {
	OptimizerNickname string `gorm:"column:optimizer_nickname"`
}

// GetAllOptimizerNickname 获取全部投放人员昵称
func (a *AccountDao) GetAllOptimizerNickname() ([]string, error) {
	var results []OptimizerNicknameResult
	db := dorisdb.DorisClient()
	sql := `
		SELECT 
			DISTINCT
			CASE 
				WHEN INSTR(account_name, '-') > 0 
				THEN SUBSTRING_INDEX(account_name, '-', 1)
				ELSE ''
			END AS optimizer_nickname
		FROM 
			` + kuaishou.AccountInfoTableName() + ` 
		ORDER by optimizer_nickname asc
	`
	err := db.Raw(sql).Scan(&results).Error
	if err != nil {
		return nil, err
	}
	var ret []string
	for _, v := range results {
		ret = append(ret, v.OptimizerNickname)
	}
	return ret, nil
}

func (a *AccountDao) GetAccountIdByNickname(prefixes []string) ([]int64, error) {
	db := dorisdb.DorisClient()
	query := db.Table(kuaishou.AccountInfoTableName())

	var accountIds []int64

	// 构建条件
	var conditions []string
	var args []interface{}
	hasEmpty := false

	for _, prefix := range prefixes {
		if prefix == "" {
			hasEmpty = true
		} else {
			conditions = append(conditions, "account_name LIKE ?")
			args = append(args, prefix+"-%")
		}
	}

	// 组合查询条件
	if len(conditions) > 0 && hasEmpty {
		query = query.Where(
			"(? OR INSTR(account_name, '-') = 0)",
			db.Where(strings.Join(conditions, " OR "), args...),
		)
	} else if len(conditions) > 0 {
		query = query.Where(strings.Join(conditions, " OR "), args...)
	} else if hasEmpty {
		query = query.Where("INSTR(account_name, '-') = 0")
	} else {
		query = query.Where("account_name IS NOT NULL")
	}

	// 执行查询
	err := query.Pluck("account_id", &accountIds).Error
	if err != nil {
		return nil, err
	}

	return accountIds, nil
}

func (a *AccountDao) GetAccountInfoByKeywords(keyword string, limit int) ([]kuaishou.AccountInfoEntity, error) {
	db := dorisdb.DorisClient()
	q := db.Table(kuaishou.AccountInfoTableName())
	q = q.Select("distinct account_name")
	q = q.Where("account_name<>''")
	if keyword != "" {
		q = q.Where("account_name LIKE ?", "%"+keyword+"%")
	}
	q = q.Order("account_name ASC")
	if limit > 0 {
		q = q.Offset(0).Limit(limit)
	}
	var res []kuaishou.AccountInfoEntity
	err := q.Find(&res).Error
	if err != nil {
		return nil, err
	}

	return res, nil
}

// InsertBatchSize 插入更新数据
func (a *AccountDao) InsertBatchSize(data []*kuaishou.AccountInfoEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = a.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (a *AccountDao) buildInsertSentence(tx *gorm.DB, data []*kuaishou.AccountInfoEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + kuaishou.AccountInfoTableName() + " ( advertiser_id, account_id, created_time, account_name, updated_time ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.AccountId,
			v.CreatedAt,
			v.AccountName,
			v.UpdatedAt,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

func (a *AccountDao) GetAccountList() (list []*kuaishou.AccountInfoEntity, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(kuaishou.AccountInfoTableName())
	err = q.Find(&list).Error
	if err != nil {
		return nil, err
	}

	return list, err
}

func (a *AccountDao) GetAccountListByAccountId(accountIds []string) (list []*kuaishou.AccountInfoEntity, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(kuaishou.AccountInfoTableName())
	err = q.Where("account_id in (?)", accountIds).Find(&list).Error
	if err != nil && errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}

	return list, err
}
