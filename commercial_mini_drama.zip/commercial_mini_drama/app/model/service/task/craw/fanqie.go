package craw

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	rawEntity "goserver/app/common/repository/raw"
	noticeCommon "goserver/app/library/utils/notice/common"
	time2 "goserver/app/library/utils/time"
	"goserver/app/model/service/raw"
	"io"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/jinzhu/gorm"
	"github.com/xuri/excelize/v2"
	"github.com/xxl-job/xxl-job-executor-go"
	"goserver/app/library/driver/dorisdb"
)

// 番茄常量
const (
	BusinessTypeFanqie = 1
	ExportCreateURL    = "https://bytedance.larkoffice.com/space/api/export/create/"
	ExportResultURL    = "https://bytedance.larkoffice.com/space/api/export/result/%s"
	DownloadURL        = "https://internal-api-drive-stream.larkoffice.com/space/api/box/stream/download/all/%s"
	SheetToken         = "GsfOstiSqhJ7h1tfDz7cb3oLn40"
	DefaultWaitTime    = 3 * time.Second
)

const GroupNum = "7652669649085783"

// FeiShu 定义飞书数据结构
type ResultData struct {
	BookName       string    `json:"book_name"`
	IAAtime        string    `json:"IAAtime"`
	ReferralUrl    string    `json:"referral_url"`
	HashID         string    `json:"hash_id"`
	CopyrightOwner string    `json:"copyright_owner"`
	CreatedTime    time.Time `json:"created_time"`
}

// CrawConfig 定义爬取配置结构
type CrawConfig struct {
	BusinessType int       `gorm:"column:business_type"`
	ReqCurl      string    `gorm:"column:req_curl"`
	CreateTime   time.Time `gorm:"create_time"`
}

// LarkClient 封装飞书API客户端
type LarkClient struct {
	Cookies    []*http.Cookie
	Headers    map[string]string
	HTTPClient *http.Client
	CSRFToken  string
}

type resultInfo struct {
	Data    interface{} `json:"data"`
	Code    int         `json:"code"`
	Message string      `json:"msg"`
}

// NewLarkClient 创建新的飞书客户端
func NewLarkClient(reqCurl string) *LarkClient {
	cookieMaps := ParseCookie(reqCurl)
	var cookies []*http.Cookie
	for k, val := range cookieMaps {
		cookies = append(cookies, &http.Cookie{Name: k, Value: val})
	}
	csrfToken := cookieMaps["_csrf_token"]

	headers := map[string]string{
		"accept":          "application/json, text/plain, */*",
		"accept-language": "zh-CN,zh;q=0.9,en;q=0.8",
		"cache-control":   "no-cache",
		"content-type":    "application/json",
		"referer":         "https://bytedance.larkoffice.com/sheets/" + SheetToken,
		"x-csrftoken":     csrfToken,
	}

	return &LarkClient{
		Cookies:    cookies,
		Headers:    headers,
		HTTPClient: &http.Client{},
		CSRFToken:  csrfToken,
	}
}

// createExportTask 创建导出任务
func (lc *LarkClient) createExportTask() (string, error) {
	jsonData := map[string]interface{}{
		"token":          SheetToken,
		"type":           "sheet",
		"file_extension": "xlsx",
		"event_source":   "1",
	}

	jsonBody, err := json.Marshal(jsonData)
	if err != nil {
		return "", fmt.Errorf("failed to marshal json data: %w", err)
	}

	req, err := http.NewRequest("POST", ExportCreateURL, bytes.NewBuffer(jsonBody))
	if err != nil {
		return "", fmt.Errorf("failed to create request: %w", err)
	}

	lc.setRequestHeaders(req)
	resp, err := lc.HTTPClient.Do(req)

	if err != nil {
		return "", fmt.Errorf("failed to execute request: %w", err)
	}

	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("export create request failed with status: %s", resp.Status)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("failed to read response body: %w", err)
	}

	var res resultInfo
	_ = json.Unmarshal(body, &res)
	if res.Code != 0 {
		// cookie  过期，推送消息提示
		content := "日期" + time.Now().Format("2006-01-02 15:04:05") + "\n【番茄】Cookie已过期，请更换cookie信息"
		err = noticeCommon.SendTuituiTextMsg(content, GroupNum, strings.Split(AtPersonOfCookie, ",")...)
		if err != nil {
			return "", fmt.Errorf("failed to send message: %w", err)
		}

	}
	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return "", fmt.Errorf("failed to unmarshal response: %w", err)
	}

	data, ok := result["data"].(map[string]interface{})
	if !ok {
		return "", fmt.Errorf("invalid response format: missing data field")
	}

	ticket, ok := data["ticket"].(string)
	if !ok {
		return "", fmt.Errorf("invalid response format: missing ticket field")
	}

	return ticket, nil
}

// getExportResult 获取导出结果
func (lc *LarkClient) getExportResult(ticket string) (string, error) {
	time.Sleep(DefaultWaitTime) // 等待导出完成

	params := map[string]string{
		"token": SheetToken,
		"type":  "sheet",
	}

	crawUrl := fmt.Sprintf(ExportResultURL, ticket)
	req, err := http.NewRequest("GET", crawUrl, nil)
	if err != nil {
		return "", fmt.Errorf("failed to create request: %w", err)
	}

	lc.setRequestHeaders(req)

	// 添加查询参数
	q := req.URL.Query()
	for key, value := range params {
		q.Add(key, value)
	}
	req.URL.RawQuery = q.Encode()

	resp, err := lc.HTTPClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("failed to execute request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return "", fmt.Errorf("export result request failed with status: %s", resp.Status)
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", fmt.Errorf("failed to read response body: %w", err)
	}

	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return "", fmt.Errorf("failed to unmarshal response: %w", err)
	}

	data, ok := result["data"].(map[string]interface{})
	if !ok {
		return "", fmt.Errorf("invalid response format: missing data field")
	}

	resultData, ok := data["result"].(map[string]interface{})
	if !ok {
		return "", fmt.Errorf("invalid response format: missing result field")
	}

	fileToken, ok := resultData["file_token"].(string)
	if !ok {
		return "", fmt.Errorf("invalid response format: missing file_token field")
	}

	return fileToken, nil
}

// downloadFile 下载文件
func (lc *LarkClient) downloadFile(fileToken string) (*excelize.File, error) {
	downloadURL := fmt.Sprintf(DownloadURL, fileToken)
	req, err := http.NewRequest("GET", downloadURL, nil)
	if err != nil {
		return nil, fmt.Errorf("failed to create request: %w", err)
	}

	lc.setRequestHeaders(req)
	resp, err := lc.HTTPClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("failed to execute request: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("download request failed with status: %s", resp.Status)
	}

	file, err := excelize.OpenReader(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to open excel file: %w", err)
	}

	return file, nil
}

// setRequestHeaders 设置请求头
func (lc *LarkClient) setRequestHeaders(req *http.Request) {
	for key, value := range lc.Headers {
		req.Header.Add(key, value)
	}

	for _, cookie := range lc.Cookies {
		req.AddCookie(cookie)
	}
}

// parseExcelData 解析Excel数据
func parseExcelData(file *excelize.File) ([]*ResultData, error) {
	var feiShuList []*ResultData
	for _, sheetName := range file.GetSheetList() {
		if sheetName != "IAA" {
			continue
		}
		rows, err := file.GetRows(sheetName)
		if err != nil {
			return nil, fmt.Errorf("failed to get rows from sheet %s: %w", sheetName, err)
		}
		if len(rows) <= 1 {
			continue // 跳过空表或只有标题的表
		}
		curDay := time.Now().Format("2006/01/02")
		// 跳过标题行
		for _, row := range rows[1:] {
			if len(row) < 3 || row[2] == "" {
				continue
			}
			if row[1] < curDay {
				continue
			}

			feishu := &ResultData{
				BookName:       row[0],
				IAAtime:        row[1],
				ReferralUrl:    row[2],
				HashID:         ParseUrl(row[2]),
				CopyrightOwner: "番茄",
				CreatedTime:    time.Now(),
			}
			if feishu.ReferralUrl == "" {
				continue
			}
			feiShuList = append(feiShuList, feishu)
		}
	}

	return feiShuList, nil
}

// saveToDatabase 保存数据到数据库
func saveToDatabase(ctx context.Context, feiShuList []*ResultData) error {
	if len(feiShuList) == 0 {
		return nil
	}
	referralService := raw.NewReferralService(ctx)
	// 格式化数据
	var formatData []rawEntity.ReferralEntity
	for _, val := range feiShuList {
		formatData = append(formatData, rawEntity.ReferralEntity{
			BookName:       val.BookName,
			CopyrightOwner: val.CopyrightOwner,
			CreatedTime:    val.CreatedTime,
			HashId:         val.HashID,
			ReferralUrl:    val.ReferralUrl,
		})
	}
	err := referralService.Import(formatData)
	if err != nil {
		return err
	}

	return nil
}

// getCrawConfig 获取爬取配置
func getCrawConfig(businessType int) (*CrawConfig, error) {
	var config CrawConfig
	sql := "select * from craw_config where business_type = ?"
	db := dorisdb.DorisClient()
	err := db.Raw(sql, businessType).Scan(&config).Error
	if err != nil {
		if gorm.IsRecordNotFoundError(err) {
			return nil, fmt.Errorf("craw config not found for business type %d", businessType)
		}
		return nil, fmt.Errorf("failed to query craw config: %w", err)
	}
	return &config, nil
}

// SycCrawFanqieData 主函数 - 爬取番茄数据
func SyncCrawFanqieData(ctx context.Context, param *xxl.RunReq) (msg string) {
	// 获取配置
	config, err := getCrawConfig(BusinessTypeFanqie)
	if err != nil {
		return fmt.Sprintf("获取配置失败: %v", err)
	}

	// 创建飞书客户端
	larkClient := NewLarkClient(config.ReqCurl)

	ticket, err := larkClient.createExportTask()
	if err != nil {
		return fmt.Sprintf("创建导出任务失败: %v", err)
	}

	// 获取导出结果
	fileToken, err := larkClient.getExportResult(ticket)
	if err != nil {
		return fmt.Sprintf("获取导出结果失败: %v", err)
	}

	// 下载文件
	file, err := larkClient.downloadFile(fileToken)
	if err != nil {
		return fmt.Sprintf("下载文件失败: %v", err)
	}

	// 解析Excel数据
	feiShuList, err := parseExcelData(file)
	if err != nil {
		return fmt.Sprintf("解析Excel数据失败: %v", err)
	}

	// 新数据消息推送
	newBookNames, err := GetNewData(ctx, feiShuList)
	if err != nil {
		return fmt.Sprintf("获取新数据失败: %v", err)
	}
	if len(newBookNames) > 0 {
		content := "番茄端原生以下剧目已上架，请及时跟进:\n" + strings.Join(newBookNames, "\n")
		err = noticeCommon.SendTuituiTextMsg(content, ChangDuGroupNum)
		if err != nil {
			return fmt.Sprintf("发送通知失败: %v", err)
		}

	}

	// 保存到数据库
	if err := saveToDatabase(ctx, feiShuList); err != nil {
		return fmt.Sprintf("保存到数据库失败: %v", err)
	}

	return fmt.Sprintf("成功处理 %d 条数据", len(feiShuList))
}

// ParseUrl 解析URL获取hash_res参数
func ParseUrl(urlStr string) string {
	u, err := url.Parse(urlStr)
	if err != nil {
		return ""
	}

	queryParams, err := url.ParseQuery(u.RawQuery)
	if err != nil {
		return ""
	}

	return queryParams.Get("playlet_id")
}

// parseCookie 解析Cookie字符串
func ParseCookie(cookieStr string) map[string]string {
	cookieMap := make(map[string]string)
	// 按分号分割 Cookie 键值对（处理可能的空格）
	pairs := strings.Split(cookieStr, ";")
	for _, pair := range pairs {
		// 去除首尾空格
		pair = strings.TrimSpace(pair)
		if pair == "" {
			continue
		}

		// 按第一个等号分割键和值（处理值中可能包含等号的情况）
		parts := strings.SplitN(pair, "=", 2)
		if len(parts) != 2 {
			continue // 跳过格式不正确的项
		}

		key := parts[0]
		value := parts[1]
		value = strings.Trim(strings.TrimSpace(value), "\"")
		cookieMap[key] = value
	}
	return cookieMap
}

func GetNewData(ctx context.Context, data []*ResultData) ([]string, error) {
	if len(data) == 0 {
		return nil, nil
	}
	// 查询当天已经插入的数据
	startTime := time2.GetTodayStart().Format("2006-01-02 15:04:05")
	endTime := time2.GetTodayEnd().Format("2006-01-02 15:04:05")
	existData, err := raw.NewReferralService(ctx).QueryByCreatedTime(startTime, endTime)
	if err != nil {
		return nil, err
	}
	existHashID := make(map[string]bool)
	for _, val := range existData {
		existHashID[val.HashId] = true
	}
	var newBookName []string
	for _, val := range data {
		if !existHashID[val.HashID] {
			newBookName = append(newBookName, val.BookName)
		}
	}
	var bookNames []string
	for k, val := range newBookName {
		bookName := fmt.Sprintf("%d、", k+1) + val
		bookNames = append(bookNames, bookName)
	}
	return bookNames, nil
}
