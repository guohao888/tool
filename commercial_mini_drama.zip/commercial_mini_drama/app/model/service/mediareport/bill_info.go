package mediareport

import (
	"context"
	"fmt"
	"github.com/panjf2000/ants/v2"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	mediaRepo "goserver/app/common/repository/mediareport"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
	mediadao "goserver/app/model/dao/mediareport"
	"goserver/app/model/dao/subscribe"
	"strconv"
	"sync"
	"time"
)

type BillInfoService struct {
	Ctx context.Context
}

func NewBillInfoService(ctx context.Context) *BillInfoService {
	return &BillInfoService{Ctx: ctx}
}

/***********************         新授权逻辑 令牌桶方式获取账单  start       ***********************/

func (r *BillInfoService) DistributeBillAccounts(crontabTime time.Time, ctx context.Context) error {

	// 获取执行时间
	startDate, endDate := GetExecTime(crontabTime)

	// 1.获取活跃账号数据
	beforeDao := subscribe.NewBeforeSubscribeDao(r.Ctx)
	activeList, err := beforeDao.UnionAdvertiserList(startDate)
	//activeDao := accountdao.NewOauthActiveAccountDao(r.Ctx)
	//activeList, err := activeDao.ListQueenAll()
	if err != nil {
		return err
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		oauthMap[v.AppId][v.UserId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncBillInfo(startDate, endDate, activeList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func SyncBillInfo(start, end string, activeList []accountrepo.OauthAccountEntity, oauth map[string]string, appId string) {

	resChan := make(chan *mediaRepo.BillInfoEntity)
	errChan := make(chan error, len(activeList))

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	once.Do(func() {
		go func() {
			dbErr := execBillDB(context.Background(), resChan)
			if dbErr != nil {
				errChan <- fmt.Errorf("execBillDB err: %s", dbErr.Error())
			}
		}()
	})

	// 获取所有活跃账号及token 请求接口数据
	for _, v := range activeList {
		currentItem := v
		advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
		userId := currentItem.UserId
		wg.Add(1)

		task := func() {
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()

			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			allBillInfo, getErr := toutiao.AllFundDailyStatV2(context.Background(), toutiao.AllFundDailyStatV2Req{
				AccessToken:  oauth[userId],
				AdvertiserId: int64(advertiserId),
				StartTime:    start,
				EndTime:      end,
			}, appId)
			if getErr != nil {
				errChan <- fmt.Errorf("账单数据请求失败, advertiserId: %d, token: %s, appId: %s, err: %s", advertiserId, oauth[userId], appId, getErr.Error())
				return
			}
			for _, row := range allBillInfo.DataRows2InnerTransformFundDaily() {
				info := &mediaRepo.BillInfoEntity{
					AdvertiserId:      row.AdvertiserId,
					SearchDate:        row.SearchDate,
					Balance:           row.Balance,
					GrantBalance:      row.GrantBalance,
					NonGrantBalance:   row.NonGrantBalance,
					CashCost:          row.CashCost,
					Cost:              row.Cost,
					Frozen:            row.Frozen,
					Income:            row.Income,
					RewardCost:        row.RewardCost,
					SharedWalletCost:  row.SharedWalletCost,
					CompanyWalletCost: row.CompanyWalletCost,
					TransferIn:        row.TransferIn,
					TransferOut:       row.TransferOut,
				}
				resChan <- info
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		errs = append(errs, errL)
	}

	if len(errs) > 0 {
		_ = sendMsg(errs, "同步账单数据\n")
	}
	return
}

/***********************         新授权逻辑 令牌桶方式获取账单  end       ***********************/

func execBillDB(ctx context.Context, resChan <-chan *mediaRepo.BillInfoEntity) (err error) {
	// 保存数据DAO
	billInfoDao := mediadao.NewBillInfoDao(ctx)
	var data = make([]*mediaRepo.BillInfoEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			err = billInfoDao.InsertBatchSize(data, 5000)
			if err != nil {
				errs = append(errs, err) // 收集错误，不退出
			}
			data = data[:0]
		}
	}
	if len(data) > 0 {
		err = billInfoDao.InsertBatchSize(data, 5000)
		if err != nil {
			errs = append(errs, err) // 收集错误，不退出
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execBillDB errors: %v", errs)
	}
	return nil
}
