package library

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"errors"
	"io/ioutil"
	"net"
	"net/http"
	"net/url"
	"strconv"
	"strings"
	"time"
)

type ReportCommonReq struct {
	AdvertiserId   int64    `json:"advertiser_id"`
	AccessToken    string   `json:"access_token"`
	PageNo         int64    `json:"page_no"`
	PageSize       int64    `json:"page_size"`
	StartTime      int64    `json:"start_time"`
	EndTime        int64    `json:"end_time"`
	SeriesType     int64    `json:"series_type,omitempty"`
	ExtraDimension []string `json:"extra_dimension"`
}

type CoreDataReq struct {
	AdvertiserId int64  `json:"advertiser_id"`
	AccessToken  string `json:"access_token"`
	PageNo       int64  `json:"page_no"`
	PageSize     int64  `json:"page_size"`
	StartTime    int64  `json:"start_time"`
	EndTime      int64  `json:"end_time"`
	SeriesType   int64  `json:"series_type"`
	Source       int64  `json:"source"`
}

/*********************************** 短剧广告报表查询接口 ***********************************/

type AdDataResp struct {
	CommonResp
	Data Data `json:"data"`
}

type Data struct {
	TotalCount int64    `json:"total_count"`
	DataList   []AdData `json:"data_list"`
}

type AdData struct {
	Date                                          string  `json:"date"`                                                  // 日期（yyyy-MM-dd hh:mm:ss）
	Likes                                         int64   `json:"likes"`                                                 // 点赞数
	Share                                         int64   `json:"share"`                                                 // 分享数
	PhotoClick                                    int64   `json:"photo_click"`                                           // 封面点击数
	Impression                                    int64   `json:"impression"`                                            // 封面曝光数
	EventPay                                      int64   `json:"event_pay"`                                             // 付费次数
	T0DirectPaidCnt                               float64 `json:"t_0_direct_paied_cnt"`                                  // 付费次数(计费时间)
	EventPayPurchaseAmount                        float64 `json:"event_pay_purchase_amount"`                             // 付费金额
	T0DirectPaidAmt                               float64 `json:"t_0_direct_paied_amt"`                                  // 付费金额(计费时间)
	AdShow                                        int64   `json:"ad_show"`                                               // 广告曝光
	TotalCharge                                   float64 `json:"total_charge"`                                          // 消耗
	EventAppInvoked                               int64   `json:"event_app_invoked"`                                     // 唤起应用数
	EventPayPurchaseAmountFirstDay                float64 `json:"event_pay_purchase_amount_first_day"`                   // 激活当日付费金额
	EventPayPurchaseAmountOneDayByConversion      float64 `json:"event_pay_purchase_amount_one_day_by_conversion"`       // 激活后24h付费金额(激活时间)
	EventPayPurchaseAmountWeekByConversion        float64 `json:"event_pay_purchase_amount_week_by_conversion"`          // 激活后七日付费金额
	EventPayPurchaseAmountThreeDayByConversion    float64 `json:"event_pay_purchase_amount_three_day_by_conversion"`     // 激活后三日付费金额
	Conversion                                    int64   `json:"conversion"`                                            // 激活数
	T0DirectConversionCnt                         int64   `json:"t_0_direct_conversion_cnt"`                             // 激活数(计费时间)
	Negative                                      int64   `json:"negative"`                                              // 减少此类作品数
	Report                                        int64   `json:"report"`                                                // 举报数
	Block                                         int64   `json:"block"`                                                 // 拉黑数
	Comment                                       int64   `json:"comment"`                                               // 评论数
	EventPayFirstDay                              int64   `json:"event_pay_first_day"`                                   // 首日付费次数
	PlayedNum                                     int64   `json:"played_num"`                                            // 素材曝光数
	PlayedThreeSeconds                            int64   `json:"played_three_seconds"`                                  // 3s播放数
	AdPhotoPlayed75percent                        int64   `json:"ad_photo_played_75_percent"`                            // 75%播放进度数
	PlayedEnd                                     int64   `json:"played_end"`                                            // 完播数
	Follow                                        int64   `json:"follow"`                                                // 新增粉丝数
	EventNewUserPay                               int64   `json:"event_new_user_pay"`                                    //新增付费人数
	AdItemClick                                   int64   `json:"ad_item_click"`                                         //行为数
	T7PaidCnt                                     int64   `json:"t7_paied_cnt"`                                          //7日累计付费次数
	T7PaidAmt                                     float64 `json:"t7_paied_amt"`                                          //7日累计付费金额
	ConversionNumByImpression7d                   int64   `json:"conversion_num_by_impression_7_d"`                      //转化数(计费时间)
	DeepConversionNumByImpression7d               int64   `json:"deep_conversion_num_by_impression_7_d"`                 //深度转化数(计费时间)
	ConversionNum                                 int64   `json:"conversion_num"`                                        //转化数(回传时间)
	DeepConversionNum                             int64   `json:"deep_conversion_num"`                                   //深度转化数
	T0PaidCnt                                     int64   `json:"t0_paied_cnt"`                                          //当日累计付费次数
	T0PaidAmt                                     float64 `json:"t0_paied_amt"`                                          //当日累计付费金额
	Play3sRatio                                   float64 `json:"play_3_s_ratio"`                                        //3s播放率
	AdPhotoPlayed75PercentRatio                   float64 `json:"ad_photo_played_75percent_ratio"`                       //75%进度播放率
	T7PaidRoi                                     float64 `json:"t7_paied_roi"`                                          //7日累计ROI
	T0PaidRoi                                     float64 `json:"t0_paied_roi"`                                          //当日累计ROI
	PhotoClickRatio                               float64 `json:"photo_click_ratio"`                                     //封面点击率
	EventPayCost                                  float64 `json:"event_pay_cost"`                                        //付费次数成本
	EventPayRoi                                   float64 `json:"event_pay_roi"`                                         //付费ROI
	EventAppInvokedCost                           float64 `json:"event_app_invoked_cost"`                                //唤起应用成本
	EventAppInvokedRatio                          float64 `json:"event_app_invoked_ratio"`                               //唤起应用率
	ConversionCost                                float64 `json:"conversion_cost"`                                       //激活单价
	EventPayFirstDayRoi                           float64 `json:"event_pay_first_day_roi"`                               //激活当日ROI
	EventPayPurchaseAmountOneDayByConversionRoi   float64 `json:"event_pay_purchase_amount_one_day_by_conversion_roi"`   //激活后24h-ROI(激活时间)
	EventPayPurchaseAmountThreeDayByConversionRoi float64 `json:"event_pay_purchase_amount_three_day_by_conversion_roi"` //激活后3日ROI
	EventPayPurchaseAmountWeekByConversionRoi     float64 `json:"event_pay_purchase_amount_week_by_conversion_roi"`      //激活后7日ROI
	PhotoClickCost                                float64 `json:"photo_click_cost"`                                      //平均封面点击单价（元）
	Impression1kCost                              float64 `json:"impression1k_cost"`                                     //平均千次封面曝光花费（元）
	Click1kCost                                   float64 `json:"click1k_cost"`                                          //平均千次素材曝光花费（元）
	ActionCost                                    float64 `json:"action_cost"`                                           //平均行为单价（元）
	DeepConversionCostByImpression7d              float64 `json:"deep_conversion_cost_by_impression7d"`                  //深度转化成本(计费时间)，单位元
	DeepConversionRatioByImpression7d             float64 `json:"deep_conversion_ratio_by_impression7d"`                 //深度转化率(计费时间)
	EventPayFirstDayCost                          float64 `json:"event_pay_first_day_cost"`                              //首日付费次数成本，单位元
	ActionRatio                                   float64 `json:"action_ratio"`                                          //素材点击率
	PlayEndRatio                                  float64 `json:"play_end_ratio"`                                        //完播率
	EventNewUserPayCost                           float64 `json:"event_new_user_pay_cost"`                               //新增付费人数成本，单位元
	EventNewUserPayRatio                          float64 `json:"event_new_user_pay_ratio"`                              //新增付费人数率
	ActionNewRatio                                float64 `json:"action_new_ratio"`                                      //行为率
	ConversionCostByImpression7d                  float64 `json:"conversion_cost_by_impression7d"`                       //转化成本(计费时间)，单位元
	ConversionRatioByImpression7d                 float64 `json:"conversion_ratio_by_impression7d"`                      //转化率(计费时间)
	KeyAction                                     int64   `json:"key_action"`                                            //关键行为数
	AdPhotoPlayed75percentRatio                   float64 `json:"ad_photo_played75percent_ratio"`                        //75%进度播放数
	MiniGameIaaRoi                                float64 `json:"mini_game_iaa_roi"`                                     //IAA广告变现ROI
	MiniGameIaaPurchaseAmount                     float64 `json:"mini_game_iaa_purchase_amount"`                         //IAA广告变现LTV（元）
}

func AllAdData(req ReportCommonReq, url string) ([]AdData, error) {
	page := int64(1)
	pageSizeMax := int64(100)
	var res []AdData
	for {
		response, err := QueryReportAdData(ReportCommonReq{
			AdvertiserId: req.AdvertiserId,
			PageNo:       page,
			PageSize:     pageSizeMax,
			StartTime:    req.StartTime,
			EndTime:      req.EndTime,
			SeriesType:   req.SeriesType,
		}, req.AccessToken, url)
		if err != nil {
			return res, err
		}
		var resp AdDataResp
		err = json.Unmarshal([]byte(response), &resp)
		if err != nil {
			return res, err
		}
		if resp.Code != http.StatusOK {
			return res, nil
		}

		res = append(res, resp.Data.DataList...)

		if resp.Data.TotalCount < pageSizeMax {
			break
		}

		page++
	}

	return res, nil
}

func QueryReportAdData(req ReportCommonReq, accessToken, url string) (resp string, err error) {
	header := getHeader(accessToken)
	resp, err = PostJson(url, req, 20, header)
	if err != nil {
		return
	}
	return
}

/***********************************短剧广告报表明细查询接口 ***********************************/

type AdDataDetailResp struct {
	CommonResp
	Data DateDetail `json:"data"`
}

type DateDetail struct {
	TotalCount int64      `json:"total_count"`
	DataList   []AdDetail `json:"data_list"`
}

type AdDetail struct {
	AdData
	Ext
}
type Ext struct {
	AccountId    int64   `json:"account_id"`    // 账号ID
	SeriesId     int64   `json:"series_id"`     // 短剧ID
	RechargeRate float64 `json:"recharge_rate"` // 充值几率
}

func AllAdDetail(req ReportCommonReq, url string) ([]AdDetail, error) {
	page := int64(1)
	pageSizeMax := int64(100)
	var res []AdDetail
	for {
		response, err := QueryReportAdData(ReportCommonReq{
			AdvertiserId:   req.AdvertiserId,
			PageNo:         page,
			PageSize:       pageSizeMax,
			StartTime:      req.StartTime,
			EndTime:        req.EndTime,
			SeriesType:     req.SeriesType,
			ExtraDimension: []string{"seriesId", "accountId"},
		}, req.AccessToken, url)
		if err != nil {
			return res, err
		}
		var resp AdDataDetailResp
		err = json.Unmarshal([]byte(response), &resp)
		if err != nil {
			return res, err
		}
		if resp.Code != http.StatusOK {
			return res, nil
		}

		res = append(res, resp.Data.DataList...)

		if resp.Data.TotalCount < pageSizeMax {
			break
		}

		page++
	}

	return res, nil
}

/*********************************** 短剧核心总览数据报表 ***********************************/

type CoreDataResp struct {
	CommonResp
	Data DateCore `json:"data"`
}

type DateCore struct {
	TotalCount int64      `json:"total_count"`
	DataList   []CoreData `json:"data_list"`
}

type CoreData struct {
	Date                            string  `json:"date"`                                 // 日期（yyyy-MM-dd hh:mm:ss）
	TotalCharge                     float64 `json:"total_charge"`                         // 消耗
	AccuFansUserNum                 int64   `json:"accu_fans_user_num"`                   // 粉丝峰值量
	FansUserNum                     int64   `json:"fans_user_num"`                        // 粉丝净增量
	EventPayRoi                     float64 `json:"event_pay_roi"`                        // 商业化ROI
	EventPayRoiAll                  float64 `json:"event_pay_roi_all"`                    // 全域ROI
	PayUserCount                    int64   `json:"pay_user_count"`                       // 付费人数
	PayCount                        int64   `json:"pay_count"`                            // 付费订单数
	PayAmt                          float64 `json:"pay_amt"`                              // 付费金额
	IsFansUser                      bool    `json:"is_fans_user"`                         // 是否粉丝
	DisplayPlayCnt                  int64   `json:"display_play_cnt"`                     // 播放数
	DisplayLikeCnt                  int64   `json:"display_like_cnt"`                     // 点赞数
	DisplayCommentCnt               int64   `json:"display_comment_cnt"`                  // 评论数
	DisplayCollectCnt               int64   `json:"display_collect_cnt"`                  // 收藏数
	MiniGameIaaRoi                  float64 `json:"mini_game_iaa_roi"`                    // IAA广告变现ROI（含返货）
	MiniGameIaaPurchaseAmount       float64 `json:"mini_game_iaa_purchase_amount"`        // IAA广告变现LTV（含返货，元）
	MiniGameIaaPurchaseAmountDivide float64 `json:"mini_game_iaa_purchase_amount_divide"` // IAA广告变现LTV（不含返货，元）
	MiniGameIaaDividedRoi           float64 `json:"mini_game_iaa_divided_roi"`            // IAA广告变现ROI（不含返货）
}

func AllCoreData(req CoreDataReq, url string) ([]CoreData, error) {
	page := int64(1)
	pageSizeMax := int64(100)
	var res []CoreData
	for {
		response, err := QueryReportCoreData(CoreDataReq{
			AdvertiserId: req.AdvertiserId,
			PageNo:       page,
			PageSize:     pageSizeMax,
			StartTime:    req.StartTime,
			EndTime:      req.EndTime,
			SeriesType:   req.SeriesType,
			Source:       req.Source,
		}, req.AccessToken, url)
		if err != nil {
			return res, err
		}
		var resp CoreDataResp
		err = json.Unmarshal([]byte(response), &resp)
		if err != nil {
			return res, err
		}
		if resp.Code != http.StatusOK {
			return res, nil
		}

		res = append(res, resp.Data.DataList...)

		if resp.Data.TotalCount < pageSizeMax {
			break
		}

		page++
	}

	return res, nil
}

func QueryReportCoreData(req CoreDataReq, accessToken, url string) (resp string, err error) {
	header := getHeader(accessToken)
	resp, err = PostJson(url, req, 20, header)
	if err != nil {
		return
	}
	return
}

/*********************************** 短剧查询账户信息接口 ***********************************/

type AccountInfoReq struct {
	AdvertiserId int64 `json:"advertiser_id"`
}

type AccountInfoResp struct {
	CommonResp
	Data AccountData `json:"data"`
}
type AccountData struct {
	AccountList []AccountInfo `json:"account_list"`
}

type AccountInfo struct {
	AccountId   string `json:"account_id"`   // 账户id
	AccountName string `json:"account_name"` // 账户名称
}

func QueryAccountData(req AccountInfoReq, accessToken, urls string) ([]AccountInfo, error) {
	header := getHeader(accessToken)
	var res []AccountInfo
	param := url.Values{}
	param.Add("advertiser_id", strconv.Itoa(int(req.AdvertiserId)))
	response, err := Get(urls+"?"+param.Encode(), 20, header)
	if err != nil {
		return res, err
	}
	var resp AccountInfoResp
	err = json.Unmarshal([]byte(response), &resp)
	if err != nil {
		return res, err
	}
	if resp.Code != 0 {
		return res, nil
	}
	res = append(res, resp.Data.AccountList...)
	return res, nil
}

/*********************************** 短剧查询账户信息接口 ***********************************/

type SeriesInfoResp struct {
	CommonResp
	Data []SeriesInfo `json:"data"`
}

type SeriesInfo struct {
	SeriesId    int64  `json:"series_id"`    // 短剧id
	SeriesName  string `json:"series_name"`  // 短剧名称
	AuditStatus int    `json:"audit_status"` // 审核状态
	SellStatus  int    `json:"sell_status"`  // 售卖状态
}

func QuerySeriesInfo(req AccountInfoReq, accessToken, url string) ([]SeriesInfo, error) {
	header := getHeader(accessToken)
	var res []SeriesInfo
	response, err := PostJson(url, req, 20, header)
	if err != nil {
		return res, err
	}
	var resp SeriesInfoResp
	err = json.Unmarshal([]byte(response), &resp)
	if err != nil {
		return res, err
	}
	if resp.Code != 0 {
		return res, nil
	}
	res = append(res, resp.Data...)
	return res, nil
}

func getHeader(accessToken string) map[string]string {
	header := make(map[string]string)
	// 获取 accessToken
	header["Access-Token"] = accessToken
	header["Content-Type"] = "application/json"
	return header
}

type CommonResp struct {
	Code    int    `json:"code"`    // 响应code，0代表成功
	Message string `json:"message"` // 提示信息
}

// tcp创建超时时长
var (
	connTimeOut time.Duration = 1
	deadTimeOut time.Duration = 10
)

func PostJson(post_url string, postData interface{}, timeout time.Duration, HC ...map[string]string) (string, error) {

	var buf bytes.Buffer
	var method string = "POSTJSON"
	encoder := json.NewEncoder(&buf)
	encoder.Encode(postData)
	var jsonBody = buf.String()
	return httpClient(method, post_url, jsonBody, timeout, HC...)
}

// 发送http请求，method请求方法
// HC=header and Cookie
func httpClient(method, urlHost string, paramStr string, timeout time.Duration, HC ...map[string]string) (string, error) {

	if timeout == 0 {
		timeout = deadTimeOut
	}
	tr := &http.Transport{
		//跳过证书校验https
		TLSClientConfig: &tls.Config{InsecureSkipVerify: true},
		Dial: func(netw, addr string) (net.Conn, error) {
			c, err := net.DialTimeout(netw, addr, connTimeOut*time.Second)
			if err != nil {
				return nil, err
			}
			c.SetDeadline(time.Now().Add(timeout * time.Second))
			return c, nil
		},
		ResponseHeaderTimeout: timeout * time.Second,
	}
	client := &http.Client{
		//Client会在试图用Head、Get、Post或Do方法执行请求时返回错误
		Timeout:   timeout * time.Second,
		Transport: tr,
	}
	var respBodyStr string
	var request *http.Request
	var resp *http.Response
	var err error
	method = strings.ToUpper(method)
	switch method {

	case "GET":
		request, err = http.NewRequest("GET", urlHost, strings.NewReader(paramStr))

	case "POSTQUERY":
		request, err = http.NewRequest("POST", urlHost, strings.NewReader(paramStr))

	case "POSTJSON":
		request, err = http.NewRequest("POST", urlHost, strings.NewReader(paramStr))

	case "PUT":
		request, err = http.NewRequest("PUT", urlHost, strings.NewReader(paramStr))

	}
	for i := 0; i < 1; i++ {
		if err != nil || request == nil {
			break
		}

		if method == "POSTJSON" {
			request.Header.Set("Content-Type", "application/json;charset=UTF-8")
		} else {
			request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
		}

		request.Header.Add("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:71.0) Gecko/20100101 Firefox/71.0")
		//HC:0:header
		if len(HC) > 0 {
			myHeader := HC[0]
			for hk, hv := range myHeader {
				request.Header.Add(hk, hv)
			}
		}
		resp, err = client.Do(request)
		if err != nil {
			break
		}

		var byteStr []byte
		byteStr, _ = ioutil.ReadAll(resp.Body)
		defer resp.Body.Close()

		//不管是http_status是否是200，仍然使用到返回结果
		//例如mediva、api.crm等
		respBodyStr = string(byteStr)

		//附带响应状态错误信息
		if resp.StatusCode != http.StatusOK {
			//例如504,err默认nil值，需重新改
			err = errors.New("http status:" + strconv.Itoa(resp.StatusCode) + ",response content is:" + respBodyStr)
			break
		}
	}

	return respBodyStr, err
}

func Get(get_url string, timeout time.Duration, HC ...map[string]string) (string, error) {
	var method string = "GET"
	return httpClient(method, get_url, "", timeout, HC...)
}
