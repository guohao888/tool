package common

import (
	"github.com/spf13/viper"
)

func SendTuituiTextMsg(content, groupNum string, at ...string) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := NewClient(appID, secret, host)
	text := &Text{
		Content: content,
	}
	msg := &GroupMessage{
		Togroups: []string{groupNum},
		Msgtype:  "text",
		Text:     text,
		At:       at,
	}
	resp, err := client.SendGroupMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}
