package fanqie

//import (
//	"github.com/gin-gonic/gin"
//	fanqie2 "goserver/app/common/dto/fanqie"
//	gl "goserver/app/library/list"
//	"goserver/app/library/myerror"
//	"goserver/app/library/utils/response"
//	timeUtil "goserver/app/library/utils/time"
//	"goserver/app/model/service/fanqie"
//	"strconv"
//)
//
//// TomatoIAPUserData 番茄IAP用户买入推送接口
//func TomatoIAPUserData(c *gin.Context) {
//	r := response.Gin{Ctx: c}
//	// 解析参数
//	req := fanqie2.NewIAPUserDataReq(c)
//	glpu := gl.GetGlpuList()
//	// todo 过滤其他包数据
//	glpu.Add(req)
//	list, length := glpu.Get()
//	buyTime, _ := strconv.Atoi(list[0].BuyingTimestamp)
//	if length >= 300 || timeUtil.BeforeFiveUnixTime() > int64(buyTime) {
//		// 保存数据
//		tomatoIAAUserService := fanqie.NewTomatoIAPUserService(c)
//		_ = tomatoIAAUserService.SaveIAPUserInfos(list)
//		glpu.Remove(length)
//	}
//	r.Response(200, myerror.OK.Message, "")
//}
