package roi

import (
	"goserver/app/common/repository"
	"time"
)

const ProjectMergeTimeDataTable = "project_merge_exec_time"

// ProjectMergeExecTime 定义 merge_exec_time 表的结构体
type ProjectMergeExecTime struct {
	ExecTime time.Time `gorm:"column:exec_time;type:datetime;not null;default:CURRENT_TIMESTAMP" json:"exec_time"`
}

func (*ProjectMergeExecTime) TableName() string {
	return ReportDataTableName()
}

func ProjectMergeTimeDataTableName() string {
	if repository.IsDebugTable(ProjectMergeTimeDataTable) {
		return ProjectMergeTimeDataTable
	} else {
		return ProjectMergeTimeDataTable
	}
}
