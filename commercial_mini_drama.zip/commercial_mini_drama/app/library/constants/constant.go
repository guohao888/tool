package constants

const FILTER_ALL = "全部"
