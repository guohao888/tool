package warning

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common/dto/warningdto"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/warning"
)

func SaveOrUpdateWarning(c *gin.Context) {
	r := response.Gin{Ctx: c}

	warningService := warning.NewMsgWarningService(c)
	taskInfo := warningdto.NewTaskInfosReq(c)
	err := warningService.SaveOrUpdateWarningInfo(taskInfo)
	if err != nil { //保存数据失败
		r.Response(myerror.SaveWarningError.Code, myerror.SaveWarningError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

func FindWarningList(c *gin.Context) {
	r := response.Gin{Ctx: c}

	warningService := warning.NewMsgWarningService(c)
	params := warningdto.NewSearchFilterReq(c)
	list, err := warningService.GetWarningList(params)
	if err != nil {
		r.Response(myerror.FindWarningError.Code, myerror.FindWarningError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, list)
}

func GetSearchOption(c *gin.Context) {
	r := response.Gin{Ctx: c}
	param := warningdto.NewSearchOptionReq(c)
	warningService := warning.NewMsgWarningService(c)
	list, err := warningService.GetOptionSearch(param.SearchType, param.Val)
	if err != nil {
		r.Response(myerror.AddOptionsListError.Code, myerror.AddOptionsListError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, list)
}
