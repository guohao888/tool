package accounts

import (
	"goserver/app/common/repository"
	"strconv"
	"time"
)

const OauthConfigTable = "oauth_config"

type OauthConfigEntity struct {
	Media     string    `gorm:"column:media" json:"media"`
	AppID     string    `gorm:"column:app_id" json:"app_id"`
	AuthType  string    `gorm:"column:auth_type" json:"auth_type"`
	AppSecret string    `gorm:"column:app_secret" json:"app_secret"`
	CreatedAt time.Time `gorm:"column:created_at" json:"created_at"`
	UpdatedAt time.Time `gorm:"column:updated_at" json:"updated_at"`
}

func (*OauthConfigEntity) TableName() string {
	return OauthConfigTableName()
}

func OauthConfigTableName() string {
	if repository.IsDebugTable(OauthConfigTable) {
		return OauthConfigTable + "_dev"
	} else {
		return OauthConfigTable
	}
}

func (e *OauthConfigEntity) GetAppId() (int64, error) {
	appId, err := strconv.ParseInt(e.AppID, 10, 64)
	return appId, err
}

func IsValidAuthType(authType string) bool {
	if authType != repository.AuthTypeZhangGuan && authType != repository.AuthTypeXieGuan {
		return false
	}
	return true
}
