package kuaishou

import (
	"context"
	"goserver/app/common/repository/kuaishou"
	"goserver/app/library/driver/dorisdb"
	"time"
)

type PullTimeDao struct {
	Ctx context.Context
}

func NewPullTimeDao(ctx context.Context) *PullTimeDao {
	return &PullTimeDao{Ctx: ctx}
}

func (p *PullTimeDao) GetMaxPullTime(pullType int64) (*time.Time, error) {
	var result struct {
		MaxTime time.Time `gorm:"column:max_pull_time"`
	}
	db := dorisdb.DorisClient()
	err := db.Table(kuaishou.PullTimeInfoTableName()).
		Select("max(pull_time) as max_pull_time").
		Where("pull_type = ?", pullType).
		Scan(&result).Error

	return &result.MaxTime, err
}
