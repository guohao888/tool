package roi

import (
	"goserver/app/common/repository"
	"time"
)

const SpiDataTable = "roi_spi_task"
const MaterialModificationLogTable = "material_modification_log"
const SPIMaterialModificationLogTable = "spi_material_modification_log"

type SpiRequestsDataEntity struct {
	TaskID          int64  `gorm:"column:task_id;type:bigint(20)" json:"task_id"`
	MessageID       string `gorm:"column:message_id;type:varchar(255);not null" json:"message_id"`
	SubscribeTaskID int64  `gorm:"column:subscribe_task_id;type:bigint(20)" json:"subscribe_task_id"`
	AdvertiserIDs   string `gorm:"column:advertiser_ids;type:string" json:"advertiser_ids"`
	AccountRelation string `gorm:"column:account_relation;type:string" json:"account_relation"`
	ServiceLabel    string `gorm:"column:service_label;type:varchar(100)" json:"service_label"`
	PublishTime     int64  `gorm:"column:publish_time;type:bigint(20)" json:"publish_time"`
	Timestamp       int64  `gorm:"column:timestamp;type:bigint(20)" json:"timestamp"`
	Nonce           int64  `gorm:"column:nonce;type:bigint(20)" json:"nonce"`
	Data            string `gorm:"column:data;type:string" json:"data"`
	IsUpdated       int8   `gorm:"column:is_updated;type:tinyint(4);default:0" json:"is_updated"`
	//CreatedAt       time.Time `gorm:"column:created_at;type:datetime;default:CURRENT_TIMESTAMP" json:"created_at"`
	//UpdatedAt       time.Time `gorm:"column:updated_at;type:datetime;default:CURRENT_TIMESTAMP" json:"updated_at"`
}

func (*SpiRequestsDataEntity) TableName() string {
	return SpiRequestsDataTableName()
}

func SpiRequestsDataTableName() string {
	if repository.IsDebugTable(SpiDataTable) {
		return SpiDataTable
	} else {
		return SpiDataTable
	}
}

// MaterialModificationLog 定义与数据库表对应的结构体
type MaterialModificationLog struct {
	TaskID          int64 `gorm:"column:task_id"`
	MaterialID      int64 `gorm:"column:material_id"`
	SubscribeTaskID int64 `gorm:"column:subscribe_task_id"`
	AdvertiserID    int64 `gorm:"column:advertiser_id"`
	CoreUserID      int64 `gorm:"column:core_user_id"`
	PublishTime     int64 `gorm:"column:publish_time"`
	Timestamp       int64 `gorm:"column:timestamp"`
}

func (*SpiRequestsDataEntity) LogTableName() string {
	return MaterialModificationLogTableNAME()
}

func MaterialModificationLogTableNAME() string {
	if repository.IsDebugTable(MaterialModificationLogTable) {
		return MaterialModificationLogTable
	} else {
		return MaterialModificationLogTable
	}
}

type SPIMaterialModificationLog struct {
	MessageID       string    `gorm:"column:message_id;type:varchar(255);not null" json:"message_id"`
	AdvertiserID    int64     `gorm:"column:advertiser_id;type:bigint(20);not null" json:"advertiser_id"`
	MaterialID      int64     `gorm:"column:material_id;type:bigint(20);not null" json:"material_id"`
	ServiceLabel    string    `gorm:"column:service_label;type:varchar(100);not null" json:"service_label"`
	SubscribeTaskID int64     `gorm:"column:subscribe_task_id;type:bigint(20);" json:"subscribe_task_id"`
	CoreUserID      int64     `gorm:"column:core_user_id;type:bigint(20);" json:"core_user_id"`
	AppID           int64     `gorm:"column:app_id;type:bigint(20);" json:"app_id"`
	PublishTime     int64     `gorm:"column:publish_time;type:bigint(20);" json:"publish_time"`
	Timestamp       int64     `gorm:"column:timestamp;type:bigint(20);" json:"timestamp"`
	Nonce           int64     `gorm:"column:nonce;type:bigint(20);" json:"nonce"`
	CreatedAt       time.Time `gorm:"column:created_at;type:datetime;not null;default:CURRENT_TIMESTAMP" json:"created_at"`
	UpdatedAt       time.Time `gorm:"column:updated_at;type:datetime;not null;default:CURRENT_TIMESTAMP" json:"updated_at"`
}

func (*SpiRequestsDataEntity) SPIMaterialModificationLogTableName() string {
	return SPIMaterialModificationLogTableName()
}
func SPIMaterialModificationLogTableName() string {
	if repository.IsDebugTable(SPIMaterialModificationLogTable) {
		return SPIMaterialModificationLogTable
	} else {
		return SPIMaterialModificationLogTable
	}
}
