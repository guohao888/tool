package fanqie

//import (
//	"context"
//	"github.com/gin-gonic/gin"
//	dto "goserver/app/common/dto/fanqie"
//	"goserver/app/model/dao/fanqie"
//)
//
//// TomatoIAPUserService 番茄IAP用户Service
//type TomatoIAPUserService struct {
//	Ctx context.Context
//}
//
//// NewTomatoIAPUserService 创建上下文IAP用户Service
//func NewTomatoIAPUserService(ctx *gin.Context) *TomatoIAPUserService {
//	return &TomatoIAPUserService{Ctx: ctx}
//}
//
//// SaveIAPUserInfos 保存IAP用户数据
//func (t *TomatoIAPUserService) SaveIAPUserInfos(req []*dto.TomatoIAPUserReq) error {
//	tomatoIAPIUserDao := fanqie.NewTomatoIAPUserDao(t.Ctx)
//	err := tomatoIAPIUserDao.Req2Entity(req)
//	return err
//}
