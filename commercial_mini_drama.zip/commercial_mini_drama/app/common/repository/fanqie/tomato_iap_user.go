package fanqie

//import (
//	"goserver/app/common/repository"
//	"time"
//)
//
//const IAPUserEntityTable = "tomato_iap_user"
//
//// IAPUserEntity 番茄IAP用户数据
//type IAPUserEntity struct {
//	DeviceId        string    `gorm:"column:device_id"`        // 用户设备id
//	BuyingTimestamp string    `gorm:"column:buying_timestamp"` // 用户点击推广链时间戳（非染色时间）
//	BuyingDate      time.Time `gorm:"column:buying_date"`      // 用户点击推广链时间 yyyy-mm-dd hh-mm-ss',
//	BuyingHour      string    `gorm:"column:buying_hour"`      // 用户点击推广链小时
//	DistributorId   string    `gorm:"column:distributor_id"`   // 快应用/公众号对应distributor_id
//	AppId           string    `gorm:"column:app_id"`           // 公众号/快应用/小程序id（分销平台id）【v1.2】
//	AppName         string    `gorm:"column:app_name"`         // 快应用/公众号/小程序名称【v1.2】
//	OpenId          string    `gorm:"column:open_id"`          // 用户openid（H5书城、微信小程序、抖音小程序）
//	PromotionId     string    `gorm:"column:promotion_id"`     // 推广链id
//	ClickId         string    `gorm:"column:click_id"`         // 巨量广告下发的唯一标识
//	Ip              string    `gorm:"column:ip"`               // IP
//	UserAgent       string    `gorm:"column:user_agent"`       // 用户点击推广链时的UA
//	Attributed      string    `gorm:"column:attributed"`       // 用户是否成功染色
//	BookId          string    `gorm:"column:book_id"`          // 染色推广链的书籍ID【v1.2】
//	BookName        string    `gorm:"column:book_name"`        // 染色推广链的书籍名称【v1.2】
//	BookGender      string    `gorm:"column:book_gender"`      // 染色推广链书籍性别(0女生、1男生、2无性别)【v1.2】
//	BookCategory    string    `gorm:"column:book_category"`    // 染色推广链的书籍类型【v1.2】
//	ActionId        string    `gorm:"column:action_id"`        // 用户点击推广链的唯一标识，平台为了尽可能通知到分销商会有重试策略，分销商可以以此进行去重【v1.4.1】
//	ProjectId       string    `gorm:"column:project_id"`       // 巨量2.0广告计划组ID（快应用、小程序均支持)
//	AdIdV2          string    `gorm:"column:ad_id_v2"`         // 巨量2.0广告计划ID（promotion_id）（快应用、小程序均支持)
//	Mid             string    `gorm:"column:mid"`              // 素材id（分别代表图片、标题、视频、试玩、落地页
//	ClueToken       string    `gorm:"column:clue_token"`       // 巨量小程序广告参数
//	MidId           string    `gorm:"column:mid_id"`           // 素材id
//}
//
//func (*IAPUserEntity) TableName() string {
//	return IAPUserEntityTable
//}
//
//func IAPUserTableName() string {
//	if repository.IsDebugTable(IAPUserEntityTable) {
//		return IAPUserEntityTable + "_dev"
//	} else {
//		return IAPUserEntityTable
//	}
//}
