package log

import (
	"fmt"
	"github.com/natefinch/lumberjack"
	"github.com/rifflock/lfshook"
	"github.com/sirupsen/logrus"
	"github.com/spf13/viper"
	"goserver/app/library/log/format"
	"path"
	"runtime/debug"
)

type mysqlLogTrace struct {
}

var LogrusLog *logrus.Logger
var MysqlLog *mysqlLogTrace

// 普通日志记录
func InitLogrusLog() {
	basePath := viper.GetString("log.basedir")
	level := viper.GetString("log.level")
	project := viper.GetString("name")

	LogrusLog = logrus.New()
	MysqlLog = &mysqlLogTrace{}
	switch level {
	case "debug":
		LogrusLog.SetLevel(logrus.DebugLevel)
	case "info":
		LogrusLog.SetLevel(logrus.InfoLevel)
	case "warn":
		LogrusLog.SetLevel(logrus.WarnLevel)
	case "error":
		LogrusLog.SetLevel(logrus.ErrorLevel)
	default:
		LogrusLog.SetLevel(logrus.InfoLevel)
	}

	lumberjackLog := path.Join(basePath, project)
	LogrusLog.SetOutput(&lumberjack.Logger{
		Filename:   fmt.Sprintf("%s.log", lumberjackLog), // 日志文件路径
		MaxSize:    viper.GetInt("log.max_size"),         // 每个日志文件保存的最大尺寸 单位：M
		MaxBackups: viper.GetInt("log.max_backups"),      // 日志文件最多保存多少个备份
		MaxAge:     viper.GetInt("log.max_age"),          // 文件最多保存多少天
		Compress:   true,                                 // 是否压缩
	})

	//日志按时间切分
	filename := path.Join(basePath, "debug")
	debugWriter, _ := getLogWriter(filename)

	filename = path.Join(basePath, "info")
	infoWriter, _ := getLogWriter(filename)

	filename = path.Join(basePath, "error")
	errorWriter, _ := getLogWriter(filename)

	writeMap := lfshook.WriterMap{
		logrus.InfoLevel:  infoWriter,
		logrus.FatalLevel: errorWriter,
		logrus.DebugLevel: debugWriter,
		logrus.WarnLevel:  debugWriter,
		logrus.ErrorLevel: errorWriter,
		logrus.PanicLevel: errorWriter,
	}

	lfHook := lfshook.NewHook(writeMap, &logrus.JSONFormatter{
		TimestampFormat: "2006-01-02 15:04:05",
	})

	// 新增 Hook
	LogrusLog.AddHook(lfHook)
}

func Debug(args ...interface{}) {
	LogrusLog.Debug(args...)
}

func Debugf(format string, args ...interface{}) {
	LogrusLog.Debugf(format, args...)
}

func Info(args ...interface{}) {
	LogrusLog.Info(args...)
}

func Infof(format string, args ...interface{}) {
	LogrusLog.Infof(format, args...)
}

func Warning(args ...interface{}) {
	LogrusLog.Warning(args...)
}

func Warningf(format string, args ...interface{}) {
	LogrusLog.Warningf(format, args...)
}

func Error(args ...interface{}) {
	LogrusLog.WithFields(logrus.Fields{"stack": string(debug.Stack())}).Error(args...)
}

func Errorf(format string, args ...interface{}) {
	LogrusLog.WithFields(logrus.Fields{"stack": string(debug.Stack())}).Errorf(format, args...)
}

func Fatal(args ...interface{}) {
	LogrusLog.Fatal(args...)
}

func Fatalf(format string, args ...interface{}) {
	LogrusLog.Fatalf(format, args...)
}

func (m *mysqlLogTrace) printf(format string, args ...interface{}) {
	Debugf(format, args...)
}

func (m *mysqlLogTrace) Print(args ...interface{}) {
	Debug(format.LogFormatter(args...)...)
}
