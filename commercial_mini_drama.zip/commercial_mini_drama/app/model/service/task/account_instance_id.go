package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	"goserver/app/library/log"
	"goserver/app/model/service/accounts"
)

func AccountInstanceIdSyncToutiao(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := accountdto.AccountInstanceIdSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			panic(fmt.Errorf("参数解析错误, err: %w", err))
		}
	}

	params.Media = repository.MediaToutiao
	if params.PoolWorkers <= 0 {
		params.PoolWorkers = 5
	}
	if params.InsertBatchSize <= 0 {
		params.InsertBatchSize = 200
	}

	accountInstanceIdService := accounts.NewAccountInstanceIdService(ctx)
	err := accountInstanceIdService.SyncToutiao(params)
	if err != nil {
		log.Errorf("同步头条广告主字节小程序资产id失败, err: %s", err)
		panic(fmt.Errorf("同步头条广告主字节小程序资产id失败, err: %w", err))
	}
	return "同步头条广告主字节小程序资产id成功"
}
