package promotion

import (
	"goserver/app/common/repository"
	"time"
)

const InfoPromotionEntityTable = "promotion_url_info"

type InfoPromotionEntity struct {
	AdvertiserId        string    `gorm:"column:advertiser_id"`         // 账号ID
	ProjectId           string    `gorm:"column:project_id"`            // 项目ID
	PromotionId         string    `gorm:"column:promotion_id"`          // 广告ID
	PromotionModifyDate time.Time `gorm:"column:promotion_modify_date"` // 组合主键
	PromotionCreateTime string    `gorm:"column:promotion_create_time"` // 广告创建时间，格式yyyy-MM-dd HH:mm:ss
	PromotionModifyTime string    `gorm:"column:promotion_modify_time"` // 广告更新时间，格式yyyy-MM-dd HH:mm:ss
	AppId               string    `gorm:"column:app_id"`                // 小程序/小游戏id
	StartPath           string    `gorm:"column:start_path"`            // 启动路径
	Params              string    `gorm:"column:params"`                // 页面监测参数
	Url                 string    `gorm:"column:url"`                   // 字节小程序调起链接
	Code                string    `gorm:"column:code"`                  // 截取code 字符串
	ScheduleTime        string    `gorm:"column:schedule_time"`         // 广告的投放时段
	StatusFirst         string    `gorm:"column:status_first"`          // PROMOTION_STATUS_ENABLE投放中 PROMOTION_STATUS_DISABLE未投放 PROMOTION_STATUS_FROZEN已终止 PROMOTION_STATUS_DONE已完成 PROMOTION_STATUS_DELETED已删除
	PlayletSeriesUrl    string    `gorm:"column:playlet_series_url"`    // 短剧合集链接url
	HashRes             string    `gorm:"column:hash_res"`              // hash_res 值
}

func (InfoPromotionEntity) TableName() string {
	return InfoPromotionEntityTable
}

func InfoPromotionEntityTableName() string {
	if repository.IsDebugTable(InfoPromotionEntityTable) {
		return InfoPromotionEntityTable + "_dev"
	} else {
		return InfoPromotionEntityTable
	}
}
