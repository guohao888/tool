package accounts

import (
	"goserver/app/common/repository"
	"time"
)

const AccountPromotionUrlTable = "account_promotion_url"

const (
	AppTypeWechatApplet = "app_type_wechat_applet"  // 微信小程序
	AppTypeByteMicroApp = "app_type_byte_micro_app" // 字节小程序
)

var AppTypes = []string{AppTypeWechatApplet, AppTypeByteMicroApp}

var AppTypeDesc = map[string]string{
	AppTypeWechatApplet: "微",
	AppTypeByteMicroApp: "抖",
}

const (
	SearchTypeCreateOnly = "CREATE_ONLY" // 只查询该账户创建的应用（默认值）
	SearchTypeShareOnly  = "SHARE_ONLY"  // 只查询被共享的应用
)

const (
	PriorityHigh    = "h" // 高
	PriorityLow     = "l" // 低
	PriorityDefault = ""  // 低
)

// SearchTypes 小程序搜索类型
var SearchTypes = []string{
	SearchTypeCreateOnly,
	SearchTypeShareOnly,
}

// Priorities 优先级
var Priorities = []string{
	PriorityHigh,
	PriorityLow,
	//PriorityDefault,
}

type AccountPromotionUrlEntity struct {
	Media          string    `gorm:"column:media"`           // 媒体
	AdvertiserId   string    `gorm:"column:advertiser_id"`   // 广告主id
	AdvertiserName string    `gorm:"column:advertiser_name"` // 广告主名称
	PromotionUrl   string    `gorm:"column:promotion_url"`   // 推广链地址
	OauthId        string    `gorm:"column:oauth_id"`        // oauth授权id
	Name           string    `gorm:"column:name"`            // 小程序名称
	InstanceId     int64     `gorm:"column:instance_id"`     // 小程序资产ID
	AppType        string    `gorm:"column:app_type"`        // 小程序类型
	SearchType     string    `gorm:"column:search_type"`     // 搜索类型 CREATE_ONLY:只查询该账户创建的应用（默认值）, SHARE_ONLY:只查询被共享的应用
	Ext            string    `gorm:"column:ext"`             // 扩展数据
	CreateTime     string    `gorm:"column:create_time"`     // 小程序数据创建时间, 2024-11-15 14:35:09
	ModifyTime     string    `gorm:"column:modify_time"`     // 小程序更新时间, 2024-11-15 14:35:09
	CreatedAt      time.Time `gorm:"column:created_at"`      // 创建时间(数据)
	UpdatedAt      time.Time `gorm:"column:updated_at"`      // 更新时间(数据库)
}

func (*AccountPromotionUrlEntity) TableName() string {
	return AccountPromotionUrlTableName()
}

func AccountPromotionUrlTableName() string {
	if repository.IsDebugTable(AccountPromotionUrlTable) {
		return AccountPromotionUrlTable + "_dev"
	} else {
		return AccountPromotionUrlTable
	}
}
