package warning

import (
	"github.com/shopspring/decimal"
	"goserver/app/common/repository"
	"time"
)

const TaskWarningEntityTable = "warning_task"

type TaskWarningEntity struct {
	ForeignKey  string          `gorm:"column:foreign_key"`  // 外键
	CreatedTime time.Time       `gorm:"column:created_time"` // 创建时间
	TaskName    string          `gorm:"column:task_name"`    // 告警任务名称
	Media       string          `gorm:"column:media"`        // 媒体
	CreateBy    string          `gorm:"column:create_by"`    // 创建人
	WarningTag  string          `gorm:"column:warning_tag"`  // 告警标签
	Dimension   string          `gorm:"column:dimension"`    // 告警维度
	Metrics     string          `gorm:"column:metrics"`      // 指标
	Interval    int             `gorm:"column:interval"`     // 时间间隔
	Condition   string          `gorm:"column:condition"`    // 条件
	Numerical   decimal.Decimal `gorm:"column:numerical"`    // 数值
	State       int             `gorm:"column:state"`        // 任务状态
	MsgTo       string          `gorm:"column:msg_to"`       // 告警人
}

func (*TaskWarningEntity) TableName() string {
	return TaskWarningEntityTable
}

func TaskWarningTableName() string {
	if repository.IsDebugTable(TaskWarningEntityTable) {
		return TaskWarningEntityTable + "_dev"
	} else {
		return TaskWarningEntityTable
	}
}

type Album struct {
	AlbumId   string  `gorm:"column:album_id"`
	AlbumName string  `gorm:"column:album_name"`
	MediaCost float64 `gorm:"column:media_cost"`
	HourCost  float64 `gorm:"column:hour_cost"`
	ROI       float64 `gorm:"column:roi"`
}

type AlbumImage struct {
	Hour     string  `gorm:"column:hour"`
	BookName string  `gorm:"column:book_name"`
	BookId   string  `gorm:"column:book_id"`
	Speed    float64 `gorm:"column:speed"`
	Cost     float64 `gorm:"column:cost"`
	Roi      float64 `gorm:"column:roi"`
}

type RawRoi struct {
	Date   string
	Hour   string
	Cost   float64
	Income float64
	Roi    float64
}
