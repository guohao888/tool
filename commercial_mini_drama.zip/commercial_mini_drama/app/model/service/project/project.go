package project

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/panjf2000/ants/v2"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/common/repository/project"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
	projectDao "goserver/app/model/dao/project"
	"goserver/app/model/dao/subscribe"
	"strconv"
	"strings"
	"sync"
	"time"
)

// InfoProjectService 账号项目Service
type InfoProjectService struct {
	Ctx context.Context
}

func NewInfoProjectService(ctx context.Context) *InfoProjectService {
	return &InfoProjectService{Ctx: ctx}
}

// SyncProjectInfos 同步项目
func (ip *InfoProjectService) SyncProjectInfos(crontabTime time.Time, ctx context.Context) error {
	todayDao := subscribe.NewTodaySubscribeDao(ctx)
	activeList, err := todayDao.ActiveAdvertiserProjectInfoList(crontabTime.Format(time.DateOnly))
	if err != nil {
		return fmt.Errorf("查询活跃账号失败, err: %v", err)
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return fmt.Errorf("查询活跃账号为空")
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0

	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			LimitProjectInfos(activeList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func LimitProjectInfos(activeList []accountrepo.OauthAccountEntity, oauth map[string]string, appId string) {
	resChan := make(chan *project.InfoProjectEntity)
	errChan := make(chan error)

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)
	once.Do(func() {
		go func() {
			insertErr := execProjectInfoDB(context.Background(), resChan)
			if insertErr != nil {
				errChan <- fmt.Errorf("execProjectInfoDB error: %v", insertErr)
			}
		}()
	})
	// 获取所有活跃账号及token 请求接口数据
	for _, v := range activeList {
		currentItem := v
		wg.Add(1)
		task := func() {
			defer wg.Done()
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("panic recovered: %v", x)
				}
			}()
			advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
			advertiserIdStr := currentItem.AdvertiserId
			userId := currentItem.UserId
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			// 获取MATERIAL_DATA数据
			allProjectInfos, getErr := execGetProject(context.Background(), oauth[userId], int64(advertiserId))
			if getErr != nil {
				errChan <- fmt.Errorf("执行查询失败 advertiser_id: %s, token: %s, appId: %s, error: %s", advertiserIdStr, oauth[userId], appId, getErr.Error())
			}
			// 查询无数据直接返回
			if allProjectInfos == nil {
				return
			}
			for _, row := range allProjectInfos {
				newRow := row
				info := &project.InfoProjectEntity{
					AdvertiserId: func() int64 {
						if newRow.AdvertiserId != nil {
							return *newRow.AdvertiserId
						}
						return 0
					}(),
					ProjectId: func() int64 {
						if newRow.ProjectId != nil {
							return *newRow.ProjectId
						}
						return 0
					}(),
					DeliveryMode: func() string {
						if newRow.DeliveryMode == nil {
							return ""
						}
						return string(*newRow.DeliveryMode.Ptr())
					}(),
					DeliveryType: func() string {
						if newRow.DeliveryType == nil {
							return ""
						}
						return string(*newRow.DeliveryType.Ptr())
					}(),
					LandingType: func() string {
						if newRow.LandingType == nil {
							return ""
						}
						return string(*newRow.LandingType.Ptr())
					}(),
					AppPromotionType: func() string {
						if newRow.AppPromotionType == nil {
							return ""
						}
						return string(*newRow.AppPromotionType.Ptr())
					}(),
					MarketingGoal: func() string {
						if newRow.MarketingGoal == nil {
							return ""
						}
						return string(*newRow.MarketingGoal.Ptr())
					}(),
					AdType: func() string {
						if newRow.AdType == nil {
							return ""
						}
						return string(*newRow.AdType.Ptr())
					}(),
					OptStatus: func() string {
						if newRow.OptStatus == nil {
							return ""
						}
						return string(*newRow.OptStatus.Ptr())
					}(),
					Name: func() string {
						if newRow.Name != nil {
							return *newRow.Name
						}
						return ""
					}(),
					ProjectCreateTime: func() string {
						if newRow.ProjectCreateTime != nil {
							return *newRow.ProjectCreateTime
						}
						return ""
					}(),
					ProjectModifyTime: func() string {
						if newRow.ProjectModifyTime != nil {
							return *newRow.ProjectModifyTime
						}
						return ""
					}(),
					Status: func() string {
						if newRow.Status == nil {
							return ""
						}
						return string(*newRow.Status.Ptr())
					}(),
					Pricing: func() string {
						if newRow.Pricing == nil {
							return ""
						}
						return string(*newRow.Pricing.Ptr())
					}(),
					PackageName: func() string {
						if newRow.PackageName != nil {
							return *newRow.PackageName
						}
						return ""
					}(),
					AppName: func() string {
						if newRow.AppName != nil {
							return *newRow.AppName
						}
						return ""
					}(),
					FeedDeliverySearch: func() string {
						if newRow.FeedDeliverySearch != nil {
							return *newRow.FeedDeliverySearch
						}
						return ""
					}(),
					SearchBidRatio: func() float64 {
						if newRow.SearchBidRatio != nil {
							return *newRow.SearchBidRatio
						}
						return 0
					}(),
					AudienceExtend: func() string {
						if newRow.AudienceExtend != nil {
							return *newRow.AudienceExtend
						}
						return ""
					}(),
					Keywords: func() string {
						var newKeywords []string
						if newRow.Keywords != nil {
							for _, vv := range newRow.Keywords {
								keyword := project.Keywords{
									BidType: func() string {
										if vv.BidType == nil {
											return ""
										}
										return string(*vv.BidType.Ptr())
									}(),
									MatchType: func() string {
										if vv.MatchType == nil {
											return ""
										}
										return string(*vv.MatchType.Ptr())
									}(),
									Word: func() string {
										if vv.Word != nil {
											return *vv.Word
										}
										return ""
									}(),
								}
								marshal, _ := json.Marshal(keyword)
								newKeywords = append(newKeywords, string(marshal))
							}
						}
						return strings.Join(newKeywords, ";")
					}(),
					RelatedProduct: func() string {
						var products []project.Products
						if newRow.RelatedProduct != nil {
							if newRow.RelatedProduct.Products != nil {
								for _, rel := range newRow.RelatedProduct.Products {
									pro := project.Products{
										AssetId: func() int64 {
											if rel.AssetId != nil {
												return *rel.AssetId
											}
											return 0
										}(),
										ProductId: func() string {
											if rel.ProductId != nil {
												return *rel.ProductId
											}
											return ""
										}(),
										ProductPlatformId: func() int64 {
											if rel.ProductPlatformId != nil {
												return *rel.ProductPlatformId
											}
											return 0
										}(),
										UniqueProductId: func() int64 {
											if rel.UniqueProductId != nil {
												return *rel.UniqueProductId
											}
											return 0
										}(),
									}
									products = append(products, pro)
								}
							}
							relateProduct := project.RelatedProduct{
								ProductId: func() string {
									if newRow.RelatedProduct.ProductId != nil {
										return *newRow.RelatedProduct.ProductId
									}
									return ""
								}(),
								ProductPlatformId: func() int64 {
									if newRow.RelatedProduct.ProductPlatformId != nil {
										return *newRow.RelatedProduct.ProductPlatformId
									}
									return 0
								}(),
								ProductSetting: func() string {
									if newRow.RelatedProduct.ProductSetting == nil {
										return ""
									}
									return string(*newRow.RelatedProduct.ProductSetting.Ptr())
								}(),
								Products: products,
								UniqueProductId: func() int64 {
									if newRow.RelatedProduct.UniqueProductId != nil {
										return *newRow.RelatedProduct.UniqueProductId
									}
									return 0
								}(),
							}
							marshal, _ := json.Marshal(relateProduct)
							return string(marshal)
						}
						return ""
					}(),
					DeliveryProduct: func() string {
						if newRow.DeliveryProduct == nil {
							return ""
						}
						return string(*newRow.DeliveryProduct.Ptr())
					}(),
					DeliveryMedium: func() string {
						if newRow.DeliveryMedium == nil {
							return ""
						}
						return string(*newRow.DeliveryMedium.Ptr())
					}(),
					MultiDeliveryMedium: func() string {
						if newRow.MultiDeliveryMedium == nil {
							return ""
						}
						return string(*newRow.MultiDeliveryMedium.Ptr())
					}(),
					DownloadUrl: func() string {
						if newRow.DownloadUrl != nil {
							return *newRow.DownloadUrl
						}
						return ""
					}(),
					DownloadType: func() string {
						if newRow.DownloadType == nil {
							return ""
						}
						return string(*newRow.DownloadType.Ptr())
					}(),
					DownloadMode: func() string {
						if newRow.DownloadMode == nil {
							return ""
						}
						return string(*newRow.DownloadMode.Ptr())
					}(),
					LaunchType: func() string {
						if newRow.LaunchType == nil {
							return ""
						}
						return string(*newRow.LaunchType.Ptr())
					}(),
					PromotionType: func() string {
						if newRow.PromotionType == nil {
							return ""
						}
						return string(*newRow.PromotionType.Ptr())
					}(),
					AssetType: func() string {
						if newRow.AssetType == nil {
							return ""
						}
						return string(*newRow.AssetType.Ptr())
					}(),
					MicroPromotionType: func() string {
						if newRow.MicroPromotionType == nil {
							return ""
						}
						return string(*newRow.MicroPromotionType.Ptr())
					}(),
					MicroAppInstanceId: func() int64 {
						if newRow.MicroAppInstanceId != nil {
							return *newRow.MicroAppInstanceId
						}
						return 0
					}(),
					OptimizeGoal: func() string {
						if newRow.OptimizeGoal != nil {
							opt := project.OptimizeGoal{
								AssetIds: newRow.OptimizeGoal.AssetIds,
								ConvertId: func() int64 {
									if newRow.OptimizeGoal.ConvertId != nil {
										return *newRow.OptimizeGoal.ConvertId
									}
									return 0
								}(),
								DeepExternalAction: func() string {
									if newRow.OptimizeGoal.DeepExternalAction == nil {
										return ""
									}
									return string(*newRow.OptimizeGoal.DeepExternalAction.Ptr())
								}(),
								ExternalAction: func() string {
									if newRow.OptimizeGoal.ExternalAction == nil {
										return ""
									}
									return string(*newRow.OptimizeGoal.ExternalAction.Ptr())
								}(),
								GameAddictionId: func() string {
									if newRow.OptimizeGoal.GameAddictionId != nil {
										return *newRow.OptimizeGoal.GameAddictionId
									}
									return ""
								}(),
								PaidSwitch: func() int64 {
									if newRow.OptimizeGoal.PaidSwitch != nil {
										return *newRow.OptimizeGoal.PaidSwitch
									}
									return 0
								}(),
							}
							marshal, _ := json.Marshal(opt)
							return string(marshal)
						}
						return ""
					}(),
					ValueOptimizedType: func() string {
						if newRow.ValueOptimizedType == nil {
							return ""
						}
						return string(*newRow.ValueOptimizedType.Ptr())
					}(),
					DeliveryRange: func() string {
						if newRow.DeliveryRange != nil {
							var invs []string
							if newRow.DeliveryRange.InventoryType != nil {
								for _, inv := range newRow.DeliveryRange.InventoryType {
									if inv != nil {
										invs = append(invs, string(*inv.Ptr()))
									}
								}
							}
							del := project.DeliveryRange{
								InventoryCatalog: func() string {
									if newRow.DeliveryRange.InventoryCatalog == nil {
										return ""
									}
									return string(*newRow.DeliveryRange.InventoryCatalog.Ptr())
								}(),
								InventoryType: invs,
								UnionVideoType: func() string {
									if newRow.DeliveryRange.UnionVideoType == nil {
										return ""
									}
									return string(*newRow.DeliveryRange.UnionVideoType.Ptr())
								}(),
							}
							marshal, _ := json.Marshal(del)
							return string(marshal)
						}
						return ""
					}(),
					Audience: func() string {
						if newRow.Audience != nil {
							var dts []string
							if newRow.Audience.DeviceType != nil {
								for _, dt := range newRow.Audience.DeviceType {
									if dt != nil {
										dts = append(dts, string(*dt.Ptr()))
									}
								}
							}
							aud := project.Audience{
								DeviceType: dts,
								ConvertedTimeDuration: func() string {
									if newRow.Audience.ConvertedTimeDuration == nil {
										return ""
									}
									return string(*newRow.Audience.ConvertedTimeDuration.Ptr())
								}(),
							}
							marshal, _ := json.Marshal(aud)
							return string(marshal)
						}
						return ""
					}(),
					Bid: func() float64 {
						if newRow.DeliverySetting.CpaBid == nil {
							return 0
						}
						return *newRow.DeliverySetting.CpaBid
					}(),
				}
				resChan <- info
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done() // 提交失败，减少计数器
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待所有任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan) // 确保所有任务完成后关闭通道
	}()
	// 收集所有错误
	var errs []error
	for errL := range errChan {
		errs = append(errs, errL)
	}
	return
}

// execProjectInfoDB 保存项目列表
func execProjectInfoDB(ctx context.Context, resChan <-chan *project.InfoProjectEntity) (err error) {
	infoProjectDao := projectDao.NewInfoProjectDao(ctx)
	// 2.3 将数据写入 report_hour
	var data = make([]*project.InfoProjectEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			if dbErr := infoProjectDao.InsertBatchSize(data, 5000); dbErr != nil {
				errs = append(errs, dbErr) // 收集错误，不退出
			}
			data = data[:0]
		}

	}
	if len(data) > 0 {
		dbErr := infoProjectDao.InsertBatchSize(data, 5000)
		if dbErr != nil {
			errs = append(errs, dbErr)
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execDB errors: %v", errs)
	}
	return nil
}

// execGetProject 执行获取账号项目数据查询
func execGetProject(ctx context.Context, accessToken string, advertiserId int64) (allProjects toutiao.ProjectRow, err error) {
	// 获取账号项目数据
	allProjects, err = toutiao.AllProjectListGet(ctx, toutiao.ProjectGetReq{
		AccessToken:  accessToken,
		AdvertiserId: advertiserId,
	})
	if err != nil {
		return
	}
	return
}
