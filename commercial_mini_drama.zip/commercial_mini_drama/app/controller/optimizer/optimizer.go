package optimizer

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common/dto/optimizerdto"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/optimizer"
)

// UpdateOptimizer 编辑优化师
func UpdateOptimizer(c *gin.Context) {
	r := response.Gin{Ctx: c}
	optimizerInfo := optimizerdto.UpdateOptimizerReq(c)

	optimizerService := optimizer.NewOptimizerService(c)
	err := optimizerService.UpdateOptimizerInfo(optimizerInfo.Params)

	if err != nil { //保存数据失败
		r.Response(myerror.AddOptimizerError.Code, err.Error(), nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

// OptimizerList 优化师列表
func OptimizerList(c *gin.Context) {
	r := response.Gin{Ctx: c}
	optimizerList := optimizerdto.OptimizerListReq(c)

	optimizerService := optimizer.NewOptimizerService(c)
	list, err := optimizerService.OptimizerInfoList(optimizerList.Params)

	if err != nil { //保存数据失败
		r.Response(myerror.AddOptimizerError.Code, err.Error(), nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, list)
}

// UpdateOptimizerCity 编辑优化师地区
func UpdateOptimizerCity(c *gin.Context) {
	r := response.Gin{Ctx: c}
	optimizerCityInfo := optimizerdto.UpdateOptimizerCityReq(c)

	optimizerService := optimizer.NewOptimizerService(c)
	err := optimizerService.UpdateOptimizerCityInfo(optimizerCityInfo.Params)

	if err != nil { //保存数据失败
		r.Response(myerror.AddOptimizerError.Code, err.Error(), nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

// OptimizerCityList 优化师地区列表
func OptimizerCityList(c *gin.Context) {
	r := response.Gin{Ctx: c}
	optimizerList := optimizerdto.OptimizerCityListReq(c)

	optimizerService := optimizer.NewOptimizerService(c)
	list, err := optimizerService.OptimizerCityInfoList(optimizerList.Params)

	if err != nil { //保存数据失败
		r.Response(myerror.AddOptimizerCityError.Code, err.Error(), nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, list)
}

// UpdateOptimizerCityRelation 编辑优化师地区绑定
func UpdateOptimizerCityRelation(c *gin.Context) {
	r := response.Gin{Ctx: c}
	optimizerCityRelationInfo := optimizerdto.UpdateOptimizerCityRelationReq(c)

	optimizerService := optimizer.NewOptimizerService(c)
	err := optimizerService.UpdateOptimizerCityRelationInfo(optimizerCityRelationInfo.Params)

	if err != nil { //保存数据失败
		r.Response(myerror.AddOptimizerCityRelationError.Code, err.Error(), nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

// OptimizerCityRelationList 优化师地区关联列表
func OptimizerCityRelationList(c *gin.Context) {
	r := response.Gin{Ctx: c}
	optimizerList := optimizerdto.OptimizerCityRelationListReq(c)

	optimizerService := optimizer.NewOptimizerService(c)
	list, err := optimizerService.OptimizerCityRelationInfoList(optimizerList.Params)

	if err != nil { //保存数据失败
		r.Response(myerror.OptimizerCityRelationViewListError.Code, err.Error(), nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, list)
}

// GetRelationByOptimizerName 通过优化师名称获取关联数据
func GetRelationByOptimizerName(c *gin.Context) {
	r := response.Gin{Ctx: c}
	optimizerInfo := optimizerdto.GetRelationByOptimizerNameReq(c)
	optimizerService := optimizer.NewOptimizerService(c)
	info, err := optimizerService.GetRelationByOptimizerName(optimizerInfo.Params)

	if err != nil { //保存数据失败
		r.Response(myerror.OptimizerCityRelationViewListError.Code, err.Error(), nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, info)
}

// RefreshData 根据优化师刷新手机号和地区
func RefreshData(c *gin.Context) {
	r := response.Gin{Ctx: c}
	optimizerData := optimizerdto.OptimizerRefreshDataReq(c)
	optimizerService := optimizer.NewOptimizerService(c)
	msg, err := optimizerService.RefreshData(optimizerData.Params)

	if err != nil { //保存数据失败
		r.Response(myerror.AddOptimizerError.Code, err.Error(), msg)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, msg)
}
