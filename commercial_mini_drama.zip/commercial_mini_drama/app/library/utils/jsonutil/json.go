package jsonutil

import (
	"time"
)

const DateTimeFormat = time.DateTime
const DateOnlyFormat = time.DateOnly

type DateTime time.Time
type DateOnly time.Time

func (t *DateTime) UnmarshalJSON(data []byte) (err error) {
	pt, err := time.ParseInLocation(`"`+DateTimeFormat+`"`, string(data), time.Local)
	*t = DateTime(pt)
	return
}

func (t DateTime) MarshalJSON() ([]byte, error) {
	b := make([]byte, 0, len(DateTimeFormat)+2)
	b = append(b, '"')
	b = time.Time(t).AppendFormat(b, DateTimeFormat)
	b = append(b, '"')
	return b, nil
}

func (t DateTime) String() string {
	return time.Time(t).Format(DateTimeFormat)
}

func (t *DateOnly) UnmarshalJSON(data []byte) (err error) {
	pt, err := time.ParseInLocation(`"`+DateOnlyFormat+`"`, string(data), time.Local)
	*t = DateOnly(pt)
	return
}

func (t DateOnly) MarshalJSON() ([]byte, error) {
	b := make([]byte, 0, len(DateOnlyFormat)+2)
	b = append(b, '"')
	b = time.Time(t).AppendFormat(b, DateOnlyFormat)
	b = append(b, '"')
	return b, nil
}

func (t DateOnly) String() string {
	return time.Time(t).Format(DateOnlyFormat)
}
