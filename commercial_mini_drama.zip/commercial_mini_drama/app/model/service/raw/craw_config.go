package raw

import (
	"context"
	raw2 "goserver/app/common/repository/raw"
	"goserver/app/model/dao/raw"
	"time"
)

type CrawConfigService struct {
	Ctx context.Context
}

type Config struct {
	Cookie       string `json:"cookie"`
	BusinessType int    `json:"business_type"`
}

func NewCrawConfigService(ctx context.Context) *CrawConfigService {
	return &CrawConfigService{Ctx: ctx}
}

func (c *CrawConfigService) UpdateData(update Config) error {
	var updateInfo = raw2.CrawConfigEntity{
		ReqCurl: &update.Cookie,
		//BusinessType: update.BusinessType,
		CreateTime: time.Now(),
		UpdateTime: time.Now(),
	}
	return raw.NewCrawConfigDao(c.Ctx).
		UpdateData(update.BusinessType, updateInfo)
}
