package kuaishou

import (
	"context"
	"fmt"
	"github.com/panjf2000/ants/v2"
	"goserver/app/common"
	ksdto "goserver/app/common/dto/kuaishoudto"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	kuaishouEntity "goserver/app/common/repository/kuaishou"
	"goserver/app/library/playlet/kuaishou"
	accountdao "goserver/app/model/dao/accounts"
	kuaishoudao "goserver/app/model/dao/kuaishou"
	"goserver/app/model/service/mediareport"
	"strconv"
	"sync"
	"time"
)

type AdDetailService struct {
	Ctx context.Context
}

func NewAdDetailService(ctx context.Context) *AdDetailService {
	return &AdDetailService{Ctx: ctx}
}

type AdDetailItem struct {
	AdvertiserId                                  int64   `json:"advertiser_id"`                                         // 用户快手号id
	Date                                          string  `json:"date"`                                                  // 日期（yyyy-MM-dd hh:mm:ss）
	SeriesType                                    string  `json:"series_type"`                                           // 短剧类型，1-IAA短剧，2-IAP短剧
	Likes                                         int64   `json:"likes"`                                                 // 点赞数
	Share                                         int64   `json:"share"`                                                 // 分享数
	PhotoClick                                    int64   `json:"photo_click"`                                           // 封面点击数
	Impression                                    int64   `json:"impression"`                                            // 封面曝光数
	EventPay                                      int64   `json:"event_pay"`                                             // 付费次数
	T0DirectPaidCnt                               float64 `json:"t0_direct_paid_cnt"`                                    // 付费次数(计费时间)
	EventPayPurchaseAmount                        float64 `json:"event_pay_purchase_amount"`                             // 付费金额
	T0DirectPaidAmt                               float64 `json:"t0_direct_paid_amt"`                                    // 付费金额(计费时间)
	AdShow                                        int64   `json:"ad_show"`                                               // 广告曝光
	TotalCharge                                   float64 `json:"total_charge"`                                          // 消耗
	EventAppInvoked                               int64   `json:"event_app_invoked"`                                     // 唤起应用数
	EventPayPurchaseAmountFirstDay                float64 `json:"event_pay_purchase_amount_first_day"`                   // 激活当日付费金额
	EventPayPurchaseAmountOneDayByConversion      float64 `json:"event_pay_purchase_amount_one_day_by_conversion"`       // 激活后24h付费金额(激活时间)
	EventPayPurchaseAmountWeekByConversion        float64 `json:"event_pay_purchase_amount_week_by_conversion"`          // 激活后七日付费金额
	EventPayPurchaseAmountThreeDayByConversion    float64 `json:"event_pay_purchase_amount_three_day_by_conversion"`     // 激活后三日付费金额
	Conversion                                    int64   `json:"conversion"`                                            // 激活数
	T0DirectConversionCnt                         int64   `json:"t0_direct_conversion_cnt"`                              // 激活数(计费时间)
	Negative                                      int64   `json:"negative"`                                              // 减少此类作品数
	Report                                        int64   `json:"report"`                                                // 举报数
	Block                                         int64   `json:"block"`                                                 // 拉黑数
	Comment                                       int64   `json:"comment"`                                               // 评论数
	EventPayFirstDay                              int64   `json:"event_pay_first_day"`                                   // 首日付费次数
	PlayedNum                                     int64   `json:"played_num"`                                            // 素材曝光数
	PlayedThreeSeconds                            int64   `json:"played_three_seconds"`                                  // 3s播放数
	AdPhotoPlayed75percent                        int64   `json:"ad_photo_played75percent"`                              // 75%播放进度数
	PlayedEnd                                     int64   `json:"played_end"`                                            // 完播数
	Follow                                        int64   `json:"follow"`                                                // 新增粉丝数
	EventNewUserPay                               int64   `json:"event_new_user_pay"`                                    // 新增付费人数
	AdItemClick                                   int64   `json:"ad_item_click"`                                         // 行为数
	T7PaidCnt                                     int64   `json:"t7_paid_cnt"`                                           // 7日累计付费次数
	T7PaidAmt                                     float64 `json:"t7_paid_amt"`                                           // 7日累计付费金额
	ConversionNumByImpression7d                   int64   `json:"conversion_num_by_impression7d"`                        // 转化数(计费时间)
	DeepConversionNumByImpression7d               int64   `json:"deep_conversion_num_by_impression7d"`                   // 深度转化数(计费时间)
	ConversionNum                                 int64   `json:"conversion_num"`                                        // 转化数(回传时间)
	DeepConversionNum                             int64   `json:"deep_conversion_num"`                                   // 深度转化数
	T0PaidCnt                                     int64   `json:"t0_paid_cnt"`                                           // 当日累计付费次数
	T0PaidAmt                                     float64 `json:"t0_paid_amt"`                                           // 当日累计付费金额
	Play3sRatio                                   float64 `json:"play3s_ratio"`                                          // 3s播放率
	AdPhotoPlayed75PercentRatio                   float64 `json:"ad_photo_played_75percent_ratio"`                       // 75%进度播放率
	T7PaidRoi                                     float64 `json:"t7_paid_roi"`                                           // 7日累计ROI
	T0PaidRoi                                     float64 `json:"t0_paid_roi"`                                           // 当日累计ROI
	PhotoClickRatio                               float64 `json:"photo_click_ratio"`                                     // 封面点击率
	EventPayCost                                  float64 `json:"event_pay_cost"`                                        // 付费次数成本
	EventPayRoi                                   float64 `json:"event_pay_roi"`                                         // 付费ROI
	EventAppInvokedCost                           float64 `json:"event_app_invoked_cost"`                                // 唤起应用成本
	EventAppInvokedRatio                          float64 `json:"event_app_invoked_ratio"`                               // 唤起应用率
	ConversionCost                                float64 `json:"conversion_cost"`                                       // 激活单价
	EventPayFirstDayRoi                           float64 `json:"event_pay_first_day_roi"`                               // 激活当日ROI
	EventPayPurchaseAmountOneDayByConversionRoi   float64 `json:"event_pay_purchase_amount_one_day_by_conversion_roi"`   // 激活后24h-ROI(激活时间)
	EventPayPurchaseAmountThreeDayByConversionRoi float64 `json:"event_pay_purchase_amount_three_day_by_conversion_roi"` // 激活后3日ROI
	EventPayPurchaseAmountWeekByConversionRoi     float64 `json:"event_pay_purchase_amount_week_by_conversion_roi"`      // 激活后7日ROI
	PhotoClickCost                                float64 `json:"photo_click_cost"`                                      // 平均封面点击单价（元）
	Impression1kCost                              float64 `json:"impression1k_cost"`                                     // 平均千次封面曝光花费（元）
	Click1kCost                                   float64 `json:"click1k_cost"`                                          // 平均千次素材曝光花费（元）
	ActionCost                                    float64 `json:"action_cost"`                                           // 平均行为单价（元）
	DeepConversionCostByImpression7d              float64 `json:"deep_conversion_cost_by_impression7d"`                  // 深度转化成本(计费时间)，单位元
	DeepConversionRatioByImpression7d             float64 `json:"deep_conversion_ratio_by_impression7d"`                 // 深度转化率(计费时间)
	EventPayFirstDayCost                          float64 `json:"event_pay_first_day_cost"`                              // 首日付费次数成本，单位元
	ActionRatio                                   float64 `json:"action_ratio"`                                          // 素材点击率
	PlayEndRatio                                  float64 `json:"play_end_ratio"`                                        // 完播率
	EventNewUserPayCost                           float64 `json:"event_new_user_pay_cost"`                               // 新增付费人数成本，单位元
	EventNewUserPayRatio                          float64 `json:"event_new_user_pay_ratio"`                              // 新增付费人数率
	ActionNewRatio                                float64 `json:"action_new_ratio"`                                      // 行为率
	ConversionCostByImpression7d                  float64 `json:"conversion_cost_by_impression7d"`                       // 转化成本(计费时间)，单位元
	ConversionRatioByImpression7d                 float64 `json:"conversion_ratio_by_impression7d"`                      // 转化率(计费时间)
	KeyAction                                     int64   `json:"key_action"`                                            // 关键行为数
	AdPhotoPlayed75percentRatio                   float64 `json:"ad_photo_played75percent_ratio"`                        // 75%进度播放数
	MiniGameIaaRoi                                float64 `json:"mini_game_iaa_roi"`                                     // IAA广告变现ROI
	MiniGameIaaPurchaseAmount                     float64 `json:"mini_game_iaa_purchase_amount"`                         // IAA广告变现LTV（元）
	AccountId                                     string  `json:"account_id"`                                            // 账号ID
	SeriesId                                      string  `json:"series_id"`                                             // 短剧ID
	RechargeRate                                  float64 `json:"recharge_rate"`                                         // 充值几率

	Media                           string  `json:"media"`                                //媒体
	SeriesName                      string  `json:"series_name"`                          // 剧目名称
	AccountName                     string  `json:"account_name"`                         // 账户名
	ActualEventPayPurchaseAmount    float64 `json:"actual_event_pay_purchase_amount"`     // 实际付费金额
	ActualCharge                    float64 `json:"actual_charge"`                        // 实际消耗
	ActualT0PaidMmt                 float64 `json:"actual_t0_paid_amt"`                   // 当日累计实际付费金额
	ActualT0PaidRoi                 float64 `json:"actual_t0_paid_roi"`                   // 当日累计实际ROI
	ActualMiniGameIaaPurchaseAmount float64 `json:"actual_mini_game_iaa_purchase_amount"` // 实际IAA广告变现LTV（元）
}

func (r *AdDetailService) formatList(dbList []kuaishouEntity.AdDetailEntity, req *ksdto.AdDataListReq) []AdDetailItem {
	var list []AdDetailItem
	for k, item := range dbList {
		// 处理日期格式
		var dateStr, seriesType, seriesId, accountId string
		if k == 0 && item.Date.Year() == 1970 && item.Date.Month() == 1 && item.Date.Day() == 1 {
			dateStr = "汇总"
		} else {
			dateStr = item.DateStr
			seriesType = getAdSeriesTypeStr(int(req.SeriesType))
			seriesId = strconv.FormatInt(item.SeriesId, 10)
			accountId = strconv.FormatInt(item.AccountId, 10)
		}

		adDetailItem := AdDetailItem{
			Media:                                    item.Media,
			AdvertiserId:                             item.AdvertiserId,
			Date:                                     dateStr,
			SeriesType:                               seriesType,
			Likes:                                    item.Likes,
			Share:                                    item.Share,
			PhotoClick:                               item.PhotoClick,
			Impression:                               item.Impression,
			EventPay:                                 item.EventPay,
			T0DirectPaidCnt:                          item.T0DirectPaidCnt,
			EventPayPurchaseAmount:                   item.EventPayPurchaseAmount,
			T0DirectPaidAmt:                          item.T0DirectPaidAmt,
			AdShow:                                   item.AdShow,
			TotalCharge:                              item.TotalCharge / 1000.0,
			EventAppInvoked:                          item.EventAppInvoked,
			EventPayPurchaseAmountFirstDay:           item.EventPayPurchaseAmountFirstDay,
			EventPayPurchaseAmountOneDayByConversion: item.EventPayPurchaseAmountOneDayByConversion,
			EventPayPurchaseAmountWeekByConversion:   item.EventPayPurchaseAmountWeekByConversion,
			EventPayPurchaseAmountThreeDayByConversion: item.EventPayPurchaseAmountThreeDayByConversion,
			Conversion:                      item.Conversion,
			T0DirectConversionCnt:           item.T0DirectConversionCnt,
			Negative:                        item.Negative,
			Report:                          item.Report,
			Block:                           item.Block,
			Comment:                         item.Comment,
			EventPayFirstDay:                item.EventPayFirstDay,
			PlayedNum:                       item.PlayedNum,
			PlayedThreeSeconds:              item.PlayedThreeSeconds,
			AdPhotoPlayed75percent:          item.AdPhotoPlayed75percent,
			PlayedEnd:                       item.PlayedEnd,
			Follow:                          item.Follow,
			EventNewUserPay:                 item.EventNewUserPay,
			AdItemClick:                     item.AdItemClick,
			T7PaidCnt:                       item.T7PaidCnt,
			T7PaidAmt:                       item.T7PaidAmt,
			ConversionNumByImpression7d:     item.ConversionNumByImpression7d,
			DeepConversionNumByImpression7d: item.DeepConversionNumByImpression7d,
			ConversionNum:                   item.ConversionNum,
			DeepConversionNum:               item.DeepConversionNum,
			T0PaidCnt:                       item.T0PaidCnt,
			T0PaidAmt:                       item.T0PaidAmt,
			Play3sRatio:                     item.Play3sRatio,
			AdPhotoPlayed75PercentRatio:     item.AdPhotoPlayed75PercentRatio,
			T7PaidRoi:                       item.T7PaidRoi,
			T0PaidRoi:                       item.T0PaidRoi,
			PhotoClickRatio:                 item.PhotoClickRatio,
			EventPayCost:                    item.EventPayCost,
			EventPayRoi:                     item.EventPayRoi,
			EventAppInvokedCost:             item.EventAppInvokedCost,
			EventAppInvokedRatio:            item.EventAppInvokedRatio,
			ConversionCost:                  item.ConversionCost,
			EventPayFirstDayRoi:             item.EventPayFirstDayRoi,
			EventPayPurchaseAmountOneDayByConversionRoi:   item.EventPayPurchaseAmountOneDayByConversionRoi,
			EventPayPurchaseAmountThreeDayByConversionRoi: item.EventPayPurchaseAmountThreeDayByConversionRoi,
			EventPayPurchaseAmountWeekByConversionRoi:     item.EventPayPurchaseAmountWeekByConversionRoi,
			PhotoClickCost:                    item.PhotoClickCost,
			Impression1kCost:                  item.Impression1kCost,
			Click1kCost:                       item.Click1kCost,
			ActionCost:                        item.ActionCost,
			DeepConversionCostByImpression7d:  item.DeepConversionCostByImpression7d,
			DeepConversionRatioByImpression7d: item.DeepConversionRatioByImpression7d,
			EventPayFirstDayCost:              item.EventPayFirstDayCost,
			ActionRatio:                       item.ActionRatio,
			PlayEndRatio:                      item.PlayEndRatio,
			EventNewUserPayCost:               item.EventNewUserPayCost,
			EventNewUserPayRatio:              item.EventNewUserPayRatio,
			ActionNewRatio:                    item.ActionNewRatio,
			ConversionCostByImpression7d:      item.ConversionCostByImpression7d,
			ConversionRatioByImpression7d:     item.ConversionRatioByImpression7d,
			KeyAction:                         item.KeyAction,
			AdPhotoPlayed75percentRatio:       item.AdPhotoPlayed75percentRatio,
			MiniGameIaaRoi:                    item.MiniGameIaaRoi,
			MiniGameIaaPurchaseAmount:         item.MiniGameIaaPurchaseAmount,
			AccountId:                         accountId,
			SeriesId:                          seriesId,
			AccountName:                       item.AccountName,
			SeriesName:                        item.SeriesName,
			RechargeRate:                      item.RechargeRate,
			ActualEventPayPurchaseAmount:      item.ActualEventPayPurchaseAmount,
			ActualCharge:                      item.ActualCharge / 1000.0,
			ActualT0PaidMmt:                   item.ActualT0PaidMmt,
			ActualT0PaidRoi:                   item.ActualT0PaidRoi,
			ActualMiniGameIaaPurchaseAmount:   item.ActualMiniGameIaaPurchaseAmount,
		}
		list = append(list, adDetailItem)
	}
	return list
}

func (r *AdDetailService) AdDataList(req *ksdto.AdDataListReq) (*ksdto.AdDataListResp, error) {
	adDetailDao := kuaishoudao.NewAdDetailDao(r.Ctx)
	pagination := req.Pagination
	// 分页数据
	dbList, cnt, err := adDetailDao.List(req)
	if err != nil {
		return nil, err
	}
	// 格式化
	list := r.formatList(dbList, req)
	pullTimeDao := kuaishoudao.NewPullTimeDao(r.Ctx)
	lastPullTime, err := pullTimeDao.GetMaxPullTime(1)
	if err != nil {
		return nil, err
	}

	paginator := common.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), cnt, list)

	return &ksdto.AdDataListResp{
		Paginator:      &paginator,
		LastModifyTime: lastPullTime.Format("2006-01-02 15:04:05"),
	}, nil
}

func getAdSeriesTypeStr(seriesType int) string {
	if seriesType == 1 {
		return "IAA"
	}
	if seriesType == 2 {
		return "IAP"
	}
	return "全部"
}

func (r *AdDetailService) AdDataExport(req *ksdto.AdDataListReq) (*[]AdDetailItem, error) {
	adDetailDao := kuaishoudao.NewAdDetailDao(r.Ctx)
	dbList, err := adDetailDao.Export(req)
	if err != nil {
		return nil, err
	}
	list := r.formatList(dbList, req)
	return &list, nil
}

// DistributeAdDetailHistory 拉取广告报表明细
func (r *AdDetailService) DistributeAdDetailHistory(crontabTime time.Time, ctx context.Context) error {

	// 获取执行时间
	startDate, endDate := mediareport.GetExecTime(crontabTime)
	start, _ := time.ParseInLocation(time.DateTime, startDate+" 00:00:00", time.Local)
	end, _ := time.ParseInLocation(time.DateTime, endDate+" 23:59:59", time.Local)
	startTime := start.UnixNano() / 1e6
	endTime := end.UnixNano() / 1e6
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用appid
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaKuaishou)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaKuaishou, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		oauthMap[v.AppId][v.UserId] = v.AccessToken
	}

	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(oauthList) / len(appIds)
	remainder := len(oauthList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		// 为每个goroutine创建局部变量
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncKuaishouDetailHistory(startTime, endTime, oauthList[start:end], oauth)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func SyncKuaishouDetailHistory(start, end int64, userIds []accountrepo.OauthEntity, oauth map[string]string) {

	resChan := make(chan *kuaishouEntity.AdDetailEntity)
	errChan := make(chan error, len(userIds))

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	once.Do(func() {
		go func() {
			dbErr := execDetailDB(context.Background(), resChan)
			if dbErr != nil {
				errChan <- fmt.Errorf("execDetailDB err: %s", dbErr.Error())
			}
		}()
	})
	for _, v := range userIds {
		wg.Add(1)
		currentItem := v
		advertiserId, _ := strconv.Atoi(currentItem.UserId)

		task := func() {
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()
			_, exists := oauth[currentItem.UserId]
			if !exists {
				return
			}
			for _, stype := range []int{1, 2} {
				allReq, getErr := kuaishou.AllDetailData(context.Background(), kuaishou.ReportQueryReq{
					AdvertiserId: int64(advertiserId),
					AccessToken:  oauth[currentItem.UserId],
					StartTime:    start,
					EndTime:      end,
					SeriesType:   stype,
				})
				if getErr != nil {
					errChan <- fmt.Errorf("短剧广告报表明细查询接口, advertiserId: %d, token: %s,  err: %s", advertiserId, oauth[currentItem.UserId], getErr.Error())
					return
				}
				for _, row := range allReq {
					info := trans2Entity(row, int64(advertiserId), stype, 2)
					resChan <- info
				}
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		fmt.Println(errL.Error())
		errs = append(errs, errL)
	}
	return
}

func execDetailDB(ctx context.Context, resChan <-chan *kuaishouEntity.AdDetailEntity) (err error) {
	// 保存数据DAO
	detailDao := kuaishoudao.NewAdDetailDao(ctx)
	var data = make([]*kuaishouEntity.AdDetailEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			err = detailDao.InsertBatchSize(data, 5000)
			if err != nil {
				errs = append(errs, err) // 收集错误，不退出
			}
			data = data[:0]
		}
	}
	if len(data) > 0 {
		err = detailDao.InsertBatchSize(data, 5000)
		if err != nil {
			errs = append(errs, err) // 收集错误，不退出
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execDetailDB errors: %v", errs)
	}
	return nil
}

func trans2Entity(v kuaishou.AdDetail, advertiserId int64, seriesType int, isToday int) *kuaishouEntity.AdDetailEntity {
	date, _ := time.ParseInLocation(time.DateOnly, v.Date, time.Local)
	info := &kuaishouEntity.AdDetailEntity{
		AdvertiserId:                             advertiserId,
		Date:                                     date,
		IsToday:                                  isToday,
		SeriesType:                               seriesType,
		Likes:                                    v.Likes,
		Share:                                    v.Share,
		PhotoClick:                               v.PhotoClick,
		Impression:                               v.Impression,
		EventPay:                                 v.EventPay,
		T0DirectPaidCnt:                          v.T0DirectPaidCnt,
		EventPayPurchaseAmount:                   v.EventPayPurchaseAmount,
		T0DirectPaidAmt:                          v.T0DirectPaidAmt,
		AdShow:                                   v.AdShow,
		TotalCharge:                              v.TotalCharge,
		EventAppInvoked:                          v.EventAppInvoked,
		EventPayPurchaseAmountFirstDay:           v.EventPayPurchaseAmountFirstDay,
		EventPayPurchaseAmountOneDayByConversion: v.EventPayPurchaseAmountOneDayByConversion,
		EventPayPurchaseAmountWeekByConversion:   v.EventPayPurchaseAmountWeekByConversion,
		EventPayPurchaseAmountThreeDayByConversion: v.EventPayPurchaseAmountThreeDayByConversion,
		Conversion:            v.Conversion,
		T0DirectConversionCnt: v.T0DirectConversionCnt,
		//Negative:                        v.Negative,
		Report:                          v.Report,
		Block:                           v.Block,
		Comment:                         v.Comment,
		EventPayFirstDay:                v.EventPayFirstDay,
		PlayedNum:                       v.PlayedNum,
		PlayedThreeSeconds:              v.PlayedThreeSeconds,
		AdPhotoPlayed75percent:          v.AdPhotoPlayed75percent,
		PlayedEnd:                       v.PlayedEnd,
		Follow:                          v.Follow,
		EventNewUserPay:                 v.EventNewUserPay,
		AdItemClick:                     v.AdItemClick,
		T7PaidCnt:                       v.T7PaidCnt,
		T7PaidAmt:                       v.T7PaidAmt,
		ConversionNumByImpression7d:     v.ConversionNumByImpression7d,
		DeepConversionNumByImpression7d: v.DeepConversionNumByImpression7d,
		ConversionNum:                   v.ConversionNum,
		DeepConversionNum:               v.DeepConversionNum,
		T0PaidCnt:                       v.T0PaidCnt,
		T0PaidAmt:                       v.T0PaidAmt,
		Play3sRatio:                     v.Play3sRatio,
		AdPhotoPlayed75PercentRatio:     v.AdPhotoPlayed75PercentRatio,
		T7PaidRoi:                       v.T7PaidRoi,
		T0PaidRoi:                       v.T0PaidRoi,
		PhotoClickRatio:                 v.PhotoClickRatio,
		EventPayCost:                    v.EventPayCost,
		EventPayRoi:                     v.EventPayRoi,
		EventAppInvokedCost:             v.EventAppInvokedCost,
		EventAppInvokedRatio:            v.EventAppInvokedRatio,
		ConversionCost:                  v.ConversionCost,
		EventPayFirstDayRoi:             v.EventPayFirstDayRoi,
		EventPayPurchaseAmountOneDayByConversionRoi:   v.EventPayPurchaseAmountOneDayByConversionRoi,
		EventPayPurchaseAmountThreeDayByConversionRoi: v.EventPayPurchaseAmountThreeDayByConversionRoi,
		EventPayPurchaseAmountWeekByConversionRoi:     v.EventPayPurchaseAmountWeekByConversionRoi,
		PhotoClickCost:                    v.PhotoClickCost,
		Impression1kCost:                  v.Impression1kCost,
		Click1kCost:                       v.Click1kCost,
		ActionCost:                        v.ActionCost,
		DeepConversionCostByImpression7d:  v.DeepConversionCostByImpression7d,
		DeepConversionRatioByImpression7d: v.DeepConversionRatioByImpression7d,
		EventPayFirstDayCost:              v.EventPayFirstDayCost,
		ActionRatio:                       v.ActionRatio,
		PlayEndRatio:                      v.PlayEndRatio,
		EventNewUserPayCost:               v.EventNewUserPayCost,
		EventNewUserPayRatio:              v.EventNewUserPayRatio,
		ActionNewRatio:                    v.ActionNewRatio,
		ConversionCostByImpression7d:      v.ConversionCostByImpression7d,
		ConversionRatioByImpression7d:     v.ConversionRatioByImpression7d,
		KeyAction:                         v.KeyAction,
		AdPhotoPlayed75percentRatio:       v.AdPhotoPlayed75percentRatio,
		MiniGameIaaRoi:                    v.MiniGameIaaRoi,
		MiniGameIaaPurchaseAmount:         v.MiniGameIaaPurchaseAmount,
		AccountId:                         v.AccountId,
		SeriesId:                          v.SeriesId,
		RechargeRate:                      v.RechargeRate,
	}
	return info
}

// DistributeAdDetailToday 拉取广告报表明细
func (r *AdDetailService) DistributeAdDetailToday(crontabTime time.Time, ctx context.Context) error {
	// 获取执行时间
	startDate, endDate := mediareport.GetExecTime(crontabTime)
	start, _ := time.ParseInLocation(time.DateTime, startDate+" 00:00:00", time.Local)
	end, _ := time.ParseInLocation(time.DateTime, endDate+" 23:59:59", time.Local)
	startTime := start.UnixNano() / 1e6
	endTime := end.UnixNano() / 1e6
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用appid
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaKuaishou)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaKuaishou, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		oauthMap[v.AppId][v.UserId] = v.AccessToken
	}

	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(oauthList) / len(appIds)
	remainder := len(oauthList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		// 为每个goroutine创建局部变量
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncKuaishouDetailToday(startTime, endTime, oauthList[start:end], oauth)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

func SyncKuaishouDetailToday(start, end int64, userIds []accountrepo.OauthEntity, oauth map[string]string) {
	resChan := make(chan *kuaishouEntity.AdDetailEntity)
	resHourChan := make(chan *kuaishouEntity.AdDetailHourEntity)
	errChan := make(chan error, len(userIds))
	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	once.Do(func() {
		go func() {
			dbErr := execDetailDB(context.Background(), resChan)
			if dbErr != nil {
				errChan <- fmt.Errorf("execDetailDB err: %s", dbErr.Error())
			}
		}()
		go func() {
			dbHourErr := execDetailHourDB(context.Background(), resHourChan)
			if dbHourErr != nil {
				errChan <- fmt.Errorf("execDetailHourDB err: %s", dbHourErr.Error())
			}
		}()
	})
	for _, v := range userIds {
		wg.Add(1)
		currentItem := v
		advertiserId, _ := strconv.Atoi(currentItem.UserId)

		task := func() {
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()
			_, exists := oauth[currentItem.UserId]
			if !exists {
				return
			}
			currAdvertiserId := advertiserId
			allReq, getErr := kuaishou.AllDetailData(context.Background(), kuaishou.ReportQueryReq{
				AdvertiserId: int64(currAdvertiserId),
				AccessToken:  oauth[currentItem.UserId],
				StartTime:    start,
				EndTime:      end,
			})
			if getErr != nil {
				errChan <- fmt.Errorf("短剧广告报表明细查询接口, advertiserId: %d, token: %s,  err: %s", advertiserId, oauth[currentItem.UserId], getErr.Error())
				return
			}
			for _, row := range allReq {
				info := trans2Entity(row, int64(advertiserId), 0, 1)
				resChan <- info
			}
			for _, row := range allReq {
				infoHour := trans2EntityHour(row, int64(advertiserId))
				resHourChan <- infoHour
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done()
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(resHourChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		fmt.Println(errL.Error())
		errs = append(errs, errL)
	}
}

func execDetailHourDB(ctx context.Context, resChan <-chan *kuaishouEntity.AdDetailHourEntity) (err error) {
	// 保存数据DAO
	detailHourDao := kuaishoudao.NewAdDetailHourDao(ctx)
	var data = make([]*kuaishouEntity.AdDetailHourEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			err = detailHourDao.InsertBatchSize(data, 5000)
			if err != nil {
				errs = append(errs, err) // 收集错误，不退出
			}
			data = data[:0]
		}
	}
	if len(data) > 0 {
		err = detailHourDao.InsertBatchSize(data, 5000)
		if err != nil {
			errs = append(errs, err) // 收集错误，不退出
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execDetailHourDB errors: %v", errs)
	}
	return nil
}

func trans2EntityHour(v kuaishou.AdDetail, advertiserId int64) *kuaishouEntity.AdDetailHourEntity {
	date, _ := time.ParseInLocation(time.DateOnly, v.Date, time.Local)
	info := &kuaishouEntity.AdDetailHourEntity{
		AdvertiserId:              advertiserId,
		AccountId:                 v.AccountId,
		Date:                      date,
		Hour:                      int64(time.Now().Hour()),
		EventPayPurchaseAmount:    v.EventPayPurchaseAmount,
		TotalCharge:               v.TotalCharge,
		MiniGameIaaPurchaseAmount: v.MiniGameIaaPurchaseAmount,
	}
	return info
}

func SavePullTime(pullTime string, pullType int) error {
	detailDao := kuaishoudao.NewAdDetailDao(context.Background())
	err := detailDao.SavePullTime(pullTime, pullType)
	if err != nil {
		return err
	}
	return nil
}
