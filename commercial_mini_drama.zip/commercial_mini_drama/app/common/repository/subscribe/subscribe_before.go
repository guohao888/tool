package subscribe

import "goserver/app/common/repository"

const BeforeSubscribeEntityTable = "subscribe_before"

type BeforeSubscribeEntity struct {
	MessageId       string `gorm:"column:message_id"`        // 消息ID，唯一标识
	SubscribeTaskId int64  `gorm:"column:subscribe_task_id"` // 订阅任务ID
	AdvertiserId    string `gorm:"column:advertiser_id"`     // 消息对应的广告主账号
	Status          int    `gorm:"column:status"`            // 拉取状态
}

func (*BeforeSubscribeEntity) TableName() string {
	return BeforeSubscribeEntityTable
}

func BeforeSubscribeEntityTableName() string {
	if repository.IsDebugTable(BeforeSubscribeEntityTable) {
		return BeforeSubscribeEntityTable + "_dev"
	} else {
		return BeforeSubscribeEntityTable
	}
}
