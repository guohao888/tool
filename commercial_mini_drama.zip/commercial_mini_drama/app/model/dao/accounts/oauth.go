package accounts

import (
	"context"
	"errors"
	"github.com/avast/retry-go"
	"github.com/jinzhu/gorm"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"time"
)

type OauthDao struct {
	Ctx context.Context
}

func NewOauthDao(ctx context.Context) *OauthDao {
	return &OauthDao{Ctx: ctx}
}

func (d *OauthDao) ExistOther(media string, appId string, oauthId string) (bool, error) {
	db := dorisdb.DorisClient()

	var exist accountrepo.OauthEntity
	err := db.Table(accountrepo.OauthTableName()).
		Select("media, oauth_id").
		Where("media = ? and app_id = ? and oauth_id != ?", media, appId, oauthId).
		First(&exist).
		Error
	if err != nil {
		if gorm.IsRecordNotFoundError(err) {
			return false, nil
		} else {
			return false, err
		}
	}

	if exist.OauthId != "" {
		return true, nil
	}

	return false, nil
}

func (d *OauthDao) Save(oauth accountrepo.OauthEntity) error {
	db := dorisdb.DorisClient()

	var exist accountrepo.OauthEntity
	err := db.Table(accountrepo.OauthTableName()).Select("media, oauth_id").Where("media = ? and oauth_id = ?", oauth.Media, oauth.OauthId).First(&exist).Error

	if err == nil && exist.OauthId != "" && exist.Media != "" { // 没有错误，且存在，更新
		err = d.UpdateById(exist.Media, exist.OauthId, &oauth)
	} else if err != nil && errors.Is(err, gorm.ErrRecordNotFound) { // 有错误，是不存在的错误，创建
		err = retry.Do(
			func() error {
				err = db.Table(accountrepo.OauthTableName()).Save(&oauth).Error
				return err
			},
			retry.Delay(time.Second*1),
			retry.Attempts(5),
		)
	}

	return err
}

func (d *OauthDao) SavePush(oauth accountrepo.OauthEntity) error {
	db := dorisdb.DorisClient()

	var exist accountrepo.OauthEntity
	err := db.Table("oauth_push").Select("media, oauth_id").Where("media = ? and oauth_id = ?", oauth.Media, oauth.OauthId).First(&exist).Error

	if err == nil && exist.OauthId != "" && exist.Media != "" { // 没有错误，且存在，更新
		err = d.UpdateById(exist.Media, exist.OauthId, &oauth)
	} else if err != nil && errors.Is(err, gorm.ErrRecordNotFound) { // 有错误，是不存在的错误，创建
		err = retry.Do(
			func() error {
				err = db.Table("oauth_push").Save(&oauth).Error
				return err
			},
			retry.Delay(time.Second*1),
			retry.Attempts(5),
		)
	}

	return err
}

func (d *OauthDao) ListOauthByMediaAndMasterAppId(media string, masterAppId string) ([]accountrepo.OauthEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.OauthTableName())
	var list []accountrepo.OauthEntity
	err := q.Where("media = ? and app_id = ?", media, masterAppId).Order("created_at desc").Find(&list).Error
	if err != nil {
		return nil, err
	}

	return list, err
}

func (d *OauthDao) ListOauthByMediaAppIds(media string, appIds []string) ([]accountrepo.OauthEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.OauthTableName())
	var list []accountrepo.OauthEntity
	if media != "" {
		q = q.Where("media = ?", media)
	}
	if len(appIds) > 0 {
		q = q.Where("app_id in (?)", appIds)
	}
	err := q.Order("created_at desc").Find(&list).Error
	if err != nil {
		return nil, err
	}

	return list, err
}

type ListOauthParams struct {
	Media    []string
	OauthIds []string
}

func (d *OauthDao) ListOauth(params ListOauthParams) ([]accountrepo.OauthEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.OauthTableName())
	var list []accountrepo.OauthEntity
	if len(params.Media) > 0 {
		q = q.Where("media in (?)", params.Media)
	}
	if len(params.OauthIds) > 0 {
		q = q.Where("oauth_id in (?)", params.OauthIds)
	}
	err := q.Order("created_at desc").Find(&list).Error
	if err != nil {
		return nil, err
	}

	return list, err
}

func (d *OauthDao) ListOauthByMedia(media ...string) ([]accountrepo.OauthEntity, error) {
	return d.ListOauth(ListOauthParams{Media: media})
}

func (d *OauthDao) UpdateById(media string, oauthId string, oauth *accountrepo.OauthEntity) error {
	db := dorisdb.DorisClient()

	err := retry.Do(
		func() error {
			err := db.Model(&accountrepo.OauthEntity{}).
				Select("access_token", "refresh_token", "expire_at", "refresh_expire_at", "expire_time", "refresh_expire_time", "ext").
				Where("media = ? and oauth_id = ?", media, oauthId).
				Updates(oauth).Error
			return err
		},
		retry.Delay(time.Second*1),
		retry.Attempts(5),
	)
	return err
}

func (d *OauthDao) DistinctAppIds(media string) ([]string, error) {
	db := dorisdb.DorisClient()

	var res []string
	err := db.Table(accountrepo.OauthTableName()).
		Where("media = ?", media).
		Order("app_id asc").
		Pluck("DISTINCT app_id", &res).
		Error
	return res, err
}

func (d *OauthDao) DistinctUserIds(media string) ([]string, error) {
	db := dorisdb.DorisClient()

	var res []string
	err := db.Table(accountrepo.OauthTableName()).
		Where("media = ?", media).
		Order("user_id asc").
		Pluck("DISTINCT user_id", &res).
		Error
	return res, err
}

func (d *OauthDao) DistinctUserIdsInfo(media string) ([]accountrepo.OauthEntity, error) {
	db := dorisdb.DorisClient()

	var res []accountrepo.OauthEntity
	sql := "SELECT app_id, user_id FROM oauth_dev WHERE media = '" + media + "' GROUP BY app_id, user_id "
	err := db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	return res, nil
}

type OauthUserIdOverview struct {
	UserAppIdCount  int `gorm:"column:user_app_id_count"`
	TotalAppIdCount int `gorm:"column:total_app_id_count"`
}

func (d *OauthDao) GetOauthUserIdOverview(userId string, media string) (*OauthUserIdOverview, error) {
	db := dorisdb.DorisClient()

	q1 := db.Table(accountrepo.OauthTableName()).Select("COUNT(*)").Where("user_id = ? and media = ?", userId, media).SubQuery()
	q2 := db.Table(accountrepo.OauthTableName()).Select("COUNT(DISTINCT app_id)").Where("media = ?", media).SubQuery()

	var o OauthUserIdOverview
	err := db.Raw("select ? as user_app_id_count, ? as total_app_id_count", q1, q2).Find(&o).Error
	if err != nil {
		return nil, err
	}

	return &o, err
}
func (d *OauthDao) GetTokenByOauthIDs(IDs []string) ([]accountrepo.OauthEntity, error) {
	var res []accountrepo.OauthEntity
	db := dorisdb.DorisClient()
	err := db.Table(accountrepo.OauthTableName()).
		Select("oauth_id, access_token,user_id").
		Where("oauth_id in (?)", IDs).
		Find(&res).Error
	return res, err

}

func (d *OauthDao) ListOauthPush(params ListOauthParams) ([]accountrepo.OauthEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table("oauth_push")
	var list []accountrepo.OauthEntity
	if len(params.Media) > 0 {
		q = q.Where("media in (?)", params.Media)
	}
	if len(params.OauthIds) > 0 {
		q = q.Where("oauth_id in (?)", params.OauthIds)
	}
	err := q.Order("created_at desc").Find(&list).Error
	if err != nil {
		return nil, err
	}

	return list, err
}

func (d *OauthDao) ListOauthPushByMedia(media ...string) ([]accountrepo.OauthEntity, error) {
	return d.ListOauthPush(ListOauthParams{Media: media})
}

func (d *OauthDao) UpdatePushById(media string, oauthId string, oauth *accountrepo.OauthEntity) error {
	db := dorisdb.DorisClient()

	err := db.Model(OauthPush{}).Debug().
		Select("access_token", "refresh_token", "expire_at", "refresh_expire_at", "expire_time", "refresh_expire_time", "ext").
		Where("media = ? and oauth_id = ?", media, oauthId).
		Updates(oauth).Error
	return err
}

// OauthPush 平台oauth授权表
type OauthPush struct {
	Media             string    `gorm:"column:media"`               // 授权媒体
	OauthId           string    `gorm:"column:oauth_id"`            // 授权唯一标识
	AccessToken       string    `gorm:"column:access_token"`        // access token
	RefreshToken      string    `gorm:"column:refresh_token"`       // refresh token
	ExpireAt          time.Time `gorm:"column:expire_at"`           // access token 到期时间
	RefreshExpireAt   time.Time `gorm:"column:refresh_expire_at"`   // refresh token 到期时间
	ExpireTime        int64     `gorm:"column:expire_time"`         // access token 有效时长
	RefreshExpireTime int64     `gorm:"column:refresh_expire_time"` // refresh token 有效时长
	AppId             string    `gorm:"column:app_id"`              // app id
	UserId            string    `gorm:"column:user_id"`             // 管家账户ID
	AppSecret         string    `gorm:"column:app_secret"`          // app secret
	Ext               string    `gorm:"column:ext"`                 // 扩展数据，根据平台存储所需数据
	CreatedAt         time.Time `gorm:"column:created_at"`          // 创建时间
	UpdatedAt         time.Time `gorm:"column:updated_at"`          // 更新时间
}
