package fanqie

import (
	"context"
	"goserver/app/common/dto/fanqie"
	"goserver/app/common/dto/page"
	repo "goserver/app/common/repository/fanqie"
	"goserver/app/library/driver/dorisdb"
	"strings"
)

// TomatoIAACoefficientDao 番茄IAA系数DAO
type TomatoIAACoefficientDao struct {
	Ctx context.Context
}

func NewTomatoIAACoefficientDao(ctx context.Context) *TomatoIAACoefficientDao {
	return &TomatoIAACoefficientDao{Ctx: ctx}
}

// InsertCoefficient 插入数据
func (t *TomatoIAACoefficientDao) InsertCoefficient(data []*repo.IAACoefficientEntity) error {
	db := dorisdb.DorisClient()
	sqlStr := "INSERT INTO " + repo.IAACoefficientTableName() + " ( search_date, coefficient ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?),"
		vals = append(vals,
			v.SearchDate,
			v.Coefficient,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := db.Exec(sqlStr, vals...).Error
	return err
}

// FindCoefficientList 查询系数表数据
func (t *TomatoIAACoefficientDao) FindCoefficientList(params *fanqie.IAACoefficientFilter) (*page.Paginator, error) {
	db := dorisdb.DorisClient()

	var res []*repo.IAACoefficientEntity
	q := db.Table(repo.IAACoefficientTableName())
	q2 := db.Table(repo.IAACoefficientTableName())
	if params.StartDate != "" && params.EndDate != "" {
		q = q.Where("DATE(search_date) BETWEEN ? AND ?", params.StartDate, params.EndDate)
		q2 = q2.Where("DATE(search_date) BETWEEN ? AND ?", params.StartDate, params.EndDate)
	}
	var total int64
	err := q2.Count(&total).Error
	pagination := params.Pagination
	err = q.Order("DATE(search_date) desc").Offset(pagination.GetOffset()).Limit(pagination.GetLimit()).Find(&res).Error
	if err != nil {
		return nil, err
	}
	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)
	return &paginator, nil
}
