package optimizer

import (
	"context"
	"errors"
	"github.com/jinzhu/gorm"
	"github.com/spf13/cast"
	"goserver/app/common/dto/optimizerdto"
	"goserver/app/common/dto/page"
	"goserver/app/common/repository/optimizer"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/library/driver/redisdb"
	"goserver/app/library/myerror"
	"time"
)

const COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_RELATION_ID = "commercial_mini_drama:OptimizerCityRelationId" // 优化师地区关联表主键

type OptimizerCityRelationDao struct {
	Ctx context.Context
}

func NewOptimizerCityRelationDao(ctx context.Context) *OptimizerCityRelationDao {
	return &OptimizerCityRelationDao{Ctx: ctx}
}

// AddOptimizerCityRelation 添加优化师地区关联
func (m *OptimizerCityRelationDao) AddOptimizerCityRelation(data *optimizerdto.OptimizerCityRelationInfoParams) error {
	db := dorisdb.DorisClient()
	tx := db.Begin() // 开始事务

	// 验证优化师地区ID是否存在
	qOptimizerCityId := tx.Table(optimizer.OptimizerCityEntityTableName())
	qOptimizerCityId = qOptimizerCityId.Where("optimizer_city_id = ?", data.OptimizerCityId)
	var OptimizerCityIdInfo optimizer.OptimizerCityEntity
	err := qOptimizerCityId.First(&OptimizerCityIdInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}
	if OptimizerCityIdInfo.OptimizerCityId == 0 {
		tx.Rollback()                                                     // 回滚事务
		return errors.New(myerror.OptimizerCityPrimaryExistError.Message) // 优化师地区ID不存在
	}

	// 验证优化师ID是否存在
	qOptimizerId := tx.Table(optimizer.OptimizerEntityTableName())
	qOptimizerId = qOptimizerId.Where("optimizer_name = ?", data.OptimizerName)
	var OptimizerIdInfo optimizer.OptimizerEntity
	err = qOptimizerId.First(&OptimizerIdInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}

	if OptimizerIdInfo.OptimizerId != 0 { // 编辑
		// 验证优化师区域关联ID是否存在
		qOptimizerCityRelationId := tx.Table(optimizer.OptimizerCityRelationEntityTableName())
		qOptimizerCityRelationId = qOptimizerCityRelationId.Where("optimizer_id = ?", OptimizerIdInfo.OptimizerId)
		var OptimizerCityRelationIdInfo optimizer.OptimizerCityRelationEntity
		err = qOptimizerCityRelationId.First(&OptimizerCityRelationIdInfo).Error
		if err != nil && !gorm.IsRecordNotFoundError(err) {
			tx.Rollback() // 回滚事务
			return err
		}
		if OptimizerCityRelationIdInfo.OptimizerCityRelationId == 0 {
			tx.Rollback()                                                    // 回滚事务
			return errors.New(myerror.OptimizerNotExistSetCityError.Message) // 当前优化师未配置地区
		}

		// 更新优化师(优化师名称不可修改，目前只能修改手机号)
		updateOptimizer := tx.Table(optimizer.OptimizerEntityTableName())
		err = updateOptimizer.Where("optimizer_id = ?", OptimizerIdInfo.OptimizerId).Update(map[string]interface{}{
			"phone":      data.Phone,
			"updated_at": time.Now(),
		}).Error
		if err != nil {
			tx.Rollback() // 回滚事务
			return err
		}

		// 新增优化师区域关联数据
		updateOptimizerCityRelation := tx.Table(optimizer.OptimizerCityRelationEntityTableName())

		OptimizerCityRelationId := OptimizerCityRelationIdInfo.OptimizerCityRelationId

		OptimizerCityRelationIdInfo.OptimizerCityRelationId = 0
		OptimizerCityRelationIdInfo.OptimizerCityId = data.OptimizerCityId
		OptimizerCityRelationIdInfo.Status = data.Status
		OptimizerCityRelationIdInfo.UpdatedAt = time.Now()
		err = updateOptimizerCityRelation.Where("optimizer_city_relation_id = ?", OptimizerCityRelationId).Update(OptimizerCityRelationIdInfo).Error
		if err != nil {
			tx.Rollback() // 回滚事务
			return err
		}

	} else { // 新增
		// 验证优化师是否绑定其他地区
		qOptimizerCityRelationViewId := tx.Table(optimizer.OptimizerCityRelationViewEntityTableName())
		qOptimizerCityRelationViewId = qOptimizerCityRelationViewId.Where("optimizer_name = ?", data.OptimizerName)
		var OptimizerCityRelationViewIdInfo optimizer.OptimizerCityRelationViewEntity
		err = qOptimizerCityRelationViewId.First(&OptimizerCityRelationViewIdInfo).Error
		if err != nil && !gorm.IsRecordNotFoundError(err) {
			tx.Rollback() // 回滚事务
			return err
		}
		if OptimizerCityRelationViewIdInfo.OptimizerCityRelationId != 0 {
			tx.Rollback()                                                 // 回滚事务
			return errors.New(myerror.OptimizerExistSetCityError.Message) // 当前优化师已配置地区
		}

		// ************************   优化师最大ID ***************************************
		var redisMaxOptimizerId int64 = 0 // 查找最大优化师ID

		redisMaxOptimizerId, err = redisdb.GetIncrValue(COMMERCIAL_MINI_DRAMA_OPTIMIZER_ID)
		_ = redisdb.SetKeyExpire(COMMERCIAL_MINI_DRAMA_OPTIMIZER_ID, 5*3600)

		if err != nil {
			tx.Rollback() // 回滚事务
			return err
		}

		if redisMaxOptimizerId == 1 {
			var MaxOptimizerIdInfo optimizer.OptimizerEntity
			err = tx.Table(optimizer.OptimizerEntityTableName()).Order("optimizer_id DESC").First(&MaxOptimizerIdInfo).Error
			if err != nil && !gorm.IsRecordNotFoundError(err) {
				tx.Rollback() // 回滚事务
				return err
			}
			optimizerId := "0"
			if MaxOptimizerIdInfo.OptimizerId != 0 {
				optimizerId = cast.ToString(MaxOptimizerIdInfo.OptimizerId)
			}

			//生成优化师数据主键 利用redis incr
			err = redisdb.Set(COMMERCIAL_MINI_DRAMA_OPTIMIZER_ID, optimizerId)
			if err != nil {
				tx.Rollback() // 回滚事务
				return err
			}

			// 获取关联最大值
			redisMaxOptimizerId, err = redisdb.GetIncrValue(COMMERCIAL_MINI_DRAMA_OPTIMIZER_ID)
			if err != nil {
				tx.Rollback() // 回滚事务
				return err
			}
		}

		// 安全验证
		if redisMaxOptimizerId == 0 {
			tx.Rollback()                                                        // 回滚事务
			return errors.New(myerror.OptimizerCityRelationPrimaryError.Message) // 优化师地区关联主键异常
		}

		var existOptimizerInfo optimizer.OptimizerCityRelationEntity
		err = tx.Table(optimizer.OptimizerCityRelationEntityTableName()).
			Where("optimizer_id = ?", redisMaxOptimizerId).First(&existOptimizerInfo).Error
		if err != nil && !gorm.IsRecordNotFoundError(err) {
			tx.Rollback() // 回滚事务
			return err
		}

		if err == nil && existOptimizerInfo.OptimizerCityRelationId != 0 {
			tx.Rollback()                                                        // 回滚事务
			return errors.New(myerror.OptimizerCityRelationPrimaryError.Message) // // 优化师地区关联主键异常
		}

		// ************************  优化师地区关联最大ID **********************************
		var redisMaxRelationId int64 = 0 // 查找最大优化师地区关联ID

		redisMaxRelationId, err = redisdb.GetIncrValue(COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_RELATION_ID)
		_ = redisdb.SetKeyExpire(COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_RELATION_ID, 5*3600)

		if err != nil {
			tx.Rollback() // 回滚事务
			return err
		}

		if redisMaxRelationId == 1 {
			var MaxIdInfo optimizer.OptimizerCityRelationEntity
			err = tx.Table(optimizer.OptimizerCityRelationEntityTableName()).Order("optimizer_city_relation_id DESC").First(&MaxIdInfo).Error
			if err != nil && !gorm.IsRecordNotFoundError(err) {
				tx.Rollback() // 回滚事务
				return err
			}
			optimizerCityRelationId := "0"
			if MaxIdInfo.OptimizerCityRelationId != 0 {
				optimizerCityRelationId = cast.ToString(MaxIdInfo.OptimizerCityRelationId)
			}

			//生成优化师数据主键 利用redis incr
			err = redisdb.Set(COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_RELATION_ID, optimizerCityRelationId)
			if err != nil {
				tx.Rollback() // 回滚事务
				return err
			}

			// 获取关联最大值
			redisMaxRelationId, err = redisdb.GetIncrValue(COMMERCIAL_MINI_DRAMA_OPTIMIZER_CITY_RELATION_ID)
			if err != nil {
				tx.Rollback() // 回滚事务
				return err
			}
		}

		// 安全验证
		if redisMaxRelationId == 0 {
			tx.Rollback()                                                        // 回滚事务
			return errors.New(myerror.OptimizerCityRelationPrimaryError.Message) // 优化师地区关联主键异常
		}

		var existInfo optimizer.OptimizerCityRelationEntity
		err = tx.Table(optimizer.OptimizerCityRelationEntityTableName()).
			Where("optimizer_city_relation_id = ?", redisMaxRelationId).First(&existInfo).Error
		if err != nil && !gorm.IsRecordNotFoundError(err) {
			tx.Rollback() // 回滚事务
			return err
		}

		if err == nil && existInfo.OptimizerCityRelationId != 0 {
			tx.Rollback()                                                        // 回滚事务
			return errors.New(myerror.OptimizerCityRelationPrimaryError.Message) // 优化师地区关联主键异常
		}

		// 增加优化师为空逻辑判断
		if len(data.OptimizerName) == 0 {
			return errors.New(myerror.OptimizerNameEmptyError.Message) // 优化师名称不能为空
		}

		// 新增优化师数据
		insertOptimizer := tx.Table(optimizer.OptimizerEntityTableName())
		optimizerData := optimizer.OptimizerEntity{
			OptimizerId:   redisMaxOptimizerId,
			OptimizerName: data.OptimizerName,
			Phone:         data.Phone,
			CreatedAt:     time.Now(),
			UpdatedAt:     time.Now(),
		}

		err = insertOptimizer.Create(optimizerData).Error
		if err != nil {
			tx.Rollback() // 回滚事务
			return err
		}

		// 新增优化师地区关联数据
		insertRelation := tx.Table(optimizer.OptimizerCityRelationEntityTableName())
		err = insertRelation.Create(optimizer.OptimizerCityRelationEntity{
			OptimizerCityRelationId: redisMaxRelationId,
			OptimizerId:             optimizerData.OptimizerId,
			OptimizerCityId:         data.OptimizerCityId,
			Status:                  data.Status,
			CreatedAt:               time.Now(),
			UpdatedAt:               time.Now(),
		}).Error
		if err != nil {
			tx.Rollback() // 回滚事务
			return err
		}

	}
	tx.Commit() // 提交事务
	return nil
}

// UpdateOptimizerCityRelation 编辑优化师地区关联
func (m *OptimizerCityRelationDao) UpdateOptimizerCityRelation(data *optimizerdto.OptimizerCityRelationInfoParams) error {
	db := dorisdb.DorisClient()
	tx := db.Begin() // 开始事务

	// 验证优化师地区ID是否存在
	qOptimizerCityId := tx.Table(optimizer.OptimizerCityEntityTableName())
	qOptimizerCityId = qOptimizerCityId.Where("optimizer_city_id = ?", data.OptimizerCityId)
	var OptimizerCityIdInfo optimizer.OptimizerCityEntity
	err := qOptimizerCityId.First(&OptimizerCityIdInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}
	if OptimizerCityIdInfo.OptimizerCityId == 0 {
		tx.Rollback()                                              // 回滚事务
		return errors.New(myerror.OptimizerIdNoExistError.Message) // 优化师地区ID不存在
	}

	// 验证优化师区域关联ID是否存在
	qOptimizerCityRelationId := tx.Table(optimizer.OptimizerCityRelationEntityTableName())
	qOptimizerCityRelationId = qOptimizerCityRelationId.Where("optimizer_city_relation_id = ?", data.OptimizerCityRelationId)
	var OptimizerCityRelationIdInfo optimizer.OptimizerCityRelationEntity
	err = qOptimizerCityRelationId.First(&OptimizerCityRelationIdInfo).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		tx.Rollback() // 回滚事务
		return err
	}
	if OptimizerCityRelationIdInfo.OptimizerCityRelationId == 0 {
		tx.Rollback()                                                          // 回滚事务
		return errors.New(myerror.OptimizerCityRelationIdNoExistError.Message) // 当前优化师地区关联ID不存在
	}

	// 更新优化师(优化师名称不可修改，目前只能修改手机号)
	updateOptimizer := tx.Table(optimizer.OptimizerEntityTableName())
	err = updateOptimizer.Where("optimizer_id = ?", OptimizerCityRelationIdInfo.OptimizerId).Update(map[string]interface{}{
		"phone":      data.Phone,
		"updated_at": time.Now(),
	}).Error
	if err != nil {
		tx.Rollback() // 回滚事务
		return err
	}

	// 新增优化师区域关联数据
	update := tx.Table(optimizer.OptimizerCityRelationEntityTableName())

	OptimizerCityRelationIdInfo.OptimizerCityRelationId = 0
	OptimizerCityRelationIdInfo.OptimizerCityId = data.OptimizerCityId
	OptimizerCityRelationIdInfo.Status = data.Status
	OptimizerCityRelationIdInfo.UpdatedAt = time.Now()
	err = update.Where("optimizer_city_relation_id = ?", data.OptimizerCityRelationId).Update(OptimizerCityRelationIdInfo).Error
	if err != nil {
		tx.Rollback() // 回滚事务
		return err
	}

	tx.Commit() // 提交事务
	return nil
}

// OptimizerCityInfoList 优化师地区列表
func (m *OptimizerCityRelationDao) OptimizerCityRelationInfoList(params *optimizerdto.OptimizerCityRelationInfoListParams) (*page.Paginator, error) {
	db := dorisdb.DorisClient()
	q := db.Table(optimizer.OptimizerCityEntityTableName())  // 分页
	q2 := db.Table(optimizer.OptimizerCityEntityTableName()) // 总数

	if params.OptimizerCityName != "" {
		q = q.Where("optimizer_city_name like ?", "%"+params.OptimizerCityName+"%")
		q2 = q2.Where("optimizer_city_name like ?", "%"+params.OptimizerCityName+"%")
	}

	var total int64
	err := q2.Count(&total).Error
	// 分页数据
	pagination := params.Pagination
	var res []*optimizer.OptimizerCityEntity
	err = q.Offset(pagination.GetOffset()).Limit(pagination.GetLimit()).Order("created_at desc").Find(&res).Error
	if err != nil {
		return nil, err
	}
	paginator := page.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, res)

	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return nil, err
	}
	return &paginator, nil
}
