package warningdto

import (
	"github.com/gin-gonic/gin"
	"goserver/app/library/myerror"
)

type AlbumsReq struct {
	AlbumList []string `json:"album_list"`
}

// NewAlbumsReq 获取剧目列表
func NewAlbumsReq(c *gin.Context) *AlbumsReq {
	req := &AlbumsReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}
