package subscribe

import (
	"context"
	"goserver/app/common/dto/subscribedto"
	entity "goserver/app/common/repository/subscribe"
	"goserver/app/model/dao/subscribe"
	"strconv"
)

type SubscribedService struct {
	Ctx context.Context
}

func NewSubscribedService(ctx context.Context) *SubscribedService {
	return &SubscribedService{Ctx: ctx}
}

func (s *SubscribedService) InsertBeforeTask(params []subscribedto.PostInfoReq) error {
	subscribeDao := subscribe.NewBeforeSubscribeDao(s.Ctx)
	var list []*entity.BeforeSubscribeEntity
	for _, param := range params {
		for _, v := range param.AdvertiserIds {
			info := &entity.BeforeSubscribeEntity{
				MessageId:       param.MessageId,
				SubscribeTaskId: param.SubscribeTaskId,
				AdvertiserId:    strconv.Itoa(int(v)),
				Status:          0,
			}
			list = append(list, info)
		}
	}
	err := subscribeDao.InsertBatchSizeBeforeTask(list, 2000)
	if err != nil {
		return err
	}
	return nil
}

func (s *SubscribedService) InsertTodayTask(params []subscribedto.PostInfoReq) error {
	subscribeDao := subscribe.NewTodaySubscribeDao(s.Ctx)
	var list []*entity.TodaySubscribeEntity
	for _, param := range params {
		for _, v := range param.AdvertiserIds {
			info := &entity.TodaySubscribeEntity{
				MessageId:       param.MessageId,
				SubscribeTaskId: param.SubscribeTaskId,
				AdvertiserId:    strconv.Itoa(int(v)),
				Status:          0,
			}
			list = append(list, info)
		}
	}
	err := subscribeDao.InsertBatchSizeTodayTask(list, 2000)
	if err != nil {
		return err
	}
	return nil
}
