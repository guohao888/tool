package fanqie

import (
	"goserver/app/common/repository"
	"time"
)

const IAAOrderEntityTable = "tomato_iaa_award"

// IAAOrderEntity 番茄IAA订单数据
type IAAOrderEntity struct {
	EcpmNo        string    `gorm:"column:ecpm_no"`        // 激励收益的唯一键，对齐抖开接口的req_id
	DeviceId      string    `gorm:"column:device_id"`      // 脱敏后的用户设备ID
	EventTime     string    `gorm:"column:event_time"`     // 激励点击的时间戳
	DistributorId string    `gorm:"column:distributor_id"` // 快应用/公众号对应distributor_id
	AppId         string    `gorm:"column:app_id"`         // 公众号/快应用/小程序id（分销平台id）【v1.2】
	AppName       string    `gorm:"column:app_name"`       // 快应用/公众号/小程序名称【v1.2】
	PromotionId   string    `gorm:"column:promotion_id"`   // 推广链id
	EcpmCost      string    `gorm:"column:ecpm_cost"`      // 激励点击金额，单位十万分之一元
	EventDate     time.Time `gorm:"column:event_date"`     // 激励点击日期
	EventHour     string    `gorm:"column:event_hour"`     // 激励点击小时
	RegisterTime  string    `gorm:"column:register_time"`  // 用户染色时间戳
	RegisterDate  time.Time `gorm:"column:register_date"`  // 用户染色日期
	RegisterHour  string    `gorm:"column:register_hour"`  // 用户染色小时
	BookId        string    `gorm:"column:book_id"`        // 染色推广链的短剧ID
	BookName      string    `gorm:"column:book_name"`      // 染色推广链的短剧名称
	BookGender    string    `gorm:"column:book_gender"`    // 染色推广链短剧性别(0女生、1男生、2无性别)
	BookCategory  string    `gorm:"column:book_category"`  // 染色推广链的短剧类型
}

func (*IAAOrderEntity) TableName() string {
	return IAAOrderEntityTable
}

func IAAOrderTableName() string {
	if repository.IsDebugTable(IAAOrderEntityTable) {
		return IAAOrderEntityTable + "_dev"
	} else {
		return IAAOrderEntityTable
	}
}
