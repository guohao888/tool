package middleware

import (
	"goserver/app/library/playlet/cache"
	"resty.dev/v3"
)

const (
	HeaderAccessToken = "Access-Token"
	HeaderOauthId     = "Oauth-Id"
)

func RequestAccessToken(c *resty.Client, r *resty.Request) error {
	oauthId := r.Header.Get(HeaderOauthId)
	if oauthId != "" { // 根据header中的oauth_id获取最新的access_token
		accessToken, err := cache.GetAccessTokenByOauthId(oauthId)
		if err == nil && accessToken != "" {
			r.Header.Set(HeaderAccessToken, accessToken)
		}
	} else { // 根据access_token获取最新的access_token
		accessToken := r.Header.Get(HeaderAccessToken)
		if accessToken != "" {
			latestAccessToken, err := cache.GetLatestAccessToken(accessToken)
			if err == nil && latestAccessToken != "" {
				r.Header.Set(HeaderAccessToken, latestAccessToken)
			}
		}
	}

	return nil
}
