package mediareport

import (
	"github.com/shopspring/decimal"
	"goserver/app/common/repository"
	"time"
)

const ReportMediaEntityTable = "report_media"

type ReportMediaEntity struct {
	AdvertiserId  string          `gorm:"column:advertiser_id"`  // 账号ID
	MaterialId    string          `gorm:"column:material_id"`    // 媒体ID
	PromotionId   string          `gorm:"column:promotion_id"`   // 广告ID
	ProjectId     string          `gorm:"column:project_id"`     // 项目ID
	PromotionName string          `gorm:"column:promotion_name"` // 广告名称
	CreateTime    time.Time       `gorm:"column:create_time"`    // 创建时间=拉取时间
	CreateHour    string          `gorm:"column:create_hour"`    // 小时
	ConvertCnt    int64           `gorm:"column:convert_cnt"`    // 转化数
	ClickCnt      int64           `gorm:"column:click_cnt"`      // 点击数
	ShowCnt       int64           `gorm:"column:show_cnt"`       // 展示数
	StatCost      decimal.Decimal `gorm:"column:stat_cost"`      // 消耗
	Active        int64           `gorm:"column:active"`         // 媒体激活
	ActivePay     int64           `gorm:"column:active_pay"`     // 媒体付费认量

}

func (*ReportMediaEntity) TableName() string {
	return ReportMediaEntityTable
}

func ReportMediaTableName() string {
	if repository.IsDebugTable(ReportMediaEntityTable) {
		return ReportMediaEntityTable + "_dev"
	} else {
		return ReportMediaEntityTable
	}
}
