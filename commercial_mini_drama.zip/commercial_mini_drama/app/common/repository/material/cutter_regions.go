package material

import (
	"goserver/app/common/repository"
)

const CutterRegionsTable = "cutter_regions"

type CutterRegionsEntity struct {
	FileCutter   string `gorm:"column:file_cutter"`   // 剪辑师名称
	CutterRegion string `gorm:"column:cutter_region"` // 剪辑师地域
}

func (*CutterRegionsEntity) TableName() string {
	return CutterRegionsTableName()
}

func CutterRegionsTableName() string {
	if repository.IsDebugTable(CutterRegionsTable) {
		return CutterRegionsTable //+ "_dev"
	} else {
		return CutterRegionsTable
	}
}
