package roidto

import (
	"errors"
	timeUtil "goserver/app/library/utils/time"
	"time"
)

type DateRangeExecutorParams struct {
	AccountId string `json:"account_id"` // 账户id
	Start     string `json:"start"`      // 起始时间，格式: 2024-05-16
	End       string `json:"end"`        // 结束时间，格式: 2024-05-17 (左闭、右闭)
	PointDate string `json:"point_date"` // 指定日期 格式: 2024-05-17
	PrevDays  []int  `json:"prev_days"`  // 前置几天
}

func (r DateRangeExecutorParams) CrontabDateList() ([]time.Time, error) {
	if (r.Start != "" && r.End == "") || (r.Start == "" && r.End != "") {
		return nil, errors.New("start date and end date must exist simultaneously")
	}

	var crontabTimeList []time.Time
	if r.PointDate != "" {
		pointDate, err := time.ParseInLocation(time.DateOnly, r.PointDate, time.Local)
		if err != nil {
			return nil, err
		}
		crontabTimeList = append(crontabTimeList, pointDate)
	} else if r.Start != "" && r.End != "" {
		s, err := time.ParseInLocation(time.DateOnly, r.Start, time.Local)
		if err != nil {
			return nil, err
		}
		e, err := time.ParseInLocation(time.DateOnly, r.End, time.Local)
		if err != nil {
			return nil, err
		}
		for s.Before(e.Add(1 * time.Hour)) {
			crontabTimeList = append(crontabTimeList, s)
			s = s.Add(24 * time.Hour)
		}
	} else if len(r.PrevDays) > 0 {
		m := make(map[int]struct{}) // 用于去重

		now, _ := timeUtil.GetDayTime(time.Now())
		for _, day := range r.PrevDays {
			if _, ok := m[day]; !ok { // 去重复
				crontabTimeList = append(crontabTimeList, now.AddDate(0, 0, -1*day))
				m[day] = struct{}{}
			}
		}
	} else {
		dateTime, _ := timeUtil.GetDayTime(time.Now())
		crontabTimeList = append(crontabTimeList, dateTime)
	}

	return crontabTimeList, nil
}
