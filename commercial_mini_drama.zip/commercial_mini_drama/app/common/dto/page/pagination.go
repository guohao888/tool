package page

type Pagination struct {
	Page     int64 `json:"page,omitempty"`      // 当前页
	PageSize int64 `json:"page_size,omitempty"` // 分页数量
}

func (p *Pagination) GetLimit() int64 {
	return p.GetPageSize()
}

func (p *Pagination) GetPage() int64 {
	if p.Page == 0 {
		p.Page = 1
	}
	return p.Page
}

func (p *Pagination) GetPageSize() int64 {
	if p.PageSize == 0 {
		p.PageSize = 100
	}
	return p.PageSize
}

func (p *Pagination) GetOffset() int64 {
	return (p.GetPage() - 1) * p.GetPageSize()
}

type Paginator struct {
	Page      int64       `json:"page"`
	PageSize  int64       `json:"page_size"`
	Total     int64       `json:"total"`
	TotalPage int64       `json:"total_page"`
	List      interface{} `json:"list"`
}

func NewPaginator(page int64, pageSize int64, total int64, list interface{}) Paginator {
	var pos int64 = 1
	if total%pageSize == 0 {
		pos = 0
	}
	totalPage := total/pageSize + pos

	return Paginator{
		Page:      page,
		PageSize:  pageSize,
		TotalPage: totalPage,
		Total:     total,
		List:      list,
	}
}

type Sort struct {
	Key   string `json:"key"`   // 按那个key排序
	Order string `json:"order"` // 排序方式, 升序:asc 降序: desc
}
