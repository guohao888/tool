package kuaishoudto

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common"
	"goserver/app/library/myerror"
	"goserver/app/library/utils"
	timeUtil "goserver/app/library/utils/time"
	"strconv"
	"strings"
	"time"
)

type FilterOptionsReq struct {
	common.CommonParams
}

func NewFilterOptionsReq(c *gin.Context) *FilterOptionsReq {
	return &FilterOptionsReq{}
}

type CoreDataFilterOptions struct {
	GroupType    []IDLabel     `json:"group_type"`    //时间周期
	SeriesName   SelectOption  `json:"series_name"`   //剧目名称
	SeriesType   SelectOption2 `json:"series_type"`   //付费类型
	ResourceType SelectOption2 `json:"resource_type"` //流量来源
	KpiFilter    []KpiOption   `json:"kpi_filter"`    //指标筛选
}

type AdDataFilterOptions struct {
	GroupType     []IDLabel     `json:"group_type"`     //时间周期
	SeriesType    SelectOption2 `json:"series_type"`    //付费类型
	AccountName   SelectOption  `json:"account_name"`   //账户名称
	SeriesName    SelectOption  `json:"series_name"`    //剧目名称
	OptimizerName SelectOption  `json:"optimizer_name"` //投放人员
	GroupBy       SelectOption  `json:"group_by"`       //维度聚合
	KpiFilter     []KpiOption   `json:"kpi_filter"`     //指标筛选
}

type FilterSearchReq struct {
	common.CommonParams
	Keywords   string `json:"keywords" binding:"required"`    // 起始时间
	SearchType string `json:"search_type" binding:"required"` // 结束时间
}

func NewFilterSearchReq(c *gin.Context) *FilterSearchReq {
	req := &FilterSearchReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.Keywords = utils.HtmlEncode(req.Keywords)
	searchTypeArr := []string{"account", "series"}
	if req.Keywords == "" || !utils.InArray(req.SearchType, searchTypeArr) {
		panic(myerror.ParamsError)
	}
	return req
}

type CoreDataListReq struct {
	StartDate         string        `json:"start_date" binding:"required"`     // 起始时间
	EndDate           string        `json:"end_date" binding:"required"`       // 结束时间
	GroupType         string        `json:"group_type" binding:"required"`     // 聚合时间类型 小时日周月选择
	SeriesID          string        `json:"series_id" binding:"omitempty"`     // 剧目ID
	SeriesName        string        `json:"series_name" binding:"omitempty"`   // 剧目名称
	SeriesType        int64         `json:"series_type" binding:"omitempty"`   // 付费类型
	ResourceType      int64         `json:"resource_type" binding:"omitempty"` // 付费类型
	Sorts             []common.Sort `json:"sorts,omitempty"`                   // 多字段排序
	Kpi               []string      `json:"kpi,omitempty"`                     // 指标筛选 - 导出的时候使用
	common.Pagination                                                          // 分页
	common.CommonParams
}

type CoreDataListResp struct {
	*common.Paginator
	LastModifyTime string `json:"last_modify_time"`
}

func NewCoreDataListReqReq(c *gin.Context, paramsType string) *CoreDataListReq {
	req := &CoreDataListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	// 时间范围效验
	var err error
	req.StartDate, err = timeUtil.Reformat(req.StartDate, "2006-01-02", time.DateOnly)
	if err != nil {
		panic(myerror.ParamsError)
	}
	req.EndDate, err = timeUtil.Reformat(req.EndDate, "2006-01-02", time.DateOnly)
	if err != nil {
		panic(myerror.ParamsError)
	}
	if req.StartDate > req.EndDate {
		panic(myerror.ParamsError)
	}

	// 数据是按照小时给出的
	endDate, _ := time.Parse("2006-01-02", req.EndDate)
	nextDay := endDate.AddDate(0, 0, 1)
	req.EndDate = nextDay.Format("2006-01-02")

	// 聚合时间类型效验
	if _, ok := GroupTypeMapping[req.GroupType]; !ok {
		panic(myerror.ParamsError)
	}

	// 付费类型
	if req.SeriesType != 0 {
		seriesType := req.SeriesType
		if _, ok := SeriesTypeMapping[seriesType]; !ok {
			panic(myerror.ParamsError)
		}
	}

	// 流量来源
	if req.ResourceType != 0 {
		resourceType := req.ResourceType
		if _, ok := ResourceTypeMapping[resourceType]; !ok {
			panic(myerror.ParamsError)
		}
	}

	// 剧目ID
	if req.SeriesID != "" {
		_, err = strconv.ParseInt(req.SeriesID, 10, 64)
		if err != nil {
			panic(myerror.ParamsError)
		}
	}
	// 剧目名称
	req.SeriesName = utils.HtmlEncode(req.SeriesName)

	// 分页传参效验
	if req.Page < 1 {
		req.Page = 1
	}
	if req.PageSize < 1 {
		req.PageSize = 25
	}
	// 排序字段效验
	if len(req.Sorts) > 0 {
		for _, v := range req.Sorts {
			if _, ok := CoreDataSortKpiMapping[v.Key]; !ok {
				panic(myerror.ParamsError)
			}
			v.Order = strings.ToLower(v.Order)
			if v.Order != "asc" && v.Order != "desc" {
				panic(myerror.ParamsError)
			}
		}
	}
	//导出时做指标筛选效验
	if paramsType == "export" {
		req.Kpi = utils.SliceUniqStr(req.Kpi) //去重
		if len(req.Kpi) == 0 {
			panic(myerror.ParamsError)
		}
		for _, v := range req.Kpi {
			if _, ok := CoreDataKpiMapping[v]; !ok {
				panic(myerror.ParamsError)
			}
		}
	}

	return req
}

type AdDataListReq struct {
	StartDate         string        `json:"start_date" binding:"required"`   // 起始时间
	EndDate           string        `json:"end_date" binding:"required"`     // 结束时间
	GroupType         string        `json:"group_type" binding:"required"`   // 聚合时间类型 小时日周月选择
	SeriesType        int64         `json:"series_type" binding:"omitempty"` // 付费类型
	AccountID         string        `json:"account_id,omitempty"`            // 账户ID
	AccountName       string        `json:"account_name,omitempty"`          // 账户名
	SeriesID          string        `json:"series_id" binding:"omitempty"`   // 剧目ID
	SeriesName        string        `json:"series_name" binding:"omitempty"` // 剧目名称
	OptimizerName     string        `json:"optimizer_name,omitempty"`        // 投放人员
	GroupBy           []string      `json:"group_by" binding:"omitempty"`    // 聚合维度
	Sorts             []common.Sort `json:"sorts,omitempty"`                 // 多字段排序
	Kpi               []string      `json:"kpi,omitempty"`                   // 指标筛选 - 导出的时候使用
	common.Pagination                                                        // 分页
	common.CommonParams
}

type AdDataListResp struct {
	*common.Paginator
	LastModifyTime string `json:"last_modify_time"`
}

func NewAdDataListReq(c *gin.Context, paramsType string) *AdDataListReq {
	req := &AdDataListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	// 时间范围效验
	var err error
	req.StartDate, err = timeUtil.Reformat(req.StartDate, "2006-01-02", time.DateOnly)
	if err != nil {
		panic(myerror.ParamsError)
	}
	req.EndDate, err = timeUtil.Reformat(req.EndDate, "2006-01-02", time.DateOnly)
	if err != nil {
		panic(myerror.ParamsError)
	}
	if req.StartDate > req.EndDate {
		panic(myerror.ParamsError)
	}

	// 聚合时间类型效验
	if _, ok := GroupTypeMapping[req.GroupType]; !ok {
		panic(myerror.ParamsError)
	}

	// 付费类型
	if req.SeriesType != 0 {
		seriesType := req.SeriesType
		if _, ok := SeriesTypeMapping[seriesType]; !ok {
			panic(myerror.ParamsError)
		}
	}

	// 账户ID
	if req.AccountID != "" {
		_, err = strconv.ParseInt(req.AccountID, 10, 64)
		if err != nil {
			panic(myerror.ParamsError)
		}
	}
	// 账户名称
	if req.AccountName != "" {
		req.AccountName = utils.HtmlEncode(req.AccountName)
	}

	// 剧目ID
	if req.SeriesID != "" {
		_, err = strconv.ParseInt(req.SeriesID, 10, 64)
		if err != nil {
			panic(myerror.ParamsError)
		}
	}
	// 剧目名称
	if req.SeriesName != "" {
		req.SeriesName = utils.HtmlEncode(req.SeriesName)
	}

	// 投放人员
	if req.OptimizerName != "" {
		req.OptimizerName = utils.HtmlEncode(req.OptimizerName)
	}

	// 聚合维度效验
	if len(req.GroupBy) > 0 {
		for _, v := range req.GroupBy {
			if _, ok := AdDataGroupByMapping[v]; !ok {
				panic(myerror.ParamsError)
			}
		}
	}
	// 分页传参效验
	if req.Page < 1 {
		req.Page = 1
	}
	if req.PageSize < 1 {
		req.PageSize = 25
	}
	// 排序字段效验
	if len(req.Sorts) > 0 {
		for _, v := range req.Sorts {
			if _, ok := AdDataSortKpiMapping[v.Key]; !ok {
				panic(myerror.ParamsError)
			}
			v.Order = strings.ToLower(v.Order)
			if v.Order != "asc" && v.Order != "desc" {
				panic(myerror.ParamsError)
			}
		}
	}
	//导出时做指标筛选效验
	if paramsType == "export" {
		req.Kpi = utils.SliceUniqStr(req.Kpi) //去重
		if len(req.Kpi) == 0 {
			panic(myerror.ParamsError)
		}
		for _, v := range req.Kpi {
			if _, ok := AdDataKpiMapping[v]; !ok {
				panic(myerror.ParamsError)
			}
		}
	}

	return req
}
