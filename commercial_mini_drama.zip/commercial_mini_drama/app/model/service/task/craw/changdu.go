package craw

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/gomodule/redigo/redis"
	"github.com/xxl-job/xxl-job-executor-go"
	"goserver/app/library/driver/redisdb"
	"goserver/app/library/utils"
	noticeCommon "goserver/app/library/utils/notice/common"
	"io"
	"net/http"
	"net/http/cookiejar"
	"net/url"
	"strings"
	"time"
)

// 需要爬取的字段
type ChangDuField struct {
	SeriesName       string `json:"series_name"`
	FirstVisibleTime string `json:"first_visible_time"`
	BookID           string `json:"book_id"`
}

const BusinessTypeChangDu = 4 // 常读

// 7652669649084640 测试群
// 7652738368403504  大群
const ChangDuGroupNum = "7652738368403504"
const AtPersonOfCookie = "18910712607,19918503784"

func SyncCrawChangDuData(ctx context.Context, param *xxl.RunReq) (msg string) {

	baseURLStr := "https://www.changdunovel.com/novelsale/distributor/content/series/list/v1"
	queryParams := url.Values{}
	// 添加所有查询参数
	queryParams.Add("permission_statuses", "3,4")
	queryParams.Add("sort_field", "7")
	queryParams.Add("sort_type", "1")
	queryParams.Add("page_index", "0")
	queryParams.Add("page_size", "100")

	// 构造完整的 URL
	baseURL, err := url.Parse(baseURLStr)
	if err != nil {
		return fmt.Sprintf("无法构造完整的 URL：%s", err)
	}
	baseURL.RawQuery = queryParams.Encode()
	finalURL := baseURL.String()

	config, err := getCrawConfig(BusinessTypeChangDu)
	if err != nil {
		return fmt.Sprintf("获取配置失败: %v", err)
	}

	// 去掉首尾的换行和空格
	cookieString := strings.TrimSpace(config.ReqCurl)

	cookies := ParseCookie(cookieString)
	for key, val := range cookies {
		cookies[key] = url.QueryEscape(val)
	}
	jar, err := cookiejar.New(nil)
	if err != nil {
		return fmt.Sprintf("创建 CookieJar 失败: %v", err)
	}

	// 设置请求头
	headers := http.Header{}
	headers.Add("accept", "application/json, text/plain, */*")
	headers.Add("accept-language", "zh-CN,zh;q=0.9")
	headers.Add("aduserid", fmt.Sprintf("%s", cookies["adUserId"]))
	headers.Add("agw-js-conv", "str")
	headers.Add("appid", fmt.Sprintf("%s", cookies["appId"]))
	headers.Add("apptype", fmt.Sprintf("%s", cookies["appType"]))
	headers.Add("distributorid", fmt.Sprintf("%s", cookies["distributorId"]))
	headers.Add("referer", "https://www.changdunovel.com/sale/short-play/list?permission_statuses=3%2C4&sort_field=7&sort_type=1&page_index=1&page_size=10")

	// 解析基础 URL 用于关联 Cookies
	u, err := url.Parse("https://www.changdunovel.com")
	if err != nil {
		return fmt.Sprintf("解析基础 URL 失败: %v", err)
	}

	// 构建 []*http.Cookie
	cookiesList := []*http.Cookie{}
	for name, value := range cookies {
		cookie := &http.Cookie{
			Name:     name,
			Value:    value,
			Domain:   u.Host,
			Path:     "/",
			HttpOnly: false,
		}
		cookiesList = append(cookiesList, cookie)
	}
	jar.SetCookies(u, cookiesList)
	client := &http.Client{
		Jar: jar, // 自动管理 Cookies
	}

	req, err := http.NewRequest("GET", finalURL, nil)
	if err != nil {
		return fmt.Sprintf("创建 GET 请求失败: %v", err)
	}

	req.Header = headers

	resp, err := client.Do(req)
	if err != nil {
		return fmt.Sprintf("发送请求失败: %v", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		// cookie可能过期
		content := "日期" + time.Now().Format("2006-01-02 15:04:05") + "\n【常读】Cookie已过期，请更换cookie信息"
		err = noticeCommon.SendTuituiTextMsg(content, GroupNum, strings.Split(AtPersonOfCookie, ",")...)
		if err != nil {
			return fmt.Sprintf("发送通知失败: %v", err)
		}
		bodyBytes, _ := io.ReadAll(resp.Body)
		return fmt.Sprintf("请求失败，状态码: %d, 响应内容: %s", resp.StatusCode, string(bodyBytes))
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return fmt.Sprintf("读取响应体失败: %v", err)
	}

	var result map[string]interface{}
	if err := json.Unmarshal(body, &result); err != nil {
		return fmt.Sprintf("解析 JSON 响应失败: %v", err)
	}

	data, ok := result["data"]
	if !ok {
		return "响应数据中不存在 data 字段"
	}
	dataMap, ok := data.(map[string]interface{})

	dataStr, _ := json.Marshal(dataMap["data"])

	var changDuField []ChangDuField
	_ = json.Unmarshal(dataStr, &changDuField)
	// 过滤掉不是今天日期的短剧
	changDuField = filterToday(changDuField)
	// 判断是否存在今天日期的短剧里面
	redisKey := "changdu:" + time.Now().Format("2006-01-02")
	bookIDStrs, err := redisdb.GetStringValue(redisKey)

	if errors.Is(err, redis.ErrNil) {
		bookIDStrs = ""
		_ = redisdb.Set(redisKey, "")

	}
	bookIDSlice := strings.Split(bookIDStrs, ",")
	var newBookIDs []string
	var bookNames []string
	for _, val := range changDuField {
		if utils.InArray(val.BookID, bookIDSlice) {
			continue
		}
		newBookIDs = append(newBookIDs, val.BookID)
		bookNames = append(bookNames, val.SeriesName)
	}

	for key, val := range bookNames {
		bookNames[key] = fmt.Sprintf("%d、", key+1) + val
	}
	// 发送消息
	if len(bookNames) > 0 {
		content := "番茄抖小以下剧目已上架，请及时跟进:\n" + strings.Join(bookNames, "\n")
		err = noticeCommon.SendTuituiTextMsg(content, ChangDuGroupNum)
		if err != nil {
			return fmt.Sprintf("发送通知失败: %v", err)
		}
	}

	// 存储redis 合并之前已经得存储的bookID
	bookIDSlice = append(bookIDSlice, newBookIDs...)
	// 去重
	bookIDSlice = utils.ArrayUnique(bookIDSlice)

	err = redisdb.Set(redisKey, strings.Join(bookIDSlice, ","))
	if err != nil {
		return fmt.Sprintf("存储redis失败: %v", err)
	}
	err = redisdb.SetKeyExpire(redisKey, 86400)
	if err != nil {
		return fmt.Sprintf("设置redis时间失败: %v", err)
	}

	return "success"

}

func filterToday(changDuField []ChangDuField) []ChangDuField {
	var todayChangDuField []ChangDuField
	for _, field := range changDuField {
		// 日期格式转化为 年月日
		fieldTime, err := time.ParseInLocation("2006-01-02 15:04:05", field.FirstVisibleTime, time.Local)
		if err != nil {
			fmt.Println("时间格式转换错误:", err)
			continue
		}
		fieldTimeStr := fieldTime.Format("2006-01-02")

		if fieldTimeStr == time.Now().Format("2006-01-02") {
			todayChangDuField = append(todayChangDuField, field)
		}
	}
	return todayChangDuField
}
