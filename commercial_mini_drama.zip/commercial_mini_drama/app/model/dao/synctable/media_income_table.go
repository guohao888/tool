package synctable

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	repo "goserver/app/common/repository/synctable"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// MediaIncomeDao 素材报表DAO
type MediaIncomeDao struct {
	Ctx context.Context
}

func NewMediaIncomeDao(ctx context.Context) *MediaIncomeDao {
	return &MediaIncomeDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (m *MediaIncomeDao) InsertBatchSize(data []repo.MediaIncomeEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = m.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (m *MediaIncomeDao) buildInsertSentence(tx *gorm.DB, data []repo.MediaIncomeEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.MediaIncomeTableName() + " ( search_date, search_hour, material_id, filename, file_cutter, url, promotion_id, advertiser_id, promotion_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income, referral_id ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += " (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.SearchDate,
			v.SearchHour,
			v.MaterialId,
			v.FileName,
			v.FileCutter,
			v.Url,
			v.PromotionId,
			v.AdvertiserId,
			v.PromotionName,
			v.ShowCnt,
			v.Click,
			v.Active,
			v.ActivePay,
			v.Cost,
			v.ConvertCnt,
			v.NewIncome,
			v.Income,
			v.NewPayUser,
			v.PayUser,
			v.NewUser,
			v.AccIncome,
			v.Acc2dayIncome,
			v.Acc3dayIncome,
			v.Acc4dayIncome,
			v.Acc5dayIncome,
			v.Acc6dayIncome,
			v.Acc7dayIncome,
			v.ReferralId,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// BuildAggMediaReportEntityDate 有消耗媒体素材
func (m *MediaIncomeDao) BuildAggMediaReportEntityDate(queryDate string) error {
	var data []repo.MediaIncomeEntity
	partition := "p" + strings.Replace(queryDate, "-", "", -1)
	adWhere := " WHERE date(create_time) = '" + queryDate + "' "
	aOrderWhere := " WHERE date(event_date) = '" + queryDate + "' "
	pOrderWhere := " WHERE date(pay_date) = '" + queryDate + "' "
	sqlOrder := "SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, u.mid_id AS mid_id, SUM(CASE WHEN o.event_date = o.register_date THEN o.income END) AS new_income, SUM(o.income) AS income, COUNT(DISTINCT CASE WHEN o.event_date = o.register_date THEN o.device_id END) AS new_pay_user, COUNT(DISTINCT o.device_id) AS pay_user, u.project_id, u.promotion_id, o.referral_id FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + aOrderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date UNION SELECT device_id, date(pay_date) AS event_date, pay_hour AS event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(CASE WHEN ( app_id = '30008812' or app_id = '30012267') AND order_type = '1' THEN pay_amount/100 * 0.801 + pay_amount/100 * 0.85 * 0.05 ELSE pay_amount/100 * 0.891 END) AS income FROM tomato_iap_orders " + pOrderWhere + " GROUP BY device_id, date(pay_date), event_hour, date(register_date), referral_id ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id,  t2.promotion_id, t2.referral_id, t2.mid_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(buying_timestamp) as buying_hour, promotion_id, mid_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), promotion_id, mid_id ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, buying_timestamp AS buying_hour, project_id, ad_id_v2 AS promotion_id, promotion_id AS referral_id, mid_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), buying_timestamp, project_id, ad_id_v2, promotion_id, mid_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date AND t1.buying_hour = t2.buying_hour and t1.promotion_id = t2.referral_id AND t1.mid_id = t2.mid_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id GROUP BY o.event_date, o.event_hour, u.project_id, u.promotion_id, o.referral_id, u.mid_id"
	sqlUser := "SELECT date(buying_date) AS buying_date, buying_hour, project_id, ad_id_v2 AS promotion_id, mid_id, COUNT(DISTINCT device_id) AS new_user FROM tomato_iaa_buy GROUP BY date(buying_date), buying_hour, project_id, ad_id_v2, mid_id "
	sqlAcc := "SELECT pay_date, pay_hour, project_id, promotion_id, referral_id, mid_id, SUM(acc_income) AS acc_income, SUM(acc_2day_income) AS acc_2day_income, SUM(acc_3day_income) AS acc_3day_income, SUM(acc_4day_income) AS acc_4day_income, SUM(acc_5day_income) AS acc_5day_income, SUM(acc_6day_income) AS acc_6day_income, SUM(acc_7day_income) AS acc_7day_income FROM ( SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, u.project_id, u.promotion_id, u.referral_id, u.mid_id, SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC, o.event_hour DESC) AS acc_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 2 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_2day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 3 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_3day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 4 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_4day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 5 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_5day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 6 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_6day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 7 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_7day_income FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + aOrderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date UNION SELECT device_id, date(pay_date) AS event_date, pay_hour AS event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(CASE WHEN ( app_id = '30008812' or app_id = '30012267') AND order_type = '1' THEN pay_amount/100 * 0.801 + pay_amount/100 * 0.85 * 0.05 ELSE pay_amount/100 * 0.891 END) AS income FROM tomato_iap_orders " + pOrderWhere + " GROUP BY device_id, date(pay_date), event_hour, date(register_date), referral_id ) o LEFT JOIN ( SELECT t2.device_id, t2.buying_date, project_id,  t2.promotion_id, t2.referral_id, t2.mid_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(buying_hour) as buying_hour, promotion_id, mid_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), promotion_id, mid_id ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, buying_hour, project_id, ad_id_v2 AS promotion_id, promotion_id AS referral_id, mid_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), buying_hour, project_id, ad_id_v2, promotion_id, mid_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date AND t1.buying_hour = t2.buying_hour and t1.promotion_id = t2.referral_id AND t1.mid_id = t2.mid_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id ) t GROUP BY pay_date, pay_hour, project_id, promotion_id, referral_id, mid_id"
	sqlReport := "SELECT ma.advertiser_id as advertiser_id, ma.material_id as material_id, promotion_id, search_date, search_hour, promotion_name, convert_cnt, click_cnt, show_cnt, stat_cost, active, active_pay, video_id, filename, poster_url as url, file_cutter FROM ( SELECT advertiser_id, material_id, promotion_id, date(create_time) as search_date, create_hour as search_hour, promotion_name, convert_cnt, click_cnt, show_cnt, stat_cost, active, active_pay FROM report_media " + adWhere + " ) ma LEFT JOIN ( SELECT advertiser_id, material_id, video_id, filename, poster_url, file_cutter FROM video_file ) fi ON ma.advertiser_id = fi.advertiser_id AND ma.material_id = fi.material_id "
	queryFile := "ad.search_date AS search_date, ad.search_hour AS search_hour, ad.material_id AS material_id, ad.filename AS filename, ad.file_cutter AS file_cutter, ad.url AS url, ad.promotion_id AS promotion_id, ad.advertiser_id AS advertiser_id,  ad.promotion_name AS promotion_name, ad.show_cnt AS show_cnt, ad.click_cnt AS click, ad.active AS active, ad.active_pay AS active_pay, ad.stat_cost AS cost, ad.convert_cnt AS convert_cnt, o.referral_id AS referral_id, o.new_income AS new_income, o.income AS income, o.new_pay_user AS new_pay_user, o.pay_user AS pay_user, o.referral_id AS referral_id, u.new_user AS new_user, acc.acc_income AS acc_income, acc.acc_2day_income AS acc_2day_income, acc.acc_3day_income AS acc_3day_income, acc.acc_4day_income AS acc_4day_income, acc.acc_5day_income AS acc_5day_income, acc.acc_6day_income AS acc_6day_income, acc.acc_7day_income AS acc_7day_income "
	sql := "SELECT " + queryFile + " FROM ( " + sqlReport + ") ad LEFT JOIN ( " + sqlOrder + ") o ON ad.search_date = o.pay_date AND ad.search_hour = o.pay_hour AND ad.promotion_id = o.promotion_id AND ad.material_id = o.mid_id LEFT JOIN ( " + sqlAcc + " ) acc ON ad.search_date = acc.pay_date AND ad.search_hour = acc.pay_hour AND ad.promotion_id = acc.promotion_id AND ad.material_id = acc.mid_id LEFT JOIN ( " + sqlUser + ") u ON ad.search_date = u.buying_date AND ad.search_hour = u.buying_hour AND ad.promotion_id = u.promotion_id AND ad.material_id = u.mid_id "
	db := dorisdb.DorisClient()
	err := db.Raw(sql).Scan(&data).Error
	if err != nil {
		return err
	}
	// 执行删除当日或历史数据
	deleteSql := "ALTER TABLE media_income_table DROP PARTITION IF EXISTS " + partition
	_ = db.Exec(deleteSql).Error
	err = m.InsertBatchSize(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggMediaReportNoRelateEntityDate 关联不上媒体素材
func (m *MediaIncomeDao) BuildAggMediaReportNoRelateEntityDate(queryDate string) error {
	var data []repo.MediaIncomeEntity
	adWhere := " WHERE date(create_time) = '" + queryDate + "' "
	aOrderWhere := " WHERE date(event_date) = '" + queryDate + "' "
	pOrderWhere := " WHERE date(pay_date) = '" + queryDate + "' "
	sqlOrder := "SELECT t1.pay_date, t1.pay_hour, t1.new_income, t1.income, t1.new_pay_user, t1.pay_user, t1.project_id, t1.promotion_id, t1.referral_id, t1.mid_id FROM ( SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, u.mid_id AS mid_id, SUM(CASE WHEN o.event_date = o.register_date THEN o.income END) AS new_income, SUM(o.income) AS income, COUNT(DISTINCT CASE WHEN o.event_date = o.register_date THEN o.device_id END) AS new_pay_user, COUNT(DISTINCT o.device_id) AS pay_user, u.project_id, u.promotion_id, o.referral_id FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + aOrderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), promotion_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date UNION SELECT device_id, date(pay_date) AS event_date, pay_hour AS event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(CASE WHEN ( app_id = '30008812' or app_id = '30012267') AND order_type = '1' THEN pay_amount/100 * 0.801 + pay_amount/100 * 0.85 * 0.05 ELSE pay_amount/100 * 0.891 END) AS income FROM tomato_iap_orders " + pOrderWhere + " GROUP BY device_id, date(pay_date), event_hour, date(register_date), promotion_id ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id,  t2.promotion_id, t2.referral_id, t2.mid_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(buying_timestamp) as buying_hour, promotion_id, mid_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), promotion_id, mid_id ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, buying_timestamp AS buying_hour, project_id, ad_id_v2 AS promotion_id, promotion_id AS referral_id, mid_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), buying_timestamp, project_id, ad_id_v2, promotion_id, mid_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date AND t1.buying_hour = t2.buying_hour and t1.promotion_id = t2.referral_id AND t1.mid_id = t2.mid_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id WHERE ( u.mid_id = '__MID3__' OR u.mid_id = '' ) GROUP BY o.event_date, o.event_hour, u.project_id, u.promotion_id, o.referral_id, u.mid_id ) t1  LEFT JOIN  ( SELECT advertiser_id, material_id, promotion_id, date(create_time) as search_date, create_hour as search_hour, promotion_name, convert_cnt, click_cnt, show_cnt, stat_cost, active, active_pay FROM report_media " + adWhere + " ) ad  ON t1.pay_date = ad.search_date AND t1.pay_hour = ad.search_hour AND t1.promotion_id = ad.promotion_id AND t1.mid_id = ad.material_id  WHERE ad.search_date IS NULL"
	sqlUser := "SELECT date(buying_date) AS buying_date, buying_hour, project_id, ad_id_v2 AS promotion_id, mid_id, COUNT(DISTINCT device_id) AS new_user FROM tomato_iaa_buy GROUP BY date(buying_date), buying_hour, project_id, ad_id_v2, mid_id "
	sqlAcc := "SELECT pay_date, pay_hour, referral_id, mid_id, SUM(acc_income) AS acc_income, SUM(acc_2day_income) AS acc_2day_income, SUM(acc_3day_income) AS acc_3day_income, SUM(acc_4day_income) AS acc_4day_income, SUM(acc_5day_income) AS acc_5day_income, SUM(acc_6day_income) AS acc_6day_income, SUM(acc_7day_income) AS acc_7day_income FROM ( SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, u.project_id, u.promotion_id, u.referral_id, u.mid_id, SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) AS acc_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 2 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_2day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 3 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_3day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 4 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_4day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 5 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_5day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 6 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_6day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 7 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_7day_income FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + aOrderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), promotion_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date UNION SELECT device_id, date(pay_date) AS event_date, pay_hour AS event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(CASE WHEN ( app_id = '30008812' or app_id = '30012267') AND order_type = '1' THEN pay_amount/100 * 0.801 + pay_amount/100 * 0.85 * 0.05 ELSE pay_amount/100 * 0.891 END) AS income FROM tomato_iap_orders " + pOrderWhere + " GROUP BY device_id, date(pay_date), event_hour, date(register_date), referral_id ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id,  t2.promotion_id, t2.referral_id, t2.mid_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(buying_timestamp) as buying_hour, promotion_id, mid_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), promotion_id, mid_id ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, buying_timestamp AS buying_hour, project_id, ad_id_v2 AS promotion_id, promotion_id AS referral_id, mid_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), buying_timestamp, project_id, ad_id_v2, promotion_id, mid_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date AND t1.buying_hour = t2.buying_hour and t1.promotion_id = t2.referral_id AND t1.mid_id = t2.mid_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id WHERE ( u.mid_id = '__MID3__' OR u.mid_id = '' )) t GROUP BY pay_date, pay_hour, referral_id, mid_id "
	queryFile := "o.pay_date AS search_date, o.pay_hour AS search_hour, o.mid_id AS material_id, vi.filename AS filename, vi.file_cutter AS file_cutter, vi.url AS url, o.promotion_id AS promotion_id, '' AS advertiser_id,  '' AS promotion_name,o.referral_id, o.new_income AS new_income, o.income AS income, o.new_pay_user AS new_pay_user, o.pay_user AS pay_user, o.referral_id AS referral_id, u.new_user AS new_user, acc.acc_income AS acc_income, acc.acc_2day_income AS acc_2day_income, acc.acc_3day_income AS acc_3day_income, acc.acc_4day_income AS acc_4day_income, acc.acc_5day_income AS acc_5day_income, acc.acc_6day_income AS acc_6day_income, acc.acc_7day_income AS acc_7day_income "
	sqlVi := "SELECT material_id, video_id, filename, poster_url AS url, file_cutter FROM video_file "
	sql := "SELECT " + queryFile + " FROM ( " + sqlOrder + ") o LEFT JOIN ( " + sqlAcc + " ) acc ON o.pay_date = acc.pay_date AND o.pay_hour = acc.pay_hour AND o.promotion_id = acc.referral_id AND o.mid_id = acc.mid_id LEFT JOIN ( " + sqlUser + ") u ON o.pay_date = u.buying_date AND o.pay_hour = u.buying_hour AND o.promotion_id = u.promotion_id AND o.mid_id = u.mid_id LEFT JOIN ( " + sqlVi + " ) vi ON o.mid_id = vi.material_id "
	db := dorisdb.DorisClient()
	err := db.Raw(sql).Scan(&data).Error
	if err != nil {
		return err
	}
	err = m.InsertBatchSize(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggMediaReportEntityDateReplenish 有消耗媒体素材
func (m *MediaIncomeDao) BuildAggMediaReportEntityDateReplenish(queryDate string) error {
	var data []repo.MediaIncomeEntity
	partition := "p" + strings.Replace(queryDate, "-", "", -1)
	adWhere := " WHERE date(create_time) = '" + queryDate + "' "
	aOrderWhere := " WHERE date(event_date) = '" + queryDate + "' "
	pOrderWhere := " WHERE date(pay_date) = '" + queryDate + "' "
	sqlOrder := "SELECT o.event_date AS pay_date, u.mid_id AS mid_id, SUM(CASE WHEN o.event_date = o.register_date THEN o.income END) AS new_income, SUM(o.income) AS income, COUNT(DISTINCT CASE WHEN o.event_date = o.register_date THEN o.device_id END) AS new_pay_user, COUNT(DISTINCT o.device_id) AS pay_user, u.project_id, u.promotion_id, o.referral_id FROM ( SELECT device_id, event_date, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + aOrderWhere + " GROUP BY device_id, date(event_date), date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id,  t2.promotion_id, t2.referral_id, t2.mid_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(mid_id) as mid_id, min(ad_id_v2) as ad_id_v2 FROM tomato_iaa_buy WHERE ad_id_v2 != '__PROMOTION_ID__' GROUP BY device_id, date(buying_date) ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, project_id, ad_id_v2 AS promotion_id, promotion_id AS referral_id, mid_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), project_id, ad_id_v2, promotion_id, mid_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date and t1.mid_id = t2.mid_id AND t1.ad_id_v2 = t2.promotion_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id GROUP BY o.event_date, u.project_id, u.promotion_id, o.referral_id, u.mid_id"
	sqlUser := "SELECT date(buying_date) AS buying_date, project_id, ad_id_v2 AS promotion_id, mid_id, COUNT(DISTINCT device_id) AS new_user FROM tomato_iaa_buy GROUP BY date(buying_date), project_id, ad_id_v2, mid_id "
	sqlAcc := "SELECT pay_date, project_id, promotion_id, referral_id, mid_id, SUM(acc_income) AS acc_income, SUM(acc_2day_income) AS acc_2day_income, SUM(acc_3day_income) AS acc_3day_income, SUM(acc_4day_income) AS acc_4day_income, SUM(acc_5day_income) AS acc_5day_income, SUM(acc_6day_income) AS acc_6day_income, SUM(acc_7day_income) AS acc_7day_income FROM ( SELECT o.event_date AS pay_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id, SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC) AS acc_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 2 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC) END AS acc_2day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 3 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC) END AS acc_3day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 4 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC) END AS acc_4day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 5 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC) END AS acc_5day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 6 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC) END AS acc_6day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 7 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id, u.mid_id ORDER BY o.event_date DESC) END AS acc_7day_income FROM ( SELECT device_id, event_date, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + aOrderWhere + " GROUP BY device_id, date(event_date), date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date UNION SELECT device_id, date(pay_date) AS event_date, date(register_date) AS register_date, promotion_id AS referral_id, SUM(CASE WHEN ( app_id = '30008812' or app_id = '30012267') AND order_type = '1' THEN pay_amount/100 * 0.801 + pay_amount/100 * 0.85 * 0.05 ELSE pay_amount/100 * 0.891 END) AS income FROM tomato_iap_orders " + pOrderWhere + " GROUP BY device_id, date(pay_date), date(register_date), referral_id ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id,  t2.promotion_id, t2.referral_id, t2.mid_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(mid_id) as mid_id, min(ad_id_v2) as ad_id_v2 FROM tomato_iaa_buy WHERE ad_id_v2 != '__PROMOTION_ID__' GROUP BY device_id, date(buying_date) ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, project_id, ad_id_v2 AS promotion_id, promotion_id AS referral_id, mid_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), project_id, ad_id_v2, promotion_id, mid_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date and t1.mid_id = t2.mid_id AND t1.ad_id_v2 = t2.promotion_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id ) t GROUP BY pay_date, project_id, promotion_id, referral_id, mid_id"
	sqlReport := "SELECT ma.advertiser_id as advertiser_id, ma.material_id as material_id, promotion_id, search_date, search_hour, promotion_name, convert_cnt, click_cnt, show_cnt, stat_cost, active, active_pay, video_id, filename, poster_url as url, file_cutter FROM ( SELECT advertiser_id, material_id, promotion_id, date(create_time) as search_date, create_hour as search_hour, promotion_name, convert_cnt, click_cnt, show_cnt, stat_cost, active, active_pay FROM report_media " + adWhere + " ) ma LEFT JOIN ( SELECT advertiser_id, material_id, video_id, filename, poster_url, file_cutter FROM video_file ) fi ON ma.advertiser_id = fi.advertiser_id AND ma.material_id = fi.material_id "
	queryFile := "ad.search_date AS search_date, ad.search_hour AS search_hour, ad.material_id AS material_id, ad.filename AS filename, ad.file_cutter AS file_cutter, ad.url AS url, ad.promotion_id AS promotion_id, ad.advertiser_id AS advertiser_id,  ad.promotion_name AS promotion_name, ad.show_cnt AS show_cnt, ad.click_cnt AS click, ad.active AS active, ad.active_pay AS active_pay, ad.stat_cost AS cost, ad.convert_cnt AS convert_cnt, o.referral_id AS referral_id, o.new_income AS new_income, o.income AS income, o.new_pay_user AS new_pay_user, o.pay_user AS pay_user, o.referral_id AS referral_id, u.new_user AS new_user, acc.acc_income AS acc_income, acc.acc_2day_income AS acc_2day_income, acc.acc_3day_income AS acc_3day_income, acc.acc_4day_income AS acc_4day_income, acc.acc_5day_income AS acc_5day_income, acc.acc_6day_income AS acc_6day_income, acc.acc_7day_income AS acc_7day_income "
	sql := "SELECT " + queryFile + " FROM ( " + sqlReport + ") ad LEFT JOIN ( " + sqlOrder + ") o ON ad.search_date = o.pay_date AND ad.promotion_id = o.promotion_id AND ad.material_id = o.mid_id LEFT JOIN ( " + sqlAcc + " ) acc ON ad.search_date = acc.pay_date AND ad.promotion_id = acc.promotion_id AND ad.material_id = acc.mid_id LEFT JOIN ( " + sqlUser + ") u ON ad.search_date = u.buying_date AND ad.promotion_id = u.promotion_id AND ad.material_id = u.mid_id "
	db := dorisdb.DorisClient()
	err := db.Raw(sql).Scan(&data).Error
	if err != nil {
		return err
	}
	// 执行删除当日或历史数据
	deleteSql := "ALTER TABLE media_income_table DROP PARTITION IF EXISTS " + partition
	_ = db.Exec(deleteSql).Error
	err = m.InsertBatchSize(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggMediaReportNoRelateEntityDateReplenish 关联不上媒体素材
func (m *MediaIncomeDao) BuildAggMediaReportNoRelateEntityDateReplenish(queryDate string) error {
	var data []repo.MediaIncomeEntity
	adWhere := " WHERE date(create_time) = '" + queryDate + "' "
	aOrderWhere := " WHERE date(event_date) = '" + queryDate + "' "
	//pOrderWhere := " WHERE date(pay_date) = '" + queryDate + "' "
	sqlOrder := "SELECT t1.pay_date, ad.search_hour as pay_hour, t1.new_income, t1.income, t1.new_pay_user, t1.pay_user, t1.project_id, t1.promotion_id, t1.referral_id, t1.mid_id FROM ( SELECT o.event_date AS pay_date, u.mid_id AS mid_id, SUM(CASE WHEN o.event_date = o.register_date THEN o.income END) AS new_income, SUM(o.income) AS income, COUNT(DISTINCT CASE WHEN o.event_date = o.register_date THEN o.device_id END) AS new_pay_user, COUNT(DISTINCT o.device_id) AS pay_user, u.project_id, u.promotion_id, o.referral_id FROM ( SELECT device_id, event_date, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + aOrderWhere + " GROUP BY device_id, date(event_date), date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id,  t2.promotion_id, t2.referral_id, t2.mid_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(mid_id) as mid_id, min(ad_id_v2) as ad_id_v2 FROM tomato_iaa_buy WHERE ad_id_v2 != '__PROMOTION_ID__' GROUP BY device_id, date(buying_date) ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, project_id, ad_id_v2 AS promotion_id, promotion_id AS referral_id, mid_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), project_id, ad_id_v2, promotion_id, mid_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date and t1.mid_id = t2.mid_id AND t1.ad_id_v2 = t2.promotion_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id GROUP BY o.event_date, u.project_id, u.promotion_id, o.referral_id, u.mid_id ) t1  LEFT JOIN  ( SELECT advertiser_id, material_id, promotion_id, date(create_time) as search_date, create_hour as search_hour, promotion_name, convert_cnt, click_cnt, show_cnt, stat_cost, active, active_pay FROM report_media " + adWhere + " ) ad  ON t1.pay_date = ad.search_date AND t1.promotion_id = ad.promotion_id AND t1.mid_id = ad.material_id  WHERE ad.search_date IS NULL"
	sqlUser := "SELECT date(buying_date) AS buying_date, project_id, ad_id_v2 AS promotion_id, mid_id, COUNT(DISTINCT device_id) AS new_user FROM tomato_iaa_buy GROUP BY date(buying_date), project_id, ad_id_v2, mid_id "
	//sqlAcc := "SELECT pay_date, referral_id, mid_id, SUM(acc_income) AS acc_income, SUM(acc_2day_income) AS acc_2day_income, SUM(acc_3day_income) AS acc_3day_income, SUM(acc_4day_income) AS acc_4day_income, SUM(acc_5day_income) AS acc_5day_income, SUM(acc_6day_income) AS acc_6day_income, SUM(acc_7day_income) AS acc_7day_income FROM ( SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, u.project_id, u.promotion_id, u.referral_id, u.mid_id, SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) AS acc_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 2 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_2day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 3 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_3day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 4 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_4day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 5 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_5day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 6 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_6day_income, CASE WHEN DATE_DIFF('day', o.event_date, o.register_date) <= 7 THEN SUM(o.income) OVER (PARTITION BY u.device_id, u.buying_date, u.project_id, u.promotion_id, u.referral_id ORDER BY o.event_date DESC, o.event_hour DESC) END AS acc_7day_income FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + aOrderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), promotion_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date UNION SELECT device_id, date(pay_date) AS event_date, pay_hour AS event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(CASE WHEN ( app_id = '30008812' or app_id = '30012267') AND order_type = '1' THEN pay_amount/100 * 0.801 + pay_amount/100 * 0.85 * 0.05 ELSE pay_amount/100 * 0.891 END) AS income FROM tomato_iap_orders " + pOrderWhere + " GROUP BY device_id, date(pay_date), event_hour, date(register_date), referral_id ) o LEFT JOIN (SELECT t1.device_id, t1.buying_date, project_id,  t2.promotion_id, t2.referral_id, t2.mid_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(promotion_id) as promotion_id  FROM tomato_iaa_buy WHERE ( promotion_id != '__PROMOTION_ID__' OR promotion_id != '') GROUP BY device_id, date(buying_date) ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, project_id, ad_id_v2 AS promotion_id, promotion_id AS referral_id, mid_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), project_id, ad_id_v2, promotion_id, mid_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date and t1.promotion_id = t2.referral_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id WHERE u.device_id IS NULL ) t GROUP BY pay_date, referral_id, mid_id "
	queryFile := "o.pay_date AS search_date, '0' AS search_hour, o.mid_id AS material_id, vi.filename AS filename, vi.file_cutter AS file_cutter, vi.url AS url, o.promotion_id AS promotion_id, '' AS advertiser_id,  '' AS promotion_name,o.referral_id, o.new_income AS new_income, o.income AS income, o.new_pay_user AS new_pay_user, o.pay_user AS pay_user, o.referral_id AS referral_id, u.new_user AS new_user, 0 AS acc_income, 0 AS acc_2day_income, 0 AS acc_3day_income, 0 AS acc_4day_income, 0 AS acc_5day_income, 0 AS acc_6day_income, 0 AS acc_7day_income "
	//queryFile := "o.pay_date AS search_date, o.pay_hour AS search_hour, o.mid_id AS material_id, vi.filename AS filename, vi.file_cutter AS file_cutter, vi.url AS url, o.promotion_id AS promotion_id, '' AS advertiser_id,  '' AS promotion_name,o.referral_id, o.new_income AS new_income, o.income AS income, o.new_pay_user AS new_pay_user, o.pay_user AS pay_user, o.referral_id AS referral_id, u.new_user AS new_user, acc.acc_income AS acc_income, acc.acc_2day_income AS acc_2day_income, acc.acc_3day_income AS acc_3day_income, acc.acc_4day_income AS acc_4day_income, acc.acc_5day_income AS acc_5day_income, acc.acc_6day_income AS acc_6day_income, acc.acc_7day_income AS acc_7day_income "
	sqlVi := "SELECT material_id, min(video_id) as video_id, min(filename) as filename, min(poster_url) AS url, max(file_cutter) as file_cutter FROM video_file GROUP BY material_id ORDER BY material_id DESC "
	sql := "SELECT " + queryFile + " FROM ( " + sqlOrder + ") o  LEFT JOIN ( " + sqlUser + ") u ON o.pay_date = u.buying_date AND o.promotion_id = u.promotion_id AND o.mid_id = u.mid_id LEFT JOIN ( " + sqlVi + " ) vi ON o.mid_id = vi.material_id "
	//LEFT JOIN ( " + sqlAcc + " ) acc ON o.pay_date = acc.pay_date  AND o.promotion_id = acc.referral_id AND o.mid_id = acc.mid_id
	db := dorisdb.DorisClient()
	err := db.Raw(sql).Scan(&data).Error
	if err != nil {
		return err
	}
	err = m.InsertBatchSize(data, 5000)
	if err != nil {
		return err
	}
	return nil
}
