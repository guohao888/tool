package materialdto

type IDLabel struct {
	ID        string `json:"id"`
	Label     string `json:"label"`
	IsDefault bool   `json:"isdefault"`
}

type SelectOption struct {
	Name  string    `json:"name"`
	Value []IDLabel `json:"value"`
}

type KpiOption struct {
	ID        int    `json:"id"`
	Label     string `json:"label"`
	Prop      string `json:"prop"`
	Format    string `json:"format"`
	SortAble  bool   `json:"sortable"`
	IsDefault bool   `json:"isdefault"`
}

type Params struct {
	GroupType    []IDLabel    `json:"group_type"`    //时间周期
	Media        SelectOption `json:"media"`         //媒体
	BookID       SelectOption `json:"book_id"`       //剧目名称
	PayType      SelectOption `json:"pay_type"`      //付费类型
	AppName      SelectOption `json:"app_name"`      //应用包名
	MaterialName SelectOption `json:"material_name"` //素材名称
	OptimizerID  SelectOption `json:"optimizer_id"`  //投放人员
	EditorName   SelectOption `json:"editor_name"`   //剪辑师
	EditorRegion SelectOption `json:"editor_region"` //剪辑师地区
	AccountID    SelectOption `json:"account_id"`    //账户名称
	GroupBy      SelectOption `json:"group_by"`      //维度聚合
	KpiFilter    []KpiOption  `json:"kpi_filter"`    //指标筛选
}

var GroupTypeArr = []IDLabel{
	{ID: "d", Label: "日", IsDefault: true},
	{ID: "w", Label: "周"},
	{ID: "m", Label: "月"},
	{ID: "h", Label: "小时"}}

var GroupTypeMapping = map[string]string{
	"d": "日",
	"w": "周",
	"m": "月",
	"h": "小时",
}

var PayTypeArr = []IDLabel{
	{ID: "1", Label: "IAA"},
	{ID: "2", Label: "IAP"}}

var PayTypeMapping = map[string]string{
	"1": "IAA",
	"2": "IAP",
}

var GroupByArr = []IDLabel{
	{ID: "media", Label: "投放载体"},
	{ID: "book_name", Label: "剧目名称"},
	{ID: "pay_type", Label: "付费方式"},
	{ID: "app_name", Label: "应用包名"},
	{ID: "material_name", Label: "素材名称", IsDefault: true},
	{ID: "optimizer_nickname", Label: "投放人员"},
	{ID: "editor_name", Label: "剪辑师"},
	{ID: "editor_region", Label: "剪辑师地区"},
	{ID: "account_name", Label: "账户名称"}}

var GroupByMapping = map[string]string{
	"media":              "投放载体",
	"book_name":          "剧目名称",
	"pay_type":           "付费方式",
	"app_name":           "应用包名",
	"material_name":      "素材名称",
	"optimizer_nickname": "投放人员",
	"editor_name":        "剪辑师",
	"editor_region":      "剪辑师地区",
	"account_name":       "账户名称",
}

var KpiFilterArr = []KpiOption{
	{Label: "实际消耗", Prop: "cost", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "消耗环比", Prop: "cost_hb", Format: "cost"},
	{Label: "媒体消耗", Prop: "media_cost", Format: "cost", SortAble: true},
	{Label: "展示数", Prop: "show_count", Format: "num", SortAble: true, IsDefault: true},
	{Label: "点击数", Prop: "click_count", Format: "num", SortAble: true, IsDefault: true},
	{Label: "点击率", Prop: "click_rate", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "关联有消耗计划数", Prop: "spending_campaigns_count", Format: "num"},
	{Label: "千展成本", Prop: "show_cost", Format: "cost", SortAble: true},
	{Label: "点击成本", Prop: "click_cost", Format: "cost", SortAble: true},
	{Label: "媒体激活数", Prop: "media_active_count", Format: "num", SortAble: true, IsDefault: true},
	{Label: "媒体激活成本", Prop: "media_active_cost", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "媒体激活率", Prop: "media_active_rate", Format: "rate", SortAble: true},
	{Label: "媒体转化数", Prop: "media_convert_count", Format: "num"},
	{Label: "媒体转化成本", Prop: "media_convert_cost", Format: "cost"},
	{Label: "媒体首日付费数", Prop: "media_first_pay_count", Format: "num"},
	{Label: "媒体首日付费成本", Prop: "media_first_pay_cost", Format: "cost"},
	{Label: "实际收入", Prop: "income", Format: "cost", SortAble: true, IsDefault: true},
	{Label: "实际ROI", Prop: "roi", Format: "rate", SortAble: true, IsDefault: true},
	{Label: "实际激活数", Prop: "active_count", Format: "num"},
	{Label: "实际激活成本", Prop: "active_cost", Format: "cost"},
	{Label: "实际新增用户付费数", Prop: "new_pay_count", Format: "num"},
	{Label: "实际活跃用户付费数", Prop: "active_pay_count", Format: "num"},
	{Label: "首日新增收入", Prop: "first_income", Format: "cost", SortAble: true},
	{Label: "首日新增ROI", Prop: "first_roi", Format: "rate", SortAble: true},
	{Label: "新用户累计收入", Prop: "new_sum_income", Format: "cost"},
	{Label: "新用户累计ROI", Prop: "new_sum_roi", Format: "rate"},
	{Label: "人均IPU次数", Prop: "avg_ipu", Format: "num"},
	{Label: "ARPU", Prop: "arpu", Format: "cost"},
	{Label: "日利润", Prop: "profit", Format: "cost"},
	{Label: "新用户2日收入", Prop: "income2", Format: "cost"},
	{Label: "新用户3日收入", Prop: "income3", Format: "cost"},
	{Label: "新用户4日收入", Prop: "income4", Format: "cost"},
	{Label: "新用户5日收入", Prop: "income5", Format: "cost"},
	{Label: "新用户6日收入", Prop: "income6", Format: "cost"},
	{Label: "新用户7日收入", Prop: "income7", Format: "cost"},
	{Label: "新用户2日ROI", Prop: "roi2", Format: "rate"},
	{Label: "新用户3日ROI", Prop: "roi3", Format: "rate"},
	{Label: "新用户4日ROI", Prop: "roi4", Format: "rate"},
	{Label: "新用户5日ROI", Prop: "roi5", Format: "rate"},
	{Label: "新用户6日ROI", Prop: "roi6", Format: "rate"},
	{Label: "新用户7日ROI", Prop: "roi7", Format: "rate"}}

var SortKpiMapping = map[string]string{
	"date":               "日期",
	"cost":               "实际消耗",
	"media_cost":         "媒体消耗",
	"show_count":         "展示数",
	"click_count":        "点击数",
	"click_rate":         "点击率",
	"show_cost":          "千展成本",
	"click_cost":         "点击成本",
	"media_active_count": "媒体激活数",
	"media_active_cost":  "媒体激活成本",
	"media_active_rate":  "媒体激活率",
	"income":             "实际收入",
	"roi":                "实际ROI",
	"first_income":       "首日新增收入",
	"first_roi":          "首日新增ROI",
}

var KpiMapping = map[string]string{
	"cost":                     "实际消耗",
	"cost_hb":                  "消耗环比",
	"media_cost":               "媒体消耗",
	"show_count":               "展示数",
	"click_count":              "点击数",
	"click_rate":               "点击率",
	"spending_campaigns_count": "关联有消耗计划数",
	"show_cost":                "千展成本",
	"click_cost":               "点击成本",
	"media_active_count":       "媒体激活数",
	"media_active_cost":        "媒体激活成本",
	"media_active_rate":        "媒体激活率",
	"media_convert_count":      "媒体转化数",
	"media_convert_cost":       "媒体转化成本",
	"media_first_pay_count":    "媒体首日付费数",
	"media_first_pay_cost":     "媒体首日付费成本",
	"income":                   "实际收入",
	"roi":                      "实际ROI",
	"active_count":             "实际激活数",
	"active_cost":              "实际激活成本",
	"new_pay_count":            "实际新增用户付费数",
	"active_pay_count":         "实际活跃用户付费数",
	"first_income":             "首日新增收入",
	"first_roi":                "首日新增ROI",
	"new_sum_income":           "新用户累计收入",
	"new_sum_roi":              "新用户累计ROI",
	"avg_ipu":                  "人均IPU次数",
	"arpu":                     "ARPU",
	"profit":                   "日利润",
	"income2":                  "新用户2日收入",
	"income3":                  "新用户3日收入",
	"income4":                  "新用户4日收入",
	"income5":                  "新用户5日收入",
	"income6":                  "新用户6日收入",
	"income7":                  "新用户7日收入",
	"roi2":                     "新用户2日ROI",
	"roi3":                     "新用户3日ROI",
	"roi4":                     "新用户4日ROI",
	"roi5":                     "新用户5日ROI",
	"roi6":                     "新用户6日ROI",
	"roi7":                     "新用户7日ROI",
}
