package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	"goserver/app/common/dto/mediareport"
	ser "goserver/app/model/service/mediareport"
)

/***********************         新授权逻辑 令牌桶方式获取账单  start       ***********************/

func SyncBillInfo(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := mediareport.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("任务参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("账单数据时间错误, err: %s", err)
	}

	billInfoService := ser.NewBillInfoService(ctx)
	for _, crontabDate := range crontabDateList {
		err = billInfoService.DistributeBillAccounts(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("同步账单失败, err: %s", err)
		}
	}

	return "账单数据拉取成功"
}

/***********************         新授权逻辑 令牌桶方式获取账单  end       ***********************/
