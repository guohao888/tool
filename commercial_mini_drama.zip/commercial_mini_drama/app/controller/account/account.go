package account

import (
	"fmt"
	"github.com/gin-gonic/gin"
	accountsDto "goserver/app/common/dto/accounts"
	"goserver/app/library/log"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	accountsService "goserver/app/model/service/accounts"
	"net/http"
	"time"
)

// Filter 筛选项
func Filter(c *gin.Context) {
	r := response.Gin{Ctx: c}
	//accountsDto := accountsDto.NewFilterReq(c)
	accountService := accountsService.NewAccountService(c)
	resp, err := accountService.GetFilterOptions()
	if err != nil {
		r.Response(myerror.ParamsError.Code, myerror.ParamsError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, resp)
}

func OptionSearch(c *gin.Context) {
	r := response.Gin{Ctx: c}
	optionSearchReq := accountsDto.NewOptionSearchReq(c)
	accountService := accountsService.NewAccountService(c)
	resp, err := accountService.GetOptionSearch(optionSearchReq.Params)
	if err != nil {
		r.Response(myerror.ParamsError.Code, myerror.ParamsError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, resp)
}

// DataList 数据列表
func DataList(c *gin.Context) {
	r := response.Gin{Ctx: c}
	dataListReq := accountsDto.NewAccountDataListReq(c)
	accountService := accountsService.NewAccountService(c)
	list, err := accountService.GetDataList(dataListReq.Params)
	if err != nil {
		r.Response(myerror.AccountDataListError.Code, myerror.AccountDataListError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, list)
}

// Export 数据导出
func Export(c *gin.Context) {
	r := response.Gin{Ctx: c}
	dataListReq := accountsDto.NewAccountDataExportReq(c)
	accountService := accountsService.NewAccountService(c)
	list, err := accountService.GetDataList(dataListReq.Params)
	if err != nil {
		r.Response(myerror.AccountDataListError.Code, myerror.AccountDataListError.Message, nil)
		return
	}
	xlFile, err := accountService.InfraDataDownload(dataListReq.Params.ListType, list)
	if err != nil {
		log.Errorf("InfraDataList download err: %v", err)
		r.Response(myerror.InternalServerError.Code, myerror.InternalServerError.Message, nil)
		return
	}
	fileName := fmt.Sprintf("%s_%s.xlsx", dataListReq.Params.ListType, time.Now().Format("20060102150405"))
	// 设置响应头
	c.Header("Content-Type", "application/force-download")
	c.Header("Content-Disposition", "attachment;filename="+fileName)
	//文件内容写入返回体
	_ = xlFile.Write(c.Writer)
	c.Status(http.StatusOK)
	c.Abort()
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

func AddFilterOptions(c *gin.Context) {
	r := response.Gin{Ctx: c}
	//addReq := accountsDto.NewAccountAddReq(c)
	accountService := accountsService.NewAccountService(c)
	list, err := accountService.AddFilterList()
	if err != nil {
		r.Response(myerror.AddOptionsListError.Code, myerror.AddOptionsListError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, list)
}

// Add 新增账户
func Add(c *gin.Context) {
	r := response.Gin{Ctx: c}
	addReq := accountsDto.NewAccountAddReq(c)
	accountService := accountsService.NewAccountService(c)
	err := accountService.AddAccount(addReq.Params)
	if err != nil {
		r.Response(myerror.AccountInsertError.Code, myerror.AccountInsertError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

// Import 批量导入账户
func Import(c *gin.Context) {
	r := response.Gin{Ctx: c}
	importReq := accountsDto.NewImportReq(c)
	accountService := accountsService.NewAccountService(c)
	advertiserIdSlice, err := accountService.Import(importReq.Params)
	if err != nil {
		r.Response(myerror.AccountImportError.Code, myerror.AccountImportError.Message, nil)
		return
	}
	resp := accountsDto.ImportResp{
		SuccessAdvertiserId: advertiserIdSlice,
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, resp)
}

// BatchAction 批量账户关停、开启操作
func BatchAction(c *gin.Context) {
	r := response.Gin{Ctx: c}
	batchReq := accountsDto.NewBatchActionReq(c)
	accountService := accountsService.NewAccountService(c)
	err := accountService.BatchAction(batchReq.Params)
	if err != nil {
		r.Response(myerror.BatchActionError.Code, myerror.BatchActionError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

// Update 更新账户信息
func Update(c *gin.Context) {
	r := response.Gin{Ctx: c}
	updateReq := accountsDto.NewUpdateReq(c)
	accountService := accountsService.NewAccountService(c)
	err := accountService.Update(updateReq.Params)
	if err != nil {
		r.Response(myerror.AccountUpdateError.Code, myerror.AccountUpdateError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}
