package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/spf13/viper"
	"github.com/tealeg/xlsx"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/widthtable"
	wModel "goserver/app/common/repository/warning"
	"goserver/app/library/utils"
	noticeCommon "goserver/app/library/utils/notice/common"
	"goserver/app/model/dao/accounts"
	"goserver/app/model/service/warning"
	"os"
	"strconv"
	"strings"
	"time"
)

func ExecMonitor(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	monitorService := warning.NewMonitorService(ctx)
	// 按 时间间隔 列表
	execListOne, err1 := monitorService.GetExecMonitorList(1)
	if err1 != nil {
		return fmt.Sprintf("获取时间间隔任务列表失败 error: %s", err1.Error())
	}
	// 按 定时 列表
	execListTwo, err2 := monitorService.GetExecMonitorList(2)
	if err2 != nil {
		return fmt.Sprintf("获取定时任务列表失败 error: %s", err2.Error())
	}
	if len(execListOne) != 0 {
		execErr1 := buildExecSqlIntervalType(ctx, execListOne)
		if execErr1 != nil {
			return fmt.Sprintf("盯盘时间间隔任务失败, err :%s", execErr1.Error())
		}
	}
	if len(execListTwo) != 0 {
		execErr2 := buildExecSqlTime(ctx, execListTwo)
		if execErr2 != nil {
			return fmt.Sprintf("盯盘定时任务失败, err :%s", execErr2.Error())
		}
	}
	return "盯盘任务执行成功"
}

func buildExecSqlIntervalType(ctx context.Context, list []*wModel.MonitorInfoEntity) error {
	monitorService := warning.NewMonitorService(ctx)
	for _, v := range list {
		execHour, _ := strconv.Atoi(v.IntervalValue)
		if time.Now().Hour()%execHour == 0 && time.Now().Minute() < 5 {
			switch v.TaskType {
			case 2:
				sqlReject := buildExecRejectSql(v)
				reList, msgTo, err := monitorService.GetExecRejectTask(sqlReject)
				if err != nil {
					return err
				}
				if len(reList) == 0 {
					return nil
				}
				// 构建Excel
				UploadMediaMonitor(reList, nil, msgTo, v.MsgTo, true)
			case 3:
				if v.Media == 2 {
					roiSql := buildExecROISql(v)
					roiList, msgTo, err := monitorService.GetExecROITask(roiSql)
					if err != nil {
						return err
					}
					if len(roiList) == 0 {
						return nil
					}
					// 构建Excel
					UploadMediaMonitor(nil, roiList, msgTo, v.MsgTo, false)
				} else {
					kuaishouSql := buildExecROISql(v)
					roiList, msgTo, err := monitorService.GetExecKuaishouROITask(kuaishouSql)
					if err != nil {
						return err
					}
					if len(roiList) == 0 {
						return nil
					}
					// 构建Excel
					UploadMediaMonitor(nil, roiList, msgTo, v.MsgTo, false)
				}
			case 4:
				if v.Media == 2 {
					scheduleSql := buildScheduleSql(v)
					scheduleList, msgTo, err := monitorService.GetWeekSchedule(scheduleSql, v.Operation)
					if err != nil {
						return err
					}
					if len(scheduleList) == 0 {
						return nil
					}
					// 构建Excel
					UploadSchedule(scheduleList, msgTo, v.MsgTo)
				} else {
					scheduleSql := buildScheduleSql(v)
					scheduleList, msgTo, err := monitorService.GetKuaishouSchedule(scheduleSql, v.Operation)
					if err != nil {
						return err
					}
					if len(scheduleList) == 0 {
						return nil
					}
					// 构建Excel
					UploadSchedule(scheduleList, msgTo, v.MsgTo)
				}
			}
		}
	}
	return nil
}

func buildExecSqlTime(ctx context.Context, list []*wModel.MonitorInfoEntity) error {
	monitorService := warning.NewMonitorService(ctx)
	for _, v := range list {
		times := strings.Split(v.EffectiveValue, ";")
		execHour, _ := strconv.Atoi(times[0])
		execMinute, _ := strconv.Atoi(times[1])
		if time.Now().Hour() == execHour && time.Now().Minute() == execMinute {
			switch v.TaskType {
			case 2:
				sqlReject := buildExecRejectSql(v)
				reList, msgTo, err := monitorService.GetExecRejectTask(sqlReject)
				if err != nil {
					return err
				}
				// 构建Excel
				UploadMediaMonitor(reList, nil, msgTo, v.MsgTo, true)
			case 3:
				roiSql := buildExecROISql(v)
				roiList, msgTo, err := monitorService.GetExecROITask(roiSql)
				if err != nil {
					return err
				}
				// 构建Excel
				UploadMediaMonitor(nil, roiList, msgTo, v.MsgTo, false)
			case 4:
				if v.Media == 2 {
					scheduleSql := buildScheduleSql(v)
					scheduleList, msgTo, err := monitorService.GetWeekSchedule(scheduleSql, v.Operation)
					if err != nil {
						return err
					}
					// 构建Excel
					UploadSchedule(scheduleList, msgTo, v.MsgTo)
				} else {
					scheduleSql := buildScheduleSql(v)
					scheduleList, msgTo, err := monitorService.GetKuaishouSchedule(scheduleSql, v.Operation)
					if err != nil {
						return err
					}
					if len(scheduleList) == 0 {
						return nil
					}
					// 构建Excel
					UploadSchedule(scheduleList, msgTo, v.MsgTo)
				}

			}
		}
	}
	return nil
}

func UploadMediaMonitor(reList []wModel.RejectInfo, roiList []wModel.ROIMonitor, msgTo string, extraTo string, isReject bool) {
	var file *os.File
	var err error
	filePath := ""
	if isReject {
		filePath = "/drama/reject_monitor.xlsx"
		file, err = createMonitorRejectExcel(reList)
	} else {
		filePath = "/drama/roi_monitor.xlsx"
		file, err = createMonitorRoiExcel(roiList)
	}
	if err != nil {
		return
	}
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return
	}
	var toUser []string
	if msgTo != "" {
		var msg []string
		for _, vv := range strings.Split(msgTo, ",") {
			msg = append(msg, vv)
		}
		optimizerDao := accounts.NewOptimizerInfoDao(context.Background())
		opList, opErr := optimizerDao.OptimizerInfoListByNamePhone(msg)
		if opErr != nil {
			return
		}
		for _, v := range opList {
			toUser = append(toUser, v.Phone)
		}
	}

	toUser = append(toUser, strings.Split(extraTo, ",")...)
	msg := &noticeCommon.SingleMessage{
		Tousers:    toUser,
		Msgtype:    "attachment",
		Attachment: &noticeCommon.Attachment{MediaID: res.MediaID},
	}
	resp, err := client.SendMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return
	}
	return
}

func createMonitorRoiExcel(list []wModel.ROIMonitor) (*os.File, error) {
	// 1. 创建新 Excel 文件和工作表
	file := xlsx.NewFile()
	sheet, err := file.AddSheet("Sheet1")
	if err != nil {
		return nil, fmt.Errorf("创建工作表失败: %v", err)
	}
	//标题行
	var title []string
	var keys = []string{"AdvertiserId", "AdvertiserName", "MediaCost", "Income", "ROI"}
	for _, v := range keys {
		title = append(title, titleMap[v])
	}

	row := sheet.AddRow()
	for _, v := range title {
		row.AddCell().Value = v
	}

	for _, v := range list {
		row = sheet.AddRow()
		data, _ := json.Marshal(v)
		var m = make(map[string]interface{})
		_ = json.Unmarshal(data, &m)
		for _, key := range keys {
			if val, ok := m[key]; ok {
				switch key {
				case "MediaCost", "Income", "ROI":
					cv := utils.Convert2Float64(val)
					row.AddCell().SetFloat(cv)
				default:
					cv := utils.Convert2String(val)
					row.AddCell().Value = cv
				}
			}
		}
	}
	// 3. 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.xlsx")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close() // 立即关闭以便后续操作

	// 4. 将 Excel 写入临时文件
	if fileErr := file.Write(tempFile); fileErr != nil {
		_ = os.Remove(tempFile.Name()) // 写入失败时清理文件
		return nil, fmt.Errorf("写入 Excel 失败: %v", fileErr)
	}

	// 5. 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}

	return outputFile, nil
}

func createMonitorRejectExcel(list []wModel.RejectInfo) (*os.File, error) {
	// 1. 创建新 Excel 文件和工作表
	file := xlsx.NewFile()
	sheet, err := file.AddSheet("Sheet1")
	if err != nil {
		return nil, fmt.Errorf("创建工作表失败: %v", err)
	}
	//标题行
	var title []string
	var keys = []string{"AccountId", "MaterialId", "FileName", "AccountName", "ProjectId", "ProjectName", "RejectReason", "Suggestion"}
	for _, v := range keys {
		title = append(title, titleMap[v])
	}

	row := sheet.AddRow()
	for _, v := range title {
		row.AddCell().Value = v
	}

	for _, v := range list {
		row = sheet.AddRow()
		data, _ := json.Marshal(v)
		var m = make(map[string]interface{})
		_ = json.Unmarshal(data, &m)
		for _, key := range keys {
			if val, ok := m[key]; ok {
				cv := utils.Convert2String(val)
				row.AddCell().Value = cv
			}
		}
	}
	// 3. 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.xlsx")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close() // 立即关闭以便后续操作

	// 4. 将 Excel 写入临时文件
	if fileErr := file.Write(tempFile); fileErr != nil {
		_ = os.Remove(tempFile.Name()) // 写入失败时清理文件
		return nil, fmt.Errorf("写入 Excel 失败: %v", fileErr)
	}

	// 5. 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}

	return outputFile, nil
}

var titleMap = map[string]string{
	"AccountId":      "所属账户ID",
	"MaterialId":     "素材ID",
	"FileName":       "素材名称",
	"AccountName":    "所属账户名称",
	"ProjectId":      "所属项目ID",
	"ProjectName":    "所属项目名称",
	"RejectReason":   "拒绝建议",
	"Suggestion":     "审核建议",
	"AdvertiserId":   "账户ID",
	"AdvertiserName": "账户名称",
	"MediaCost":      "账面消耗",
	"Income":         "账面收入",
	"ROI":            "ROI",
}

// buildExecRejectSql 执行拒审查询条件拼接
func buildExecRejectSql(v *wModel.MonitorInfoEntity) (sqlInfo wModel.ExecSqlInfo) {
	sql := ""
	if v.Metrics == 1 {
		numericalList := strings.Split(v.Numerical, ";")
		if v.Condition == "between" {
			sql += " media_cost  BETWEEN " + numericalList[0] + "' AND '" + numericalList[1] + "' "
		} else {
			sql += " media_cost " + v.Condition + " " + v.Numerical + " "
		}
	}
	if v.Metrics == 2 {
		if len(sql) > 0 {
			sql += " AND "
		}
		numericalList := strings.Split(v.Numerical, ";")
		if v.Condition == "between" {
			sql += " reject_time BETWEEN " + numericalList[0] + "' AND '" + numericalList[1] + "' "
		} else {
			sql += " reject_time " + v.Condition + " " + v.Numerical + " "
		}
	}
	if v.MetricsTwo == 1 {
		if len(sql) > 0 {
			sql += " AND "
		}
		numericalTowList := strings.Split(v.NumericalTwo, ";")
		if v.ConditionTwo == "between" {
			sql += " media_cost BETWEEN " + numericalTowList[0] + " AND " + numericalTowList[1] + " "
		} else {
			sql += " media_cost " + v.ConditionTwo + " " + v.NumericalTwo + " "
		}
	}
	if v.MetricsTwo == 2 {
		if len(sql) > 0 {
			sql += " AND "
		}
		numericalTowList := strings.Split(v.NumericalTwo, ";")
		if v.ConditionTwo == "between" {
			sql += " reject_time BETWEEN " + numericalTowList[0] + " AND " + numericalTowList[1] + " "
		} else {
			sql += " reject_time " + v.ConditionTwo + " " + v.NumericalTwo + " "
		}
	}
	var start, end, startTwo, endTwo string
	if v.DateCondition == 1 {
		start = time.Now().Add(-86400).Format(time.DateOnly)
		end = time.Now().Format(time.DateOnly)
	}
	if v.DateCondition == 2 {
		start = time.Now().Format(time.DateOnly)
		end = start
	}
	if v.DateCondition == 3 {
		start = time.Now().AddDate(0, 0, -3).Format(time.DateOnly)
		end = time.Now().Format(time.DateOnly)
	}
	if v.DateConditionTwo == 1 {
		startTwo = time.Now().Add(-86400).Format(time.DateOnly)
		endTwo = time.Now().Format(time.DateOnly)
	}
	if v.DateConditionTwo == 2 {
		startTwo = time.Now().Format(time.DateOnly)
		endTwo = start
	}
	if v.DateConditionTwo == 3 {
		startTwo = time.Now().AddDate(0, 0, -3).Format(time.DateOnly)
		endTwo = time.Now().Format(time.DateOnly)
	}
	if v.ScopeType == 2 {
		sql += " AND rej.advertiser_id in (" + v.ScopeValue + " )"
	}
	var startTimeList, endTimeList []wModel.K2V
	startTimeList = append(startTimeList, wModel.K2V{
		K: v.Metrics,
		V: start,
	}, wModel.K2V{
		K: v.MetricsTwo,
		V: startTwo,
	})
	endTimeList = append(endTimeList, wModel.K2V{
		K: v.Metrics,
		V: end,
	}, wModel.K2V{
		K: v.MetricsTwo,
		V: endTwo,
	})
	info := wModel.ExecSqlInfo{
		Start:    startTimeList,
		End:      endTimeList,
		MsgTo:    v.MsgTo,
		WhereSql: sql,
	}
	return info
}

// buildExecRejectSql 执行ROI查询条件拼接
func buildExecROISql(v *wModel.MonitorInfoEntity) (sqlInfo wModel.ExecSqlInfo) {
	sql := ""
	if v.Metrics == 1 {
		numericalList := strings.Split(v.Numerical, ";")
		if v.Condition == "between" {
			sql += " cos.media_cost BETWEEN " + numericalList[0] + " AND " + numericalList[1] + " "
		} else {
			sql += " cos.media_cost " + v.Condition + " " + v.Numerical + " "
		}
	}
	if v.Metrics == 3 {
		if len(sql) > 0 {
			sql += " AND "
		}
		numericalList := strings.Split(v.Numerical, ";")
		if v.Condition == "between" {
			numerical1, _ := strconv.Atoi(numericalList[0])
			numerical2, _ := strconv.Atoi(numericalList[1])
			sql += " roi BETWEEN " + fmt.Sprintf("%.2f", float64(numerical1)/100) + " AND " + fmt.Sprintf("%.2f", float64(numerical2)/100) + " "
		} else {
			numerical, _ := strconv.Atoi(numericalList[0])
			sql += " roi " + v.Condition + " " + fmt.Sprintf("%.2f", float64(numerical)/100) + " "
		}
	}
	if v.MetricsTwo == 1 {
		if len(sql) > 0 {
			sql += " AND "
		}
		numericalTwoList := strings.Split(v.NumericalTwo, ";")
		if v.ConditionTwo == "between" {
			sql += " media_cost BETWEEN " + numericalTwoList[0] + " AND " + numericalTwoList[1] + " "
		} else {
			sql += " media_cost " + v.ConditionTwo + " " + v.NumericalTwo + " "
		}
	}
	if v.MetricsTwo == 3 {
		if len(sql) > 0 {
			sql += " AND "
		}
		numericalTwoList := strings.Split(v.NumericalTwo, ";")
		if v.ConditionTwo == "between" {
			numerical1, _ := strconv.Atoi(numericalTwoList[0])
			numerical2, _ := strconv.Atoi(numericalTwoList[1])
			sql += " roi BETWEEN " + fmt.Sprintf("%.2f", float64(numerical1)/100) + " AND " + fmt.Sprintf("%.2f", float64(numerical2)/100) + " "
		} else {
			numerical, _ := strconv.Atoi(v.NumericalTwo)
			sql += " roi " + v.ConditionTwo + " " + fmt.Sprintf("%.2f", float64(numerical)/100) + " "
		}
	}
	var start, end, startTwo, endTwo string
	if v.DateCondition == 1 {
		start = time.Now().Add(-86400).Format(time.DateOnly)
		end = time.Now().Format(time.DateOnly)
	}
	if v.DateCondition == 2 {
		start = time.Now().Format(time.DateOnly)
		end = start
	}
	if v.DateCondition == 3 {
		start = time.Now().AddDate(0, 0, -3).Format(time.DateOnly)
		end = time.Now().Format(time.DateOnly)
	}
	if v.DateConditionTwo == 1 {
		startTwo = time.Now().Add(-86400).Format(time.DateOnly)
		endTwo = time.Now().Format(time.DateOnly)
	}
	if v.DateConditionTwo == 2 {
		startTwo = time.Now().Format(time.DateOnly)
		endTwo = start
	}
	if v.DateConditionTwo == 3 {
		startTwo = time.Now().AddDate(0, 0, -3).Format(time.DateOnly)
		endTwo = time.Now().Format(time.DateOnly)
	}
	if v.ScopeType == 2 {
		if v.Media == 2 {
			sql += " AND cosr.account_id in (" + v.ScopeValue + " )"
		} else if v.Media == 3 {

		}

	}
	var startTimeList, endTimeList []wModel.K2V
	startTimeList = append(startTimeList, wModel.K2V{
		K: v.Metrics,
		V: start,
	}, wModel.K2V{
		K: v.MetricsTwo,
		V: startTwo,
	})
	endTimeList = append(endTimeList, wModel.K2V{
		K: v.Metrics,
		V: end,
	}, wModel.K2V{
		K: v.MetricsTwo,
		V: endTwo,
	})
	info := wModel.ExecSqlInfo{
		Start:    startTimeList,
		End:      endTimeList,
		MsgTo:    v.MsgTo,
		WhereSql: sql,
	}
	return info
}

// buildScheduleSql 执行ROI查询条件拼接
func buildScheduleSql(v *wModel.MonitorInfoEntity) (sqlInfo wModel.ExecSqlInfo) {
	sql := ""
	if v.Metrics == 1 {
		numericalList := strings.Split(v.Numerical, ";")
		if v.Condition == "between" {
			sql += " cos.cost BETWEEN " + numericalList[0] + " AND " + numericalList[1] + " "
		} else {
			sql += " cos.cost " + v.Condition + " " + v.Numerical + " "
		}
	}
	if v.Metrics == 3 {
		if len(sql) > 0 {
			sql += " AND "
		}
		numericalList := strings.Split(v.Numerical, ";")
		if v.Condition == "between" {
			numerical1, _ := strconv.Atoi(numericalList[0])
			numerical2, _ := strconv.Atoi(numericalList[1])
			sql += " roi BETWEEN " + fmt.Sprintf("%.2f", float64(numerical1)/100) + " AND " + fmt.Sprintf("%.2f", float64(numerical2)/100) + " "
		} else {
			numerical, _ := strconv.Atoi(v.Numerical)
			sql += " roi " + v.Condition + " " + fmt.Sprintf("%.2f", float64(numerical)/100) + " "
		}
	}
	if v.MetricsTwo == 1 {
		if len(sql) > 0 {
			sql += " AND "
		}
		numericalTwoList := strings.Split(v.NumericalTwo, ";")
		if v.ConditionTwo == "between" {
			sql += " cos.cost BETWEEN " + numericalTwoList[0] + " AND " + numericalTwoList[1] + " "
		} else {
			sql += " cos.cost " + v.ConditionTwo + " " + v.NumericalTwo + " "
		}
	}
	if v.MetricsTwo == 3 {
		if len(sql) > 0 {
			sql += " AND "
		}
		numericalTwoList := strings.Split(v.NumericalTwo, ";")
		if v.ConditionTwo == "between" {
			numerical1, _ := strconv.Atoi(numericalTwoList[0])
			numerical2, _ := strconv.Atoi(numericalTwoList[1])
			sql += " roi BETWEEN " + fmt.Sprintf("%.2f", float64(numerical1)/100) + " AND " + fmt.Sprintf("%.2f", float64(numerical2)/100) + " "
		} else {
			numerical, _ := strconv.Atoi(v.NumericalTwo)
			sql += " roi " + v.Condition + " " + fmt.Sprintf("%.2f", float64(numerical)/100) + " "
		}
	}
	var start, end, startTwo, endTwo string
	if v.DateCondition == 1 {
		start = time.Now().Add(-86400).Format(time.DateOnly)
		end = time.Now().Format(time.DateOnly)
	}
	if v.DateCondition == 2 {
		start = time.Now().Format(time.DateOnly)
		end = start
	}
	if v.DateCondition == 3 {
		start = time.Now().AddDate(0, 0, -3).Format(time.DateOnly)
		end = time.Now().Format(time.DateOnly)
	}
	if v.DateConditionTwo == 1 {
		startTwo = time.Now().Add(-86400).Format(time.DateOnly)
		endTwo = time.Now().Format(time.DateOnly)
	}
	if v.DateConditionTwo == 2 {
		startTwo = time.Now().Format(time.DateOnly)
		endTwo = start
	}
	if v.DateConditionTwo == 3 {
		startTwo = time.Now().AddDate(0, 0, -3).Format(time.DateOnly)
		endTwo = time.Now().Format(time.DateOnly)
	}
	if v.ScopeType == 2 {
		sql += " AND cos.account_id in ( '" + v.ScopeValue + "' )"
	}
	var startTimeList, endTimeList []wModel.K2V
	startTimeList = append(startTimeList, wModel.K2V{
		K: v.Metrics,
		V: start,
	}, wModel.K2V{
		K: v.MetricsTwo,
		V: startTwo,
	})
	endTimeList = append(endTimeList, wModel.K2V{
		K: v.Metrics,
		V: end,
	}, wModel.K2V{
		K: v.MetricsTwo,
		V: endTwo,
	})
	info := wModel.ExecSqlInfo{
		Start:    startTimeList,
		End:      endTimeList,
		MsgTo:    v.MsgTo,
		WhereSql: sql,
	}
	return info
}

func UploadSchedule(scheduleList []wModel.WeekSchedule, msgTo string, extraTo string) {
	var file *os.File
	var err error
	filePath := "/drama/week_schedule_monitor.xlsx"
	file, err = createScheduleExcel(scheduleList)
	if err != nil {
		return
	}
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return
	}
	var toUser []string
	if msgTo != "" {
		var msg []string
		for _, v := range strings.Split(msgTo, ",") {
			msg = append(msg, v)
		}
		optimizerDao := accounts.NewOptimizerInfoDao(context.Background())
		opList, opErr := optimizerDao.OptimizerInfoListByNamePhone(msg)
		if opErr != nil {
			return
		}
		for _, v := range opList {
			toUser = append(toUser, v.Phone)
		}
	}
	toUser = append(toUser, strings.Split(extraTo, ",")...)
	msg := &noticeCommon.SingleMessage{
		Tousers:    toUser,
		Msgtype:    "attachment",
		Attachment: &noticeCommon.Attachment{MediaID: res.MediaID},
	}
	resp, err := client.SendMessage(msg)
	if err == nil && resp.Errcode != 0 {
		return
	}
	return
}

func createScheduleExcel(list []wModel.WeekSchedule) (*os.File, error) {
	// 1. 创建新 Excel 文件和工作表
	file := xlsx.NewFile()
	sheet, err := file.AddSheet("Sheet1")
	if err != nil {
		return nil, fmt.Errorf("创建工作表失败: %v", err)
	}
	//标题行
	var title []string
	var keys = []string{"AdvertiserId", "AdvertiserName", "ProjectId", "ProjectName", "Cost", "ROI", "Operation", "Result", "ErrMsg"}
	for _, v := range keys {
		title = append(title, ScheduleTitleMap[v])
	}

	row := sheet.AddRow()
	for _, v := range title {
		row.AddCell().Value = v
	}

	for _, v := range list {
		row = sheet.AddRow()
		data, _ := json.Marshal(v)
		var m = make(map[string]interface{})
		_ = json.Unmarshal(data, &m)
		for _, key := range keys {
			if val, ok := m[key]; ok {
				cv := utils.Convert2String(val)
				row.AddCell().Value = cv
			}
		}
	}
	// 3. 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.xlsx")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close() // 立即关闭以便后续操作

	// 4. 将 Excel 写入临时文件
	if fileErr := file.Write(tempFile); fileErr != nil {
		_ = os.Remove(tempFile.Name()) // 写入失败时清理文件
		return nil, fmt.Errorf("写入 Excel 失败: %v", fileErr)
	}

	// 5. 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}

	return outputFile, nil
}

var ScheduleTitleMap = map[string]string{
	"AdvertiserId":   "账户ID",
	"AdvertiserName": "账户名称",
	"ProjectId":      "所属项目ID",
	"ProjectName":    "所属项目名称",
	"Cost":           "项目消耗",
	"ROI":            "项目ROI",
	"Operation":      "操作",
	"Result":         "操作结果",
	"ErrMsg":         "失败原因",
}

func ExecReverseSchedule(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	monitorService := warning.NewMonitorService(ctx)
	scheduleList, msgTo, err := monitorService.GetWeekScheduleT1()
	if err != nil {
		return fmt.Sprintf("反向拉空失败: %s", err.Error())
	}
	UploadSchedule(scheduleList, msgTo, "")
	return "反向拉空成功"
}

func ExecReverseKuaishouSchedule(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	monitorService := warning.NewMonitorService(ctx)
	scheduleList, msgTo, err := monitorService.GetKuaishouWeekScheduleT1()
	if err != nil {
		return fmt.Sprintf("反向拉空失败: %s", err.Error())
	}
	UploadSchedule(scheduleList, msgTo, "")
	return "反向拉空成功"
}
