package raw

import (
	"encoding/base64"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/tealeg/xlsx"
	rawEntity "goserver/app/common/repository/raw"
	"goserver/app/library/myerror"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/raw"
	"time"
)

// ExcelUploadRequest 定义请求结构体
type ExcelUploadRequest struct {
	FileName    string `json:"fileName" binding:"required"`
	FileContent string `json:"fileContent" binding:"required"` // Base64 编码的 Excel 文件内容
}

// Import 批量导入账户
func Import(c *gin.Context) {
	r := response.Gin{Ctx: c}
	var request ExcelUploadRequest

	// 1. 绑定 JSON 请求体
	if err := c.ShouldBindJSON(&request); err != nil {
		r.Response(myerror.ReferralImportFileError.Code, myerror.ReferralImportFileError.Message, nil)
		return
	}

	// 2. 解码 Base64 文件内容
	fileBytes, err := base64.StdEncoding.DecodeString(request.FileContent)
	if err != nil {
		r.Response(myerror.ReferralImportOpenFileError.Code, myerror.ReferralImportOpenFileError.Message, nil)
		return
	}

	// 3. 解析 Excel 文件
	excelData, err := parseExcelWithXlsx(fileBytes)
	if err != nil {
		r.Response(myerror.ReferralImportFileParseError.Code, myerror.ReferralImportFileParseError.Message, nil)
		return
	}

	// 4. 保存数据
	referralService := raw.NewReferralService(c)
	err = referralService.Import(excelData)
	if err != nil {
		r.Response(myerror.ReferralImportError.Code, myerror.ReferralImportError.Message, nil)
		return
	}
	// 5. 返回成功响应
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

// 解析 Excel 文件
func parseExcelWithXlsx(fileBytes []byte) ([]rawEntity.ReferralEntity, error) {
	// 3.2 打开 Excel 文件
	xlFile, err := xlsx.OpenBinary(fileBytes)
	if err != nil {
		return nil, fmt.Errorf("打开Excel文件失败: %w", err)
	}

	// 3.3 获取第一个工作表
	if len(xlFile.Sheets) == 0 {
		return nil, fmt.Errorf("Excel 文件中没有工作表")
	}
	sheet := xlFile.Sheets[0]

	// 3.4 验证是否有数据
	if len(sheet.Rows) < 2 {
		return nil, fmt.Errorf("Excel 文件至少需要包含标题行和一行数据")
	}

	// 3.6 解析数据行
	var referralInfo []rawEntity.ReferralEntity
	for _, row := range sheet.Rows[1:] {
		// 跳过空行
		if len(row.Cells) == 0 {
			continue
		}
		hashId := row.Cells[0].Value
		referralUrl := row.Cells[1].Value
		bookName := row.Cells[2].Value
		copyrightOwner := row.Cells[3].Value

		referralInfo = append(referralInfo, rawEntity.ReferralEntity{
			HashId:         hashId,
			ReferralUrl:    referralUrl,
			BookName:       bookName,
			CopyrightOwner: copyrightOwner,
			CreatedTime:    time.Now(),
		})
	}
	return referralInfo, nil
}
