package accountadd

import "goserver/app/common/repository"

const AddAccountEntityTable = "account_add"

type AddAccountEntity struct {
	AdvertiserId string `gorm:"column:advertiser_id"` // 广告主id
	CreatedTime  string `gorm:"column:created_time"`  // 推送时间
	Status       int    `gorm:"column:status"`        // 推送状态
}

func (*AddAccountEntity) TableName() string {
	return AddAccountTableName()
}

func AddAccountTableName() string {
	if repository.IsDebugTable(AddAccountEntityTable) {
		return AddAccountEntityTable + "_dev"
	} else {
		return AddAccountEntityTable
	}
}
