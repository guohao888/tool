package middleware

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common"
	"goserver/app/library/log"
	"goserver/app/library/myerror"
	"time"
)

func PermissionMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		req := common.GetRequest(c)
		// 验证权限是否足够
		if len(req.UserInfo.Permission) <= 0 && req.UserInfo.Role != 1 && req.UserInfo.Role != 2 {
			log.Errorf("[permission] server sign mis match, client token: %s; user_name: %s", req.Token, req.UserInfo.Name)
			panic(myerror.PermissionError)
		}
		log.Debugf("权限校验结束时间：%v", time.Now().UnixNano()/1e6)
	}
}
