package warningdto

import (
	"github.com/gin-gonic/gin"
	"github.com/shopspring/decimal"
	"goserver/app/common"
	"goserver/app/library/myerror"
)

// SearchFilter 告警任务查询筛选项
type SearchFilter struct {
	StartDate         string `json:"start_date" form:"start_date"` // 开始日期
	EndDate           string `json:"end_date" form:"end_date"`     // 结束日期
	Media             string `json:"media" form:"media"`           // 媒体
	TaskId            string `json:"task_id" form:"task_id"`       // 任务ID
	CreateBy          string `json:"create_by" form:"create_by"`   // 创建人
	common.Pagination        // 分页
	common.CommonParams
}

type SearchResp struct {
	OptimizerList  []Optimizer   `json:"optimizer_list" form:"optimizer_list"`
	MediaList      []MediaStruct `json:"media_list" form:"media_list"`
	AdvertiserList []Advertiser  `json:"advertiser_list" form:"advertiser_list"`
	AlbumList      []Album       `json:"album_list" form:"album_list"`
	MaList         []MaStruct    `json:"ma_list" form:"ma_list"`
}

type MaStruct struct {
	Val string `json:"val" form:"val" gorm:"column:material_id"`
}

type MediaStruct struct {
	Val string `json:"val" form:"val" gorm:"column:media"`
}

type Advertiser struct {
	Val string `json:"val" form:"val" gorm:"column:advertiser_id"`
}

type Optimizer struct {
	Val string `json:"val" form:"val" gorm:"column:optimizer_name"`
}

type Album struct {
	Val string `json:"val" form:"val" gorm:"column:book_name"`
}

type SearchOptionReq struct {
	SearchType string `json:"search_type" form:"search_type"`
	Val        string `json:"val" form:"val"`
}

// TaskInfos 新建/修改告警任务
type TaskInfos struct {
	common.CommonParams
	ForeignKey string          `json:"foreign_key" form:"foreign_key"` // 外键
	TaskName   string          `json:"task_name" form:"task_name"`     // 告警任务名称
	WarningTag string          `json:"warning_tag" form:"warning_tag"` // 告警标签
	Dimension  string          `json:"dimension" form:"dimension"`     // 告警维度
	Metrics    string          `json:"metrics" form:"metrics"`         // 指标
	Interval   int             `json:"interval" form:"interval"`       // 时间间隔
	Condition  string          `json:"condition" form:"condition"`     // 条件
	Numerical  decimal.Decimal `json:"numerical" form:"numerical"`     // 数值
	State      int             `json:"state" form:"state"`             // 任务状态
	MsgTo      string          `json:"msg_to" form:"msg_to"`           // 告警人
	Content    string          `json:"content" form:"content"`         // 内容 使用;分割
}

// TaskList 告警任务列表
type TaskList struct {
	SearchDate string `json:"search_date" form:"search_date"` // 日期
	TaskId     string `json:"task_id" form:"task_id"`         // 任务ID
	TaskName   string `json:"task_name" form:"task_name"`     // 告警任务名称
	ExecTime   string `json:"exec_time" form:"exec_time"`     // 执行时间
}

type MaterialList struct {
	SearchDate string  `json:"search_date" form:"search_date"` // 日期
	Media      string  `json:"media" form:"media"`             // 媒体
	AlbumName  string  `json:"album_name" form:"album_name"`   // 剧目名称
	MaterialId string  `json:"material_id" form:"material_id"` // 素材ID
	Cost       float64 `json:"cost" form:"cost"`               // 素材花费
	RejectTime int64   `json:"reject_time" form:"reject_time"` // 拒审次数
}

type MaterialListReq struct {
	StartDate         string `json:"start_date" form:"start_date"`       // 开始日期
	EndDate           string `json:"end_date" form:"end_date"`           // 结束日期
	Media             string `json:"media" form:"media"`                 // 媒体
	MaterialId        string `json:"material_id" form:"material_id"`     // 素材ID
	AdvertiserId      string `json:"advertiser_id" form:"advertiser_id"` // 账号ID
	AlbumName         string `json:"album_name" form:"album_name"`       // 剧目名称
	Optimizer         string `json:"optimizer" form:"optimizer"`         // 投放人员
	common.Pagination        // 分页
	common.CommonParams
}

// NewTaskInfosReq 解析绑定告警任务参数
func NewTaskInfosReq(c *gin.Context) *TaskInfos {
	req := &TaskInfos{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

// NewSearchFilterReq 解析绑定告警任务搜索参数
func NewSearchFilterReq(c *gin.Context) *SearchFilter {
	req := &SearchFilter{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

// NewMaterialSearchReq 解析绑定素材拒审查询
func NewMaterialSearchReq(c *gin.Context) *MaterialListReq {
	req := &MaterialListReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}

// NewSearchOptionReq 解析绑定查询条件查询
func NewSearchOptionReq(c *gin.Context) *SearchOptionReq {
	req := &SearchOptionReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}
