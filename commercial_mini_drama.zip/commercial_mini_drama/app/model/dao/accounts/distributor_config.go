package accounts

import (
	"context"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
)

type DistributorConfigDao struct {
	Ctx context.Context
}

func NewDistributorConfigDao(ctx context.Context) *DistributorConfigDao {
	return &DistributorConfigDao{Ctx: ctx}
}

func (d *DistributorConfigDao) ListByDistributor(distributor string, keys []string) ([]accountrepo.DistributorConfigEntity, error) {
	db := dorisdb.DorisClient()

	var list []accountrepo.DistributorConfigEntity

	q := db.Table(accountrepo.DistributorConfigTableName())
	if distributor != "" {
		q = q.Where("distributor = ?", distributor)
	}
	if len(keys) > 0 {
		q = q.Where("api_id in (?)", keys)
	}

	err := q.Order("created_at desc").Find(&list).Error
	if err != nil {
		return nil, err
	}

	return list, err
}
