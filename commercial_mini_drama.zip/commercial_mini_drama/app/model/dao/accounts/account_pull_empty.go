package accounts

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
	"strings"
)

const (
	CurHour     = 1
	LastHour    = 2
	Daily       = 3
	LastTwoHour = 4 // 上上一小时
)

type AccountPullEmpty struct {
	Ctx context.Context
}

func NewAccountPullEmptyDao(ctx context.Context) *AccountPullEmpty {
	return &AccountPullEmpty{Ctx: ctx}
}

func (d *AccountPullEmpty) Create(pullEmpty []*accountrepo.AccountEmptyEntity) error {

	defer func() {
		if err := recover(); err != nil {
			fmt.Println("panic:", err)
		}
	}()
	args := []interface{}{} // 存储参
	db := dorisdb.DorisClient()
	sql := "INSERT INTO account_pull_empty_detail (account_id,project_id,user_id,created_time) VALUES"
	for i, record := range pullEmpty {
		sql += "(?, ?, ?, ?)"
		// 最后一条数据后不加逗号
		if i != len(pullEmpty)-1 {
			sql += ", "
		}
		args = append(args,
			record.AccountID,
			record.ProjectID,
			record.UserID,
			record.CreatedTime, // 格式化时间为字符串
		)

	}

	return db.Exec(sql, args...).Error

	//err := retry.Do(func() error {
	//err := db.Table(accountrepo.AccountPullEmptyTableName()).Debug().Create(pullEmpty).Error
	//fmt.Println(err)
	//return err

	//},
	//retry.Attempts(3),
	//retry.Delay(time.Second*1),
	//)

	//return err
}

// 账户数据统计
type AccountReportData struct {
	AccountID string  `gorm:"column:account_id"` // 账户ID
	HourCost  float64 `gorm:"column:hour_cost"`  // 小时消耗
	Hour      int     `gorm:"column:hour"`
	DayRoi    float64 `gorm:"column:day_roi"`    // 当天ROI
	ProjectID string  `gorm:"column:project_id"` // 项目ID
}

// 账户维度sql
func GetAccountSql(typeInt int) string {
	var sql string
	switch typeInt {
	case CurHour:
		sql = "SELECT SUM(media_cost/1.02) as hour_cost,`hour`, account_id  from roi_project_hourly_today where `hour` = HOUR(CURTIME())-1 group by `hour`, account_id "
	case LastHour:
		sql = "SELECT SUM(media_cost/1.02) as hour_cost,`hour`, account_id  from roi_project_hourly_today where `hour` = HOUR(CURTIME())-2 group by `hour`, account_id "
	case LastTwoHour:
		sql = "SELECT SUM(media_cost/1.02) as hour_cost,`hour`, account_id  from roi_project_hourly_today where `hour` = HOUR(CURTIME())-3 group by `hour`, account_id "
	case Daily:
		sql = "SELECT ROUND(SUM(income)/ SUM(media_cost/1.02), 2)*100 as day_roi,account_id  from roi_project_hourly_today where `date` = CURDATE()  group by account_id"
	}
	return sql
}

// 获取账户数据
func (d *AccountPullEmpty) GetDataByAccount(typeInt int) (res []AccountReportData, err error) {
	sql := GetAccountSql(typeInt)
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return

}
func (d *AccountPullEmpty) GetProjectIDList(accountIDs []string) (res []AccountReportData, err error) {
	sql := "SELECT project_id,account_id from roi_project_hourly_today  where account_id in ( " + strings.Join(accountIDs, ",") + ") group by project_id,account_id"
	fmt.Println(sql)
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return res, nil
}
