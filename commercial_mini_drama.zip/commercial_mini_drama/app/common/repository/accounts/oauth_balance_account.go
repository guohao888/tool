package accounts

import "goserver/app/common/repository"

const OauthBalanceAccountEntityTable = "oauth_balance_account"

type OauthBalanceAccountEntity struct {
	Media          string `gorm:"column:media"`           // 媒体
	AdvertiserId   string `gorm:"column:advertiser_id"`   // 广告主id
	AdvertiserName string `gorm:"column:advertiser_name"` // 广告主名称
	OauthId        string `gorm:"column:oauth_id"`        // 授权唯一标识
	AppId          string `gorm:"column:app_id"`          // 应用ID
	UserId         string `gorm:"column:user_id"`         // 管家账号ID
}

func (*OauthBalanceAccountEntity) TableName() string {
	return OauthBalanceAccountTableName()
}

func OauthBalanceAccountTableName() string {
	if repository.IsDebugTable(OauthBalanceAccountEntityTable) {
		return OauthBalanceAccountEntityTable + "_dev"
	} else {
		return OauthBalanceAccountEntityTable
	}
}
