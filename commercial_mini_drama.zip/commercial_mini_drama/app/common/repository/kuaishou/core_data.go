package kuaishou

import (
	"goserver/app/common/repository"
	"time"
)

const CoreDataTable = "kuaishou_core_data"

type CoreDataEntity struct {
	AdvertiserId                    int64     `gorm:"column:advertiser_id"`                         // 用户快手号id
	Date                            time.Time `gorm:"column:date"`                                  // 日期（yyyy-MM-dd hh:mm:ss）
	ResourceType                    int64     `gorm:"column:resource_type"`                         // 流量来源，1-自然流量，2-商业流量
	Source                          int64     `gorm:"column:source"`                                // 数据来源，0-实时数据，1-离线数据
	SeriesId                        int64     `gorm:"column:series_id"`                             // 短剧id
	SeriesType                      int       `gorm:"column:series_type"`                           // 短剧类型，1-IAA短剧，2-IAP短剧
	TotalCharge                     int64     `gorm:"column:total_charge"`                          // 消耗
	AccuFansUserNum                 int64     `gorm:"column:accu_fans_user_num"`                    // 粉丝峰值量
	FansUserNum                     int64     `gorm:"column:fans_user_num"`                         // 粉丝净增量
	EventPayRoi                     float64   `gorm:"column:event_pay_roi"`                         // 商业化ROI
	EventPayRoiAll                  float64   `gorm:"column:event_pay_roi_all"`                     // 全域ROI
	PayUserCount                    int64     `gorm:"column:pay_user_count"`                        // 付费人数
	PayCount                        int64     `gorm:"column:pay_count"`                             // 付费订单数
	PayAmt                          float64   `gorm:"column:pay_amt"`                               // 付费金额
	IsFansUser                      int       `gorm:"column:is_fans_user"`                          // 是否粉丝
	DisplayPlayCnt                  int64     `gorm:"column:display_play_cnt"`                      // 播放数
	DisplayLikeCnt                  int64     `gorm:"column:display_like_cnt"`                      // 点赞数
	DisplayCommentCnt               int64     `gorm:"column:display_comment_cnt"`                   // 评论数
	DisplayCollectCnt               int64     `gorm:"column:display_collect_cnt"`                   // 收藏数
	MiniGameIaaRoi                  float64   `gorm:"column:mini_game_iaa_roi"`                     // IAA广告变现ROI（含返货）
	MiniGameIaaPurchaseAmount       float64   `gorm:"column:mini_game_iaa_purchase_amount"`         // IAA广告变现LTV（含返货，元）
	MiniGameIaaPurchaseAmountDivide float64   `gorm:"column:mini_game_iaa_purchase_amount_divided"` // IAA广告变现LTV（不含返货，元）
	MiniGameIaaDividedRoi           float64   `gorm:"column:mini_game_iaa_divided_roi"`             // IAA广告变现ROI（不含返货）
	ActualMiniGameIaaPurchaseAmount float64   `gorm:"column:actual_mini_game_iaa_purchase_amount"`  // 实际IAA广告变现LTV（含返货）
	ActualMiniGameIaaRoi            float64   `gorm:"column:actual_mini_game_iaa_roi"`              // 实际IAA广告变现ROI（含返货）

	DateStr           string  `gorm:"column:date_str"`             // 日期
	SeriesName        string  `gorm:"column:series_name"`          // 剧目名称
	ActualCharge      float64 `gorm:"column:actual_charge"`        // 实际消耗
	ActualEventPayRoi float64 `gorm:"column:actual_event_pay_roi"` // 商业化实际ROI
	ActualPayAmt      float64 `gorm:"column:actual_pay_amt"`       // 实际付费金额
}

func (*CoreDataEntity) TableName() string {
	return CoreDataTable
}

func CoreDataTableName() string {
	if repository.IsDebugTable(CoreDataTable) {
		return CoreDataTable // + "_dev"
	} else {
		return CoreDataTable
	}
}

type NewlySpentSeriesRoiInfo struct {
	DateTime      string  `gorm:"column:date_time"`
	Date          string  `gorm:"column:date"`
	Hour          int     `gorm:"column:hour"`
	SeriesId      int64   `gorm:"column:series_id"`
	SeriesName    string  `gorm:"column:series_name"`
	TotalCharge   float64 `gorm:"column:total_charge"`
	PayAmt        float64 `gorm:"column:pay_amt"`
	ActualROI     float64 `gorm:"column:actual_roi"`
	HbTotalCharge float64 `gorm:"column:hb_total_charge"` // 上期消耗
	HbPayAmt      float64 `gorm:"column:hb_pay_amt"`      // 上期收入
	HbActualROI   float64 `gorm:"column:hb_actual_roi"`   // 上期收入 / 上期消耗 * 100%
	TotalChargeHb float64 `gorm:"column:total_charge_hb"` // 消耗环比（当期消耗-上期消耗）/上期消耗 * 100%
	ActualROIHb   float64 `gorm:"column:actual_roi_hb"`   // ROI环比（当期roi-上期roi）/上期roi * 100%
}

type ManagerRoiInfo struct {
	DateTime       string `gorm:"column:date_time"`
	Date           string `gorm:"column:date"`
	Hour           int    `gorm:"column:hour"`
	AdvertiserId   int64  `gorm:"column:advertiser_id"`
	AdvertiserName string `gorm:"column:advertiser_name"`

	ActualCharge        float64 `gorm:"column:actual_charge"`           // 实际消耗
	ActualPayAmt        float64 `gorm:"column:actual_pay_amt"`          // 实际IAA广告变现LTV
	ActualEventPayROI   float64 `gorm:"column:actual_event_pay_roi"`    // 消耗环比
	HbActualCharge      float64 `gorm:"column:hb_actual_charge"`        // 昨日实际消耗
	HbActualPayAmt      float64 `gorm:"column:hb_actual_pay_amt"`       // 昨日实际IAA广告变现LTV
	HbActualEventPayROI float64 `gorm:"column:hb_actual_event_pay_roi"` // 实际IAA广告变现LTV环比
	ActualChargeHb      float64 `gorm:"column:actual_charge_hb"`        // 实际消耗环比
	ActualPayAmtHb      float64 `gorm:"column:actual_pay_amt_hb"`       // 实际IAA广告变现LTV环比
	ActualEventPayROIHb float64 `gorm:"column:actual_event_pay_roi_hb"` // 实际IAA广告变现ROI
}

type LastCostIncomeInfo struct {
	Date                            string  `gorm:"column:date"`
	Hour                            string  `gorm:"column:hour"`
	ActualCharge                    float64 `gorm:"column:actual_charge"`                        // 实际消耗
	ActualMiniGameIaaPurchaseAmount float64 `gorm:"column:actual_mini_game_iaa_purchase_amount"` // 实际IAA广告变现LTV
	ActualMiniGameIaaRoi            float64 `gorm:"column:actual_mini_game_iaa_roi"`             // 实际IAA广告变现ROI
}
