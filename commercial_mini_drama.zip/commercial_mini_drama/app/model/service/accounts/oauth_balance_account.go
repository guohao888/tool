package accounts

import (
	"context"
	"fmt"
	"github.com/duke-git/lancet/v2/slice"
	"github.com/jinzhu/gorm"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/model/dao/accounts"
	"math"
)

type OauthBalanceAccountService struct {
	Ctx context.Context
}

func NewOauthBalanceAccountService(ctx context.Context) *OauthBalanceAccountService {
	return &OauthBalanceAccountService{Ctx: ctx}
}

func ceilDivide(a, b int) int {
	return int(math.Ceil(float64(a) / float64(b)))
}

func (s *OauthBalanceAccountService) OauthBalanceAccountSyncToutiao(media string) error {
	oauthDao := accounts.NewOauthDao(s.Ctx)
	oauthList, err := oauthDao.ListOauthByMedia(media)
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return err
	}
	if len(oauthList) == 0 {
		return nil
	}

	userIdAppIdOauthIdMap := make(map[string]string)
	for _, v := range oauthList {
		userIdAppIdOauthIdMap[fmt.Sprintf("%s_%s", v.UserId, v.AppId)] = v.OauthId
	}

	userIds, err := oauthDao.DistinctUserIds(media)
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return err
	}
	if len(userIds) == 0 {
		return nil
	}

	appIds, err := oauthDao.DistinctAppIds(media)
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return err
	}
	if len(appIds) == 0 {
		return nil
	}

	oauthMasterAppIdActiveAccountDao := accounts.NewOauthMasterAppIdActiveAccountDao(s.Ctx)
	oauthBalanceAccountDao := accounts.NewOauthBalanceAccountDao(s.Ctx)
	for _, userId := range userIds {
		// 根据管家id，从主应用授权的管家下的活跃广告主视图中，查询对应管家下的广告主
		userIdAccounts, err := oauthMasterAppIdActiveAccountDao.ListByUserId(media, userId)
		if err != nil && gorm.IsRecordNotFoundError(err) {
			log.Errorf("根据管家id从oauth_master_app_id_active_account_view视图查询广告主失败, err: %s", err)
			continue
		}
		if len(userIdAccounts) == 0 {
			continue
		}

		var data []accountrepo.OauthBalanceAccountEntity
		size := ceilDivide(len(userIdAccounts), len(appIds))
		chunkUserIdAccounts := slice.Chunk(userIdAccounts, size)
		for i, chunk := range chunkUserIdAccounts {
			// 获取对应的应用id
			appId := appIds[i]

			oauthId, ok := userIdAppIdOauthIdMap[fmt.Sprintf("%s_%s", userId, appId)]
			if !ok {
				continue
			}
			for _, v := range chunk {
				data = append(data, accountrepo.OauthBalanceAccountEntity{
					Media:          v.Media,
					AdvertiserId:   v.AdvertiserId,
					AdvertiserName: v.AdvertiserName,
					OauthId:        oauthId,
					AppId:          appId,
					UserId:         userId,
				})
			}
		}

		if len(data) > 0 {
			err := oauthBalanceAccountDao.InsertBatchSize(data, 5000)
			if err != nil {
				log.Error("[oauthBalanceAccountDao.InsertBatchSize]插入数失败, err: %s", err)
			}
		}
	}

	return nil
}
