package fanqie

import (
	"goserver/app/common/repository"
	"time"
)

const UserEntityTable = "tomato_iaa_buy" // todo 更改为 tomato_buy

// UserEntity 番茄用户数据
type UserEntity struct {
	DeviceId        string    `gorm:"column:device_id"`        // 脱敏后的用户设备ID
	BuyingTimestamp string    `gorm:"column:buying_timestamp"` // 用户点击推广链时间戳（非染色时间）
	BuyingDate      time.Time `gorm:"column:buying_date"`      // 买入日期 yyyy-mm-dd
	BuyingHour      string    `gorm:"column:buying_hour"`      // 买入小时  hh
	DistributorId   string    `gorm:"column:distributor_id"`   // 快应用/公众号对应distributor_id
	AppId           string    `gorm:"column:app_id"`           // 公众号/快应用/小程序id（分销平台id）【v1.2】
	AppName         string    `gorm:"column:app_name"`         // 快应用/公众号/小程序名称【v1.2】
	PromotionId     string    `gorm:"column:promotion_id"`     // 推广链id
	AdId            string    `gorm:"column:ad_id"`            // ad_id(仅支持快应用) 仅快应用一跳（快应用推广目的）有，二跳（应用推广/线索推广）没有
	Ip              string    `gorm:"column:ip"`               // 用户点击推广链时的IP
	UserAgent       string    `gorm:"column:user_agent"`       // 用户点击推广链时的UA
	Attributed      string    `gorm:"column:attributed"`       // 用户是否成功染色
	BookId          string    `gorm:"column:book_id"`          // 染色推广链的短剧ID
	BookName        string    `gorm:"column:book_name"`        // 染色推广链的短剧名称
	BookGender      string    `gorm:"column:book_gender"`      // 染色推广链短剧性别(0女生、1男生、2无性别)
	BookCategory    string    `gorm:"column:book_category"`    // 染色推广链的短剧类型
	ActionId        string    `gorm:"column:action_id"`        // 用户点击推广链的唯一标识，平台为了尽可能通知到分销商会有重试策略，分销商可以以此进行去重
	ProjectId       string    `gorm:"column:project_id"`       // 巨量2.0广告计划组ID
	AdIdV2          string    `gorm:"column:ad_id_v2"`         // 巨量2.0广告计划ID（promotion_id）
	Mid             string    `gorm:"column:mid"`              // 素材id（分别代表图片、标题、视频、试玩、落地页）（仅小程序均支持）
	ClueToken       string    `gorm:"column:clue_token"`       // 巨量小程序广告参数
	UnionId         string    `gorm:"column:union_id"`         // 用户在微信/抖音开放平台下的唯一id
	MidId           string    `gorm:"column:mid_id"`           // 图片或视频ID
}

func (*UserEntity) TableName() string {
	return UserEntityTable
}

func IAAUserTableName() string {
	if repository.IsDebugTable(UserEntityTable) {
		return UserEntityTable + "_dev"
	} else {
		return UserEntityTable
	}
}
