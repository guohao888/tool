package fanqie

import (
	"goserver/app/common/repository"
	"time"
)

const IAPOrderEntityTable = "tomato_iap_orders"

// IAPOrderEntity 番茄IAP订单数据
type IAPOrderEntity struct {
	OutTradeNo    string    `gorm:"column:out_trade_no"`   // 第三方订单号
	PayDate       time.Time `gorm:"column:pay_date"`       // 付费时间 yyy-mm-dd hh-mm-ss
	PayHour       string    `gorm:"column:pay_hour"`       // 支付小时 hh
	DeviceId      string    `gorm:"column:device_id"`      // 用户设备ID
	DistributorId string    `gorm:"column:distributor_id"` // 快应用/公众号对应distributor_id
	AppId         string    `gorm:"column:app_id"`         // 公众号/快应用id（分销平台id）【v1.2】
	AppName       string    `gorm:"column:app_name"`       // 快应用/公众号名称【v1.2】
	TradeNo       string    `gorm:"column:trade_no"`       // 脱敏后的订单ID（MD5加密）
	TradeNoRaw    string    `gorm:"column:trade_no_raw"`   // 未脱敏的订单ID（未加密）
	OpenId        string    `gorm:"column:open_id"`        // 用户openid（H5书城、微信小程序、抖音小程序)
	PayAmount     string    `gorm:"column:pay_amount"`     // 支付金额，单位分
	PromotionId   string    `gorm:"column:promotion_id"`   // 用户染色归属推广链ID
	PayTimestamp  string    `gorm:"column:pay_timestamp"`  // 付费时间戳
	Ip            string    `gorm:"column:ip"`             // 用户最近一次点击推广链时的IP
	UserAgent     string    `gorm:"column:user_agent"`     // 用户最近一次点击推广链时的UA
	RegisterTime  string    `gorm:"column:register_time"`  // 用户染色时间戳
	RegisterDate  time.Time `gorm:"column:register_date"`  // 用户染色时间 yyy-mm-dd hh-mm-ss
	RegisterHour  string    `gorm:"column:register_hour"`  // 用户染色小时
	BookId        string    `gorm:"column:book_id"`        // 染色推广链的书籍ID【v1.2】
	BookName      string    `gorm:"column:book_name"`      // 染色推广链的书籍名称【v1.2】
	BookGender    string    `gorm:"column:book_gender"`    // 染色推广链书籍性别【v1.2】
	BookCategory  string    `gorm:"column:book_category"`  // 染色推广链的书籍类型【v1.2】
	ExternalId    string    `gorm:"column:external_id"`    // 企微用户企微id
	OrderType     string    `gorm:"column:order_type"`     // 订单类型：1 虚拟支付，2 非虚拟支付
	UnionId       string    `gorm:"column:union_id"`       // 用户在微信/抖音开放平台下的唯一id
}

func (*IAPOrderEntity) TableName() string {
	return IAPOrderEntityTable
}

func IAPOrderTableName() string {
	if repository.IsDebugTable(IAPOrderEntityTable) {
		return IAPOrderEntityTable + "_dev"
	} else {
		return IAPOrderEntityTable
	}
}
