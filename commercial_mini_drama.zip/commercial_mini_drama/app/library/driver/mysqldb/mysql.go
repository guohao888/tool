package mysqldb

import (
	"fmt"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/mysql"
	"github.com/spf13/viper"
	"goserver/app/library/log"
	"time"
)

var MySQLMaxOpenConns = 20
var MySQLMaxIdleConns = 20
var MySQLConnMaxIdleTime = time.Second * 5

var mysqlDB *gorm.DB

func InitMysql() error {
	MySQLConnMaxIdleTime = time.Duration(viper.GetInt("mysql_conn_max_idle_time")) * time.Second
	dbPrefix := "mysql"

	host := viper.GetString(dbPrefix + ".host")
	port := viper.GetInt(dbPrefix + ".port")
	uname := viper.GetString(dbPrefix + ".uname")
	passwd := viper.GetString(dbPrefix + ".passwd")
	charset := viper.GetString(dbPrefix + ".charset")
	dbname := viper.GetString(dbPrefix + ".dbname")

	log.Debugf("connecting to mysql instance, host = '%s', port = %d, uname = '%s', db = '%s', charset = '%s'. \n",
		host, port, uname, dbname, charset)

	db_conf := fmt.Sprintf("%s:%s@(%s:%d)/%s?charset=utf8mb4&parseTime=True&loc=Local", uname, passwd, host, port, dbname)
	temp_db, err := gorm.Open("mysql", db_conf)
	if nil != err {
		return err
	}

	temp_db.DB().SetMaxOpenConns(MySQLMaxOpenConns)
	temp_db.DB().SetMaxIdleConns(MySQLMaxIdleConns)
	temp_db.DB().SetConnMaxLifetime(MySQLConnMaxIdleTime)
	// 全局禁用表名复数
	temp_db.SingularTable(true) // 如果设置为true,`User`的默认表名为`user`,使用`TableName`设置的表名不受影响
	temp_db.SetLogger(log.MysqlLog)
	temp_db.LogMode(true)
	temp_db.DB().Exec("SET SESSION group_concat_max_len=-1;")

	mysqlDB = temp_db

	return nil
}

func MysqlClient() *gorm.DB {
	return mysqlDB
}
