package accounts

import (
	"context"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
)

type OauthMasterAppIdActiveAccountDao struct {
	Ctx context.Context
}

func NewOauthMasterAppIdActiveAccountDao(ctx context.Context) *OauthMasterAppIdActiveAccountDao {
	return &OauthMasterAppIdActiveAccountDao{Ctx: ctx}
}

func (d *OauthMasterAppIdActiveAccountDao) ListByUserId(media string, userId string) ([]accountrepo.OauthMasterAppIdActiveAccountEntity, error) {
	db := dorisdb.DorisClient()

	q := db.Table(accountrepo.OauthMasterAppIdActiveAccountTableName()).Select("advertiser_id,advertiser_name")
	q = q.Where("media = ? and user_id = ?", media, userId)

	var res []accountrepo.OauthMasterAppIdActiveAccountEntity
	err := q.Find(&res).Error
	return res, err
}
