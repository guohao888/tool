package optimizer

import (
	"goserver/app/common/repository"
	"time"
)

// OptimizerEntityTable 优化师表
const OptimizerEntityTable = "optimizer"

type OptimizerEntity struct {
	OptimizerId   int64     `gorm:"column:optimizer_id"`   // 优化师主键
	OptimizerName string    `gorm:"column:optimizer_name"` // 优化师名称 唯一
	Phone         string    `gorm:"column:phone"`          // 手机号
	CreatedAt     time.Time `gorm:"column:created_at"`     // 创建时间
	UpdatedAt     time.Time `gorm:"column:updated_at"`     // 更新时间
}

// OptimizerEntityTableName 表名称
func OptimizerEntityTableName() string {
	if repository.IsDebugTable(OptimizerEntityTable) {
		return OptimizerEntityTable + "_dev"
	} else {
		return OptimizerEntityTable
	}
}
