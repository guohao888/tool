package kuaishou

import (
	"context"
	"fmt"
	repo "goserver/app/common/repository"
	kuaishouEntity "goserver/app/common/repository/kuaishou"
	"goserver/app/library/playlet/kuaishou"
	accountdao "goserver/app/model/dao/accounts"
	kuaishoudao "goserver/app/model/dao/kuaishou"
	"strconv"
	"time"
)

type AccountService struct {
	Ctx context.Context
}

func NewAccountService(ctx context.Context) *AccountService {
	return &AccountService{Ctx: ctx}
}

// KuaishouAccountInfo 快手账号信息
func (r *AccountService) KuaishouAccountInfo(ctx context.Context) error {

	// 获取所有token
	oauthDao := accountdao.NewOauthDao(ctx)
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaKuaishou, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	for _, oa := range oauthList {
		advertiserId, _ := strconv.Atoi(oa.UserId)
		res, err := kuaishou.ReportQueryAccountInfo(ctx, kuaishou.ReportQueryAccountInfoReq{
			OauthId:      oa.OauthId,
			AccessToken:  oa.AccessToken,
			AdvertiserId: int64(advertiserId),
		})
		if res != nil && res.Code != kuaishou.CodeSuccess {
			return err
		}
		var list []*kuaishouEntity.AccountInfoEntity
		for _, v := range res.Data.AccountList {
			accountId, _ := strconv.Atoi(v.AccountId)
			info := &kuaishouEntity.AccountInfoEntity{
				AdvertiserId: int64(advertiserId),
				AccountId:    int64(accountId),
				AccountName:  v.AccountName,
				CreatedAt:    time.Now(),
				UpdatedAt:    time.Now(),
			}
			list = append(list, info)
		}
		accountDao := kuaishoudao.NewAccountDao(ctx)
		insertErr := accountDao.InsertBatchSize(list, 2000)
		if insertErr != nil {
			return insertErr
		}
	}
	return nil
}
