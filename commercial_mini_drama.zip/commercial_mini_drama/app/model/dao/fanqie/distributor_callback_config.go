package fanqie

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	repo "goserver/app/common/repository/fanqie"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// CallbackConfigDao 番茄广告回传DAO
type CallbackConfigDao struct {
	Ctx context.Context
}

func NewCallbackConfigDao(ctx context.Context) *CallbackConfigDao {
	return &CallbackConfigDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (c *CallbackConfigDao) InsertBatchSize(data []*repo.CallbackConfigEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 3000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = c.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (t *CallbackConfigDao) buildInsertSentence(tx *gorm.DB, data []*repo.CallbackConfigEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.CallbackConfigEntityTableName() + " ( config_id, config_name ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?),"
		vals = append(vals,
			v.ConfigId,
			v.ConfigName,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
