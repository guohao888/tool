package accounts

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/library/playlet/toutiao"
	"goserver/app/library/utils/md5"
	accountdao "goserver/app/model/dao/accounts"
	"strconv"
	"time"
)

type OauthAssistService struct {
	Ctx context.Context
}

func NewOauthAssistService(ctx context.Context) *OauthAssistService {
	return &OauthAssistService{Ctx: ctx}
}

func (s *OauthAssistService) Callback(media string, req accountdto.CallbackToutiaoReq) error {
	ctx := s.Ctx

	oauthConfigService := NewOauthConfigService(s.Ctx)
	oauthConfig, err := oauthConfigService.OneByMediaAppId(media, req.AppId)
	if err != nil {
		return err
	}

	appId, err := oauthConfig.GetAppId()
	if err != nil {
		return err
	}

	resp, err := toutiao.Oauth2AccessToken(ctx, models.Oauth2AccessTokenRequest{
		AppId:    &appId,
		AuthCode: req.AuthCode,
		Secret:   oauthConfig.AppSecret,
	})
	if err != nil {
		return err
	}

	// 获取授权User信息
	userInfoV2, err := toutiao.UserInfoV2(ctx, *resp.Data.AccessToken)
	if err != nil {
		return err
	}
	if userInfoV2 == nil || userInfoV2.Data == nil || userInfoV2.Data.Id == nil {
		return errors.New("获取授权用户信息id失败")
	}
	userId := strconv.FormatInt(*userInfoV2.Data.Id, 10)
	if req.Uid != userId {
		return errors.New("获取授权用户信息id与回调参数uid不一致")
	}

	expiresIn := *resp.Data.ExpiresIn
	refreshTokenExpiresIn := *resp.Data.RefreshTokenExpiresIn
	now := time.Now()

	oauthId := md5.GetStringMd5(fmt.Sprintf("%s_%s_%s", oauthConfig.AppID, oauthConfig.AppSecret, userId))
	oauthAssistDao := accountdao.NewOauthAssistDao(s.Ctx)

	// 将获取的accessToken和refreshToken入库
	newOauth := accountrepo.OauthAssistEntity{
		Media:        media,
		OauthId:      oauthId,
		AccessToken:  *resp.Data.AccessToken,
		RefreshToken: *resp.Data.RefreshToken,
		ExpireAt: func() time.Time {
			return now.Add(time.Duration(expiresIn) * time.Second)
		}(),
		RefreshExpireAt: func() time.Time {
			return now.Add(time.Duration(refreshTokenExpiresIn) * time.Second)
		}(),
		ExpireTime:        expiresIn,
		RefreshExpireTime: refreshTokenExpiresIn,
		AppId:             oauthConfig.AppID,
		UserId:            userId,
		AppSecret:         oauthConfig.AppSecret,
		Ext: func() string {
			ext := accountrepo.ToutiaoExt{
				CommonExt: accountrepo.CommonExt{
					UserId:   *userInfoV2.Data.Id,
					UserName: *userInfoV2.Data.DisplayName,
				},
			}
			marshal, _ := json.Marshal(ext)
			return string(marshal)
		}(),
	}
	err = oauthAssistDao.Save(newOauth)
	if err != nil {
		return err
	}
	return err
}

func (s *OauthAssistService) OauthRefresh(media string, params accountdto.OauthRefreshExecutorParams) error {
	oauthAssistDao := accountdao.NewOauthAssistDao(s.Ctx)
	list, err := oauthAssistDao.ListOauthByMedia(media)
	if err != nil {
		return err
	}

	m := params.OauthIdsStruct.ToMap()

	for _, oauth := range list {
		if len(m) > 0 { // 制定oauth_id的话，就只更新指定的oauth授权
			if _, ok := m[oauth.OauthId]; !ok {
				continue
			}
		}

		var newAssistOauth *accountrepo.OauthAssistEntity
		var err error

		// 调用更新授权令牌接口
		switch {
		case media == repository.MediaToutiao:
			newAssistOauth, err = s.oauthRefreshAssist(oauth)
		case media == repository.MediaKuaishou:
			// todo 快手oauth授权刷新
		}

		if err != nil {
			log.Errorf("oauth授权刷新错误, err: %s", err)
			return err
		}

		if newAssistOauth != nil {
			// 保存到数据库
			err := oauthAssistDao.UpdateById(newAssistOauth.Media, newAssistOauth.OauthId, newAssistOauth)
			if err != nil {
				log.Errorf("oauth授权刷新保存到数据库错误, err: %s", err)
				return err
			}
		}
	}

	return nil
}

func (s *OauthAssistService) oauthRefreshAssist(oauth accountrepo.OauthAssistEntity) (newOauthAssist *accountrepo.OauthAssistEntity, err error) {
	appId, err := strconv.ParseInt(oauth.AppId, 10, 64)
	if err != nil {
		return nil, err
	}
	resp, err := toutiao.Oauth2RefreshToken(s.Ctx, models.Oauth2RefreshTokenRequest{
		AppId:        &appId,
		RefreshToken: oauth.RefreshToken,
		Secret:       oauth.AppSecret,
	})
	if err != nil {
		return nil, err
	}

	// 获取授权User信息

	now := time.Now()
	newOauthAssist = &accountrepo.OauthAssistEntity{
		Media:        oauth.Media,
		OauthId:      oauth.OauthId,
		AccessToken:  *resp.Data.AccessToken,
		RefreshToken: *resp.Data.RefreshToken,
		ExpireAt: func() time.Time {
			return now.Add(time.Duration(*resp.Data.ExpiresIn) * time.Second)
		}(),
		RefreshExpireAt: func() time.Time {
			return now.Add(time.Duration(*resp.Data.RefreshTokenExpiresIn) * time.Second)
		}(),
		ExpireTime:        *resp.Data.ExpiresIn,
		RefreshExpireTime: *resp.Data.RefreshTokenExpiresIn,
		AppId:             oauth.AppId,
		UserId:            oauth.UserId,
		AppSecret:         oauth.AppSecret,
		Ext:               oauth.Ext,
	}

	return newOauthAssist, nil
}
