package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	"goserver/app/model/service/logsearch"
	"time"
)

// SyncLogSearchSubscribe 按照订阅消息拉取操作日志
func SyncLogSearchSubscribe(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("拉取操作日志参数解析错误, err: %s", err)
		}
	}

	//
	logSearchService := logsearch.NewSearchLogService(ctx)
	startTime := time.Now().AddDate(0, 0, -7).Format(time.DateOnly) + " 00:00:00"
	endTime := time.Now().AddDate(0, 0, -1).Format(time.DateOnly) + " 23:59:59"
	err := logSearchService.SyncLogSearch(startTime, endTime, ctx)
	if err != nil {
		return fmt.Sprintf("拉取操作日志失败, err: %s", err)
	}
	return "拉取操作日志成功"
}
