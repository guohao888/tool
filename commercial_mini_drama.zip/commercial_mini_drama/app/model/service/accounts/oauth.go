package accounts

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"github.com/spf13/viper"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/library/playlet/cache"
	"goserver/app/library/playlet/kuaishou"
	"goserver/app/library/playlet/toutiao"
	"goserver/app/library/utils/md5"
	noticeCommon "goserver/app/library/utils/notice/common"
	accountdao "goserver/app/model/dao/accounts"
	"strconv"
	"strings"
	"time"
)

type OauthService struct {
	Ctx context.Context
}

func NewOauthService(ctx context.Context) *OauthService {
	return &OauthService{Ctx: ctx}
}

func (s *OauthService) RefreshFailedMessage1(oauthList []OauthFailedInfo) error {
	mm := make(map[string]map[string][]string) // 媒体/应用/账号id(名称)
	for _, v := range oauthList {
		o := v.Oauth
		if _, ok := mm[o.Media]; !ok {
			mm[o.Media] = make(map[string][]string)
		}

		ext, _ := o.GetCommonExt()
		var userName string
		if ext.UserName != "" {
			userName = fmt.Sprintf("(%s)", ext.UserName)
		}
		var errMsg string
		if v.ErrMessage != "" {
			errMsg = fmt.Sprintf("\n   %s", v.ErrMessage)
		}
		mm[o.Media][o.AppId] = append(mm[o.Media][o.AppId], fmt.Sprintf("%d%s%s", ext.UserId, userName, errMsg))
	}

	env := viper.GetString("env")
	var ss []string
	ss = append(ss,
		fmt.Sprintf("oauth授权刷新失败[%s]:", env),
	)

	for media, v := range mm {
		ss = append(ss, fmt.Sprintf("媒体: %s", media))
		for appId, vv := range v {
			ss = append(ss, fmt.Sprintf(" 应用id: %s", appId))
			ss = append(ss, "  账户id: ")
			for _, userId := range vv {
				ss = append(ss, fmt.Sprintf("   %s", userId))
			}
		}
	}
	ss = append(ss,
		"请尽快重新授权!!!",
	)

	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	text := &noticeCommon.Text{Content: strings.Join(ss, "\n")}
	groups := viper.GetStringSlice("oauth.notify_groups")
	sMsg := &noticeCommon.GroupMessage{
		Togroups: groups,
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(sMsg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

func (s *OauthService) CallbackToutiaoMessage(userId string, userName string, appId int64) error {
	return s.CallbackMessage(repository.MediaToutiao, userId, userName, appId)
}

func (s *OauthService) CallbackKuaishouMessage(userId string, userName string, appId int64) error {
	return s.CallbackMessage(repository.MediaKuaishou, userId, userName, appId)
}

func (s *OauthService) CallbackMessage(media string, userId string, userName string, appId int64) error {
	oauthDao := accountdao.NewOauthDao(s.Ctx)

	var ss []string
	ss = append(ss,
		fmt.Sprintf("oauth授权通知(%s):", media),
	)
	overview, err := oauthDao.GetOauthUserIdOverview(userId, media)
	if err != nil {
		ss = append(ss,
			fmt.Sprintf("授权账号: %s, 统计查询错误: %s", userId, err),
		)
	} else {
		ss = append(ss,
			fmt.Sprintf("授权账号id: %s", userId),
			fmt.Sprintf("授权账号名称: %s", userName),
			fmt.Sprintf("应用id: %d", appId),
			fmt.Sprintf("此账号授权数量/应用数量: (%d/%d)", overview.UserAppIdCount, overview.TotalAppIdCount),
		)
	}

	message := strings.Join(ss, "\n")

	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	text := &noticeCommon.Text{Content: message}
	groups := viper.GetStringSlice("oauth.notify_groups")
	sMsg := &noticeCommon.GroupMessage{
		Togroups: groups,
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(sMsg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

func (s *OauthService) CallbackToutiao(media string, req accountdto.CallbackToutiaoReq) error {
	ctx := s.Ctx

	oauthConfigService := NewOauthConfigService(s.Ctx)
	oauthConfig, err := oauthConfigService.OneByMediaAppId(media, req.AppId)
	if err != nil {
		return err
	}

	appId, err := oauthConfig.GetAppId()
	if err != nil {
		return err
	}

	resp, err := toutiao.Oauth2AccessToken(ctx, models.Oauth2AccessTokenRequest{
		AppId:    &appId,
		AuthCode: req.AuthCode,
		Secret:   oauthConfig.AppSecret,
	})
	if err != nil {
		return err
	}

	// 获取授权User信息
	userInfoV2, err := toutiao.UserInfoV2(ctx, *resp.Data.AccessToken)
	if err != nil {
		return err
	}
	if userInfoV2 == nil || userInfoV2.Data == nil || userInfoV2.Data.Id == nil {
		return errors.New("获取授权用户信息id失败")
	}
	userId := strconv.FormatInt(*userInfoV2.Data.Id, 10)
	if req.Uid != userId {
		return errors.New("获取授权用户信息id与回调参数uid不一致")
	}

	expiresIn := *resp.Data.ExpiresIn
	refreshTokenExpiresIn := *resp.Data.RefreshTokenExpiresIn
	now := time.Now()

	oauthId := md5.GetStringMd5(fmt.Sprintf("%s_%s_%s", oauthConfig.AppID, oauthConfig.AppSecret, userId))
	oauthDao := accountdao.NewOauthDao(s.Ctx)

	// 将获取的accessToken和refreshToken入库
	newOauth := accountrepo.OauthEntity{
		Media:        media,
		OauthId:      oauthId,
		AccessToken:  *resp.Data.AccessToken,
		RefreshToken: *resp.Data.RefreshToken,
		ExpireAt: func() time.Time {
			return now.Add(time.Duration(expiresIn) * time.Second)
		}(),
		RefreshExpireAt: func() time.Time {
			return now.Add(time.Duration(refreshTokenExpiresIn) * time.Second)
		}(),
		ExpireTime:        expiresIn,
		RefreshExpireTime: refreshTokenExpiresIn,
		AppId:             oauthConfig.AppID,
		UserId:            userId,
		AppSecret:         oauthConfig.AppSecret,
		Ext: func() string {
			ext := accountrepo.ToutiaoExt{
				accountrepo.CommonExt{
					UserId:   *userInfoV2.Data.Id,
					UserName: *userInfoV2.Data.DisplayName,
				},
			}
			marshal, _ := json.Marshal(ext)
			return string(marshal)
		}(),
	}
	err = oauthDao.Save(newOauth)
	if err != nil {
		return err
	}

	// 重新授权设置oauth缓存
	err = cache.SetOauthCache(newOauth.OauthId, newOauth.AccessToken)
	if err != nil {
		return err
	}

	_ = s.CallbackToutiaoMessage(userId, *userInfoV2.Data.DisplayName, appId)

	return err
}

type OauthFailedInfo struct {
	Oauth      accountrepo.OauthEntity
	ErrMessage string
}

func (s *OauthService) OauthRefresh(media string, params accountdto.OauthRefreshExecutorParams) error {
	oauthDao := accountdao.NewOauthDao(s.Ctx)
	list, err := oauthDao.ListOauth(accountdao.ListOauthParams{
		Media:    []string{media},
		OauthIds: params.OauthIds,
	})
	if err != nil {
		return err
	}

	var refreshFailed []OauthFailedInfo
	for _, oauth := range list {
		var newOauth *accountrepo.OauthEntity
		var e error

		// 调用更新授权令牌接口
		switch {
		case media == repository.MediaToutiao:
			newOauth, e = s.oauthRefreshToutiao(oauth)
		case media == repository.MediaKuaishou:
			newOauth, e = s.oauthRefreshKuaishou(oauth)
		case media == repository.MediaKuaishouMagnet:
			newOauth, e = s.oauthRefreshKuaishou(oauth)
		}

		if e != nil {
			errMsg := fmt.Sprintf("请求错误: %s", e)
			refreshFailed = append(refreshFailed, OauthFailedInfo{
				Oauth:      oauth,
				ErrMessage: errMsg,
			})
			log.Error(errMsg)
			continue
		}

		if newOauth != nil {
			// 保存到数据库
			e = oauthDao.UpdateById(newOauth.Media, newOauth.OauthId, newOauth)
			if e != nil {
				errMsg := fmt.Sprintf("入库错误: %s", e)
				refreshFailed = append(refreshFailed, OauthFailedInfo{
					Oauth:      oauth,
					ErrMessage: errMsg,
				})
				log.Error(errMsg)
				continue
			}

			// 将oauth更新到缓存
			switch newOauth.Media {
			case repository.MediaToutiao, repository.MediaKuaishou, repository.MediaKuaishouMagnet:
				e = cache.SetOauthCache(newOauth.OauthId, newOauth.AccessToken)
				if e != nil {
					errMsg := fmt.Sprintf("缓存错误: %s", e)
					refreshFailed = append(refreshFailed, OauthFailedInfo{
						Oauth:      oauth,
						ErrMessage: errMsg,
					})
					log.Error(errMsg)
					continue
				}
			}
		}
	}

	if len(refreshFailed) > 0 {
		_ = s.RefreshFailedMessage1(refreshFailed)
	}

	return nil
}

func (s *OauthService) oauthRefreshToutiao(oauth accountrepo.OauthEntity) (newOauth *accountrepo.OauthEntity, err error) {
	appId, err := strconv.ParseInt(oauth.AppId, 10, 64)
	if err != nil {
		return nil, err
	}
	resp, err := toutiao.Oauth2RefreshToken(s.Ctx, models.Oauth2RefreshTokenRequest{
		AppId:        &appId,
		RefreshToken: oauth.RefreshToken,
		Secret:       oauth.AppSecret,
	})
	if err != nil {
		return nil, err
	}

	// 获取授权User信息

	now := time.Now()
	newOauth = &accountrepo.OauthEntity{
		Media:        oauth.Media,
		OauthId:      oauth.OauthId,
		AccessToken:  *resp.Data.AccessToken,
		RefreshToken: *resp.Data.RefreshToken,
		ExpireAt: func() time.Time {
			return now.Add(time.Duration(*resp.Data.ExpiresIn) * time.Second)
		}(),
		RefreshExpireAt: func() time.Time {
			return now.Add(time.Duration(*resp.Data.RefreshTokenExpiresIn) * time.Second)
		}(),
		ExpireTime:        *resp.Data.ExpiresIn,
		RefreshExpireTime: *resp.Data.RefreshTokenExpiresIn,
		AppId:             oauth.AppId,
		UserId:            oauth.UserId,
		AppSecret:         oauth.AppSecret,
		Ext:               oauth.Ext,
	}

	return newOauth, nil
}

func (s *OauthService) oauthRefreshKuaishou(oauth accountrepo.OauthEntity) (newOauth *accountrepo.OauthEntity, err error) {
	appId, err := strconv.ParseInt(oauth.AppId, 10, 64)
	if err != nil {
		return nil, err
	}
	resp, err := kuaishou.OauthRefreshToken(s.Ctx, kuaishou.RefreshTokenReq{
		AppId:        appId,
		Secret:       oauth.AppSecret,
		RefreshToken: oauth.RefreshToken,
	})
	if err != nil {
		return nil, err
	}
	if resp.Code != kuaishou.CodeSuccess {
		return nil, fmt.Errorf("code: %d, msg: %s", resp.Code, resp.Message)
	}

	// 获取授权User信息

	now := time.Now()
	newOauth = &accountrepo.OauthEntity{
		Media:        oauth.Media,
		OauthId:      oauth.OauthId,
		AccessToken:  resp.Data.AccessToken,
		RefreshToken: resp.Data.RefreshToken,
		ExpireAt: func() time.Time {
			return now.Add(time.Duration(resp.Data.AccessTokenExpiresIn) * time.Second)
		}(),
		RefreshExpireAt: func() time.Time {
			return now.Add(time.Duration(resp.Data.RefreshTokenExpiresIn) * time.Second)
		}(),
		ExpireTime:        resp.Data.AccessTokenExpiresIn,
		RefreshExpireTime: resp.Data.RefreshTokenExpiresIn,
		AppId:             oauth.AppId,
		UserId:            oauth.UserId,
		AppSecret:         oauth.AppSecret,
		Ext:               oauth.Ext,
	}

	return newOauth, nil
}

func (s *OauthService) DistinctAppIds(media string) ([]string, error) {
	oauthDao := accountdao.NewOauthDao(s.Ctx)
	return oauthDao.DistinctAppIds(media)
}

func (s *OauthService) CallbackKuaishou(media string, req accountdto.CallbackKuaishouReq) error {
	ctx := s.Ctx

	state, err := req.GetState()
	if err != nil {
		return err
	}

	oauthConfigService := NewOauthConfigService(s.Ctx)
	oauthConfig, err := oauthConfigService.OneByMediaAppId(media, state.AppId.String())
	if err != nil {
		return err
	}
	appId, err := oauthConfig.GetAppId()
	if err != nil {
		return err
	}

	resp, err := kuaishou.OauthAccessToken(ctx, kuaishou.AccessTokenReq{
		AppId:    appId,
		Secret:   oauthConfig.AppSecret,
		AuthCode: req.AuthCode,
	})
	if err != nil {
		return err
	}

	userId := resp.Data.UserId
	userIdStr := strconv.FormatInt(userId, 10)
	expiresIn := resp.Data.AccessTokenExpiresIn
	refreshTokenExpiresIn := resp.Data.RefreshTokenExpiresIn
	now := time.Now()

	oauthId := md5.GetStringMd5(fmt.Sprintf("%s_%s_%s", oauthConfig.AppID, oauthConfig.AppSecret, userId))
	oauthDao := accountdao.NewOauthDao(s.Ctx)

	// 将获取的accessToken和refreshToken入库
	newOauth := accountrepo.OauthEntity{
		Media:        media,
		OauthId:      oauthId,
		AccessToken:  resp.Data.AccessToken,
		RefreshToken: resp.Data.RefreshToken,
		ExpireAt: func() time.Time {
			return now.Add(time.Duration(expiresIn) * time.Second)
		}(),
		RefreshExpireAt: func() time.Time {
			return now.Add(time.Duration(refreshTokenExpiresIn) * time.Second)
		}(),
		ExpireTime:        expiresIn,
		RefreshExpireTime: refreshTokenExpiresIn,
		AppId:             oauthConfig.AppID,
		UserId:            userIdStr,
		AppSecret:         oauthConfig.AppSecret,
		Ext: func() string {
			ext := accountrepo.KuaishouExt{
				CommonExt: accountrepo.CommonExt{
					UserId:   userId,
					UserName: "",
				},
			}
			marshal, _ := json.Marshal(ext)
			return string(marshal)
		}(),
	}
	err = oauthDao.Save(newOauth)
	if err != nil {
		return err
	}

	// 重新授权设置oauth缓存
	err = cache.SetOauthCache(newOauth.OauthId, newOauth.AccessToken)
	if err != nil {
		return err
	}

	_ = s.CallbackKuaishouMessage(userIdStr, "", appId)

	return nil
}

func (s *OauthService) OauthCheckValidity(params accountdto.OauthCheckValidityParams) error {
	oauthDao := accountdao.NewOauthDao(s.Ctx)
	list, err := oauthDao.ListOauth(accountdao.ListOauthParams{
		Media:    params.Media,
		OauthIds: params.OauthIds,
	})
	if err != nil {
		return err
	}

	ctx := context.Background()
	var checkFailedOauth []OauthFailedInfo
	for _, v := range list {
		switch v.Media {
		case repository.MediaToutiao:
			resp, e := toutiao.UserInfoV2(ctx, v.AccessToken)
			if resp != nil && *resp.Code != toutiao.CodeSuccess {
				checkFailedOauth = append(checkFailedOauth, OauthFailedInfo{
					Oauth:      v,
					ErrMessage: fmt.Sprintf("code: %d, msg: %s", *resp.Code, *resp.Message),
				})
				continue
			}
			if e != nil {
				checkFailedOauth = append(checkFailedOauth, OauthFailedInfo{
					Oauth:      v,
					ErrMessage: e.Error(),
				})
				continue
			}
		case repository.MediaKuaishou:
			userId, _ := v.UserIdInt64()
			resp, e := kuaishou.ReportQueryAccountInfo(ctx, kuaishou.ReportQueryAccountInfoReq{
				OauthId:      v.OauthId,
				AppId:        v.AppId,
				AccessToken:  v.AccessToken,
				AdvertiserId: userId,
			})
			if resp != nil && resp.Code != kuaishou.CodeSuccess {
				checkFailedOauth = append(checkFailedOauth, OauthFailedInfo{
					Oauth:      v,
					ErrMessage: fmt.Sprintf("code: %d, msg: %s", resp.Code, resp.Message),
				})
				continue
			}
			if e != nil {
				checkFailedOauth = append(checkFailedOauth, OauthFailedInfo{
					Oauth:      v,
					ErrMessage: e.Error(),
				})
				continue
			}
		}
	}

	if len(checkFailedOauth) > 0 {
		err = s.OauthCheckValidityFailedMessage(checkFailedOauth)
		if err != nil {
			log.Errorf("授权access_token有效性校验错误, err: %s", err)
			return err
		}
	}

	// 查询授权数据
	return nil
}

func (s *OauthService) OauthCheckValidityFailedMessage(oauthList []OauthFailedInfo) error {
	mm := make(map[string]map[string][]string) // 媒体/应用/账号id(名称)
	for _, v := range oauthList {
		o := v.Oauth
		if _, ok := mm[o.Media]; !ok {
			mm[o.Media] = make(map[string][]string)
		}

		ext, _ := o.GetCommonExt()
		var userName string
		if ext.UserName != "" {
			userName = fmt.Sprintf("(%s)", ext.UserName)
		}
		var errMsg string
		if v.ErrMessage != "" {
			errMsg = fmt.Sprintf("\n   %s", v.ErrMessage)
		}

		mm[o.Media][o.AppId] = append(mm[o.Media][o.AppId], fmt.Sprintf("%d%s%s", ext.UserId, userName, errMsg))
	}

	env := viper.GetString("env")
	var ss []string
	ss = append(ss,
		fmt.Sprintf("token有效性校验失败[%s]:", env),
	)

	for media, v := range mm {
		ss = append(ss, fmt.Sprintf("媒体: %s", media))
		for appId, vv := range v {
			ss = append(ss, fmt.Sprintf(" 应用id: %s", appId))
			ss = append(ss, "  账户id: ")
			for _, userId := range vv {
				ss = append(ss, fmt.Sprintf("   %s", userId))
			}
		}
	}
	ss = append(ss,
		"请尽快重新授权!!!",
	)

	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	text := &noticeCommon.Text{Content: strings.Join(ss, "\n")}
	groups := viper.GetStringSlice("oauth.notify_groups")
	sMsg := &noticeCommon.GroupMessage{
		Togroups: groups,
		Msgtype:  "text",
		Text:     text,
	}
	resp, err := client.SendGroupMessage(sMsg)
	if err == nil && resp.Errcode != 0 {
		return err
	}
	return nil
}

func (s *OauthService) CallbackToutiaoPush(media string, req accountdto.CallbackToutiaoReq) error {
	ctx := s.Ctx

	oauthConfigService := NewOauthConfigService(s.Ctx)
	oauthConfig, err := oauthConfigService.OneByMediaAppId(media, req.AppId)
	if err != nil {
		return err
	}

	appId, err := oauthConfig.GetAppId()
	if err != nil {
		return err
	}

	resp, err := toutiao.Oauth2AccessToken(ctx, models.Oauth2AccessTokenRequest{
		AppId:    &appId,
		AuthCode: req.AuthCode,
		Secret:   oauthConfig.AppSecret,
	})
	if err != nil {
		return err
	}

	// 获取授权User信息
	userInfoV2, err := toutiao.UserInfoV2(ctx, *resp.Data.AccessToken)
	if err != nil {
		return err
	}
	if userInfoV2 == nil || userInfoV2.Data == nil || userInfoV2.Data.Id == nil {
		return errors.New("获取授权用户信息id失败")
	}
	userId := strconv.FormatInt(*userInfoV2.Data.Id, 10)
	if req.Uid != userId {
		return errors.New("获取授权用户信息id与回调参数uid不一致")
	}

	expiresIn := *resp.Data.ExpiresIn
	refreshTokenExpiresIn := *resp.Data.RefreshTokenExpiresIn
	now := time.Now()

	oauthId := md5.GetStringMd5(fmt.Sprintf("%s_%s_%s", oauthConfig.AppID, oauthConfig.AppSecret, userId))
	oauthDao := accountdao.NewOauthDao(s.Ctx)

	// 将获取的accessToken和refreshToken入库
	newOauth := accountrepo.OauthEntity{
		Media:        media,
		OauthId:      oauthId,
		AccessToken:  *resp.Data.AccessToken,
		RefreshToken: *resp.Data.RefreshToken,
		ExpireAt: func() time.Time {
			return now.Add(time.Duration(expiresIn) * time.Second)
		}(),
		RefreshExpireAt: func() time.Time {
			return now.Add(time.Duration(refreshTokenExpiresIn) * time.Second)
		}(),
		ExpireTime:        expiresIn,
		RefreshExpireTime: refreshTokenExpiresIn,
		AppId:             oauthConfig.AppID,
		UserId:            userId,
		AppSecret:         oauthConfig.AppSecret,
		Ext: func() string {
			ext := accountrepo.ToutiaoExt{
				accountrepo.CommonExt{
					UserId:   *userInfoV2.Data.Id,
					UserName: *userInfoV2.Data.DisplayName,
				},
			}
			marshal, _ := json.Marshal(ext)
			return string(marshal)
		}(),
	}
	err = oauthDao.SavePush(newOauth)
	if err != nil {
		return err
	}
	return err
}
