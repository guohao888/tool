package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/widthtable"
	"goserver/app/model/service/synctable"
	"time"
)

func SyncReportPromotionHistory(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewProjectCostService(ctx)
	// 最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfosHistory()
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	return "最终关联数据刷新成功"
}

/********************************        当日/历史 ROI 分离  start     ********************************/

func SyncReportPromotionToday(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewProjectCostService(ctx)
	//最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfosToday()
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	// swap
	err := syncService.SwapProjectTable()
	if err != nil {
		return err.Error()
	}
	// 写入最终关联数据时间表
	err = syncService.InsertProjectExecTime(time.Now().Format(time.DateTime))
	if err != nil {
		return err.Error()
	}
	return "最终关联数据刷新成功"
}
