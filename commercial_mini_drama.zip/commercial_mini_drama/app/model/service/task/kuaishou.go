package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	"goserver/app/model/service/kuaishou"
	"time"
)

// SyncKuaishouAccount 拉取快手账号
func SyncKuaishouAccount(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	accountService := kuaishou.NewAccountService(ctx)
	err := accountService.KuaishouAccountInfo(ctx)
	if err != nil {
		return fmt.Sprintf("同步快手账号数据失败, err: %s", err)
	}

	return "同步快手账号数据成功"
}

// SyncKuaishouDetailHistory 拉取广告报表明细历史
/**
{
	"is_history":1
}
*/
func SyncKuaishouDetailHistory(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("拉取快手历史广告报表明细时间错误, err: %s", err)
	}
	adDetailService := kuaishou.NewAdDetailService(ctx)
	for _, crontabDate := range crontabDateList {
		err = adDetailService.DistributeAdDetailHistory(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("拉取广告报表明细失败, err: %s", err)
		}
	}
	return "拉取快手历史广告报表明细成功"
}

// SyncKuaishouDetailToday 拉取广告报表明细实时
/**
{
	"is_history":0
}
*/
func SyncKuaishouDetailToday(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("拉取快手实时广告报表明细时间错误, err: %s", err)
	}
	adDetailService := kuaishou.NewAdDetailService(ctx)
	for _, crontabDate := range crontabDateList {
		err = adDetailService.DistributeAdDetailToday(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("拉取快手实时广告报表明细失败, err: %s", err)
		}
	}
	err = kuaishou.SavePullTime(time.Now().Format(time.DateTime), 1)
	if err != nil {
		return "保存拉取快手实时广告报表明细时间失败"
	}
	return "拉取快手实时广告报表明细成功"
}

// SyncKuaishouSeries 拉取快手剧目信息
func SyncKuaishouSeries(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	seriesService := kuaishou.NewSeriesService(ctx)

	err := seriesService.KuaishouSeriesInfo(ctx)
	if err != nil {
		return fmt.Sprintf("同步快手短剧信息失败, err: %s", err)
	}

	return "同步快手短剧信息成功"
}

// SyncKuaishouCoreDataHistory 拉取广告报表明细 历史
/**
{
	"is_history":1
}
*/
func SyncKuaishouCoreDataHistory(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("拉取快手历史核心报表时间错误, err: %s", err)
	}
	coreDataService := kuaishou.NewCoreDataService(ctx)
	for _, crontabDate := range crontabDateList {
		err = coreDataService.DistributeCoreDataHistory(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("拉取快手历史核心报表失败, err: %s", err)
		}
	}
	return "拉取快手历史核心报表成功"
}

// SyncKuaishouCoreDataTodayIAA 快手核心报表 实时 IAA
/**
{
	"is_history":0
}
*/
func SyncKuaishouCoreDataTodayIAA(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("拉取快手实时核心报表IAA时间错误, err: %s", err)
	}
	coreDataService := kuaishou.NewCoreDataService(ctx)
	for _, crontabDate := range crontabDateList {
		err = coreDataService.DistributeCoreDataTodayIAA(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("拉取快手实时核心报表IAA失败, err: %s", err)
		}
	}
	err = kuaishou.SavePullTime(time.Now().Format(time.DateTime), 2)
	if err != nil {
		return "保存拉取快手实时核心报表IAA时间失败"
	}
	return "拉取快手实时核心报表IAA成功"
}

// SyncKuaishouCoreDataTodayIAP 快手核心报表 实时 IAP
/**
{
	"is_history":0
}
*/
func SyncKuaishouCoreDataTodayIAP(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	crontabDateList, err := params.CrontabDateList()
	if err != nil {
		return fmt.Sprintf("拉取快手实时核心报表IAA时间错误, err: %s", err)
	}
	coreDataService := kuaishou.NewCoreDataService(ctx)
	for _, crontabDate := range crontabDateList {
		err = coreDataService.DistributeCoreDataTodayIAP(crontabDate, ctx)
		if err != nil {
			return fmt.Sprintf("拉取快手实时核心报表IAP失败, err: %s", err)
		}
	}
	err = kuaishou.SavePullTime(time.Now().Format(time.DateTime), 2)
	if err != nil {
		return "保存拉取快手实时核心报表IAP时间失败"
	}
	return "拉取快手实时核心报表IAP成功"
}
