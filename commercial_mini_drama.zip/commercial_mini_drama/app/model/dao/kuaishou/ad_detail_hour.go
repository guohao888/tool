package kuaishou

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/kuaishou"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// AdDetailHourDao 短剧广告小时报表明细
type AdDetailHourDao struct {
	Ctx context.Context
}

func NewAdDetailHourDao(ctx context.Context) *AdDetailHourDao {
	return &AdDetailHourDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (a *AdDetailHourDao) InsertBatchSize(data []*kuaishou.AdDetailHourEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = a.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (a *AdDetailHourDao) buildInsertSentence(tx *gorm.DB, data []*kuaishou.AdDetailHourEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + kuaishou.AdDetailHourTableName() + " ( advertiser_id, account_id, date, hour, event_pay_purchase_amount, total_charge, mini_game_iaa_purchase_amount ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.AccountId,
			v.Date,
			v.Hour,
			v.EventPayPurchaseAmount,
			v.TotalCharge,
			v.MiniGameIaaPurchaseAmount,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

type CostAndIncomeStruct struct {
	Date         string
	Hour         string
	AdvertiserId string
	AccountId    string
	AccountName  string
	Cost         float64
	Income       float64
	Roi          float64
	Optimizer    string
}

func (a *AdDetailHourDao) CostAndIncome() (res []CostAndIncomeStruct, err error) {
	db := dorisdb.DorisClient()
	sql := "SELECT SUBSTR(date, 1, 10) as date, `hour`, cos.advertiser_id, cos.account_id, account_name, cost, income, roi, optimizer FROM ( SELECT date, c.`hour`,c.advertiser_id, c.account_id, costc- costb as cost, income, round(income/costc, 2) as roi FROM ( SELECT date(date) as date, `hour`, advertiser_id, account_id, sum(total_charge/1000) as costc, sum(event_pay_purchase_amount+mini_game_iaa_purchase_amount) as income FROM kuaishou_ad_detail_hour WHERE date(date) = CURRENT_DATE AND `hour` = hour(CURRENT_TIME) GROUP BY date(date), `hour`, advertiser_id, account_id ) c LEFT JOIN ( SELECT `hour`, advertiser_id, account_id, sum(total_charge/1000) as costb FROM kuaishou_ad_detail_hour WHERE date(date) = CURRENT_DATE AND `hour` = hour(CURRENT_TIME)-1 GROUP BY `hour`, advertiser_id, account_id ) b ON c.advertiser_id = b.advertiser_id AND c.account_id = b.account_id WHERE costc- costb > 200 ) cos LEFT JOIN (SELECT advertiser_id, account_id, account_name, SUBSTRING_INDEX(account_name,'-',1) as optimizer FROM kuaishou_account_info) acc ON cos.advertiser_id = acc.advertiser_id AND cos.account_id = acc.account_id ORDER BY cost DESC"
	//sql := "SELECT SUBSTR(date, 1, 10) as date, `hour`, cos.advertiser_id, cos.account_id, account_name, costc as cost, income, roi, optimizer FROM ( SELECT date(date) as date, `hour`, advertiser_id, account_id, sum(total_charge/1000) as costc, sum(event_pay_purchase_amount+mini_game_iaa_purchase_amount) as income, round(sum(event_pay_purchase_amount+mini_game_iaa_purchase_amount)/sum(total_charge/1000), 2) as roi  FROM kuaishou_ad_detail_hour WHERE date(date) = CURRENT_DATE AND `hour` = hour(CURRENT_TIME) GROUP BY date(date), `hour`, advertiser_id, account_id ) cos LEFT JOIN (SELECT advertiser_id, account_id, account_name, SUBSTRING_INDEX(account_name,'-',1) as optimizer FROM kuaishou_account_info) acc ON cos.advertiser_id = acc.advertiser_id AND cos.account_id = acc.account_id  WHERE optimizer = '刘硕' ORDER BY cost DESC limit 1"
	err = db.Raw(sql).Scan(&res).Error
	return
}
