package roi

import (
	"context"
	"encoding/json"
	"fmt"
	"goserver/app/common"
	"goserver/app/common/dto/roidto"
	"goserver/app/common/repository/accounts"
	"goserver/app/common/repository/fanqie"
	repo "goserver/app/common/repository/roi"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/library/utils"
	"goserver/app/model/dao"
	"strconv"
	"strings"
	"time"

	"github.com/jinzhu/gorm"
	errgroup "golang.org/x/sync/errgroup"
)

const Yesterday = 2
const Today = 1

type ReportDataDao struct {
	Ctx context.Context
}

type ProductTodayReportData struct {
	Date      time.Time `gorm:"column:date"`
	Hour      int       `gorm:"column:hour"`
	DayCost   float64   `gorm:"column:day_cost"`
	DayRoi    float64   `gorm:"column:day_roi"`
	HourCost  float64   `gorm:"column:hour_cost"`
	HourRoi   float64   `gorm:"column:hour_roi"`
	CostRatio float64   `gorm:"column:cost_ratio"` // 消耗环比
	RoiRatio  float64   `gorm:"column:roi_ratio"`  // roi 环比
}

type AccountDataInfo struct {
	SearchDate     time.Time `gorm:"column:search_date"`
	AccountID      int64     `gorm:"column:advertiser_id"`
	AccountName    string    `gorm:"column:advertiser_name"`
	Cost           float64   `gorm:"column:cost"`
	Income         float64   `gorm:"column:income"`
	Roi            string    `gorm:"column:roi"`
	UserID         int64     `gorm:"column:user_id"`
	UserName       string    `gorm:"column:user_name"`
	TodayIncome    float64   `gorm:"column:today_income"`
	ThreeDayIncome float64   `gorm:"column:threeday_income"`
	ThreeIncomeRoi float64   `gorm:"column:three_income_roi"`
	TodayIncomeRoi float64   `gorm:"column:today_income_roi"`
	IncomeRoi24    float64   `gorm:"column:income_roi_24"`
	ProFit         float64   `gorm:"column:profit"` // 利润
}

type AccountData struct {
	Hour   int     `gorm:"column:hour"`
	Cost   float64 `gorm:"column:cost"`
	Income float64 `gorm:"column:income"`
	Roi    string  `gorm:"column:roi"`
}

// 剧目统计
type ProductBookData struct {
	BookName string  `gorm:"column:book_name"` // 剧目名称
	BookID   int64   `gorm:"column:book_id"`   // 剧目ID
	HourCost float64 `gorm:"column:hour_cost"` // 小时消耗
	HourRoi  float64 `gorm:"column:hour_roi"`  // 小时ROI
	DayCost  float64 `gorm:"column:day_cost"`  // 当天累计消耗
	DayRoi   float64 `gorm:"column:day_roi"`   // 当天ROI
}

// 商品库地区统计
type ProductReginData struct {
	Region    string  `gorm:"column:region"`     // 地区名称
	HourCost  float64 `gorm:"column:hour_cost"`  // 小时消耗
	HourRoi   float64 `gorm:"column:hour_roi"`   // 小时ROI
	DayCost   float64 `gorm:"column:day_cost"`   // 当天累计消耗
	DayRoi    float64 `gorm:"column:day_roi"`    // 当天ROI
	CostRadio float64 `gorm:"column:cost_radio"` //消耗环比(环比上个小时)
	RoiRadio  float64 `gorm:"column:roi_radio"`  // roi 环比(环比上个小时)
}

// 投手数据统计
type OptimizeData struct {
	OptimizeID   int64     `gorm:"column:optimizer_id"`       // 投手ID
	OptimizeName string    `gorm:"column:optimizer_nickname"` // 投手名称
	Date         time.Time `gorm:"column:date"`               // 日期
	HourCost     float64   `gorm:"column:hour_cost"`          // 小时消耗
	HourRoi      float64   `gorm:"column:hour_roi"`           // 小时ROI
	DayCost      float64   `gorm:"column:day_cost"`           // 当天累计消耗
	DayRoi       float64   `gorm:"column:day_roi"`            // 当天ROI
	CostRadio    float64   `gorm:"column:cost_radio"`         //消耗环比(环比上个小时)
	RoiRadio     float64   `gorm:"column:roi_radio"`          // roi 环比(环比上个小时)
}

type UserExt struct {
	UserID int64  `gorm:"column:user_id"`
	Ext    string `gorm:"column:ext"`
}

func NewReportDataDao(ctx context.Context) *ReportDataDao {
	return &ReportDataDao{Ctx: ctx}
}

// InsertBatchSizeV2 插入更新数据
func (d *ReportDataDao) InsertBatchSizeV2(data []repo.ReportDataEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsert(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (d *ReportDataDao) batchInsert(tx *gorm.DB, data []repo.ReportDataEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.ReportDataTableName() + " (point_time,media,campaign_id,group_id,adcreative_id,account_id,platform,source,cost,show_count,click_count,download_count,active_count,pay_count,key_behavior_count,campaign_name,group_name,adcreative_name,point_date) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.PointTime,
			v.Media,
			v.CampaignId,
			v.GroupId,
			v.AdCreativeId,
			v.AccountId,
			v.Platform,
			v.Source,
			v.Cost,
			v.ShowCount,
			v.ClickCount,
			v.DownloadCount,
			v.ActiveCount,
			v.PayCount,
			v.KeyBehaviorCount,
			v.CampaignName,
			v.GroupName,
			v.AdCreativeName,
			v.PointDate,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// MediaAry 获取ROI报表媒体筛选项列表
func (d *ReportDataDao) MediaAry() (result []roidto.IDLabel, err error) {
	//db := dorisdb.DorisClient()
	//q := db.Table(accounts.OauthActiveAccountTableName())
	//q = q.Select("media")
	//q = q.Where("media<>''")
	//q = q.Group("media")
	//q = q.Order("media ASC")
	//type Row struct {
	//	Name string `gorm:"column:media"`
	//}
	//var res []Row
	//err = q.Find(&res).Error
	//if err != nil {
	//	return
	//}
	//for _, row := range res {
	result = append(result, roidto.IDLabel{
		ID:    "抖小",
		Label: "抖小",
	}, roidto.IDLabel{
		ID:    "端原生",
		Label: "端原生",
	},
	)
	//}
	return
}

// RegionAry 获取ROI报表地区筛选项列表
func (d *ReportDataDao) RegionAry() (result []roidto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.OptimizerInfoTableName())
	q = q.Select("region")
	q = q.Where("region<>''")
	q = q.Group("region")
	q = q.Order("region ASC")
	type Row struct {
		Name string `gorm:"column:region"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, roidto.IDLabel{
			ID:    row.Name,
			Label: row.Name,
		})
	}
	return
}

// OptimizerRegionMapping 获取ROI报表投放人员与地区映射
func (d *ReportDataDao) OptimizerRegionMapping() (result map[string]string, err error) {
	result = make(map[string]string)
	db := dorisdb.DorisClient()
	q := db.Table(accounts.OptimizerInfoTableName())
	q = q.Select("nick_name,region")
	q = q.Where("region<>''")
	q = q.Group("nick_name,region")
	q = q.Order("region ASC")
	type Row struct {
		ID   string `gorm:"column:nick_name"`
		Name string `gorm:"column:region"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result[row.ID] = row.Name
	}
	return
}

// ManagerAry 获取ROI报表账管列表
func (d *ReportDataDao) ManagerAry() (result []roidto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	table := accounts.OauthTableName()
	sql := `SELECT JSON_STRING(ext)AS ext FROM(SELECT user_id,ext,ROW_NUMBER()OVER(PARTITION BY user_id ORDER BY created_at DESC)AS rn FROM %s WHERE media="今日头条")t WHERE rn=1 ORDER BY user_id ASC`
	sql = fmt.Sprintf(sql, table)
	type Row struct {
		Ext string `gorm:"column:ext"`
	}

	var res []Row
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}

	type User struct {
		UserID   int64  `json:"user_id"`
		UserName string `json:"user_name"`
	}

	for _, row := range res {
		if row.Ext == "" {
			continue
		}
		var user User
		err = json.Unmarshal([]byte(row.Ext), &user)
		if err != nil {
			continue
		}
		result = append(result, roidto.IDLabel{
			ID:    strconv.FormatInt(user.UserID, 10),
			Label: user.UserName,
		})
	}

	return
}

// AppAry 获取ROI报表应用筛选项列表
func (d *ReportDataDao) AppAry() (result []roidto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(fanqie.IAAOrderTableName())
	q = q.Select("distinct app_name")
	q = q.Where("app_name<>''")
	q = q.Order("app_name ASC")
	type Row struct {
		Name string `gorm:"column:app_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, roidto.IDLabel{
			ID:    row.Name,
			Label: row.Name,
		})
	}
	return
}

// BookAry 获取ROI报表剧目筛选项列表
func (d *ReportDataDao) BookAry(keywords string, limit int) (result []roidto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	tableToday := repo.ProjectReportTodayDataViewTableName()
	tableHis := repo.ProjectReportDataViewTableName()

	innerSql := "(SELECT book_name FROM " + tableToday + " UNION ALL SELECT book_name FROM " + tableHis + ") t"
	sql := "SELECT DISTINCT book_name FROM " + innerSql + " WHERE book_name!='' "
	if keywords != "" {
		sql += " AND book_name LIKE '%" + keywords + "%'"
	}
	sql += "  ORDER BY book_name ASC"
	if limit > 0 {
		sql += " LIMIT " + strconv.FormatInt(int64(limit), 10)
	}

	type Row struct {
		Name string `gorm:"column:book_name"`
	}
	var res []Row
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, roidto.IDLabel{
			ID:    row.Name, // 特殊处理
			Label: row.Name,
		})
	}
	return
}

// BookMapping 获取ROI报表剧目映射
func (d *ReportDataDao) BookMapping() (result map[string]string, err error) {
	result = make(map[string]string)
	db := dorisdb.DorisClient()
	q := db.Table(accounts.AccountDistributorTableName())
	q = q.Select("book_id,book_name")
	q = q.Group("book_id,book_name")
	q = q.Order("book_name ASC")
	type Row struct {
		ID   string `gorm:"column:book_id"`
		Name string `gorm:"column:book_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result[row.ID] = row.Name
	}
	return
}

// OptimizerAry 获取ROI报表投放人员筛选项列表
func (d *ReportDataDao) OptimizerAry() (result []roidto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.OptimizerInfoTableName())
	q = q.Select("nick_name")
	q = q.Where("nick_name<>''")
	q = q.Group("nick_name")
	q = q.Order("nick_name ASC")
	type Row struct {
		Name string `gorm:"column:nick_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, roidto.IDLabel{
			ID:    row.Name,
			Label: row.Name,
		})
	}
	return
}

// CopyRightAry 获取ROI报表版权方筛选项列表
func (d *ReportDataDao) CopyRightAry() (result []roidto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	//sql := "SELECT copyright_owner FROM ( SELECT case when LOCATE('点众', copyright_owner) > 0 then '点众' when LOCATE('掌阅', copyright_owner) > 0 then '掌阅' when LOCATE('抖音视界', copyright_owner) > 0 then '番茄' else '其他' end as copyright_owner FROM product_info ) a GROUP BY copyright_owner "
	sql := "SELECT DISTINCT copyright_owner FROM raw_referral_config "
	type Row struct {
		Name string `gorm:"column:copyright_owner"`
	}
	var res []Row
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, roidto.IDLabel{
			ID:    row.Name,
			Label: row.Name,
		})
	}
	return
}

// OptimizerMapping 获取ROI报表投放人员映射
func (d *ReportDataDao) OptimizerMapping() (result map[string]string, err error) {
	result = make(map[string]string)
	db := dorisdb.DorisClient()
	q := db.Table(accounts.AccountDistributorTableName())
	q = q.Select("optimizer_id,optimizer_name")
	q = q.Group("optimizer_id,optimizer_name")
	q = q.Order("optimizer_name ASC")
	type Row struct {
		ID   string `gorm:"column:optimizer_id"`
		Name string `gorm:"column:book_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result[row.ID] = row.Name
	}
	return
}

// AccountAry 获取ROI报表账户筛选项列表
func (d *ReportDataDao) AccountAry(keywords string, limit int) (result []roidto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	q := db.Table(accounts.OauthActiveAccountTableName())
	q = q.Select("advertiser_id,advertiser_name")
	q = q.Where("advertiser_name<>''")
	if keywords != "" {
		q = q.Where("advertiser_name LIKE ?", "%"+keywords+"%")
	}
	q = q.Group("advertiser_id,advertiser_name")
	q = q.Order("advertiser_name ASC")
	if limit > 0 {
		q = q.Offset(0).Limit(limit)
	}
	type Row struct {
		ID   string `gorm:"column:advertiser_id"`
		Name string `gorm:"column:advertiser_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, roidto.IDLabel{
			ID:    row.ID,
			Label: row.Name,
		})
	}
	return
}

// AccountMapping 获取ROI报表账户映射
func (d *ReportDataDao) AccountMapping() (result map[string]string, err error) {
	result = make(map[string]string)
	db := dorisdb.DorisClient()
	q := db.Table(accounts.OauthActiveAccountTableName())
	q = q.Select("advertiser_id,advertiser_name")
	q = q.Group("advertiser_id,advertiser_name")
	q = q.Order("advertiser_name ASC")
	type Row struct {
		ID   string `gorm:"column:advertiser_id"`
		Name string `gorm:"column:advertiser_name"`
	}
	var res []Row
	err = q.Find(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result[row.ID] = row.Name
	}
	return
}

func (d *ReportDataDao) ReportData(params *roidto.ReportDataReq) (*common.Paginator, error) {
	db := dorisdb.DorisClient()
	roiTable := repo.ReportDataViewTableName()
	roiTodayTable := repo.ReportTodayDataViewTableName()

	pagination := params.Pagination
	limit := pagination.GetLimit()
	offset := pagination.GetOffset()
	var sql string
	var columns, columnsHb, columnsTb, columnsAccumulateInner, columnsOuterLayer, columnsTotal []string
	var kpis, kpisHb, kpisTb, kpisAccumulate, kpisAccumulateInner, kpisOuterLayer, kpisHourTotal []string
	var where, whereHb, whereTb []string
	var groups, groupsHb, groupsTb, groupsAccumulateInner, groupsOuterLayer []string
	var sorts []string
	columnsAccumulateArr := []string{"account_id", "promotion_id", "promotion_name",
		"media", "region", "pay_type", "app_name", "book_name", "optimizer_nickname",
		"account_name", "project_name", "project_id", "mid_id", "mid_type"}

	/* 同环比及累计指标查询示例
	-- 子查询sql
	SELECT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columns
	        ,sum(income) AS income,0 AS income_hb,0 AS income_tb,0 AS income2 -- kpis
	    FROM roi_report_hourly
	    WHERE DATE>='2025-02-03' AND DATE<='2025-02-09' AND promotion_id IN (7455361602293104650) -- where
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groups
	    UNION ALL
	    SELECT DATE_ADD(DATE,INTERVAL 7 DAY) AS DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsHb
	        ,0 AS income,sum(income) AS income_hb,0 AS income_tb,0 AS income2 -- kpisHb
	    FROM roi_report_hourly
	    WHERE DATE>='2025-01-27' AND DATE<='2025-02-02' AND promotion_id IN (7455361602293104650) -- whereHb
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groupsHb
	    UNION ALL
	    SELECT DATE_ADD(DATE,INTERVAL 1 MONTH) AS DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsTb
	        ,0 AS income,0 AS income_hb,sum(income) AS income_tb,0 AS income2 -- kpisTb
	    FROM roi_report_hourly
	    WHERE DATE>='2025-01-03' AND DATE<='2025-01-09' AND promotion_id IN (7455361602293104650)  -- whereTb
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groupsTb
	    UNION ALL
	    SELECT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsOuterLayer
	        ,0 AS income,0 AS income_hb,0 AS income_tb,SUM(income2) AS income2 -- kpisAccumulate
	    FROM (
	        SELECT DATE,account_id,promotion_id
	            ,media,region,pay_type,app_name,book_name,optimizer_nickname
	            ,account_name,project_name,promotion_name,mid_id,mid_type  -- columnsAccumulateInner
	            ,MAX(new_sum_income) AS new_sum_income,MAX(income2) AS income2,MAX(income3) AS income3
	            ,MAX(income4) AS income4,MAX(income5) AS income5,MAX(income6) AS income6,MAX(income7) AS income7 -- kpisAccumulateInner
	        FROM roi_report_hourly
	        WHERE DATE>='2025-02-03' AND DATE<='2025-02-09' AND promotion_id IN (7455361602293104650) -- where
	        GROUP BY DATE,account_id,promotion_id
	            ,media,region,media,pay_type,app_name,book_name,optimizer_nickname
	            ,account_name,project_name,promotion_name,mid_id,mid_type  -- groupsAccumulateInner
	    ) AS tt
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id; -- groupsOuterLayer
	-- 分页明细数据查询
	SELECT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsOuterLayer
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income_tb) AS income_tb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t
	GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groupsOuterLayer
	ORDER BY DATE ASC,income DESC -- sorts
	LIMIT 19 OFFSET 0; -- limit offset
	-- 汇总行数据查询
	SELECT '汇总' AS DATE -- columnTotal
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income_tb) AS income_tb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t;
	-- 总行数查询
	SELECT COUNT(DISTINCT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id) AS cnt -- groupsOuterLayer
	FROM (子查询sql) AS t;
	*/

	// 时间聚合维度
	columnsTotal = append(columnsTotal, "'汇总' as date")
	hbStr := "DATE(DATE_ADD(date,INTERVAL " + strconv.Itoa(params.DaysOfHb) + " DAY))"
	tbStr := "DATE(DATE_ADD(date,INTERVAL 1 MONTH))"
	if params.GroupType == "w" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%xW%v') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%xW%v') AS date")
		columnsTb = append(columnsTb, "DATE_FORMAT("+tbStr+", '%xW%v') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%xW%v') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%xW%v')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%xW%v')")
		groupsTb = append(groupsTb, "DATE_FORMAT("+tbStr+", '%xW%v')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%xW%v')")
	} else if params.GroupType == "m" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%Y-%m') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%Y-%m') AS date")
		columnsTb = append(columnsTb, "DATE_FORMAT("+tbStr+", '%Y-%m') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%Y-%m') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%Y-%m')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%Y-%m')")
		groupsTb = append(groupsTb, "DATE_FORMAT("+tbStr+", '%Y-%m')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%Y-%m')")
	} else if params.GroupType == "h" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groups = append(groups, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00')")
		if params.IsRealTimeQuery {
			// 固定加一小时
			columnsHb = append(columnsHb, "CONCAT(date,' ',IF(hour<10,'0',''),hour,':00:00') + INTERVAL 1 HOUR AS date")
			groupsHb = append(groupsHb, "CONCAT(date,' ',IF(hour<10,'0',''),hour,':00:00') + INTERVAL 1 HOUR")
		} else {
			columnsHb = append(columnsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
			groupsHb = append(groupsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")
		}
		columnsTb = append(columnsTb, "CONCAT("+tbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groupsTb = append(groupsTb, "CONCAT("+tbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")

		// 分小时的汇总行计算需要特殊逻辑
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	} else {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "date")
		columnsHb = append(columnsHb, hbStr+" AS date")
		columnsTb = append(columnsTb, tbStr+" AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groups = append(groups, "date")
		groupsHb = append(groupsHb, "date")
		groupsTb = append(groupsTb, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	}
	groupsOuterLayer = append(groupsOuterLayer, "date")
	columnsAccumulateInner = append(columnsAccumulateInner, columnsAccumulateArr...)
	groupsAccumulateInner = append(groupsAccumulateInner, columnsAccumulateArr...)

	// 用户定制聚合维度 (group by)
	columns = append(columns, params.GroupBy...)
	columnsHb = append(columnsHb, params.GroupBy...)
	columnsTb = append(columnsTb, params.GroupBy...)
	columnsOuterLayer = append(columnsOuterLayer, params.GroupBy...)
	groups = append(groups, params.GroupBy...)
	groupsHb = append(groupsHb, params.GroupBy...)
	groupsTb = append(groupsTb, params.GroupBy...)
	groupsOuterLayer = append(groupsOuterLayer, params.GroupBy...)

	// 普通指标
	kpiArr := []string{"media_cost", "show_count", "click_count",
		"media_active_count", "media_convert_count", "media_first_pay_count",
		"active_count", "new_pay_count", "active_pay_count", "first_income"}
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
		if kpi == "media_cost" || kpi == "first_income" {
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0.0 AS "+kpi)
		} else {
			kpisHb = append(kpisHb, "0 AS "+kpi)
			kpisTb = append(kpisTb, "0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0 AS "+kpi)
		}
	}

	// 同环比指标
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost) as cost")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_hb) as cost_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_tb) as cost_tb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income) as income")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income_hb) as income_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income_tb) as income_tb")
	//实际消耗=(媒体消耗-赠款reward_cost-共享赠款shared_wallet_cost)/(1+返点比例2%)
	mediaCostSql := "SUM(media_cost)"
	rewardCostSql := "SUM(reward_cost)"
	sharedWalletCostSql := "SUM(shared_wallet_cost)"
	//账户返点比例先写死0.02, 后续等数据库实时处理好了, 再使用数据库的
	mediaRebateRateSql := "0.02" //"MAX(media_rebate_rate)"
	costSql := "(" + mediaCostSql + "-" + rewardCostSql + "-" + sharedWalletCostSql + ")/(1.0+" + mediaRebateRateSql + ")"
	kpis = append(kpis, costSql+" as cost")
	kpis = append(kpis, "0.0 as cost_hb")
	kpis = append(kpis, "0.0 as cost_tb")
	kpisHb = append(kpisHb, "0.0 as cost")
	kpisHb = append(kpisHb, costSql+" as cost_hb")
	kpisHb = append(kpisHb, "0.0 as cost_tb")
	kpisTb = append(kpisTb, "0.0 as cost")
	kpisTb = append(kpisTb, "0.0 as cost_hb")
	kpisTb = append(kpisTb, costSql+" as cost_tb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_tb")
	//实际收入
	kpis = append(kpis, "SUM(income) as income")
	kpis = append(kpis, "0.0 as income_hb")
	kpis = append(kpis, "0.0 as income_tb")
	kpisHb = append(kpisHb, "0.0 as income")
	kpisHb = append(kpisHb, "SUM(income) as income_hb")
	kpisHb = append(kpisHb, "0.0 as income_tb")
	kpisTb = append(kpisTb, "0.0 as income")
	kpisTb = append(kpisTb, "0.0 as income_hb")
	kpisTb = append(kpisTb, "SUM(income) as income_tb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income_tb")

	//累计指标的, 小时的直接取, 日周天 的 要取当天的最早有消费的小时的数据
	kpiArr = []string{"new_sum_income", "income2", "income3", "income4", "income5", "income6", "income7"}
	kpisHourTotal = append(kpisHourTotal, kpis...)
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		if params.GroupType == "h" {
			kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisHourTotal = append(kpisHourTotal, "0.0 AS "+kpi) //分小时汇总行的累计指标需要特殊处理
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		} else { //非小时的日周天独立查询
			kpis = append(kpis, "0.0 AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		}
	}

	// 最外层计算指标排序的，需要特殊处理
	var kpi string
	//{Label: "点击率", Prop: "click_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(click_count)/SUM(show_count), 0) AS click_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "点击成本", Prop: "click_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(cost)/SUM(click_count), 0) AS click_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "千展成本", Prop: "show_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(cost)/SUM(show_count), 0) AS show_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活成本", Prop: "media_active_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(media_active_count)>0, SUM(cost)/SUM(media_active_count), 0) AS media_active_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活率", Prop: "media_active_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(media_active_count)/SUM(click_count), 0) AS media_active_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "实际ROI", Prop: "roi", Format: "rate", SortAble: true, IsDefault: true},
	kpi = "IF(SUM(cost)>0, SUM(income)/SUM(cost), 0) AS roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "首日新增ROI", Prop: "first_roi", Format: "rate", SortAble: true},
	kpi = "IF(SUM(cost)>0, SUM(first_income)/SUM(cost), 0) AS first_roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)

	// 查询条件 (where)
	var filterStr string
	if len(params.Media) > 0 {
		filterStr = "media IN ('" + strings.Join(params.Media, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.Region) > 0 {
		filterStr = "region IN ('" + strings.Join(params.Region, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.PayType) > 0 {
		filterStr = "pay_type IN ('" + strings.Join(params.PayType, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AppName) > 0 {
		filterStr = "app_name IN ('" + strings.Join(params.AppName, "','") + "')"
		where = append(where, filterStr)
	}
	if params.BookID != "" {
		bookId, _ := strconv.Atoi(params.BookID)
		filterStr = "book_id=" + strconv.Itoa(bookId)
		where = append(where, filterStr)
	}
	if len(params.BookNames) > 0 {
		filterStr = "book_name IN ('" + strings.Join(params.BookNames, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.OptimizerName) > 0 {
		filterStr = "optimizer_nickname IN ('" + strings.Join(params.OptimizerName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AccountID) > 0 {
		filterStr = "account_id IN ('" + strings.Join(params.AccountID, "','") + "')"
		where = append(where, filterStr)
	}
	id1, _ := strconv.Atoi(params.ProjectID)
	if id1 > 0 {
		filterStr = "project_id=" + strconv.Itoa(id1)
		where = append(where, filterStr)
	}
	id2, _ := strconv.Atoi(params.PromotionID)
	if id2 > 0 {
		filterStr = "promotion_id=" + strconv.Itoa(id2)
		where = append(where, filterStr)
	}
	id3, _ := strconv.Atoi(params.MidID)
	if id3 > 0 {
		filterStr = "mid_id=" + strconv.Itoa(id3)
		where = append(where, filterStr)
	}

	whereHb = append(whereHb, where...)
	whereTb = append(whereTb, where...)

	if params.StartDate == params.EndDate {
		where = append(where, "date='"+params.StartDate+"'")
		whereTb = append(whereTb, "date='"+params.StartDateTb+"'")
		if params.IsRealTimeQuery {
			whereHb = append(whereHb, "((date='"+params.StartDate+"' AND hour <= 23) OR (date='"+params.StartDateHb+"' AND hour=23))")
		} else {
			whereHb = append(whereHb, "date='"+params.StartDateHb+"'")
		}
	} else {
		where = append(where, "date>='"+params.StartDate+"' AND date<='"+params.EndDate+"'")
		whereHb = append(whereHb, "date>='"+params.StartDateHb+"' AND date<='"+params.EndDateHb+"'")
		whereTb = append(whereTb, "date>='"+params.StartDateTb+"' AND date<='"+params.EndDateTb+"'")
	}

	// 排序 (sort)
	if len(params.Sorts) == 0 {
		params.Sorts = append(params.Sorts,
			common.Sort{Key: "date", Order: "asc"},
			common.Sort{Key: "cost", Order: "desc"},
		)
	}
	for _, sort := range params.Sorts {
		sorts = append(sorts, fmt.Sprintf("%s %s", sort.Key, sort.Order))
	}

	// T T-1 数据存储在不同表
	baseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columns, ",")+","+strings.Join(kpis, ","), strings.Join(where, " AND "), strings.Join(groups, ","))
	var hbBaseSql, tbBaseSql string
	if params.IsRealTimeQuery { // 实时查询上一小时也是今天数据
		hbBaseSql = getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsHb, ",")+","+strings.Join(kpisHb, ","), strings.Join(whereHb, " AND "), strings.Join(groupsHb, ","))
	} else {
		hbBaseSql = getBaseUnionSql(roiTable, "", strings.Join(columnsHb, ",")+","+strings.Join(kpisHb, ","), strings.Join(whereHb, " AND "), strings.Join(groupsHb, ","))
	}
	tbBaseSql = getBaseUnionSql(roiTable, "", strings.Join(columnsTb, ",")+","+strings.Join(kpisTb, ","), strings.Join(whereTb, " AND "), strings.Join(groupsTb, ","))
	//子查询构造
	subSql := baseSql +
		" UNION ALL" +
		hbBaseSql +
		" UNION ALL" +
		tbBaseSql
	if params.GroupType != "h" {
		hBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsAccumulateInner, ",")+","+strings.Join(kpisAccumulateInner, ","), strings.Join(where, " AND "), strings.Join(groupsAccumulateInner, ","))
		subSql += " UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			hBaseSql +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}

	// 总行数查询
	var total int64
	type Dist struct {
		Cnt int64 `gorm:"column:cnt"`
	}
	var dist Dist
	sql = "SELECT COUNT(DISTINCT " + strings.Join(groupsOuterLayer, ",") + ") AS cnt " +
		" FROM (" + subSql + ") AS t"

	err := db.Raw(sql).Scan(&dist).Error
	if err != nil {
		return nil, err
	}
	total = dist.Cnt

	// 分页明细数据查询
	var res []repo.ReportDataViewEntity
	sql = "SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t" +
		" GROUP BY " + strings.Join(groupsOuterLayer, ",") +
		" ORDER BY " + strings.Join(sorts, ",") +
		" LIMIT " + strconv.FormatInt(limit, 10) + " OFFSET " + strconv.FormatInt(offset, 10)

	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	// 计算指标处理
	for i, row := range res {
		res[i] = *row.Calculate()
		if params.GroupType == "h" {
			res[i].Date = row.Date[0:10] + " " + row.Date[11:19]
		} else if params.GroupType == "d" {
			res[i].Date = row.Date[0:10]
		}
	}

	// 汇总行数据查询
	if params.GroupType == "h" {
		//子查询构造 - 小时维度特殊处理
		nBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columns, ",")+","+strings.Join(kpisHourTotal, ","), strings.Join(where, " AND "), strings.Join(groups, ","))
		nhBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsAccumulateInner, ",")+","+strings.Join(kpisAccumulateInner, ","), strings.Join(where, " AND "), strings.Join(groupsAccumulateInner, ","))
		ntBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsTb, ",")+","+strings.Join(kpisTb, ","), strings.Join(whereTb, " AND "), strings.Join(groupsTb, ","))

		subSql = nBaseSql +
			" UNION ALL" +
			hbBaseSql +
			" UNION ALL" +
			ntBaseSql +
			" UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			nhBaseSql +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}

	var countRow repo.ReportDataViewEntity
	sql = "SELECT " + strings.Join(columnsTotal, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t"

	err = db.Raw(sql).Scan(&countRow).Error
	if err != nil {
		return nil, err
	}
	//拼接返回列表行
	var list []repo.ReportDataViewEntity
	if countRow.Date != "" {
		// 计算指标处理
		countRow.Calculate()
		list = append(list, countRow)
	}
	list = append(list, res...)

	// 格式化数据
	for i, row := range list {
		list[i].Media = utils.HtmlEncode(row.Media)
		list[i].Region = utils.HtmlEncode(row.Region)
		if val, ok := roidto.PayTypeMapping[row.PayType]; ok {
			list[i].PayType = val
		}
		list[i].AppID = utils.HtmlEncode(row.AppID)
		list[i].AppName = utils.HtmlEncode(row.AppName)
		list[i].BookName = utils.HtmlEncode(row.BookName)
		list[i].OptimizerNickname = utils.HtmlEncode(row.OptimizerNickname)
		list[i].AccountID = utils.HtmlEncode(row.AccountID)
		list[i].AccountName = utils.HtmlEncode(row.AccountName)
		list[i].ProjectID = utils.HtmlEncode(row.ProjectID)
		list[i].ProjectName = utils.HtmlEncode(row.ProjectName)
		list[i].PromotionID = utils.HtmlEncode(row.PromotionID)
		list[i].PromotionName = utils.HtmlEncode(row.PromotionName)
		list[i].MidID = utils.HtmlEncode(row.MidID)
		list[i].MidType = utils.HtmlEncode(row.MidType)
	}

	paginator := common.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, list)
	return &paginator, nil
}

// 拼接两表聚合
func getBaseUnionSql(table1, table2, columns, where, group string) string {
	var oauthSql, viewTable1, viewTable2, viewTable string
	oauthSql = `(SELECT user_id,advertiser_id FROM oauth_account WHERE media = '今日头条') oauth_account`
	viewTable1 = fmt.Sprintf(`SELECT * FROM %s LEFT JOIN %s ON %s.account_id = oauth_account.advertiser_id WHERE %s`, table1, oauthSql, table1, where)
	if table2 != "" {
		viewTable2 = fmt.Sprintf(` UNION ALL SELECT * FROM %s LEFT JOIN %s ON %s.account_id = oauth_account.advertiser_id WHERE %s`, table2, oauthSql, table2, where)
	}
	viewTable = "(" + viewTable1 + viewTable2 + ") as bbt"
	return " SELECT " + columns + " FROM " + viewTable + " GROUP BY " + group
}

func (d *ReportDataDao) ExportData(params *roidto.ReportDataReq) (result *[]repo.ReportDataViewEntity, err error) {
	db := dorisdb.DorisClient()
	roiTable := repo.ReportDataViewTableName()
	roiTodayTable := repo.ReportTodayDataViewTableName()

	var sql string
	var columns, columnsHb, columnsTb, columnsAccumulateInner, columnsOuterLayer, columnsTotal []string
	var kpis, kpisHb, kpisTb, kpisAccumulate, kpisAccumulateInner, kpisOuterLayer, kpisHourTotal []string
	var where, whereHb, whereTb []string
	var groups, groupsHb, groupsTb, groupsAccumulateInner, groupsOuterLayer []string
	var sorts []string
	columnsAccumulateArr := []string{"account_id", "promotion_id", "promotion_name",
		"media", "region", "pay_type", "app_name", "book_name", "optimizer_nickname",
		"account_name", "project_name", "project_id", "mid_id", "mid_type"}

	/* 同环比及累计指标查询示例
	-- 子查询sql
	SELECT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columns
	        ,sum(income) AS income,0 AS income_hb,0 AS income_tb,0 AS income2 -- kpis
	    FROM roi_report_hourly
	    WHERE DATE>='2025-02-03' AND DATE<='2025-02-09' AND promotion_id IN (7455361602293104650) -- where
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groups
	    UNION ALL
	    SELECT DATE_ADD(DATE,INTERVAL 7 DAY) AS DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsHb
	        ,0 AS income,sum(income) AS income_hb,0 AS income_tb,0 AS income2 -- kpisHb
	    FROM roi_report_hourly
	    WHERE DATE>='2025-01-27' AND DATE<='2025-02-02' AND promotion_id IN (7455361602293104650) -- whereHb
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groupsHb
	    UNION ALL
	    SELECT DATE_ADD(DATE,INTERVAL 1 MONTH) AS DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsTb
	        ,0 AS income,0 AS income_hb,sum(income) AS income_tb,0 AS income2 -- kpisTb
	    FROM roi_report_hourly
	    WHERE DATE>='2025-01-03' AND DATE<='2025-01-09' AND promotion_id IN (7455361602293104650)  -- whereTb
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groupsTb
	    UNION ALL
	    SELECT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsOuterLayer
	        ,0 AS income,0 AS income_hb,0 AS income_tb,SUM(income2) AS income2 -- kpisAccumulate
	    FROM (
	        SELECT DATE,account_id,promotion_id
	            ,media,region,pay_type,app_name,book_name,optimizer_nickname
	            ,account_name,project_name,promotion_name,mid_id,mid_type  -- columnsAccumulateInner
	            ,MAX(new_sum_income) AS new_sum_income,MAX(income2) AS income2,MAX(income3) AS income3
	            ,MAX(income4) AS income4,MAX(income5) AS income5,MAX(income6) AS income6,MAX(income7) AS income7 -- kpisAccumulateInner
	        FROM roi_report_hourly
	        WHERE DATE>='2025-02-03' AND DATE<='2025-02-09' AND promotion_id IN (7455361602293104650) -- where
	        GROUP BY DATE,account_id,promotion_id
	            ,media,region,media,pay_type,app_name,book_name,optimizer_nickname
	            ,account_name,project_name,promotion_name,mid_id,mid_type  -- groupsAccumulateInner
	    ) AS tt
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id; -- groupsOuterLayer
	-- 分页明细数据查询
	SELECT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsOuterLayer
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income_tb) AS income_tb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t
	GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groupsOuterLayer
	ORDER BY DATE ASC,income DESC -- sorts
	LIMIT 19 OFFSET 0; -- limit offset
	-- 汇总行数据查询
	SELECT '汇总' AS DATE -- columnTotal
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income_tb) AS income_tb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t;
	-- 总行数查询
	SELECT COUNT(DISTINCT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id) AS cnt -- groupsOuterLayer
	FROM (子查询sql) AS t;
	*/

	// 时间聚合维度
	columnsTotal = append(columnsTotal, "'汇总' as date")
	hbStr := "DATE(DATE_ADD(date,INTERVAL " + strconv.Itoa(params.DaysOfHb) + " DAY))"
	tbStr := "DATE(DATE_ADD(date,INTERVAL 1 MONTH))"
	if params.GroupType == "w" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%xW%v') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%xW%v') AS date")
		columnsTb = append(columnsTb, "DATE_FORMAT("+tbStr+", '%xW%v') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%xW%v') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%xW%v')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%xW%v')")
		groupsTb = append(groupsTb, "DATE_FORMAT("+tbStr+", '%xW%v')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%xW%v')")
	} else if params.GroupType == "m" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%Y-%m') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%Y-%m') AS date")
		columnsTb = append(columnsTb, "DATE_FORMAT("+tbStr+", '%Y-%m') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%Y-%m') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%Y-%m')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%Y-%m')")
		groupsTb = append(groupsTb, "DATE_FORMAT("+tbStr+", '%Y-%m')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%Y-%m')")
	} else if params.GroupType == "h" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groups = append(groups, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00')")
		if params.IsRealTimeQuery {
			// 固定加一小时
			columnsHb = append(columnsHb, "CONCAT(date,' ',IF(hour<10,'0',''),hour,':00:00') + INTERVAL 1 HOUR AS date")
			groupsHb = append(groupsHb, "CONCAT(date,' ',IF(hour<10,'0',''),hour,':00:00') + INTERVAL 1 HOUR")
		} else {
			columnsHb = append(columnsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
			groupsHb = append(groupsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")
		}
		columnsTb = append(columnsTb, "CONCAT("+tbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groupsTb = append(groupsTb, "CONCAT("+tbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")

		// 分小时的汇总行计算需要特殊逻辑
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	} else {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "date")
		columnsHb = append(columnsHb, hbStr+" AS date")
		columnsTb = append(columnsTb, tbStr+" AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groups = append(groups, "date")
		groupsHb = append(groupsHb, "date")
		groupsTb = append(groupsTb, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	}
	groupsOuterLayer = append(groupsOuterLayer, "date")
	columnsAccumulateInner = append(columnsAccumulateInner, columnsAccumulateArr...)
	groupsAccumulateInner = append(groupsAccumulateInner, columnsAccumulateArr...)

	// 用户定制聚合维度 (group by)
	columns = append(columns, params.GroupBy...)
	columnsHb = append(columnsHb, params.GroupBy...)
	columnsTb = append(columnsTb, params.GroupBy...)
	columnsOuterLayer = append(columnsOuterLayer, params.GroupBy...)
	groups = append(groups, params.GroupBy...)
	groupsHb = append(groupsHb, params.GroupBy...)
	groupsTb = append(groupsTb, params.GroupBy...)
	groupsOuterLayer = append(groupsOuterLayer, params.GroupBy...)

	// 普通指标
	kpiArr := []string{"media_cost", "show_count", "click_count",
		"media_active_count", "media_convert_count", "media_first_pay_count",
		"active_count", "new_pay_count", "active_pay_count", "first_income"}
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
		if kpi == "media_cost" || kpi == "first_income" {
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0.0 AS "+kpi)
		} else {
			kpisHb = append(kpisHb, "0 AS "+kpi)
			kpisTb = append(kpisTb, "0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0 AS "+kpi)
		}
	}

	// 同环比指标
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost) as cost")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_hb) as cost_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_tb) as cost_tb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income) as income")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income_hb) as income_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income_tb) as income_tb")
	//实际消耗=(媒体消耗-赠款reward_cost-共享赠款shared_wallet_cost)/(1+返点比例2%)
	mediaCostSql := "SUM(media_cost)"
	rewardCostSql := "SUM(reward_cost)"
	sharedWalletCostSql := "SUM(shared_wallet_cost)"
	//账户返点比例先写死0.02, 后续等数据库实时处理好了, 再使用数据库的
	mediaRebateRateSql := "0.02" //"MAX(media_rebate_rate)"
	costSql := "(" + mediaCostSql + "-" + rewardCostSql + "-" + sharedWalletCostSql + ")/(1.0+" + mediaRebateRateSql + ")"
	kpis = append(kpis, costSql+" as cost")
	kpis = append(kpis, "0.0 as cost_hb")
	kpis = append(kpis, "0.0 as cost_tb")
	kpisHb = append(kpisHb, "0.0 as cost")
	kpisHb = append(kpisHb, costSql+" as cost_hb")
	kpisHb = append(kpisHb, "0.0 as cost_tb")
	kpisTb = append(kpisTb, "0.0 as cost")
	kpisTb = append(kpisTb, "0.0 as cost_hb")
	kpisTb = append(kpisTb, costSql+" as cost_tb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_tb")

	//实际收入
	kpis = append(kpis, "SUM(income) as income")
	kpis = append(kpis, "0.0 as income_hb")
	kpis = append(kpis, "0.0 as income_tb")
	kpisHb = append(kpisHb, "0.0 as income")
	kpisHb = append(kpisHb, "SUM(income) as income_hb")
	kpisHb = append(kpisHb, "0.0 as income_tb")
	kpisTb = append(kpisTb, "0.0 as income")
	kpisTb = append(kpisTb, "0.0 as income_hb")
	kpisTb = append(kpisTb, "SUM(income) as income_tb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income_tb")

	//累计指标的, 小时的直接取, 日周天 的 要取当天的最早有消费的小时的数据
	kpiArr = []string{"new_sum_income", "income2", "income3", "income4", "income5", "income6", "income7"}
	kpisHourTotal = append(kpisHourTotal, kpis...)
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		if params.GroupType == "h" {
			kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisHourTotal = append(kpisHourTotal, "0.0 AS "+kpi) //分小时汇总行的累计指标需要特殊处理
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		} else { //非小时的日周天独立查询
			kpis = append(kpis, "0.0 AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		}
	}

	// 最外层计算指标排序的，需要特殊处理
	var kpi string
	//{Label: "点击率", Prop: "click_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(click_count)/SUM(show_count), 0) AS click_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "点击成本", Prop: "click_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(cost)/SUM(click_count), 0) AS click_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "千展成本", Prop: "show_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(cost)/SUM(show_count), 0) AS show_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活成本", Prop: "media_active_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(media_active_count)>0, SUM(cost)/SUM(media_active_count), 0) AS media_active_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活率", Prop: "media_active_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(media_active_count)/SUM(click_count), 0) AS media_active_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "实际ROI", Prop: "roi", Format: "rate", SortAble: true, IsDefault: true},
	kpi = "IF(SUM(cost)>0, SUM(income)/SUM(cost), 0) AS roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "首日新增ROI", Prop: "first_roi", Format: "rate", SortAble: true},
	kpi = "IF(SUM(cost)>0, SUM(first_income)/SUM(cost), 0) AS first_roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)

	// 查询条件 (where)
	var filterStr string
	if len(params.Media) > 0 {
		filterStr = "media IN ('" + strings.Join(params.Media, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.Region) > 0 {
		filterStr = "region IN ('" + strings.Join(params.Region, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.PayType) > 0 {
		filterStr = "pay_type IN ('" + strings.Join(params.PayType, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AppName) > 0 {
		filterStr = "app_name IN ('" + strings.Join(params.AppName, "','") + "')"
		where = append(where, filterStr)
	}
	if params.BookID != "" {
		bookId, _ := strconv.Atoi(params.BookID)
		filterStr = "book_id=" + strconv.Itoa(bookId)
		where = append(where, filterStr)
	}
	if len(params.BookNames) > 0 {
		filterStr = "book_name IN  ('" + strings.Join(params.BookNames, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.OptimizerName) > 0 {
		filterStr = "optimizer_nickname IN ('" + strings.Join(params.OptimizerName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AccountID) > 0 {
		filterStr = "account_id IN ('" + strings.Join(params.AccountID, "','") + "')"
		where = append(where, filterStr)
	}
	id1, _ := strconv.Atoi(params.ProjectID)
	if id1 > 0 {
		filterStr = "project_id=" + strconv.Itoa(id1)
		where = append(where, filterStr)
	}
	id2, _ := strconv.Atoi(params.PromotionID)
	if id2 > 0 {
		filterStr = "promotion_id=" + strconv.Itoa(id2)
		where = append(where, filterStr)
	}
	id3, _ := strconv.Atoi(params.MidID)
	if id3 > 0 {
		filterStr = "mid_id=" + strconv.Itoa(id3)
		where = append(where, filterStr)
	}

	whereHb = append(whereHb, where...)
	whereTb = append(whereTb, where...)

	if params.StartDate == params.EndDate {
		where = append(where, "date='"+params.StartDate+"'")
		whereTb = append(whereTb, "date='"+params.StartDateTb+"'")
		if params.IsRealTimeQuery {
			whereHb = append(whereHb, "((date='"+params.StartDate+"' AND hour <= 23) OR (date='"+params.StartDateHb+"' AND hour=23))")
		} else {
			whereHb = append(whereHb, "date='"+params.StartDateHb+"'")
		}
	} else {
		where = append(where, "date>='"+params.StartDate+"' AND date<='"+params.EndDate+"'")
		whereHb = append(whereHb, "date>='"+params.StartDateHb+"' AND date<='"+params.EndDateHb+"'")
		whereTb = append(whereTb, "date>='"+params.StartDateTb+"' AND date<='"+params.EndDateTb+"'")
	}

	// 排序 (sort)
	if len(params.Sorts) == 0 {
		params.Sorts = append(params.Sorts,
			common.Sort{Key: "date", Order: "asc"},
			common.Sort{Key: "cost", Order: "desc"},
		)
	}
	for _, sort := range params.Sorts {
		sorts = append(sorts, fmt.Sprintf("%s %s", sort.Key, sort.Order))
	}
	//子查询构造
	baseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columns, ",")+","+strings.Join(kpis, ","), strings.Join(where, " AND "), strings.Join(groups, ","))
	var hbBaseSql string
	if params.IsRealTimeQuery { // 实时查询上一小时也是今天数据
		hbBaseSql = getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsHb, ",")+","+strings.Join(kpisHb, ","), strings.Join(whereHb, " AND "), strings.Join(groupsHb, ","))
	} else {
		hbBaseSql = " SELECT " + strings.Join(columnsHb, ",") + "," + strings.Join(kpisHb, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(whereHb, " AND ") +
			" GROUP BY " + strings.Join(groupsHb, ",")
	}
	subSql := "SELECT *" +
		" FROM (" + baseSql + ") AS u" +
		" UNION ALL" +
		hbBaseSql +
		" UNION ALL" +
		" SELECT " + strings.Join(columnsTb, ",") + "," + strings.Join(kpisTb, ",") +
		" FROM " + roiTable +
		" WHERE " + strings.Join(whereTb, " AND ") +
		" GROUP BY " + strings.Join(groupsTb, ",")
	if params.GroupType != "h" {
		hBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsAccumulateInner, ",")+","+strings.Join(kpisAccumulateInner, ","), strings.Join(where, " AND "), strings.Join(groupsAccumulateInner, ","))
		subSql += " UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			" SELECT *" +
			" FROM (" + hBaseSql + ") AS hu" +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}

	// 分页明细数据查询
	var res []repo.ReportDataViewEntity
	sql = "SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t" +
		" GROUP BY " + strings.Join(groupsOuterLayer, ",") +
		" ORDER BY " + strings.Join(sorts, ",")
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	// 计算指标处理
	for i, row := range res {
		res[i] = *row.Calculate()
		if params.GroupType == "h" {
			res[i].Date = row.Date[0:10] + " " + row.Date[11:19]
		} else if params.GroupType == "d" {
			res[i].Date = row.Date[0:10]
		}
	}

	// 汇总行数据查询
	if params.GroupType == "h" {
		//子查询构造 - 小时维度特殊处理
		nBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columns, ",")+","+strings.Join(kpisHourTotal, ","), strings.Join(where, " AND "), strings.Join(groups, ","))
		nhBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsAccumulateInner, ",")+","+strings.Join(kpisAccumulateInner, ","), strings.Join(where, " AND "), strings.Join(groupsAccumulateInner, ","))
		subSql = "SELECT *" +
			" FROM (" + nBaseSql + ") AS nu" +
			" UNION ALL" +
			hbBaseSql +
			" UNION ALL" +
			" SELECT " + strings.Join(columnsTb, ",") + "," + strings.Join(kpisTb, ",") +
			" FROM " + roiTable +
			" WHERE " + strings.Join(whereTb, " AND ") +
			" GROUP BY " + strings.Join(groupsTb, ",") +
			" UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			" SELECT *" +
			" FROM (" + nhBaseSql + ") AS nhu" +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}
	var countRow repo.ReportDataViewEntity
	sql = "SELECT " + strings.Join(columnsTotal, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t"

	err = db.Raw(sql).Scan(&countRow).Error
	if err != nil {
		return nil, err
	}
	//拼接返回列表行
	var list []repo.ReportDataViewEntity
	if countRow.Date != "" {
		// 计算指标处理
		countRow.Calculate()
		list = append(list, countRow)
	}
	list = append(list, res...)

	// 格式化数据
	for i, row := range list {
		list[i].Media = utils.HtmlEncode(row.Media)
		list[i].Region = utils.HtmlEncode(row.Region)
		if val, ok := roidto.PayTypeMapping[row.PayType]; ok {
			list[i].PayType = val
		}
		list[i].AppID = utils.HtmlEncode(row.AppID)
		list[i].AppName = utils.HtmlEncode(row.AppName)
		list[i].BookName = utils.HtmlEncode(row.BookName)
		list[i].OptimizerNickname = utils.HtmlEncode(row.OptimizerNickname)
		list[i].AccountID = utils.HtmlEncode(row.AccountID)
		list[i].AccountName = utils.HtmlEncode(row.AccountName)
		list[i].ProjectID = utils.HtmlEncode(row.ProjectID)
		list[i].ProjectName = utils.HtmlEncode(row.ProjectName)
		list[i].PromotionID = utils.HtmlEncode(row.PromotionID)
		list[i].PromotionName = utils.HtmlEncode(row.PromotionName)
		list[i].MidID = utils.HtmlEncode(row.MidID)
		list[i].MidType = utils.HtmlEncode(row.MidType)
	}

	result = &list
	return
}

func addDateGroup(groupType, start string) (dateGroup, dateColumn, finalDateColumn, finalJoin string) {
	switch groupType {
	case "h":
		dateGroup = "date(date), hour "
		dateColumn = "date(date) as date, hour "
		finalDateColumn = "CONCAT(date(base.date),' ', case when base.hour < 10 then concat('0',base.hour,':00:00') else concat(base.hour,':00:00') end ) as date, base.hour"
		finalJoin = "date, hour"
	case "d":
		dateGroup = "date(date)"
		dateColumn = "date(date) as date"
		finalDateColumn = "substr(base.date, 1, 11) as date"
		finalJoin = "date"
	case "w":
		dateGroup = "week(date, 1)"
		dateColumn = "week(date, 1) as date"
		finalDateColumn = "CONCAT(SUBSTR('" + start + "', 1,4),\"w\",base.date) as date"
		finalJoin = "date"
	case "m":
		dateGroup = "month(date)"
		dateColumn = "month(date) as date"
		finalDateColumn = "CONCAT(SUBSTR('" + start + "', 1,4),'-',base.date) as date"
		finalJoin = "date"
	}
	return
}

func tb2HbTime(groupType string, start, end string) (tbStart, tbEnd, tbDateGroup, tbDateColumn, hbStart, hbEnd, hbDateGroup, hbDateColumn string) {
	startTime, _ := time.ParseInLocation(time.DateOnly, start, time.UTC)
	EndTime, _ := time.ParseInLocation(time.DateOnly, end, time.UTC)
	switch groupType {
	case "h":
		tbStart = startTime.Add(-86400 * time.Second).Format(time.DateOnly)
		tbEnd = EndTime.Add(-86400 * time.Second).Format(time.DateOnly)
		tbDateGroup = "date(DATE_ADD(date,INTERVAL 1 DAY)), hour"
		tbDateColumn = "date(DATE_ADD(date,INTERVAL 1 DAY)) as date, hour"
		hbStart = start
		hbEnd = end
		hbDateGroup = "date(date), hour"
		hbDateColumn = "date(date) as date, hour+1 as hour"
	case "d":
		tbStart = startTime.AddDate(0, -1, 0).Format(time.DateOnly)
		tbEnd = EndTime.AddDate(0, -1, 0).Format(time.DateOnly)
		tbDateGroup = "date(DATE_ADD(date,INTERVAL 1 MONTH))"
		tbDateColumn = "date(DATE_ADD(date,INTERVAL 1 MONTH)) as date"
		hbStart = startTime.Add(-86400 * time.Second).Format(time.DateOnly)
		hbEnd = EndTime.Add(-86400 * time.Second).Format(time.DateOnly)
		hbDateGroup = "date(DATE_ADD(date,INTERVAL 1 DAY))"
		hbDateColumn = "date(DATE_ADD(date,INTERVAL 1 DAY)) as date"
	case "w":
		tbStart = startTime.AddDate(-1, 0, 0).Format(time.DateOnly)
		tbEnd = EndTime.AddDate(-1, 0, 0).Format(time.DateOnly)
		tbDateGroup = "week(DATE_ADD(date,INTERVAL 1 YEAR), 1)"
		tbDateColumn = "week(DATE_ADD(date,INTERVAL 1 YEAR), 1) as date"
		hbStart = startTime.AddDate(0, 0, -7).Format(time.DateOnly)
		hbEnd = EndTime.AddDate(0, 0, -7).Format(time.DateOnly)
		hbDateGroup = "week(DATE_ADD(date,INTERVAL 1 WEEK), 1)"
		hbDateColumn = "week(DATE_ADD(date,INTERVAL 1 WEEK), 1) as date"
	case "m":
		tbStart = startTime.AddDate(-1, 0, 0).Format(time.DateOnly)
		tbEnd = EndTime.AddDate(-1, 0, 0).Format(time.DateOnly)
		tbDateGroup = "month(DATE_ADD(date,INTERVAL 1 YEAR))"
		tbDateColumn = "month(DATE_ADD(date,INTERVAL 1 YEAR)) as date"
		hbStart = startTime.AddDate(0, -1, 0).Format(time.DateOnly)
		hbEnd = EndTime.AddDate(0, -1, 0).Format(time.DateOnly)
		hbDateGroup = "month(DATE_ADD(date,INTERVAL 1 MONTH))"
		hbDateColumn = "month(DATE_ADD(date,INTERVAL 1 MONTH)) as date"
	}
	return
}

func unionGroup(dateGroup, groupBy string) (group string) {
	if len(groupBy) > 0 {
		group = dateGroup + "," + groupBy
	} else {
		group = dateGroup
	}
	return
}

func isBill(groupBy []string, groupType string) bool {
	if groupType == "d" && len(groupBy) == 0 {
		return true
	}
	if groupType != "h" {
		if len(groupBy) == 1 && utils.InArray("account_name", groupBy) {
			return true
		}
		if len(groupBy) == 1 && utils.InArray("media", groupBy) {
			return true
		}
		if len(groupBy) == 1 && utils.InArray("user_id", groupBy) {
			return true
		}
		if len(groupBy) == 2 && utils.InArray("media", groupBy) && utils.InArray("account_name", groupBy) {
			return true
		}
		if len(groupBy) == 2 && utils.InArray("media", groupBy) && utils.InArray("user_id", groupBy) {
			return true
		}
		if len(groupBy) == 2 && utils.InArray("user_id", groupBy) && utils.InArray("account_name", groupBy) {
			return true
		}
		if len(groupBy) == 3 && utils.InArray("media", groupBy) && utils.InArray("account_name", groupBy) && utils.InArray("user_id", groupBy) {
			return true
		}
	}
	return false
}

func (d *ReportDataDao) ProjectReportDataNew(params *roidto.ReportDataReq) (*common.Paginator, error) {
	db := dorisdb.DorisClient()
	pagination := params.Pagination
	limit := pagination.GetLimit()
	offset := pagination.GetOffset()

	start := params.StartDate
	end := params.EndDate
	var baseBillSql, tbBillSql, hbBillSql string

	// 查询条件
	whereConditionStr := whereCondition(params)
	// base 查询条件+时间
	baseTimeSql := " WHERE date(date) BETWEEN '" + start + "' AND '" + end + "' AND data_type = 1 AND " + whereConditionStr + " "
	// 历史数据查询
	baseHistorySql := "SELECT date(date) as date, `hour`, account_id, account_name, project_id, project_name, media, pay_type, app_name, book_id, book_name, optimizer_id, optimizer_nickname, delivery_product, region, media_cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, copyright_owner FROM roi_project_hourly "
	// 当日数据
	BaseTodaySql := "SELECT date(date) as date, `hour`, account_id, account_name, project_id, project_name, media, pay_type, app_name, book_id, book_name, optimizer_id, optimizer_nickname, delivery_product, region, media_cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, copyright_owner FROM roi_project_hourly_today "
	// 管家查询
	oauthSql := "SELECT advertiser_id, oa.user_id, user_name FROM ( SELECT advertiser_id, user_id, oauth_id FROM oauth_account) oa LEFT JOIN ( SELECT oauth_id, cast(ext->'user_name' as char) as user_name FROM oauth ) oh ON oa.oauth_id = oh.oauth_id "
	// 计算指标
	calculateColumn := "sum(media_cost) as media_cost, sum(show_count) as show_count, sum(click_count) as click_count, sum(income) as income, sum(active_count) as active_count, sum(new_pay_count) as new_pay_count, sum(active_pay_count) as active_pay_count, sum(first_income) as first_income, sum(media_active_count) as media_active_count, sum(media_convert_count) as media_convert_count, sum(media_first_pay_count) as media_first_pay_count "
	// 历史和今日 UNION
	baseUnion := baseHistorySql + baseTimeSql + " UNION " + BaseTodaySql + baseTimeSql
	// 日期聚合条件
	dateGroup, dateColumn, finalDateColumn, finalJoin := addDateGroup(params.GroupType, start)
	// group 条件
	groupBy := strings.Join(appendFiled(params.GroupBy), ",")
	baseGroup := unionGroup(dateGroup, groupBy)
	selectColum := unionGroup(dateColumn, groupBy)
	baseAddUser := "SELECT " + selectColum + "," + calculateColumn + " FROM ( " + baseUnion + " ) base LEFT JOIN ( " + oauthSql + " ) oa ON base.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + baseGroup

	tbStart, tbEnd, tbDateGroup, tbDateColumn, hbStart, hbEnd, hbDateGroup, hbDateColumn := tb2HbTime(params.GroupType, start, end)
	tbCalculateColumn := "sum(media_cost) as tb_cost, sum(income) as tb_income, sum(first_income) as tb_first_income, sum(income)/sum(media_cost/1.02) as tb_roi"
	hbCalculateColumn := "sum(media_cost) as hb_cost, sum(income) as  hb_income, sum(first_income) as  hb_first_income, sum(income)/sum(media_cost/1.02) as hb_roi"
	// 同比指标
	tbTimeSql := " WHERE date(date) BETWEEN '" + tbStart + "' AND '" + tbEnd + "' AND data_type = 1 AND " + whereConditionStr + " "
	tbUnion := baseHistorySql + tbTimeSql + " UNION " + BaseTodaySql + tbTimeSql
	tbGroup := unionGroup(tbDateGroup, groupBy)
	tbSelectColumn := unionGroup(tbDateColumn, groupBy)
	tbAddUser := "SELECT " + tbSelectColumn + "," + tbCalculateColumn + " FROM ( " + tbUnion + " ) base LEFT JOIN ( " + oauthSql + " ) oa ON base.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + tbGroup

	// 环比指标
	hbTimeSql := " WHERE date(date) BETWEEN '" + hbStart + "' AND '" + hbEnd + "' AND data_type = 1 AND " + whereConditionStr + " "
	hbUnion := baseHistorySql + hbTimeSql + " UNION " + BaseTodaySql + hbTimeSql
	hbGroup := unionGroup(hbDateGroup, groupBy)
	hbSelectColumn := unionGroup(hbDateColumn, groupBy)
	hbAddUser := "SELECT " + hbSelectColumn + "," + hbCalculateColumn + " FROM ( " + hbUnion + " ) base LEFT JOIN ( " + oauthSql + " ) oa ON base.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + hbGroup

	var final string
	// 如果聚合条件包含账单
	if isBill(params.GroupBy, params.GroupType) {
		billCalculateColumn := "sum(reward_cost) as reward_cost, sum(shared_wallet_cost) as shared_wallet_cost "
		billGroupBy := strings.Join(billGroup(params.GroupBy), ",")
		baseBillGroup := unionGroup(dateGroup, billGroupBy)
		hbBillGroup := unionGroup(hbDateGroup, billGroupBy)
		tbBillGroup := unionGroup(tbDateGroup, billGroupBy)
		// 账单
		baseBillTimeSql := "WHERE date(date) BETWEEN '" + start + "' AND '" + end + "' AND data_type = 2 "
		hbBillTimeSql := "WHERE date(date) BETWEEN '" + hbStart + "' AND '" + hbEnd + "' AND data_type = 2 "
		tbBillTimeSql := "WHERE date(date) BETWEEN '" + tbStart + "' AND '" + tbEnd + "' AND data_type = 2 "
		if len(groupBy) > 0 {
			baseBillSql = "SELECT " + dateColumn + "," + billGroupBy + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + baseBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + baseBillGroup
			hbBillSql = "SELECT " + hbDateColumn + "," + billGroupBy + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + hbBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + hbBillGroup
			tbBillSql = "SELECT " + tbDateColumn + "," + billGroupBy + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + tbBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + tbBillGroup
		} else {
			baseBillSql = "SELECT " + dateColumn + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + baseBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + baseBillGroup
			hbBillSql = "SELECT " + hbDateColumn + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + hbBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + hbBillGroup
			tbBillSql = "SELECT " + tbDateColumn + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + tbBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + tbBillGroup
		}

		var selectColumn, finalSelectColumn string
		if len(groupBy) > 0 {
			selectColumn = "b.date,"
			finalSelectColumn = finalDateColumn + ","
		} else {
			selectColumn = "b.date"
			finalSelectColumn = finalDateColumn
		}
		joinOn := "b.date = bb.date "
		finalTbJoinOn := "base.date = tb.date"
		finalHbJoinOn := "base.date = hb.date"
		if len(groupBy) > 0 {
			for k, v := range strings.Split(groupBy, ",") {
				if k == len(strings.Split(groupBy, ","))-1 {
					selectColumn += " b." + v
					finalSelectColumn += " base." + v
				} else {
					selectColumn += " b." + v + ","
					finalSelectColumn += " base." + v + ","
				}
			}
		}
		if len(billGroupBy) > 0 {
			for _, v := range strings.Split(billGroupBy, ",") {
				joinOn += " AND " + "b." + v + " = " + "bb." + v
				finalTbJoinOn += " AND " + "base." + v + " = " + "tb." + v
				finalHbJoinOn += " AND " + "base." + v + " = " + "hb." + v
			}
		}
		selectFinal := "media_cost, cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, click_rate, click_cost, show_cost, media_active_cost, media_active_rate, roi, first_roi,  (cost-hb_cost)/hb_cost as cost_hb_ratio, (cost-tb_cost)/tb_cost as cost_tb_ratio, (roi-hb_roi)/hb_roi as roi_hb, (roi-tb_roi/tb_roi) as roi_tb, (income-hb_income)/hb_income as income_hb_ratio, (income-tb_income)/tb_income as income_tb_ratio, income-cost as profit, reward_cost, shared_wallet_cost "
		baseHasBill := "media_cost, (media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02 as cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, round(click_count/show_count) as click_rate, round((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02/click_count,2) as click_cost, round((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02/show_count*1000, 2) as show_cost, round((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02/media_active_count, 2) as media_active_cost, round(media_active_count/click_count, 2) as media_active_rate, round(income/((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02), 2) as roi, round(first_income/((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02), 2) as first_roi, case when reward_cost is null then 0 else reward_cost end as reward_cost, case when shared_wallet_cost is null then 0 else shared_wallet_cost end as shared_wallet_cost "
		baseFinalSql := "SELECT " + selectColumn + "," + baseHasBill + " FROM ( " + baseAddUser + " ) b LEFT JOIN ( " + baseBillSql + " ) bb ON " + joinOn
		hbHasBill := "(hb_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02 as hb_cost, case when hb_income is null then 0 else hb_income end as hb_income, hb_first_income, case when hb_income is null then 0 else hb_income end/((hb_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02) as hb_roi "
		tbHasBill := "(tb_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02 as tb_cost, case when tb_income is null then 0 else tb_income end as tb_income, tb_first_income, case when tb_income is null then 0 else tb_income end/((tb_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02) as tb_roi "
		hbFinalSql := "SELECT " + selectColumn + "," + hbHasBill + " FROM ( " + hbAddUser + ") b LEFT JOIN ( " + hbBillSql + " ) bb ON " + joinOn
		tbFinalSql := "SELECT " + selectColumn + "," + tbHasBill + " FROM ( " + tbAddUser + ") b LEFT JOIN ( " + tbBillSql + " ) bb ON " + joinOn
		final = "SELECT " + finalSelectColumn + "," + selectFinal + " FROM ( " + baseFinalSql + " ) base LEFT JOIN (" + hbFinalSql + ") hb ON " + finalHbJoinOn + " LEFT JOIN (" + tbFinalSql + ") tb ON " + finalTbJoinOn
	} else {
		selectFinal := "media_cost, (media_cost/1.02) as cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, round(click_count/show_count) as click_rate, round((media_cost/1.02)/click_count,2) as click_cost, round((media_cost/1.02)/show_count*1000, 2) as show_cost, round((media_cost/1.02)/media_active_count, 2) as media_active_cost, round(media_active_count/click_count, 2) as media_active_rate, round(income/(media_cost/1.02), 2) as roi, round(first_income/(media_cost/1.02), 2) as first_roi,  (media_cost/1.02-hb_cost/1.02)/hb_cost/1.02 as cost_hb_ratio, (media_cost/1.02-tb_cost/1.02)/tb_cost/1.02 as cost_tb_ratio, income/media_cost/1.02-hb_roi/hb_roi as roi_hb, (income/media_cost/1.02-tb_roi/tb_roi) as roi_tb, (income-hb_income)/hb_income as income_hb_ratio, (income-tb_income)/tb_income as income_tb_ratio, income-(media_cost/1.02) as profit, '0' as reward_cost, '0' as shared_wallet_cost "
		finalSelectColumn := ""
		finalTbJoinOn := ""
		finalHbJoinOn := ""
		if len(groupBy) > 0 {
			for k, v := range strings.Split(groupBy, ",") {
				if k == len(strings.Split(groupBy, ","))-1 {
					finalSelectColumn += " base." + v
				} else {
					finalSelectColumn += " base." + v + ","
				}
			}
			for k, v := range strings.Split(finalJoin+","+groupBy, ",") {
				if k == len(strings.Split(finalJoin+","+groupBy, ","))-1 {
					finalTbJoinOn += " base." + v + " = " + "tb." + v
					finalHbJoinOn += " base." + v + " = " + "hb." + v
				} else {
					finalTbJoinOn += " base." + v + " = " + "tb." + v + " AND "
					finalHbJoinOn += " base." + v + " = " + "hb." + v + " AND "
				}

			}
		} else {
			for k, v := range strings.Split(finalJoin, ",") {
				if k == len(strings.Split(finalJoin, ","))-1 {
					finalTbJoinOn += " base." + v + " = " + "tb." + v
					finalHbJoinOn += " base." + v + " = " + "hb." + v
				} else {
					finalTbJoinOn += " base." + v + " = " + "tb." + v + " AND "
					finalHbJoinOn += " base." + v + " = " + "hb." + v + " AND "
				}

			}
		}
		selectC := unionGroup(finalDateColumn, finalSelectColumn)
		final = "SELECT " + selectC + "," + selectFinal + " FROM ( " + baseAddUser + " ) base LEFT JOIN ( " + tbAddUser + " ) tb ON " + finalTbJoinOn + " LEFT JOIN ( " + hbAddUser + " ) hb ON " + finalHbJoinOn
	}
	orderBy := ""
	// 排序 (sort)
	if len(params.Sorts) == 0 {
		params.Sorts = append(params.Sorts,
			common.Sort{Key: "date", Order: "asc"},
			common.Sort{Key: "cost", Order: "desc"},
		)
	}
	for k, sort := range params.Sorts {
		if k == len(params.Sorts)-1 {
			orderBy = sort.Key + " " + sort.Order
		} else {
			orderBy = sort.Key + " " + sort.Order + ","
		}
	}
	sql := final + " ORDER BY " + orderBy + " LIMIT " + strconv.FormatInt(limit, 10) + " OFFSET " + strconv.FormatInt(offset, 10)

	var list []repo.ProjectReportDataViewEntity
	err := db.Raw(sql).Scan(&list).Error
	if err != nil {
		return nil, err
	}
	var total int64
	type Dist struct {
		Cnt int64 `gorm:"column:cnt"`
	}
	var dist Dist
	totalSql := "SELECT count(*) as cnt FROM ( " + final + " ) a"
	err = db.Raw(totalSql).Scan(&dist).Error
	if err != nil {
		return nil, err
	}
	total = dist.Cnt
	var count []repo.ProjectReportDataViewEntity
	countField := "SELECT '汇总' as date, round(sum(media_cost), 2) as media_cost, round(sum(cost), 2) as cost, sum(show_count) as show_count, sum(click_count) as click_count, round(sum(income), 2) as income, sum(active_count) as active_count, sum(new_pay_count) as new_pay_count, sum(active_pay_count) as active_pay_count, round(sum(first_income), 2) as first_income, sum(media_active_count) as media_active_count, sum(media_convert_count) as media_convert_count, sum(media_first_pay_count) as media_first_pay_count, round(sum(click_count)/sum(show_count), 2) as click_rate, round(sum(cost)/sum(click_count),2) as click_cost, round(sum(cost)/sum(show_count)*1000, 2) as show_cost, round(sum(cost)/sum(media_active_count), 2) as media_active_cost, round(sum(media_active_count)/sum(click_count), 2) as media_active_rate, round(sum(income)/sum(cost), 2) as roi, round(sum(first_income)/sum(cost), 2) as first_roi, sum(income)-sum(cost) as profit, sum(reward_cost) as reward_cost, sum(shared_wallet_cost) as shared_wallet_cost "
	countSql := countField + " FROM ( " + final + " ) a"
	err = db.Raw(countSql).Scan(&count).Error
	if err != nil {
		return nil, err
	}
	count = append(count, list...)
	paginator := common.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, count)
	return &paginator, nil
}

func (d *ReportDataDao) ProjectExportDataNew(params *roidto.ReportDataReq) ([]repo.ProjectReportDataViewEntity, error) {
	db := dorisdb.DorisClient()
	start := params.StartDate
	end := params.EndDate
	var baseBillSql, tbBillSql, hbBillSql string

	// 查询条件
	whereConditionStr := whereCondition(params)
	// base 查询条件+时间
	baseTimeSql := " WHERE date(date) BETWEEN '" + start + "' AND '" + end + "' AND data_type = 1 AND " + whereConditionStr + " "
	// 历史数据查询
	baseHistorySql := "SELECT date(date) as date, `hour`, account_id, account_name, project_id, project_name, media, pay_type, app_name, book_id, book_name, optimizer_id, optimizer_nickname, delivery_product, region, media_cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, copyright_owner FROM roi_project_hourly "
	// 当日数据
	BaseTodaySql := "SELECT date(date) as date, `hour`, account_id, account_name, project_id, project_name, media, pay_type, app_name, book_id, book_name, optimizer_id, optimizer_nickname, delivery_product, region, media_cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, copyright_owner FROM roi_project_hourly_today "
	// 管家查询
	oauthSql := "SELECT advertiser_id, oa.user_id, user_name FROM ( SELECT advertiser_id, user_id, oauth_id FROM oauth_account) oa LEFT JOIN ( SELECT oauth_id, cast(ext->'user_name' as char) as user_name FROM oauth ) oh ON oa.oauth_id = oh.oauth_id "
	// 计算指标
	calculateColumn := "sum(media_cost) as media_cost, sum(show_count) as show_count, sum(click_count) as click_count, sum(income) as income, sum(active_count) as active_count, sum(new_pay_count) as new_pay_count, sum(active_pay_count) as active_pay_count, sum(first_income) as first_income, sum(media_active_count) as media_active_count, sum(media_convert_count) as media_convert_count, sum(media_first_pay_count) as media_first_pay_count "
	// 历史和今日 UNION
	baseUnion := baseHistorySql + baseTimeSql + " UNION " + BaseTodaySql + baseTimeSql
	// 日期聚合条件
	dateGroup, dateColumn, finalDateColumn, finalJoin := addDateGroup(params.GroupType, start)
	// group 条件
	groupBy := strings.Join(appendFiled(params.GroupBy), ",")
	baseGroup := unionGroup(dateGroup, groupBy)
	selectColum := unionGroup(dateColumn, groupBy)
	baseAddUser := "SELECT " + selectColum + "," + calculateColumn + " FROM ( " + baseUnion + " ) base LEFT JOIN ( " + oauthSql + " ) oa ON base.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + baseGroup

	tbStart, tbEnd, tbDateGroup, tbDateColumn, hbStart, hbEnd, hbDateGroup, hbDateColumn := tb2HbTime(params.GroupType, start, end)
	tbCalculateColumn := "sum(media_cost) as tb_cost, sum(income) as tb_income, sum(first_income) as tb_first_income, sum(income)/sum(media_cost/1.02) as tb_roi"
	hbCalculateColumn := "sum(media_cost) as hb_cost, sum(income) as  hb_income, sum(first_income) as  hb_first_income, sum(income)/sum(media_cost/1.02) as hb_roi"
	// 同比指标
	tbTimeSql := " WHERE date(date) BETWEEN '" + tbStart + "' AND '" + tbEnd + "' AND data_type = 1 AND " + whereConditionStr + " "
	tbUnion := baseHistorySql + tbTimeSql + " UNION " + BaseTodaySql + tbTimeSql
	tbGroup := unionGroup(tbDateGroup, groupBy)
	tbSelectColumn := unionGroup(tbDateColumn, groupBy)
	tbAddUser := "SELECT " + tbSelectColumn + "," + tbCalculateColumn + " FROM ( " + tbUnion + " ) base LEFT JOIN ( " + oauthSql + " ) oa ON base.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + tbGroup

	// 环比指标
	hbTimeSql := " WHERE date(date) BETWEEN '" + hbStart + "' AND '" + hbEnd + "' AND data_type = 1 AND " + whereConditionStr + " "
	hbUnion := baseHistorySql + hbTimeSql + " UNION " + BaseTodaySql + hbTimeSql
	hbGroup := unionGroup(hbDateGroup, groupBy)
	hbSelectColumn := unionGroup(hbDateColumn, groupBy)
	hbAddUser := "SELECT " + hbSelectColumn + "," + hbCalculateColumn + " FROM ( " + hbUnion + " ) base LEFT JOIN ( " + oauthSql + " ) oa ON base.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + hbGroup

	var final string
	// 如果聚合条件包含账单
	if isBill(params.GroupBy, params.GroupType) {
		billCalculateColumn := "sum(reward_cost) as reward_cost, sum(shared_wallet_cost) as shared_wallet_cost "
		billGroupBy := strings.Join(billGroup(params.GroupBy), ",")
		baseBillGroup := unionGroup(dateGroup, billGroupBy)
		hbBillGroup := unionGroup(hbDateGroup, billGroupBy)
		tbBillGroup := unionGroup(tbDateGroup, billGroupBy)
		// 账单
		baseBillTimeSql := "WHERE date(date) BETWEEN '" + start + "' AND '" + end + "' AND data_type = 2 "
		hbBillTimeSql := "WHERE date(date) BETWEEN '" + hbStart + "' AND '" + hbEnd + "' AND data_type = 2 "
		tbBillTimeSql := "WHERE date(date) BETWEEN '" + tbStart + "' AND '" + tbEnd + "' AND data_type = 2 "
		if len(groupBy) > 0 {
			baseBillSql = "SELECT " + dateColumn + "," + billGroupBy + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + baseBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + baseBillGroup
			hbBillSql = "SELECT " + hbDateColumn + "," + billGroupBy + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + hbBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + hbBillGroup
			tbBillSql = "SELECT " + tbDateColumn + "," + billGroupBy + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + tbBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + tbBillGroup
		} else {
			baseBillSql = "SELECT " + dateColumn + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + baseBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + baseBillGroup
			hbBillSql = "SELECT " + hbDateColumn + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + hbBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + hbBillGroup
			tbBillSql = "SELECT " + tbDateColumn + "," + billCalculateColumn + " FROM ( SELECT * FROM roi_project_hourly " + tbBillTimeSql + " ) a LEFT JOIN ( " + oauthSql + " )oa ON a.account_id = oa.advertiser_id " + userCondition(params) + " GROUP BY " + tbBillGroup
		}

		var selectColumn, finalSelectColumn string
		if len(groupBy) > 0 {
			selectColumn = "b.date,"
			finalSelectColumn = finalDateColumn + ","
		} else {
			selectColumn = "b.date"
			finalSelectColumn = finalDateColumn
		}
		joinOn := "b.date = bb.date "
		finalTbJoinOn := "base.date = tb.date"
		finalHbJoinOn := "base.date = hb.date"
		if len(groupBy) > 0 {
			for k, v := range strings.Split(groupBy, ",") {
				if k == len(strings.Split(groupBy, ","))-1 {
					selectColumn += " b." + v
					finalSelectColumn += " base." + v
				} else {
					selectColumn += " b." + v + ","
					finalSelectColumn += " base." + v + ","
				}
			}
		}
		if len(billGroupBy) > 0 {
			for _, v := range strings.Split(billGroupBy, ",") {
				joinOn += " AND " + "b." + v + " = " + "bb." + v
				finalTbJoinOn += " AND " + "base." + v + " = " + "tb." + v
				finalHbJoinOn += " AND " + "base." + v + " = " + "hb." + v
			}
		}
		selectFinal := "media_cost, (media_cost/1.02) as cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, round(click_count/show_count) as click_rate, round((media_cost/1.02)/click_count,2) as click_cost, round((media_cost/1.02)/show_count*1000, 2) as show_cost, round((media_cost/1.02)/media_active_count, 2) as media_active_cost, round(media_active_count/click_count, 2) as media_active_rate, round(income/(media_cost/1.02), 2) as roi, round(first_income/(media_cost/1.02), 2) as first_roi,  (media_cost/1.02-hb_cost/1.02)/hb_cost/1.02 as cost_hb_ratio, (media_cost/1.02-tb_cost/1.02)/tb_cost/1.02 as cost_tb_ratio, income/media_cost/1.02-hb_roi/hb_roi as roi_hb, (income/media_cost/1.02-tb_roi/tb_roi) as roi_tb, (income-hb_income)/hb_income as income_hb_ratio, (income-tb_income)/tb_income as income_tb_ratio, income-(media_cost/1.02) as profit, '0' as reward_cost, '0' as shared_wallet_cost "
		baseHasBill := "media_cost, (media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02 as cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, round(click_count/show_count) as click_rate, round((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02/click_count,2) as click_cost, round((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02/show_count*1000, 2) as show_cost, round((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02/media_active_count, 2) as media_active_cost, round(media_active_count/click_count, 2) as media_active_rate, round(income/((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02), 2) as roi, round(first_income/((media_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02), 2) as first_roi, case when reward_cost is null then 0 else reward_cost end as reward_cost, case when shared_wallet_cost is null then 0 else shared_wallet_cost end as shared_wallet_cost "
		baseFinalSql := "SELECT " + selectColumn + "," + baseHasBill + " FROM ( " + baseAddUser + " ) b LEFT JOIN ( " + baseBillSql + " ) bb ON " + joinOn
		hbHasBill := "(hb_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02 as hb_cost, case when hb_income is null then 0 else hb_income end as hb_income, hb_first_income, case when hb_income is null then 0 else hb_income end/((hb_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02) as hb_roi "
		tbHasBill := "(tb_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02 as tb_cost, case when tb_income is null then 0 else tb_income end as tb_income, tb_first_income, case when tb_income is null then 0 else tb_income end/((tb_cost- case when reward_cost is null then 0 else reward_cost end - case when shared_wallet_cost is null then 0 else shared_wallet_cost end  )/1.02) as tb_roi "
		hbFinalSql := "SELECT " + selectColumn + "," + hbHasBill + " FROM ( " + hbAddUser + ") b LEFT JOIN ( " + hbBillSql + " ) bb ON " + joinOn
		tbFinalSql := "SELECT " + selectColumn + "," + tbHasBill + " FROM ( " + tbAddUser + ") b LEFT JOIN ( " + tbBillSql + " ) bb ON " + joinOn
		final = "SELECT " + finalSelectColumn + "," + selectFinal + " FROM ( " + baseFinalSql + " ) base LEFT JOIN (" + hbFinalSql + ") hb ON " + finalHbJoinOn + " LEFT JOIN (" + tbFinalSql + ") tb ON " + finalTbJoinOn
	} else {
		selectFinal := "media_cost, (media_cost/1.02) as cost, show_count, click_count, income, active_count, new_pay_count, active_pay_count, first_income, media_active_count, media_convert_count, media_first_pay_count, round(click_count/show_count) as click_rate, round((media_cost/1.02)/click_count,2) as click_cost, round((media_cost/1.02)/show_count*1000, 2) as show_cost, round((media_cost/1.02)/media_active_count, 2) as media_active_cost, round(media_active_count/click_count, 2) as media_active_rate, round(income/(media_cost/1.02), 2) as roi, round(first_income/(media_cost/1.02), 2) as first_roi,  (media_cost/1.02-hb_cost/1.02)/hb_cost/1.02 as cost_hb_ratio, (media_cost/1.02-tb_cost/1.02)/tb_cost/1.02 as cost_tb_ratio, income/media_cost/1.02-hb_roi/hb_roi as roi_hb, (income/media_cost/1.02-tb_roi/tb_roi) as roi_tb, (income-hb_income)/hb_income as income_hb_ratio, (income-tb_income)/tb_income as income_tb_ratio, income-(media_cost/1.02) as profit, '0' as reward_cost, '0' as shared_wallet_cost "
		finalSelectColumn := ""
		finalTbJoinOn := ""
		finalHbJoinOn := ""
		if len(groupBy) > 0 {
			for k, v := range strings.Split(groupBy, ",") {
				if k == len(strings.Split(groupBy, ","))-1 {
					finalSelectColumn += " base." + v
				} else {
					finalSelectColumn += " base." + v + ","
				}
			}
			for k, v := range strings.Split(finalJoin+","+groupBy, ",") {
				if k == len(strings.Split(finalJoin+","+groupBy, ","))-1 {
					finalTbJoinOn += " base." + v + " = " + "tb." + v
					finalHbJoinOn += " base." + v + " = " + "hb." + v
				} else {
					finalTbJoinOn += " base." + v + " = " + "tb." + v + " AND "
					finalHbJoinOn += " base." + v + " = " + "hb." + v + " AND "
				}

			}
		} else {
			for k, v := range strings.Split(finalJoin, ",") {
				if k == len(strings.Split(finalJoin, ","))-1 {
					finalTbJoinOn += " base." + v + " = " + "tb." + v
					finalHbJoinOn += " base." + v + " = " + "hb." + v
				} else {
					finalTbJoinOn += " base." + v + " = " + "tb." + v + " AND "
					finalHbJoinOn += " base." + v + " = " + "hb." + v + " AND "
				}

			}
		}
		selectC := unionGroup(finalDateColumn, finalSelectColumn)
		final = "SELECT " + selectC + "," + selectFinal + " FROM ( " + baseAddUser + " ) base LEFT JOIN ( " + tbAddUser + " ) tb ON " + finalTbJoinOn + " LEFT JOIN ( " + hbAddUser + " ) hb ON " + finalHbJoinOn
	}
	orderBy := ""
	// 排序 (sort)
	if len(params.Sorts) == 0 {
		params.Sorts = append(params.Sorts,
			common.Sort{Key: "date", Order: "asc"},
			common.Sort{Key: "cost", Order: "desc"},
		)
	}
	for k, sort := range params.Sorts {
		if k == len(params.Sorts)-1 {
			orderBy = sort.Key + " " + sort.Order
		} else {
			orderBy = sort.Key + " " + sort.Order + ","
		}
	}
	sql := final + " ORDER BY " + orderBy

	var list []repo.ProjectReportDataViewEntity
	err := db.Raw(sql).Scan(&list).Error
	if err != nil {
		return nil, err
	}
	var count []repo.ProjectReportDataViewEntity
	countField := "SELECT '汇总' as date, round(sum(media_cost), 2) as media_cost, round(sum(cost), 2) as cost, sum(show_count) as show_count, sum(click_count) as click_count, round(sum(income), 2) as income, sum(active_count) as active_count, sum(new_pay_count) as new_pay_count, sum(active_pay_count) as active_pay_count, round(sum(first_income), 2) as first_income, sum(media_active_count) as media_active_count, sum(media_convert_count) as media_convert_count, sum(media_first_pay_count) as media_first_pay_count, round(sum(click_count)/sum(show_count), 2) as click_rate, round(sum(cost)/sum(click_count),2) as click_cost, round(sum(cost)/sum(show_count)*1000, 2) as show_cost, round(sum(cost)/sum(media_active_count), 2) as media_active_cost, round(sum(media_active_count)/sum(click_count), 2) as media_active_rate, round(sum(income)/sum(cost), 2) as roi, round(sum(first_income)/sum(cost), 2) as first_roi, sum(income)-sum(cost) as profit, sum(reward_cost) as reward_cost, sum(shared_wallet_cost) as shared_wallet_cost "
	countSql := countField + " FROM ( " + final + " ) a"
	err = db.Raw(countSql).Scan(&count).Error
	if err != nil {
		return nil, err
	}
	count = append(count, list...)
	return count, nil
}

func userCondition(params *roidto.ReportDataReq) (filterStr string) {
	if len(params.UserID) > 0 {
		filterStr = " WHERE user_id IN ('" + strings.Join(params.UserID, "','") + "')"
	}
	return
}

func billGroup(groupBy []string) (newGroup []string) {
	if utils.InArray("account_name", groupBy) {
		newGroup = append(newGroup, "account_id")
	}
	if utils.InArray("media", groupBy) {
		newGroup = append(newGroup, "media")
	}
	if utils.InArray("user_id", groupBy) {
		newGroup = append(newGroup, "user_id")
	}
	return
}

func appendFiled(groupBy []string) (newGroup []string) {
	newGroup = append(groupBy)
	if utils.InArray("account_name", groupBy) {
		newGroup = append(newGroup, "account_id")
	}
	if utils.InArray("book_name", groupBy) {
		newGroup = append(newGroup, "book_id")
	}
	if utils.InArray("project_id", groupBy) {
		newGroup = append(newGroup, "project_name")
	}
	if utils.InArray("optimizer_nickname", groupBy) {
		newGroup = append(newGroup, "optimizer_id")
	}
	if utils.InArray("user_id", groupBy) {
		newGroup = append(newGroup, "user_name")
	}
	return
}

func groupTypeConvert(groupType, start, end string) (baseGroup, extFiled, ext, extT, startTb, endTb, tbExt, startHb, endHb, hbExt string) {
	tbTimeStart, _ := time.Parse(time.DateOnly, start)
	tbTimeEnd, _ := time.Parse(time.DateOnly, end)
	switch groupType {
	case "h":
		baseGroup = "date(date), hour "
		ext = "date(date) as date, hour "
		extT = "date(date) as date, hour "
		extFiled = "CONCAT(date(bj.date),' ', case when bj.hour < 10 then concat('0',bj.hour,':00:00') else concat(bj.hour,':00:00') end ) as date, bj.hour "
		startTb = tbTimeStart.Add(-86400 * time.Second).Format(time.DateOnly)
		endTb = tbTimeEnd.Add(-86400 * time.Second).Format(time.DateOnly)
		tbExt = "date(date) as date, hour "
		startHb = start
		endHb = end
		hbExt = "date(date) as date, hour as hour "
	case "d":
		baseGroup = "date(date)"
		ext = "date(date) as date "
		extT = "date(DATE_ADD(date,INTERVAL 1 MONTH)) as date "
		extFiled = "substr(bj.date, 1, 10) as date"
		startTb = tbTimeStart.AddDate(0, -1, 0).Format(time.DateOnly)
		endTb = tbTimeEnd.AddDate(0, -1, 0).Format(time.DateOnly)
		tbExt = "date(date) as date "
		startHb = tbTimeStart.Add(-86400 * time.Second).Format(time.DateOnly)
		endHb = tbTimeEnd.Add(-86400 * time.Second).Format(time.DateOnly)
		hbExt = "date(date) as date "
	case "w":
		baseGroup = "date"
		ext = "CONCAT(SUBSTR(date, 1,4),\"w\",week(date, 1)) as date "
		extT = "date"
		extFiled = "bj.date as date "
		startTb = tbTimeStart.AddDate(-1, 0, 0).Format(time.DateOnly)
		endTb = tbTimeEnd.AddDate(-1, 0, 0).Format(time.DateOnly)
		tbExt = "CONCAT(SUBSTR(date, 1,4),\"w\",week(DATE_ADD(date,INTERVAL 1 YEAR),1)) as date "
		startHb = tbTimeStart.AddDate(0, 0, -7).Format(time.DateOnly)
		endHb = tbTimeEnd.AddDate(0, 0, -7).Format(time.DateOnly)
		hbExt = "CONCAT(SUBSTR(date, 1,4),\"w\",week(DATE_ADD(date,INTERVAL 7 DAY),1)) as date "
	case "m":
		baseGroup = "date"
		ext = "CONCAT(SUBSTR(date, 1,4),\"-\",MONTH(date)) as date "
		extT = "date"
		extFiled = "bj.date as date "
		startTb = tbTimeStart.AddDate(-1, 0, 0).Format(time.DateOnly)
		endTb = tbTimeEnd.AddDate(-1, 0, 0).Format(time.DateOnly)
		tbExt = "CONCAT(SUBSTR(date, 1,4),\"-\",MONTH(DATE_ADD(date,INTERVAL 1 YEAR))) as date "
		startHb = tbTimeStart.AddDate(0, -1, 0).Format(time.DateOnly)
		endHb = tbTimeEnd.AddDate(0, -1, 0).Format(time.DateOnly)
		hbExt = "CONCAT(SUBSTR(date, 1,4),\"-\",MONTH(DATE_ADD(date,INTERVAL 1 MONTH))) as date "
	}
	return
}

func whereCondition(params *roidto.ReportDataReq) string {
	var filterStr string
	var where string
	where += " 1 = 1 "
	if len(params.Media) > 0 {
		filterStr = "media IN ('" + strings.Join(params.Media, "','") + "')"
		where += " AND " + filterStr
	}
	if len(params.Region) > 0 {
		filterStr = "region IN ('" + strings.Join(params.Region, "','") + "')"
		where += " AND " + filterStr
	}
	if len(params.PayType) > 0 {
		filterStr = "pay_type IN ('" + strings.Join(params.PayType, "','") + "')"
		where += " AND " + filterStr
	}
	if len(params.AppName) > 0 {
		filterStr = "app_name IN ('" + strings.Join(params.AppName, "','") + "')"
		where += " AND " + filterStr
	}
	if params.BookID != "" {
		bookId, _ := strconv.Atoi(params.BookID)
		filterStr = "book_id=" + strconv.Itoa(bookId)

		where += " AND " + filterStr
	}
	if len(params.BookNames) > 0 {
		filterStr = "book_name IN ('" + strings.Join(params.BookNames, "','") + "')"
		where += " AND " + filterStr
	}
	if len(params.OptimizerName) > 0 {
		filterStr = "optimizer_nickname IN ('" + strings.Join(params.OptimizerName, "','") + "')"
		where += " AND " + filterStr
	}
	if len(params.AccountID) > 0 {
		filterStr = "account_id IN ('" + strings.Join(params.AccountID, "','") + "')"
		where += " AND " + filterStr
	}
	if len(params.CopyRightOwner) > 0 {
		filterStr = "copyright_owner IN ('" + strings.Join(params.CopyRightOwner, "','") + "')"
		where += " AND " + filterStr
	}
	if params.DeliveryProduct != "" {
		if params.DeliveryProduct == "PRODUCT" {
			filterStr = "delivery_product = '" + params.DeliveryProduct + "'"
			where += " AND " + filterStr
		} else {
			filterStr = "delivery_product != 'PRODUCT' "
			where += " AND " + filterStr
		}
	}
	id1, _ := strconv.Atoi(params.ProjectID)
	if id1 > 0 {
		filterStr = "project_id=" + strconv.Itoa(id1)
		where += " AND " + filterStr
	}
	return where
}

func (d *ReportDataDao) ProjectReportData(params *roidto.ReportDataReq) (*common.Paginator, error) {
	db := dorisdb.DorisClient()
	roiTable := repo.ProjectReportDataViewTableName()
	roiTodayTable := repo.ProjectReportTodayDataViewTableName()

	pagination := params.Pagination
	limit := pagination.GetLimit()
	offset := pagination.GetOffset()
	var sql string
	var columns, columnsHb, columnsTb, columnsAccumulateInner, columnsOuterLayer, columnsTotal []string
	var kpis, kpisHb, kpisTb, kpisAccumulate, kpisAccumulateInner, kpisOuterLayer, kpisHourTotal []string
	var where, whereHb, whereTb []string
	var groups, groupsHb, groupsTb, groupsAccumulateInner, groupsOuterLayer []string
	var sorts []string
	columnsAccumulateArr := []string{"account_id",
		"media", "region", "pay_type", "app_name", "book_name", "book_id", "optimizer_nickname",
		"account_name", "project_id", "project_name", "user_id"}

	/* 同环比及累计指标查询示例
	-- 子查询sql
	SELECT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columns
	        ,sum(income) AS income,0 AS income_hb,0 AS income_tb,0 AS income2 -- kpis
	    FROM roi_report_hourly
	    WHERE DATE>='2025-02-03' AND DATE<='2025-02-09' AND promotion_id IN (7455361602293104650) -- where
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groups
	    UNION ALL
	    SELECT DATE_ADD(DATE,INTERVAL 7 DAY) AS DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsHb
	        ,0 AS income,sum(income) AS income_hb,0 AS income_tb,0 AS income2 -- kpisHb
	    FROM roi_report_hourly
	    WHERE DATE>='2025-01-27' AND DATE<='2025-02-02' AND promotion_id IN (7455361602293104650) -- whereHb
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groupsHb
	    UNION ALL
	    SELECT DATE_ADD(DATE,INTERVAL 1 MONTH) AS DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsTb
	        ,0 AS income,0 AS income_hb,sum(income) AS income_tb,0 AS income2 -- kpisTb
	    FROM roi_report_hourly
	    WHERE DATE>='2025-01-03' AND DATE<='2025-01-09' AND promotion_id IN (7455361602293104650)  -- whereTb
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groupsTb
	    UNION ALL
	    SELECT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsOuterLayer
	        ,0 AS income,0 AS income_hb,0 AS income_tb,SUM(income2) AS income2 -- kpisAccumulate
	    FROM (
	        SELECT DATE,account_id,promotion_id
	            ,media,region,pay_type,app_name,book_name,optimizer_nickname
	            ,account_name,project_name,promotion_name,mid_id,mid_type  -- columnsAccumulateInner
	            ,MAX(new_sum_income) AS new_sum_income,MAX(income2) AS income2,MAX(income3) AS income3
	            ,MAX(income4) AS income4,MAX(income5) AS income5,MAX(income6) AS income6,MAX(income7) AS income7 -- kpisAccumulateInner
	        FROM roi_report_hourly
	        WHERE DATE>='2025-02-03' AND DATE<='2025-02-09' AND promotion_id IN (7455361602293104650) -- where
	        GROUP BY DATE,account_id,promotion_id
	            ,media,region,media,pay_type,app_name,book_name,optimizer_nickname
	            ,account_name,project_name,promotion_name,mid_id,mid_type  -- groupsAccumulateInner
	    ) AS tt
	    GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id; -- groupsOuterLayer
	-- 分页明细数据查询
	SELECT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- columnsOuterLayer
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income_tb) AS income_tb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t
	GROUP BY DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id -- groupsOuterLayer
	ORDER BY DATE ASC,income DESC -- sorts
	LIMIT 19 OFFSET 0; -- limit offset
	-- 汇总行数据查询
	SELECT '汇总' AS DATE -- columnTotal
	    ,sum(income) AS income,sum(income_hb) AS income_hb,sum(income_tb) AS income_tb,sum(income2) AS income2 -- kpisOuterLayer
	FROM (子查询sql) AS t;
	-- 总行数查询
	SELECT COUNT(DISTINCT DATE,media,app_name,book_name,optimizer_nickname,account_name,account_id) AS cnt -- groupsOuterLayer
	FROM (子查询sql) AS t;
	*/

	// 时间聚合维度
	columnsTotal = append(columnsTotal, "'汇总' as date")
	hbStr := "DATE(DATE_ADD(date,INTERVAL " + strconv.Itoa(params.DaysOfHb) + " DAY))"
	tbStr := "DATE(DATE_ADD(date,INTERVAL 1 MONTH))"
	if params.GroupType == "w" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%xW%v') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%xW%v') AS date")
		columnsTb = append(columnsTb, "DATE_FORMAT("+tbStr+", '%xW%v') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%xW%v') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%xW%v')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%xW%v')")
		groupsTb = append(groupsTb, "DATE_FORMAT("+tbStr+", '%xW%v')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%xW%v')")
	} else if params.GroupType == "m" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%Y-%m') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%Y-%m') AS date")
		columnsTb = append(columnsTb, "DATE_FORMAT("+tbStr+", '%Y-%m') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%Y-%m') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%Y-%m')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%Y-%m')")
		groupsTb = append(groupsTb, "DATE_FORMAT("+tbStr+", '%Y-%m')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%Y-%m')")
	} else if params.GroupType == "h" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groups = append(groups, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00')")
		if params.IsRealTimeQuery {
			// 固定加一小时
			columnsHb = append(columnsHb, "CONCAT(date,' ',IF(hour<10,'0',''),hour,':00:00') + INTERVAL 1 HOUR AS date")
			groupsHb = append(groupsHb, "CONCAT(date,' ',IF(hour<10,'0',''),hour,':00:00') + INTERVAL 1 HOUR")
		} else {
			columnsHb = append(columnsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
			groupsHb = append(groupsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")
		}
		columnsTb = append(columnsTb, "CONCAT("+tbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groupsTb = append(groupsTb, "CONCAT("+tbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")

		// 分小时的汇总行计算需要特殊逻辑
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	} else {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "date")
		columnsHb = append(columnsHb, hbStr+" AS date")
		columnsTb = append(columnsTb, tbStr+" AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groups = append(groups, "date")
		groupsHb = append(groupsHb, "date")
		groupsTb = append(groupsTb, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	}
	groupsOuterLayer = append(groupsOuterLayer, "date")
	columnsAccumulateInner = append(columnsAccumulateInner, columnsAccumulateArr...)
	groupsAccumulateInner = append(groupsAccumulateInner, columnsAccumulateArr...)

	// 用户定制聚合维度 (group by)
	columns = append(columns, params.GroupBy...)
	deep := make([]string, len(params.GroupBy))
	copy(deep, params.GroupBy)
	for k, v := range deep {
		if v == "media" {
			deep[k] = "case when media = '今日头条' then '抖小' else media end as media"
		}
	}
	columnsHb = append(columnsHb, deep...)
	columnsTb = append(columnsTb, deep...)
	columnsOuterLayer = append(columnsOuterLayer, params.GroupBy...)
	groups = append(groups, params.GroupBy...)
	groupsHb = append(groupsHb, params.GroupBy...)
	groupsTb = append(groupsTb, params.GroupBy...)
	groupsOuterLayer = append(groupsOuterLayer, params.GroupBy...)

	// 普通指标
	kpiArr := []string{"media_cost", "show_count", "click_count",
		"media_active_count", "media_convert_count", "media_first_pay_count",
		"active_count", "new_pay_count", "active_pay_count", "first_income"}
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
		if kpi == "media_cost" || kpi == "first_income" {
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0.0 AS "+kpi)
		} else {
			kpisHb = append(kpisHb, "0 AS "+kpi)
			kpisTb = append(kpisTb, "0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0 AS "+kpi)
		}
	}

	// 同环比指标
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost) as cost")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_hb) as cost_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_tb) as cost_tb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income) as income")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income_hb) as income_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income_tb) as income_tb")
	//实际消耗=(媒体消耗-赠款reward_cost-共享赠款shared_wallet_cost)/(1+返点比例2%)
	mediaCostSql := "SUM(media_cost)"
	rewardCostSql := "SUM(reward_cost)"
	sharedWalletCostSql := "SUM(shared_wallet_cost)"
	//账户返点比例先写死0.02, 后续等数据库实时处理好了, 再使用数据库的
	mediaRebateRateSql := "0.02" //"MAX(media_rebate_rate)"
	costSql := "(" + mediaCostSql + "-" + rewardCostSql + "-" + sharedWalletCostSql + ")/(1.0+" + mediaRebateRateSql + ")"
	totalCostSql := "(" + mediaCostSql + "-" + rewardCostSql + "-" + sharedWalletCostSql + ")/(1.0+" + mediaRebateRateSql + ")"
	if params.HasProjectId {
		costSql = "(" + mediaCostSql + ")/(1.0+" + mediaRebateRateSql + ")"
	}
	kpis = append(kpis, costSql+" as cost")
	kpis = append(kpis, "0.0 as cost_hb")
	kpis = append(kpis, "0.0 as cost_tb")
	kpisHb = append(kpisHb, "0.0 as cost")
	kpisHb = append(kpisHb, costSql+" as cost_hb")
	kpisHb = append(kpisHb, "0.0 as cost_tb")
	kpisTb = append(kpisTb, "0.0 as cost")
	kpisTb = append(kpisTb, "0.0 as cost_hb")
	kpisTb = append(kpisTb, costSql+" as cost_tb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_tb")
	//实际收入
	kpis = append(kpis, "SUM(income) as income")
	kpis = append(kpis, "0.0 as income_hb")
	kpis = append(kpis, "0.0 as income_tb")
	kpisHb = append(kpisHb, "0.0 as income")
	kpisHb = append(kpisHb, "SUM(income) as income_hb")
	kpisHb = append(kpisHb, "0.0 as income_tb")
	kpisTb = append(kpisTb, "0.0 as income")
	kpisTb = append(kpisTb, "0.0 as income_hb")
	kpisTb = append(kpisTb, "SUM(income) as income_tb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income_tb")

	//累计指标的, 小时的直接取, 日周天 的 要取当天的最早有消费的小时的数据
	kpiArr = []string{"new_sum_income", "income2", "income3", "income4", "income5", "income6", "income7"}
	kpisHourTotal = append(kpisHourTotal, kpis...)
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		if params.GroupType == "h" {
			kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisHourTotal = append(kpisHourTotal, "0.0 AS "+kpi) //分小时汇总行的累计指标需要特殊处理
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		} else { //非小时的日周天独立查询
			kpis = append(kpis, "0.0 AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		}
	}

	// 最外层计算指标排序的，需要特殊处理
	var kpi string
	//{Label: "点击率", Prop: "click_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(click_count)/SUM(show_count), 0) AS click_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "点击成本", Prop: "click_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(cost)/SUM(click_count), 0) AS click_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "千展成本", Prop: "show_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(cost)/SUM(show_count), 0) AS show_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活成本", Prop: "media_active_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(media_active_count)>0, SUM(cost)/SUM(media_active_count), 0) AS media_active_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活率", Prop: "media_active_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(media_active_count)/SUM(click_count), 0) AS media_active_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "实际ROI", Prop: "roi", Format: "rate", SortAble: true, IsDefault: true},
	kpi = "IF(SUM(cost)>0, SUM(income)/SUM(cost), 0) AS roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "首日新增ROI", Prop: "first_roi", Format: "rate", SortAble: true},
	kpi = "IF(SUM(cost)>0, SUM(first_income)/SUM(cost), 0) AS first_roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)

	// 查询条件 (where)
	var filterStr string
	if len(params.Media) > 0 {
		filterStr = "media IN ('" + strings.Join(params.Media, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.Region) > 0 {
		filterStr = "region IN ('" + strings.Join(params.Region, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.PayType) > 0 {
		filterStr = "pay_type IN ('" + strings.Join(params.PayType, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AppName) > 0 {
		filterStr = "app_name IN ('" + strings.Join(params.AppName, "','") + "')"
		where = append(where, filterStr)
	}
	if params.BookID != "" {
		bookId, _ := strconv.Atoi(params.BookID)
		filterStr = "book_id=" + strconv.Itoa(bookId)
		where = append(where, filterStr)
	}
	if len(params.BookNames) > 0 {
		filterStr = "book_name IN ('" + strings.Join(params.BookNames, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.OptimizerName) > 0 {
		filterStr = "optimizer_nickname IN ('" + strings.Join(params.OptimizerName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AccountID) > 0 {
		filterStr = "account_id IN ('" + strings.Join(params.AccountID, "','") + "')"
		where = append(where, filterStr)
	}
	//if len(params.DeliveryProduct) > 0 {
	//	filterStr = "delivery_product IN ('" + strings.Join(params.DeliveryProduct, "','") + "')"
	//	where = append(where, filterStr)
	//}
	if len(params.UserID) > 0 {
		filterStr = "user_id IN ('" + strings.Join(params.UserID, "','") + "')"
		where = append(where, filterStr)
	}
	id1, _ := strconv.Atoi(params.ProjectID)
	if id1 > 0 {
		filterStr = "project_id=" + strconv.Itoa(id1)
		where = append(where, filterStr)
	}
	id3, _ := strconv.Atoi(params.MidID)
	if id3 > 0 {
		filterStr = "mid_id=" + strconv.Itoa(id3)
		where = append(where, filterStr)
	}

	whereHb = append(whereHb, where...)
	whereTb = append(whereTb, where...)

	if params.StartDate == params.EndDate {
		where = append(where, "date='"+params.StartDate+"'")
		whereTb = append(whereTb, "date='"+params.StartDateTb+"'")
		if params.IsRealTimeQuery {
			whereHb = append(whereHb, "((date='"+params.StartDate+"' AND hour <= 23) OR (date='"+params.StartDateHb+"' AND hour=23))")
		} else {
			whereHb = append(whereHb, "date='"+params.StartDateHb+"'")
		}
	} else {
		where = append(where, "date>='"+params.StartDate+"' AND date<='"+params.EndDate+"'")
		whereHb = append(whereHb, "date>='"+params.StartDateHb+"' AND date<='"+params.EndDateHb+"'")
		whereTb = append(whereTb, "date>='"+params.StartDateTb+"' AND date<='"+params.EndDateTb+"'")
	}

	// 排序 (sort)
	if len(params.Sorts) == 0 {
		params.Sorts = append(params.Sorts,
			common.Sort{Key: "date", Order: "asc"},
			common.Sort{Key: "cost", Order: "desc"},
		)
	}
	for _, sort := range params.Sorts {
		sorts = append(sorts, fmt.Sprintf("%s %s", sort.Key, sort.Order))
	}

	// T T-1 数据存储在不同表
	baseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columns, ",")+","+strings.Join(kpis, ","), strings.Join(where, " AND "), strings.Join(groups, ","))
	var hbBaseSql, tbBaseSql string
	if params.IsRealTimeQuery { // 实时查询上一小时也是今天数据
		hbBaseSql = getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsHb, ",")+","+strings.Join(kpisHb, ","), strings.Join(whereHb, " AND "), strings.Join(groupsHb, ","))
	} else {
		hbBaseSql = getBaseUnionSql(roiTable, "", strings.Join(columnsHb, ",")+","+strings.Join(kpisHb, ","), strings.Join(whereHb, " AND "), strings.Join(groupsHb, ","))
	}
	tbBaseSql = getBaseUnionSql(roiTable, "", strings.Join(columnsTb, ",")+","+strings.Join(kpisTb, ","), strings.Join(whereTb, " AND "), strings.Join(groupsTb, ","))
	//子查询构造
	subSql := baseSql +
		" UNION ALL" +
		hbBaseSql +
		" UNION ALL" +
		tbBaseSql
	if params.GroupType != "h" {
		hBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsAccumulateInner, ",")+","+strings.Join(kpisAccumulateInner, ","), strings.Join(where, " AND "), strings.Join(groupsAccumulateInner, ","))
		subSql += " UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			hBaseSql +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}

	// 总行数查询
	var total int64
	type Dist struct {
		Cnt int64 `gorm:"column:cnt"`
	}
	var dist Dist
	sql = "SELECT COUNT(DISTINCT " + strings.Join(groupsOuterLayer, ",") + ") AS cnt " +
		" FROM (" + subSql + ") AS t"

	err := db.Raw(sql).Scan(&dist).Error
	if err != nil {
		return nil, err
	}
	total = dist.Cnt

	// 分页明细数据查询
	var res []repo.ProjectReportDataViewEntity
	sql = "SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t" +
		" GROUP BY " + strings.Join(groupsOuterLayer, ",") +
		" ORDER BY " + strings.Join(sorts, ",") +
		" LIMIT " + strconv.FormatInt(limit, 10) + " OFFSET " + strconv.FormatInt(offset, 10)

	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	// 计算指标处理
	for i, row := range res {
		res[i] = *row.Calculate()
		if params.GroupType == "h" {
			res[i].Date = row.Date[0:10] + " " + row.Date[11:19]
		} else if params.GroupType == "d" {
			res[i].Date = row.Date[0:10]
		}
	}

	// 汇总行数据查询
	if params.GroupType == "h" {
		//子查询构造 - 小时维度特殊处理
		nBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columns, ",")+","+strings.Join(kpisHourTotal, ","), strings.Join(where, " AND "), strings.Join(groups, ","))
		nhBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsAccumulateInner, ",")+","+strings.Join(kpisAccumulateInner, ","), strings.Join(where, " AND "), strings.Join(groupsAccumulateInner, ","))
		ntBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsTb, ",")+","+strings.Join(kpisTb, ","), strings.Join(whereTb, " AND "), strings.Join(groupsTb, ","))
		subSql = nBaseSql +
			" UNION ALL" +
			hbBaseSql +
			" UNION ALL" +
			ntBaseSql +
			" UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			nhBaseSql +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}

	var countRow repo.ProjectReportDataViewEntity
	// 汇总数据特殊处理
	totalSubSql := subSql
	if params.HasProjectId {
		totalSubSql = strings.ReplaceAll(totalSubSql, costSql, totalCostSql)
	}
	sql = "SELECT " + strings.Join(columnsTotal, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + totalSubSql + ") AS t"

	err = db.Raw(sql).Scan(&countRow).Error
	if err != nil {
		return nil, err
	}
	//拼接返回列表行
	var list []repo.ProjectReportDataViewEntity
	if countRow.Date != "" {
		// 计算指标处理
		countRow.Calculate()
		list = append(list, countRow)
	}
	list = append(list, res...)

	// 获取全部管家名称  group_by
	usersInfo, _ := d.ManagerAry()
	userMap := make(map[string]string, len(usersInfo))
	for _, v := range usersInfo {
		userMap[v.ID] = v.Label
	}

	// 格式化数据
	for i, row := range list {
		list[i].BookIDStr = strconv.FormatInt(row.BookID, 10)
		list[i].Media = utils.HtmlEncode(row.Media)
		list[i].Region = utils.HtmlEncode(row.Region)
		if val, ok := roidto.PayTypeMapping[row.PayType]; ok {
			list[i].PayType = val
		}
		list[i].AppID = utils.HtmlEncode(row.AppID)
		list[i].AppName = utils.HtmlEncode(row.AppName)
		list[i].BookName = utils.HtmlEncode(row.BookName)
		list[i].OptimizerNickname = utils.HtmlEncode(row.OptimizerNickname)
		list[i].AccountID = utils.HtmlEncode(row.AccountID)
		list[i].AccountName = utils.HtmlEncode(row.AccountName)
		list[i].ProjectID = utils.HtmlEncode(row.ProjectID)
		list[i].ProjectName = utils.HtmlEncode(row.ProjectName)
		if row.UserID != "" {
			list[i].UserName = utils.HtmlEncode(userMap[row.UserID])
		}
	}

	paginator := common.NewPaginator(pagination.GetPage(), pagination.GetPageSize(), total, list)
	return &paginator, nil
}

func (d *ReportDataDao) ProjectExportData(params *roidto.ReportDataReq) (result *[]repo.ProjectReportDataViewEntity, err error) {
	db := dorisdb.DorisClient()
	roiTable := repo.ProjectReportDataViewTableName()
	roiTodayTable := repo.ProjectReportTodayDataViewTableName()

	var sql string
	var columns, columnsHb, columnsTb, columnsAccumulateInner, columnsOuterLayer, columnsTotal []string
	var kpis, kpisHb, kpisTb, kpisAccumulate, kpisAccumulateInner, kpisOuterLayer, kpisHourTotal []string
	var where, whereHb, whereTb []string
	var groups, groupsHb, groupsTb, groupsAccumulateInner, groupsOuterLayer []string
	var sorts []string
	columnsAccumulateArr := []string{"account_id",
		"media", "region", "pay_type", "app_name", "book_name", "book_id", "optimizer_nickname",
		"account_name", "project_id", "project_name", "user_id"}

	// 时间聚合维度
	columnsTotal = append(columnsTotal, "'汇总' as date")
	hbStr := "DATE(DATE_ADD(date,INTERVAL " + strconv.Itoa(params.DaysOfHb) + " DAY))"
	tbStr := "DATE(DATE_ADD(date,INTERVAL 1 MONTH))"
	if params.GroupType == "w" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%xW%v') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%xW%v') AS date")
		columnsTb = append(columnsTb, "DATE_FORMAT("+tbStr+", '%xW%v') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%xW%v') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%xW%v')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%xW%v')")
		groupsTb = append(groupsTb, "DATE_FORMAT("+tbStr+", '%xW%v')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%xW%v')")
	} else if params.GroupType == "m" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "DATE_FORMAT(date, '%Y-%m') AS date")
		columnsHb = append(columnsHb, "DATE_FORMAT("+hbStr+", '%Y-%m') AS date")
		columnsTb = append(columnsTb, "DATE_FORMAT("+tbStr+", '%Y-%m') AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "DATE_FORMAT(date, '%Y-%m') AS date")
		groups = append(groups, "DATE_FORMAT(date, '%Y-%m')")
		groupsHb = append(groupsHb, "DATE_FORMAT("+hbStr+", '%Y-%m')")
		groupsTb = append(groupsTb, "DATE_FORMAT("+tbStr+", '%Y-%m')")
		groupsAccumulateInner = append(groupsAccumulateInner, "DATE_FORMAT(date, '%Y-%m')")
	} else if params.GroupType == "h" {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groups = append(groups, "CONCAT(DATE(date),' ',IF(hour<10,'0',''),hour,':00:00')")
		if params.IsRealTimeQuery {
			// 固定加一小时
			columnsHb = append(columnsHb, "CONCAT(date,' ',IF(hour<10,'0',''),hour,':00:00') + INTERVAL 1 HOUR AS date")
			groupsHb = append(groupsHb, "CONCAT(date,' ',IF(hour<10,'0',''),hour,':00:00') + INTERVAL 1 HOUR")
		} else {
			columnsHb = append(columnsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
			groupsHb = append(groupsHb, "CONCAT("+hbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")
		}
		columnsTb = append(columnsTb, "CONCAT("+tbStr+",' ',IF(hour<10,'0',''),hour,':00:00') AS date")
		groupsTb = append(groupsTb, "CONCAT("+tbStr+",' ',IF(hour<10,'0',''),hour,':00:00')")

		// 分小时的汇总行计算需要特殊逻辑
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	} else {
		columnsOuterLayer = append(columnsOuterLayer, "date")
		columns = append(columns, "date")
		columnsHb = append(columnsHb, hbStr+" AS date")
		columnsTb = append(columnsTb, tbStr+" AS date")
		columnsAccumulateInner = append(columnsAccumulateInner, "date")
		groups = append(groups, "date")
		groupsHb = append(groupsHb, "date")
		groupsTb = append(groupsTb, "date")
		groupsAccumulateInner = append(groupsAccumulateInner, "date")
	}
	groupsOuterLayer = append(groupsOuterLayer, "date")
	columnsAccumulateInner = append(columnsAccumulateInner, columnsAccumulateArr...)
	groupsAccumulateInner = append(groupsAccumulateInner, columnsAccumulateArr...)

	// 用户定制聚合维度 (group by)
	columns = append(columns, params.GroupBy...)
	columnsHb = append(columnsHb, params.GroupBy...)
	columnsTb = append(columnsTb, params.GroupBy...)
	columnsOuterLayer = append(columnsOuterLayer, params.GroupBy...)
	groups = append(groups, params.GroupBy...)
	groupsHb = append(groupsHb, params.GroupBy...)
	groupsTb = append(groupsTb, params.GroupBy...)
	groupsOuterLayer = append(groupsOuterLayer, params.GroupBy...)

	// 普通指标
	kpiArr := []string{"media_cost", "show_count", "click_count",
		"media_active_count", "media_convert_count", "media_first_pay_count",
		"active_count", "new_pay_count", "active_pay_count", "first_income"}
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
		if kpi == "media_cost" || kpi == "first_income" {
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0.0 AS "+kpi)
		} else {
			kpisHb = append(kpisHb, "0 AS "+kpi)
			kpisTb = append(kpisTb, "0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "0 AS "+kpi)
		}
	}

	// 同环比指标
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost) as cost")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_hb) as cost_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(cost_tb) as cost_tb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income) as income")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income_hb) as income_hb")
	kpisOuterLayer = append(kpisOuterLayer, "SUM(income_tb) as income_tb")
	//实际消耗=(媒体消耗-赠款reward_cost-共享赠款shared_wallet_cost)/(1+返点比例2%)
	mediaCostSql := "SUM(media_cost)"
	rewardCostSql := "SUM(reward_cost)"
	sharedWalletCostSql := "SUM(shared_wallet_cost)"
	//账户返点比例先写死0.02, 后续等数据库实时处理好了, 再使用数据库的
	mediaRebateRateSql := "0.02" //"MAX(media_rebate_rate)"
	costSql := "(" + mediaCostSql + "-" + rewardCostSql + "-" + sharedWalletCostSql + ")/(1.0+" + mediaRebateRateSql + ")"
	totalCostSql := "(" + mediaCostSql + "-" + rewardCostSql + "-" + sharedWalletCostSql + ")/(1.0+" + mediaRebateRateSql + ")"
	if params.HasProjectId {
		costSql = "(" + mediaCostSql + ")/(1.0+" + mediaRebateRateSql + ")"
	}
	kpis = append(kpis, costSql+" as cost")
	kpis = append(kpis, "0.0 as cost_hb")
	kpis = append(kpis, "0.0 as cost_tb")
	kpisHb = append(kpisHb, "0.0 as cost")
	kpisHb = append(kpisHb, costSql+" as cost_hb")
	kpisHb = append(kpisHb, "0.0 as cost_tb")
	kpisTb = append(kpisTb, "0.0 as cost")
	kpisTb = append(kpisTb, "0.0 as cost_hb")
	kpisTb = append(kpisTb, costSql+" as cost_tb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as cost_tb")
	//实际收入
	kpis = append(kpis, "SUM(income) as income")
	kpis = append(kpis, "0.0 as income_hb")
	kpis = append(kpis, "0.0 as income_tb")
	kpisHb = append(kpisHb, "0.0 as income")
	kpisHb = append(kpisHb, "SUM(income) as income_hb")
	kpisHb = append(kpisHb, "0.0 as income_tb")
	kpisTb = append(kpisTb, "0.0 as income")
	kpisTb = append(kpisTb, "0.0 as income_hb")
	kpisTb = append(kpisTb, "SUM(income) as income_tb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income_hb")
	kpisAccumulate = append(kpisAccumulate, "0.0 as income_tb")

	//累计指标的, 小时的直接取, 日周天 的 要取当天的最早有消费的小时的数据
	kpiArr = []string{"new_sum_income", "income2", "income3", "income4", "income5", "income6", "income7"}
	kpisHourTotal = append(kpisHourTotal, kpis...)
	for _, kpi := range kpiArr {
		kpisOuterLayer = append(kpisOuterLayer, "SUM("+kpi+") AS "+kpi)
		if params.GroupType == "h" {
			kpis = append(kpis, "SUM("+kpi+") AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisHourTotal = append(kpisHourTotal, "0.0 AS "+kpi) //分小时汇总行的累计指标需要特殊处理
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		} else { //非小时的日周天独立查询
			kpis = append(kpis, "0.0 AS "+kpi)
			kpisHb = append(kpisHb, "0.0 AS "+kpi)
			kpisTb = append(kpisTb, "0.0 AS "+kpi)
			kpisAccumulate = append(kpisAccumulate, "SUM("+kpi+") AS "+kpi)
			kpisAccumulateInner = append(kpisAccumulateInner, "MAX("+kpi+") AS "+kpi)
		}
	}

	// 最外层计算指标排序的，需要特殊处理
	var kpi string
	//{Label: "点击率", Prop: "click_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(click_count)/SUM(show_count), 0) AS click_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "点击成本", Prop: "click_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(cost)/SUM(click_count), 0) AS click_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "千展成本", Prop: "show_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(show_count)>0, SUM(cost)/SUM(show_count), 0) AS show_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活成本", Prop: "media_active_cost", Format: "cost", SortAble: true},
	kpi = "IF(SUM(media_active_count)>0, SUM(cost)/SUM(media_active_count), 0) AS media_active_cost"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "媒体激活率", Prop: "media_active_rate", Format: "rate", SortAble: true},
	kpi = "IF(SUM(click_count)>0, SUM(media_active_count)/SUM(click_count), 0) AS media_active_rate"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "实际ROI", Prop: "roi", Format: "rate", SortAble: true, IsDefault: true},
	kpi = "IF(SUM(cost)>0, SUM(income)/SUM(cost), 0) AS roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)
	//{Label: "首日新增ROI", Prop: "first_roi", Format: "rate", SortAble: true},
	kpi = "IF(SUM(cost)>0, SUM(first_income)/SUM(cost), 0) AS first_roi"
	kpisOuterLayer = append(kpisOuterLayer, kpi)

	// 查询条件 (where)
	var filterStr string
	if len(params.Media) > 0 {
		filterStr = "media IN ('" + strings.Join(params.Media, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.Region) > 0 {
		filterStr = "region IN ('" + strings.Join(params.Region, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.PayType) > 0 {
		filterStr = "pay_type IN ('" + strings.Join(params.PayType, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AppName) > 0 {
		filterStr = "app_name IN ('" + strings.Join(params.AppName, "','") + "')"
		where = append(where, filterStr)
	}
	if params.BookID != "" {
		bookId, _ := strconv.Atoi(params.BookID)
		filterStr = "book_id=" + strconv.Itoa(bookId)
		where = append(where, filterStr)
	}
	if len(params.BookNames) > 0 {
		filterStr = "book_name IN ('" + strings.Join(params.BookNames, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.OptimizerName) > 0 {
		filterStr = "optimizer_nickname IN ('" + strings.Join(params.OptimizerName, "','") + "')"
		where = append(where, filterStr)
	}
	if len(params.AccountID) > 0 {
		filterStr = "account_id IN ('" + strings.Join(params.AccountID, "','") + "')"
		where = append(where, filterStr)
	}
	//if len(params.DeliveryProduct) > 0 {
	//	filterStr = "delivery_product IN ('" + strings.Join(params.DeliveryProduct, "','") + "')"
	//	where = append(where, filterStr)
	//}
	if len(params.UserID) > 0 {
		filterStr = "user_id IN ('" + strings.Join(params.UserID, "','") + "')"
		where = append(where, filterStr)
	}
	id1, _ := strconv.Atoi(params.ProjectID)
	if id1 > 0 {
		filterStr = "project_id=" + strconv.Itoa(id1)
		where = append(where, filterStr)
	}
	id3, _ := strconv.Atoi(params.MidID)
	if id3 > 0 {
		filterStr = "mid_id=" + strconv.Itoa(id3)
		where = append(where, filterStr)
	}

	whereHb = append(whereHb, where...)
	whereTb = append(whereTb, where...)

	if params.StartDate == params.EndDate {
		where = append(where, "date='"+params.StartDate+"'")
		whereTb = append(whereTb, "date='"+params.StartDateTb+"'")
		if params.IsRealTimeQuery {
			whereHb = append(whereHb, "((date='"+params.StartDate+"' AND hour <= 23) OR (date='"+params.StartDateHb+"' AND hour=23))")
		} else {
			whereHb = append(whereHb, "date='"+params.StartDateHb+"'")
		}
	} else {
		where = append(where, "date>='"+params.StartDate+"' AND date<='"+params.EndDate+"'")
		whereHb = append(whereHb, "date>='"+params.StartDateHb+"' AND date<='"+params.EndDateHb+"'")
		whereTb = append(whereTb, "date>='"+params.StartDateTb+"' AND date<='"+params.EndDateTb+"'")
	}

	// 排序 (sort)
	if len(params.Sorts) == 0 {
		params.Sorts = append(params.Sorts,
			common.Sort{Key: "date", Order: "asc"},
			common.Sort{Key: "cost", Order: "desc"},
		)
	}
	for _, sort := range params.Sorts {
		sorts = append(sorts, fmt.Sprintf("%s %s", sort.Key, sort.Order))
	}
	//子查询构造
	baseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columns, ",")+","+strings.Join(kpis, ","), strings.Join(where, " AND "), strings.Join(groups, ","))
	var hbBaseSql, tbBaseSql string
	if params.IsRealTimeQuery { // 实时查询上一小时也是今天数据
		hbBaseSql = getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsHb, ",")+","+strings.Join(kpisHb, ","), strings.Join(whereHb, " AND "), strings.Join(groupsHb, ","))
	} else {
		hbBaseSql = getBaseUnionSql(roiTable, "", strings.Join(columnsHb, ",")+","+strings.Join(kpisHb, ","), strings.Join(whereHb, " AND "), strings.Join(groupsHb, ","))
	}
	tbBaseSql = getBaseUnionSql(roiTable, "", strings.Join(columnsTb, ",")+","+strings.Join(kpisTb, ","), strings.Join(whereTb, " AND "), strings.Join(groupsTb, ","))
	subSql := baseSql +
		" UNION ALL" +
		hbBaseSql +
		" UNION ALL" +
		tbBaseSql
	if params.GroupType != "h" {
		hBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsAccumulateInner, ",")+","+strings.Join(kpisAccumulateInner, ","), strings.Join(where, " AND "), strings.Join(groupsAccumulateInner, ","))
		subSql += " UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			hBaseSql +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}

	// 分页明细数据查询
	var res []repo.ProjectReportDataViewEntity
	sql = "SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + subSql + ") AS t" +
		" GROUP BY " + strings.Join(groupsOuterLayer, ",") +
		" ORDER BY " + strings.Join(sorts, ",")
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	// 计算指标处理
	for i, row := range res {
		res[i] = *row.Calculate()
		if params.GroupType == "h" {
			res[i].Date = row.Date[0:10] + " " + row.Date[11:19]
		} else if params.GroupType == "d" {
			res[i].Date = row.Date[0:10]
		}
	}

	// 汇总行数据查询
	if params.GroupType == "h" {
		//子查询构造 - 小时维度特殊处理
		nBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columns, ",")+","+strings.Join(kpisHourTotal, ","), strings.Join(where, " AND "), strings.Join(groups, ","))
		nhBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsAccumulateInner, ",")+","+strings.Join(kpisAccumulateInner, ","), strings.Join(where, " AND "), strings.Join(groupsAccumulateInner, ","))
		ntBaseSql := getBaseUnionSql(roiTodayTable, roiTable, strings.Join(columnsTb, ",")+","+strings.Join(kpisTb, ","), strings.Join(whereTb, " AND "), strings.Join(groupsTb, ","))
		subSql = nBaseSql +
			" UNION ALL" +
			hbBaseSql +
			" UNION ALL" +
			ntBaseSql +
			" UNION ALL" +
			" SELECT " + strings.Join(columnsOuterLayer, ",") + "," + strings.Join(kpisAccumulate, ",") +
			" FROM (" +
			nhBaseSql +
			" ) AS tt" +
			" GROUP BY " + strings.Join(groupsOuterLayer, ",")
	}
	var countRow repo.ProjectReportDataViewEntity

	// 汇总数据特殊处理
	totalSubSql := subSql
	if params.HasProjectId {
		totalSubSql = strings.ReplaceAll(totalSubSql, costSql, totalCostSql)
	}
	sql = "SELECT " + strings.Join(columnsTotal, ",") + "," + strings.Join(kpisOuterLayer, ",") +
		" FROM (" + totalSubSql + ") AS t"
	err = db.Raw(sql).Scan(&countRow).Error
	if err != nil {
		return nil, err
	}
	//拼接返回列表行
	var list []repo.ProjectReportDataViewEntity
	if countRow.Date != "" {
		// 计算指标处理
		countRow.Calculate()
		list = append(list, countRow)
	}
	list = append(list, res...)

	// 获取全部管家名称  group_by
	usersInfo, _ := d.ManagerAry()
	userMap := make(map[string]string, len(usersInfo))
	for _, v := range usersInfo {
		userMap[v.ID] = v.Label
	}

	// 格式化数据
	for i, row := range list {
		list[i].BookIDStr = strconv.FormatInt(row.BookID, 10)
		list[i].Media = utils.HtmlEncode(row.Media)
		list[i].Region = utils.HtmlEncode(row.Region)
		if val, ok := roidto.PayTypeMapping[row.PayType]; ok {
			list[i].PayType = val
		}
		list[i].AppID = utils.HtmlEncode(row.AppID)
		list[i].AppName = utils.HtmlEncode(row.AppName)
		list[i].BookName = utils.HtmlEncode(row.BookName)
		list[i].OptimizerNickname = utils.HtmlEncode(row.OptimizerNickname)
		list[i].AccountID = utils.HtmlEncode(row.AccountID)
		list[i].AccountName = utils.HtmlEncode(row.AccountName)
		list[i].ProjectID = utils.HtmlEncode(row.ProjectID)
		list[i].ProjectName = utils.HtmlEncode(row.ProjectName)
		if row.UserID != "" {
			list[i].UserName = utils.HtmlEncode(userMap[row.UserID])
		}
	}

	result = &list
	return
}

// GetMediaCostByAdvertiserId 获取媒体花费大于0的账户id列表
func (d *ReportDataDao) GetMediaCostByAdvertiserId(startTime, endTime string, advertiserId []string) ([]string, error) {
	advertiserIdSlice := []string{}
	db := dorisdb.DorisClient()
	err := db.Table(repo.ReportDataViewTableName()).
		Where("date>=? AND date<=?", startTime, endTime).
		Where("account_id in (?)", advertiserId).
		Where("media_cost>?", 0).
		Pluck("distinct(account_id)", &advertiserIdSlice).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return advertiserIdSlice, err
	}
	return advertiserIdSlice, nil
}

func (d *ReportDataDao) GetLastBookNameByBookId(bookIds []string, isToday bool, date string) (map[int64]string, error) {
	table := "roi_project_hourly"
	if isToday {
		table = "roi_project_hourly_today"
	}
	booksStr := strings.Join(bookIds, ",")

	sql := fmt.Sprintf(`
SELECT book_id, book_name
FROM (
    SELECT 
        book_id, 
        book_name, 
        hour,
        ROW_NUMBER() OVER (PARTITION BY book_id ORDER BY hour DESC) AS rn
    FROM %s
    WHERE book_id IN (%s)
	AND date='%s'
) ranked
WHERE rn = 1
ORDER BY book_id ASC`, table, booksStr, date)
	db := dorisdb.DorisClient()

	// 声明结构体来接收查询结果
	type Row struct {
		BookId   int64  `gorm:"column:book_id"`
		BookName string `gorm:"column:book_name"`
	}
	var rows []Row

	err := db.Raw(sql).Scan(&rows).Error
	if err != nil {
		return nil, err
	}

	// 将结果转换为 map
	res := make(map[int64]string)
	for _, row := range rows {
		res[row.BookId] = row.BookName
	}

	return res, nil
}

// GetNewlySpentBooksRoiInfo 按照小时、剧目ID聚合消费及环比数据
func (d *ReportDataDao) GetNewlySpentBooksRoiInfo(isToday bool, date string, hour int64, bookIds []string) ([]repo.NewlySpentBooksRoiInfo, error) {
	table := "roi_project_hourly"
	if isToday {
		table = "roi_project_hourly_today"
	}
	booksStr := strings.Join(bookIds, ",")
	sql := fmt.Sprintf(`
SELECT
    book_id,
    date_hour AS date_time,
    SUM(cost) AS media_cost,
    SUM(income) AS income,
    SUM(hb_cost) AS hb_media_cost,
    SUM(hb_income) AS hb_income
FROM
    (
        -- 当前小时数据
        SELECT
            book_id,
            CONCAT(DATE(date), ' ', LPAD(hour, 2, '0'), ':00:00') AS date_hour,
            SUM(media_cost) AS cost,
            SUM(income) AS income,
            0.0 AS hb_cost,
            0.0 AS hb_income
        FROM
            %s
        WHERE
            date = '%s'
            AND hour <= %d
            AND book_id in(%s)
        GROUP BY
            book_id,
            CONCAT(DATE(date), ' ', LPAD(hour, 2, '0'), ':00:00')
        
        UNION ALL
        
        -- 上一小时数据（作为环比数据）
        SELECT
            book_id,
            DATE_ADD(
                CONCAT(DATE(date), ' ', LPAD(hour, 2, '0'), ':00:00'), 
                INTERVAL 1 HOUR
            ) AS date_hour,
            0.0 AS cost,
            0.0 AS income,
            SUM(media_cost) AS hb_cost,
            SUM(income) AS hb_income
        FROM
            %s
        WHERE
            date = '%s'
            AND hour <= %d
            AND book_id in(%s)
        GROUP BY
            book_id,
            DATE_ADD(
                CONCAT(DATE(date), ' ', LPAD(hour, 2, '0'), ':00:00'), 
                INTERVAL 1 HOUR
            )
    ) combined_data
GROUP BY
    book_id,
    date_hour
ORDER BY
    date_hour desc, media_cost desc`, table, date, hour, booksStr, table, date, hour-1, booksStr)
	db := dorisdb.DorisClient()
	var res []repo.NewlySpentBooksRoiInfo
	err := db.Raw(sql).Scan(&res).Error
	if err != nil {
		return nil, err
	}
	return res, nil
}

// GetNewlySpentBooks 获取今日有消耗昨日无消耗的剧目   查了两张表，不通用
func (d *ReportDataDao) GetNewlySpentBooks(todayDate, yesterdayDate string) ([]string, error) {
	sql := fmt.Sprintf(`
SELECT 
    DISTINCT today.book_id
FROM 
    roi_project_hourly_today today
LEFT JOIN (
    SELECT DISTINCT 
        book_id
    FROM 
        roi_project_hourly
    WHERE 
        date = '%s'
        AND media_cost > 0
) yesterday_has_cost ON today.book_id = yesterday_has_cost.book_id
WHERE 
    today.date = '%s'
    AND today.media_cost > 0
    AND yesterday_has_cost.book_id IS NULL`, yesterdayDate, todayDate)

	db := dorisdb.DorisClient()
	var bookIds []string
	rows, err := db.Raw(sql).Rows()
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	for rows.Next() {
		var bookId int64
		if err := rows.Scan(&bookId); err != nil {
			return nil, err
		}
		bookIds = append(bookIds, strconv.FormatInt(bookId, 10))
	}

	return bookIds, nil
}

// GetTopBookInfoByManagerId 根据管家账户ID获取整体及TOP n剧目数据
func (d *ReportDataDao) GetTopBookInfoByManagerId(isToday bool, managerId string, date string, hour int64, limit int64, bookIds []int64) (*repo.UserAndBookRoiData, error) {
	db := dorisdb.DorisClient()
	tableName := "roi_project_hourly_today"
	if !isToday {
		tableName = "roi_project_hourly"
	}

	// 第一个查询：获取总体数据
	var totalData repo.UserRoiData
	err := db.Table(tableName+" r").
		Select("sum(r.media_cost) as media_cost, sum(r.income) as income").
		Joins("JOIN oauth_account a ON a.advertiser_id = r.account_id").
		Where("a.user_id = ? AND r.date = ? AND r.hour <= ?", managerId, date, hour).
		Scan(&totalData).Error

	if err != nil {
		return nil, err
	}

	// 第二个查询：获取书籍排名数据
	var bookRanking []repo.BookRoiData
	q := db.Table(tableName+" r").
		Select("sum(r.media_cost) as media_cost, sum(r.income) as income, r.book_id").
		Joins("JOIN oauth_account a ON a.advertiser_id = r.account_id").
		Where("a.user_id = ? AND r.date = ? AND r.hour <= ?", managerId, date, hour)
	if len(bookIds) > 0 {
		q = q.Where("r.book_id in (?)", bookIds)
		limit = int64(len(bookIds))
	}

	err = q.Group("r.book_id").
		Order("media_cost DESC").
		Limit(int(limit)).
		Scan(&bookRanking).Error

	if err != nil {
		return nil, err
	}

	// 查询剧目名称
	if len(bookIds) == 0 {
		for _, book := range bookRanking {
			bookIds = append(bookIds, book.BookId)
		}

		// 查询最新的book_name
		type BookNameRow struct {
			BookId   int64  `gorm:"column:book_id"`
			BookName string `gorm:"column:book_name"`
			Hour     int64  `gorm:"column:hour"`
		}
		var bookNames []BookNameRow
		err = db.Table(tableName).
			Select("book_id, book_name, hour").
			Where("book_id IN (?) AND hour <= ?", bookIds, hour).
			Order("hour DESC").
			Scan(&bookNames).Error

		if err != nil {
			return nil, err
		}

		// 创建book_id到book_name的映射
		bookNameMap := make(map[int64]string)
		for _, row := range bookNames {
			if _, exists := bookNameMap[row.BookId]; !exists {
				bookNameMap[row.BookId] = row.BookName
			}
		}

		// 更新bookRanking中的book_name
		for i := range bookRanking {
			if name, exists := bookNameMap[bookRanking[i].BookId]; exists {
				bookRanking[i].BookName = name
			}
		}
	}

	// 返回两个查询的结果
	return &repo.UserAndBookRoiData{
		UserRoi: totalData,
		BookRoi: bookRanking,
	}, nil
}

// InsertBatchSizeFinalTable  插入更新最总报表数据
func (d *ReportDataDao) InsertBatchSizeFinalTable(data []repo.ReportDataViewEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsertFinalDate(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (d *ReportDataDao) batchInsertFinalDate(tx *gorm.DB, data []repo.ReportDataViewEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.ReportDataViewTableName() + " ( `date`, `hour`, media, region, pay_type, app_id, app_name, book_id, book_name, optimizer_id, optimizer_nickname, account_id, account_name, project_id, project_name, promotion_id, promotion_name, data_type, media_cost, reward_cost, shared_wallet_cost, media_rebate_rate, show_count, click_count, media_active_count, media_convert_count, media_first_pay_count, income, active_count, new_pay_count, active_pay_count, first_income, new_sum_income, income2, income3, income4, income5, income6, income7 )  VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.Date,
			v.Hour,
			v.Media,
			v.Region,
			v.PayType,
			v.AppID,
			v.AppName,
			v.BookID,
			v.BookName,
			v.OptimizerID,
			v.OptimizerNickname,
			v.AccountID,
			v.AccountName,
			v.ProjectID,
			v.ProjectName,
			v.PromotionID,
			v.PromotionName,
			v.DataType,
			v.MediaCost,
			v.RewardCost,
			v.SharedWalletCost,
			v.MediaRebateRate,
			v.ShowCount,
			v.ClickCount,
			v.MediaActiveCount,
			v.MediaConvertCount,
			v.MediaFirstPayCount,
			v.Income,
			v.ActiveCount,
			v.NewPayCount,
			v.ActivePayCount,
			v.FirstIncome,
			v.NewSumIncome,
			v.Income2,
			v.Income3,
			v.Income4,
			v.Income5,
			v.Income6,
			v.Income7,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// BuildAggFinalBillEntity 保存扣减数据
func (d *ReportDataDao) BuildAggFinalBillEntity() error {
	var data []repo.ReportDataViewEntity
	bill := "SELECT SUBSTR(search_date, 1, 10) AS date, 0 AS `hour`, media AS media, 2 AS data_type, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, app_name AS app_name, '0' AS project_id, '0' AS promotion_id, '0' AS mid_id, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, b.advertiser_id AS account_id,  reward_cost AS reward_cost, shared_wallet_cost AS shared_wallet_cost, 0.02 AS media_rebate_rate FROM bill_details b LEFT JOIN ( SELECT module, media, ad.advertiser_id as advertiser_id, advertiser_name, distributor, promotion_id, app_name, book_id, book_name, region, optimizer_id, optimizer_name FROM ( SELECT advertiser_id, max(promotion_id) as max_promotion_id FROM account_distributor_promotion_url GROUP BY advertiser_id ) ad LEFT JOIN ( SELECT module, media, advertiser_id, advertiser_name, book_id, book_name, distributor, promotion_id, app_name, region, optimizer_id, optimizer_name, dpu_create_time FROM account_distributor_promotion_url ) adl ON ad.advertiser_id = adl.advertiser_id AND ad.max_promotion_id = adl.promotion_id ) ac ON b.advertiser_id = ac.advertiser_id"
	db := dorisdb.DorisClient()
	err := db.Raw(bill).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggProjectFinalBillEntity 保存项目扣减数据
func (d *ReportDataDao) BuildAggProjectFinalBillEntity(date string) error {
	var data []repo.ProjectReportDataViewEntity
	bill := "SELECT SUBSTR(search_date, 1, 10) AS date, 0 AS `hour`, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then '端原生' else '抖小' end AS media, 2 AS data_type, '1' AS pay_type,  '0' AS project_id, '0' AS mid_id,  b.advertiser_id AS account_id,  reward_cost AS reward_cost, shared_wallet_cost AS shared_wallet_cost, 0.02 AS media_rebate_rate FROM ( SELECT * FROM bill_details WHERE date(search_date) = '" + date + "') b  LEFT JOIN ( SELECT advertiser_id, min(delivery_product) as delivery_product, min(delivery_medium) as delivery_medium FROM project_info GROUP BY advertiser_id ) p ON b.advertiser_id = p.advertiser_id WHERE reward_cost > 0 OR shared_wallet_cost > 0 "
	db := dorisdb.DorisClient()
	err := db.Raw(bill).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeProjectFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggReplenishFinalBillEntity 保存补充扣减数据
func (d *ReportDataDao) BuildAggReplenishFinalBillEntity(date string) error {
	var data []repo.ProjectReportDataViewEntity
	bill := "SELECT SUBSTR(search_date, 1, 10) AS date, 0 AS `hour`, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then '端原生' else '抖小' end AS media, 2 AS data_type, '1' AS pay_type,  '0' AS project_id, '0' AS mid_id,  b.advertiser_id AS account_id,  reward_cost AS reward_cost, shared_wallet_cost AS shared_wallet_cost, 0.02 AS media_rebate_rate FROM ( SELECT * FROM bill_details WHERE date(search_date) = '" + date + "') b  LEFT JOIN ( SELECT advertiser_id, min(delivery_product) as delivery_product, min(delivery_medium) as delivery_medium FROM project_info GROUP BY advertiser_id ) p ON b.advertiser_id = p.advertiser_id WHERE reward_cost > 0 OR shared_wallet_cost > 0 "
	db := dorisdb.DorisClient()
	err := db.Raw(bill).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeProjectFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggHasCostAndIncomeFinalEntityData 按时间刷新数据 有消耗有收入 按照账号ID和推广链接ID关联
func (d *ReportDataDao) BuildAggHasCostAndIncomeFinalEntityData(queryDate string) error {
	var data []repo.ReportDataViewEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	partition := "p" + strings.Replace(queryDate, "-", "", -1)
	ac := "SELECT module, media, ad.advertiser_id, advertiser_name, distributor, ad.promotion_id, app_name, book_id, book_name, region, optimizer_id, optimizer_name FROM ( SELECT advertiser_id, promotion_id, max(dpu_create_time) as max_created_at FROM account_distributor_promotion_url GROUP BY advertiser_id, distributor, promotion_id ) ad LEFT JOIN ( SELECT module, media, advertiser_id, advertiser_name, book_id, book_name, distributor, promotion_id, app_name, region, optimizer_id, optimizer_name, dpu_create_time FROM account_distributor_promotion_url ) adl ON ad.advertiser_id = adl.advertiser_id  AND ad.promotion_id = adl.promotion_id AND ad.max_created_at = adl.dpu_create_time "
	ad := "SELECT search_date, search_hour, promotion_id, advertiser_id, project_id, project_name, promotion_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, referral_id, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM cost_income_table " + adWhere + " AND promotion_id != '' AND income != 0"
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, media AS media, region AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, advertiser_name AS account_name, CASE WHEN project_id = '' THEN '0' ELSE project_id END AS project_id, project_name AS project_name, CASE WHEN t.promotion_id = '' THEN '0' ELSE t.promotion_id END AS promotion_id, promotion_name AS promotion_name, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id AND t.referral_id = ac.promotion_id "
	db := dorisdb.DorisClient()
	q := db.Table(repo.ReportDataViewTableName())
	err := q.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	// 执行删除当日或历史数据
	deleteSql := "ALTER TABLE roi_report_hourly DROP PARTITION IF EXISTS " + partition
	_ = db.Exec(deleteSql).Error
	err = d.InsertBatchSizeFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggHasCostNoIncomeFinalEntityData 按时间刷新数据 有消耗有无收入 按账号ID关联
func (d *ReportDataDao) BuildAggHasCostNoIncomeFinalEntityData(queryDate string) error {
	var data []repo.ReportDataViewEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	ac := "SELECT module, media, ad.advertiser_id, advertiser_name, distributor, promotion_id, app_name, book_id, book_name, region, optimizer_id, optimizer_name FROM ( SELECT advertiser_id, max(promotion_id) as max_promotion_id FROM account_distributor_promotion_url GROUP BY advertiser_id ) ad LEFT JOIN ( SELECT module, media, advertiser_id, advertiser_name, book_id, book_name, distributor, promotion_id, app_name, region, optimizer_id, optimizer_name, dpu_create_time FROM account_distributor_promotion_url ) adl ON ad.advertiser_id = adl.advertiser_id AND ad.max_promotion_id = adl.promotion_id "
	ad := "SELECT search_date, search_hour, promotion_id, advertiser_id, project_id, project_name, promotion_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, referral_id, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM cost_income_table " + adWhere + " AND promotion_id != '' AND income = 0 "
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, media AS media, region AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, advertiser_name AS account_name, CASE WHEN project_id = '' THEN '0' ELSE project_id END AS project_id, project_name AS project_name, CASE WHEN t.promotion_id = '' THEN '0' ELSE t.promotion_id END AS promotion_id, promotion_name AS promotion_name, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id"
	db := dorisdb.DorisClient()
	q := db.Table(repo.ReportDataViewTableName())
	err := q.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggNoCostFinalEntityData 保存无收入的实际数据 按账号ID关联
func (d *ReportDataDao) BuildAggNoCostFinalEntityData(queryDate string) error {
	var data []repo.ReportDataViewEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	ac := "SELECT module, media, ad.advertiser_id, advertiser_name, distributor, promotion_id, app_name, book_id, book_name, region, optimizer_id, optimizer_name FROM ( SELECT advertiser_id, max(promotion_id) as max_promotion_id FROM account_distributor_promotion_url GROUP BY advertiser_id ) ad LEFT JOIN ( SELECT module, media, advertiser_id, advertiser_name, book_id, book_name, distributor, promotion_id, app_name, region, optimizer_id, optimizer_name, dpu_create_time FROM account_distributor_promotion_url ) adl ON ad.advertiser_id = adl.advertiser_id AND ad.max_promotion_id = adl.promotion_id "
	ad := "SELECT search_date, search_hour, '' as promotion_id, advertiser_id, '' as project_id, '' as project_name, '' as promotion_name, sum(show_cnt) as show_cnt, sum(click) as click, sum(active) as active, sum(active_pay) as active_pay, sum(cost) as cost, sum(convert_cnt) as convert_cnt, sum(new_income) as new_income, sum(income) as income, max(new_pay_user) as new_pay_user, max(pay_user) as pay_user, '' as referral_id, max(new_user) as new_user, max(acc_income) as acc_income, max(acc_2day_income) as acc_2day_income, max(acc_3day_income) as acc_3day_income, max(acc_4day_income) as acc_4day_income, max(acc_5day_income) as acc_5day_income, max(acc_6day_income) as acc_6day_income, max(acc_7day_income) as acc_7day_income FROM cost_income_table " + adWhere + " AND promotion_id = '' GROUP BY search_date, search_hour, advertiser_id"
	//ad := "SELECT search_date, search_hour, promotion_id, advertiser_id, project_id, project_name, promotion_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, referral_id, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM cost_income_table " + adWhere + " AND income = 0 "
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, media AS media, region AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2' END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, advertiser_name AS account_name, CASE WHEN project_id = '' THEN '0' ELSE project_id END AS project_id, project_name AS project_name, CASE WHEN t.promotion_id = '' THEN '0' ELSE t.promotion_id END AS promotion_id, promotion_name AS promotion_name, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id "
	db := dorisdb.DorisClient()
	q := db.Table(repo.ReportDataViewTableName())
	err := q.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

/********************************        当日/历史 ROI 分离       ********************************/

// BuildAggHasCostAndIncomeFinalEntityDataToday 按时间刷新数据 有消耗有收入 按照账号ID和推广链接ID关联
func (d *ReportDataDao) BuildAggHasCostAndIncomeFinalEntityDataToday(queryDate string) error {
	var data []repo.ReportDataViewEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	ac := "SELECT module, media, ad.advertiser_id, advertiser_name, distributor, ad.promotion_id, app_name, book_id, book_name, region, optimizer_id, optimizer_name FROM ( SELECT advertiser_id, promotion_id, max(dpu_create_time) as max_created_at FROM account_distributor_promotion_url GROUP BY advertiser_id, distributor, promotion_id ) ad LEFT JOIN ( SELECT module, media, advertiser_id, advertiser_name, book_id, book_name, distributor, promotion_id, app_name, region, optimizer_id, optimizer_name, dpu_create_time FROM account_distributor_promotion_url ) adl ON ad.advertiser_id = adl.advertiser_id  AND ad.promotion_id = adl.promotion_id AND ad.max_created_at = adl.dpu_create_time "
	ad := "SELECT search_date, search_hour, promotion_id, advertiser_id, project_id, project_name, promotion_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, referral_id, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM cost_income_table " + adWhere + " AND promotion_id != '' AND income != 0"
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, media AS media, region AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, advertiser_name AS account_name, CASE WHEN project_id = '' THEN '0' ELSE project_id END AS project_id, project_name AS project_name, CASE WHEN t.promotion_id = '' THEN '0' ELSE t.promotion_id END AS promotion_id, promotion_name AS promotion_name, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id AND t.referral_id = ac.promotion_id "
	db := dorisdb.DorisClient()
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeFinalTableToday(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggHasCostNoIncomeFinalEntityDataToday 按时间刷新数据 有消耗有无收入 按账号ID关联
func (d *ReportDataDao) BuildAggHasCostNoIncomeFinalEntityDataToday(queryDate string) error {
	var data []repo.ReportDataViewEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	ac := "SELECT module, media, ad.advertiser_id, advertiser_name, distributor, promotion_id, app_name, book_id, book_name, region, optimizer_id, optimizer_name FROM ( SELECT advertiser_id, max(promotion_id) as max_promotion_id FROM account_distributor_promotion_url GROUP BY advertiser_id ) ad LEFT JOIN ( SELECT module, media, advertiser_id, advertiser_name, book_id, book_name, distributor, promotion_id, app_name, region, optimizer_id, optimizer_name, dpu_create_time FROM account_distributor_promotion_url ) adl ON ad.advertiser_id = adl.advertiser_id AND ad.max_promotion_id = adl.promotion_id "
	ad := "SELECT search_date, search_hour, promotion_id, advertiser_id, project_id, project_name, promotion_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, referral_id, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM cost_income_table " + adWhere + " AND promotion_id != '' AND income = 0 "
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, media AS media, region AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, advertiser_name AS account_name, CASE WHEN project_id = '' THEN '0' ELSE project_id END AS project_id, project_name AS project_name, CASE WHEN t.promotion_id = '' THEN '0' ELSE t.promotion_id END AS promotion_id, promotion_name AS promotion_name, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id"
	db := dorisdb.DorisClient()
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeFinalTableToday(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggNoCostFinalEntityDataToday 保存无收入的实际数据 按账号ID关联
func (d *ReportDataDao) BuildAggNoCostFinalEntityDataToday(queryDate string) error {
	var data []repo.ReportDataViewEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	ac := "SELECT module, media, ad.advertiser_id, advertiser_name, distributor, promotion_id, app_name, book_id, book_name, region, optimizer_id, optimizer_name FROM ( SELECT advertiser_id, max(promotion_id) as max_promotion_id FROM account_distributor_promotion_url GROUP BY advertiser_id ) ad LEFT JOIN ( SELECT module, media, advertiser_id, advertiser_name, book_id, book_name, distributor, promotion_id, app_name, region, optimizer_id, optimizer_name, dpu_create_time FROM account_distributor_promotion_url ) adl ON ad.advertiser_id = adl.advertiser_id AND ad.max_promotion_id = adl.promotion_id "
	ad := "SELECT search_date, search_hour, '' as promotion_id, advertiser_id, '' as project_id, '' as project_name, '' as promotion_name, sum(show_cnt) as show_cnt, sum(click) as click, sum(active) as active, sum(active_pay) as active_pay, sum(cost) as cost, sum(convert_cnt) as convert_cnt, sum(new_income) as new_income, sum(income) as income, max(new_pay_user) as new_pay_user, max(pay_user) as pay_user, '' as referral_id, max(new_user) as new_user, max(acc_income) as acc_income, max(acc_2day_income) as acc_2day_income, max(acc_3day_income) as acc_3day_income, max(acc_4day_income) as acc_4day_income, max(acc_5day_income) as acc_5day_income, max(acc_6day_income) as acc_6day_income, max(acc_7day_income) as acc_7day_income FROM cost_income_table " + adWhere + " AND promotion_id = '' GROUP BY search_date, search_hour, advertiser_id"
	//ad := "SELECT search_date, search_hour, promotion_id, advertiser_id, project_id, project_name, promotion_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, referral_id, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM cost_income_table " + adWhere + " AND income = 0 "
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, media AS media, region AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2' END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, advertiser_name AS account_name, CASE WHEN project_id = '' THEN '0' ELSE project_id END AS project_id, project_name AS project_name, CASE WHEN t.promotion_id = '' THEN '0' ELSE t.promotion_id END AS promotion_id, promotion_name AS promotion_name, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id "
	db := dorisdb.DorisClient()
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeFinalTableToday(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// SwapTable 原子交换表数据
func (d *ReportDataDao) SwapTable() error {
	db := dorisdb.DorisClient()
	swapSql := "ALTER TABLE `roi_report_hourly_today_temp` SWAP WITH `roi_report_hourly_today`"
	err := db.Exec(swapSql).Error
	if err != nil {
		return err
	}
	// 清空临时表
	truncateSql := "TRUNCATE TABLE `roi_report_hourly_today_temp`"
	err = db.Exec(truncateSql).Error
	if err != nil {
		return err
	}
	return nil
}

// ExecTimetable 最终关联数据时间表
func (d *ReportDataDao) ExecTimetable(execTime string) error {
	db := dorisdb.DorisClient()
	insertSql := "INSERT INTO merge_exec_time (`exec_time`) VALUES ('" + execTime + "')"
	err := db.Exec(insertSql).Error
	if err != nil {
		return err
	}
	return nil
}

// ProjectExecTimetable 最终关联数据时间表
func (d *ReportDataDao) ProjectExecTimetable(execTime string) error {
	db := dorisdb.DorisClient()
	insertSql := "INSERT INTO project_merge_exec_time (`exec_time`) VALUES ('" + execTime + "')"
	err := db.Exec(insertSql).Error
	if err != nil {
		return err
	}
	return nil
}

// InsertBatchSizeFinalTableToday 插入更新最总报表数据
func (d *ReportDataDao) InsertBatchSizeFinalTableToday(data []repo.ReportDataViewEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsertFinalDateToday(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (d *ReportDataDao) batchInsertFinalDateToday(tx *gorm.DB, data []repo.ReportDataViewEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + "roi_report_hourly_today_temp" + " ( `date`, `hour`, media, region, pay_type, app_id, app_name, book_id, book_name, optimizer_id, optimizer_nickname, account_id, account_name, project_id, project_name, promotion_id, promotion_name, data_type, media_cost, reward_cost, shared_wallet_cost, media_rebate_rate, show_count, click_count, media_active_count, media_convert_count, media_first_pay_count, income, active_count, new_pay_count, active_pay_count, first_income, new_sum_income, income2, income3, income4, income5, income6, income7 )  VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.Date,
			v.Hour,
			v.Media,
			v.Region,
			v.PayType,
			v.AppID,
			v.AppName,
			v.BookID,
			v.BookName,
			v.OptimizerID,
			v.OptimizerNickname,
			v.AccountID,
			v.AccountName,
			v.ProjectID,
			v.ProjectName,
			v.PromotionID,
			v.PromotionName,
			v.DataType,
			v.MediaCost,
			v.RewardCost,
			v.SharedWalletCost,
			v.MediaRebateRate,
			v.ShowCount,
			v.ClickCount,
			v.MediaActiveCount,
			v.MediaConvertCount,
			v.MediaFirstPayCount,
			v.Income,
			v.ActiveCount,
			v.NewPayCount,
			v.ActivePayCount,
			v.FirstIncome,
			v.NewSumIncome,
			v.Income2,
			v.Income3,
			v.Income4,
			v.Income5,
			v.Income6,
			v.Income7,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

/******************************************      项目级插入        ******************************************/

// InsertBatchSizeProjectFinalTable 插入更新最总报表数据
func (d *ReportDataDao) InsertBatchSizeProjectFinalTable(data []repo.ProjectReportDataViewEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsertProjectFinalDate(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (d *ReportDataDao) batchInsertProjectFinalDate(tx *gorm.DB, data []repo.ProjectReportDataViewEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + repo.ProjectReportDataViewTableName() + " ( `date`, `hour`, media, region, pay_type, app_id, app_name, book_id, book_name, optimizer_id, optimizer_nickname, account_id, account_name, project_id, project_name, delivery_product, data_type, media_cost, reward_cost, shared_wallet_cost, media_rebate_rate, show_count, click_count, media_active_count, media_convert_count, media_first_pay_count, income, active_count, new_pay_count, active_pay_count, first_income, new_sum_income, income2, income3, income4, income5, income6, income7, copyright_owner )  VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.Date,
			v.Hour,
			v.Media,
			v.Region,
			v.PayType,
			v.AppID,
			v.AppName,
			v.BookID,
			v.BookName,
			v.OptimizerID,
			v.OptimizerNickname,
			v.AccountID,
			v.AccountName,
			v.ProjectID,
			v.ProjectName,
			v.DeliveryProduct,
			v.DataType,
			v.MediaCost,
			v.RewardCost,
			v.SharedWalletCost,
			v.MediaRebateRate,
			v.ShowCount,
			v.ClickCount,
			v.MediaActiveCount,
			v.MediaConvertCount,
			v.MediaFirstPayCount,
			v.Income,
			v.ActiveCount,
			v.NewPayCount,
			v.ActivePayCount,
			v.FirstIncome,
			v.NewSumIncome,
			v.Income2,
			v.Income3,
			v.Income4,
			v.Income5,
			v.Income6,
			v.Income7,
			v.CopyRightOwner,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// InsertBatchSizeProjectFinalTableToday 插入更新最总报表数据
func (d *ReportDataDao) InsertBatchSizeProjectFinalTableToday(data []repo.ProjectReportDataViewEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = d.batchInsertProjectFinalDateToday(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

func (d *ReportDataDao) batchInsertProjectFinalDateToday(tx *gorm.DB, data []repo.ProjectReportDataViewEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + "roi_project_hourly_today_temp" + " ( `date`, `hour`, media, region, pay_type, app_id, app_name, book_id, book_name, optimizer_id, optimizer_nickname, account_id, account_name, project_id, project_name, delivery_product, data_type, media_cost, reward_cost, shared_wallet_cost, media_rebate_rate, show_count, click_count, media_active_count, media_convert_count, media_first_pay_count, income, active_count, new_pay_count, active_pay_count, first_income, new_sum_income, income2, income3, income4, income5, income6, income7, copyright_owner )  VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.Date,
			v.Hour,
			v.Media,
			v.Region,
			v.PayType,
			v.AppID,
			v.AppName,
			v.BookID,
			v.BookName,
			v.OptimizerID,
			v.OptimizerNickname,
			v.AccountID,
			v.AccountName,
			v.ProjectID,
			v.ProjectName,
			v.DeliveryProduct,
			v.DataType,
			v.MediaCost,
			v.RewardCost,
			v.SharedWalletCost,
			v.MediaRebateRate,
			v.ShowCount,
			v.ClickCount,
			v.MediaActiveCount,
			v.MediaConvertCount,
			v.MediaFirstPayCount,
			v.Income,
			v.ActiveCount,
			v.NewPayCount,
			v.ActivePayCount,
			v.FirstIncome,
			v.NewSumIncome,
			v.Income2,
			v.Income3,
			v.Income4,
			v.Income5,
			v.Income6,
			v.Income7,
			v.CopyRightOwner,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}

// GetLastExecTime 获取最后的更新时间
func (d *ReportDataDao) GetLastExecTime() (time.Time, error) {
	db := dorisdb.DorisClient()
	var lastUpdatedTime time.Time
	now := time.Now()
	hour := now.Hour()
	db = db.Table(repo.MergeTimeDataTableName())
	if hour == 0 {
		db = db.Where("exec_time < ?", now.Format("2006-01-02 00:00:0"))
	}
	result := db.Select("MAX(exec_time)").Row().Scan(&lastUpdatedTime)
	if result != nil {
		return time.Time{}, result
	}
	return lastUpdatedTime, nil
}

func (d *ReportDataDao) GetProjectLastExecTime() (time.Time, error) {
	db := dorisdb.DorisClient()
	var lastUpdatedTime time.Time
	now := time.Now()
	hour := now.Hour()
	db = db.Table(repo.ProjectMergeTimeDataTableName())
	if hour == 0 {
		db = db.Where("exec_time < ?", now.Format("2006-01-02 00:00:0"))
	}
	result := db.Select("MAX(exec_time)").Row().Scan(&lastUpdatedTime)
	if result != nil {
		return time.Time{}, result
	}
	return lastUpdatedTime, nil
}

func (d *ReportDataDao) todayWhereStr(accountId, bookName, media, deliveryProduct string) string {
	var whereSlice []string
	if accountId != "" {
		whereSlice = append(whereSlice, fmt.Sprintf("account_id = '%s'", accountId))
	}
	if bookName != "" {
		whereSlice = append(whereSlice, fmt.Sprintf("book_name LIKE '%s'", "%"+bookName+"%"))
	}
	if media != "" && media != repo.FilterOptionAllDesc {
		filterOptionsDao := NewFilterOptionsDao(d.Ctx)
		mediaSlice, _ := filterOptionsDao.SelectOptionEnum(ValueTypeMedia, media)
		if len(mediaSlice) > 0 {
			whereSlice = append(whereSlice, fmt.Sprintf("media in ('%s')", strings.Join(mediaSlice, "','")))
		}
	}
	if deliveryProduct != "" && deliveryProduct != repo.FilterOptionAllDesc {
		filterOptionsDao := NewFilterOptionsDao(d.Ctx)
		deliveryProductSlice, _ := filterOptionsDao.SelectOptionEnum(ValueTypeDeliveryProduct, deliveryProduct)
		if len(deliveryProductSlice) > 0 {
			whereSlice = append(whereSlice, fmt.Sprintf("delivery_product in ('%s')", strings.Join(deliveryProductSlice, "','")))
		}
	}
	whereStr := ""
	if len(whereSlice) > 0 {
		whereStr = fmt.Sprintf(" AND %s", strings.Join(whereSlice, " AND "))
	}
	return whereStr
}

func (d *ReportDataDao) TodayMarketData(params *roidto.TodayMarketDataReq) (repo.ProjectTodayMarketData, error) {
	now := time.Now()

	hour := now.Hour()
	if hour == 0 {
		midnight := time.Date(
			now.Year(),
			now.Month(),
			now.Day(),
			0, 0, 0, 0, // 0点0分0秒0纳秒
			now.Location(), // 关键：使用当前时区
		)
		now = midnight.Add(-1 * time.Second)
	}
	// 今天日期
	today := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local)
	todayStr := today.Format("2006-01-02")
	// 昨日日期
	yesterday := now.AddDate(0, 0, -1)
	yesterdayStr := yesterday.Format("2006-01-02")
	// 环比日期
	hbday := now.AddDate(0, 0, -7)
	hbddayStr := hbday.Format("2006-01-02")

	var data repo.ProjectTodayMarketData
	db := dorisdb.DorisClient()
	whereStr := d.todayWhereStr(params.Params.AccountId, params.Params.BookName, params.Params.Media, params.Params.DeliveryProduct)
	todaySql := "SELECT (SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02) as cost,0 as cost_hb,0 as cost_tb,SUM(income) as income, 0 as income_hb, 0 as income_tb, 0 as cost_hb_same, 0 as income_hb_same FROM " +
		repo.ProjectReportTodayDataViewTableName() + " WHERE date = " + "'" + todayStr + "'" + whereStr + " GROUP BY date"
	tbSql := "SELECT 0 as cost,(SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)  as cost_hb,0 as cost_tb,0 as income, SUM(income) as income_hb, 0 as income_tb, 0 as cost_hb_same, 0 as income_hb_same FROM " +
		repo.ProjectReportDataViewTableName() + " WHERE date = " + "'" + yesterdayStr + "'" + whereStr + " GROUP BY date"
	hbSql := "SELECT 0 as cost,0 as cost_hb,(SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)  as cost_tb,0 as income, 0 as income_hb, SUM(income) as income_tb, 0 as cost_hb_same, 0 as income_hb_same FROM " +
		repo.ProjectReportDataViewTableName() + " WHERE date = " + "'" + hbddayStr + "'" + whereStr + " GROUP BY date"
	//sameSql := "SELECT 0 as cost, 0 as cost_hb,0 as cost_tb,0 as income, 0 as income_hb, 0 as income_tb, (SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02) as cost_hb_same, SUM(income) as income_hb_same FROM " +
	//	repo.ProjectReportDataViewTableName() + " WHERE date = " + "'" + yesterdayStr + "'" + " and hour <= " + "" + fmt.Sprintf("%d", hour) + whereStr + " GROUP BY date"
	// + " UNION ALL " + sameSql
	sqlStr := "SELECT SUM(cost) as cost,SUM(cost_hb) as cost_hb,SUM(cost_tb) as cost_tb,SUM(income) as income,SUM(income_hb) as income_hb,SUM(income_tb) as income_tb,SUM(cost_hb_same) as cost_hb_same,SUM(income_hb_same) as income_hb_same FROM (" + todaySql + " UNION ALL " + tbSql + " UNION ALL " + hbSql + ") as t"
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return data, err
	}
	return data, nil
}

func (d *ReportDataDao) TodayTimeData(params *roidto.TodayTodayTimeDataReq) ([]repo.ProjectTodayTimeData, error) {
	now := time.Now()
	// 今天日期
	today := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local)
	todayStr := today.Format("2006-01-02")
	whereStr := d.todayWhereStr(params.Params.AccountId, params.Params.BookName, params.Params.Media, params.Params.DeliveryProduct)
	var data []repo.ProjectTodayTimeData
	db := dorisdb.DorisClient()
	todaySql := "SELECT hour," +
		"((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)) AS cost," +
		"(SUM(income)-((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02))) AS profit," +
		"(SUM(income)/((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02))) AS roi," +
		"IF(SUM(show_count)> 0, ((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02))/ SUM(show_count),0) AS show_cost FROM " +
		repo.ProjectReportTodayDataViewTableName() + " WHERE date = " + "'" + todayStr + "'" + whereStr + " GROUP BY hour "

	order := "ORDER BY hour desc"
	if params.Source == 1 {
		order = "ORDER BY hour desc"
	} else {
		order = "ORDER BY hour asc"
	}
	sqlStr := todaySql + order

	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return data, err
	}
	return data, nil
}

func (d *ReportDataDao) TodayTotalData(params *roidto.TodayTodayTimeDataReq) (repo.ProjectTodayTotalData, error) {
	now := time.Now()
	hour := now.Hour()
	if hour == 0 {
		midnight := time.Date(
			now.Year(),
			now.Month(),
			now.Day(),
			0, 0, 0, 0, // 0点0分0秒0纳秒
			now.Location(), // 关键：使用当前时区
		)
		now = midnight.Add(-1 * time.Second)
	}
	// 今天日期
	today := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local)
	todayStr := today.Format("2006-01-02")
	whereStr := d.todayWhereStr(params.Params.AccountId, params.Params.BookName, params.Params.Media, params.Params.DeliveryProduct)
	var data repo.ProjectTodayTotalData
	db := dorisdb.DorisClient()
	todaySql := "SELECT " +
		"((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)) AS cost," +
		"(SUM(income)-((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02))) AS profit," +
		"(SUM(income)/((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02))) AS roi," +
		"IF(SUM(show_count)> 0, ((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02))/ SUM(show_count),0) AS show_cost FROM " +
		repo.ProjectReportTodayDataViewTableName() + " WHERE date = " + "'" + todayStr + "'" + whereStr

	sqlStr := todaySql
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return data, err
	}
	return data, nil
}

func (d *ReportDataDao) TodayBookRankingData(params *roidto.TodayBookRankingDataReq) ([]repo.ProjectTodayBookRankingData, error) {
	now := time.Now()
	hour := now.Hour()
	if hour == 0 {
		midnight := time.Date(
			now.Year(),
			now.Month(),
			now.Day(),
			0, 0, 0, 0, // 0点0分0秒0纳秒
			now.Location(), // 关键：使用当前时区
		)
		now = midnight.Add(-1 * time.Second)
	}
	// 今天日期
	today := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local)
	todayStr := today.Format("2006-01-02")
	whereStr := d.todayWhereStr(params.Params.AccountId, params.Params.BookName, params.Params.Media, params.Params.DeliveryProduct)
	var data []repo.ProjectTodayBookRankingData
	db := dorisdb.DorisClient()
	todaySql := "SELECT book_name,book_id," + // 短剧名称/ID
		"((SUM(media_cost) - SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)) AS cost," + // 实际消耗
		"SUM(media_cost) AS total_cost," + // 消耗
		"(SUM(income)-((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02))) AS profit," + // 实际利润=实际收入-实际消耗  income-cost
		"(SUM(income)/((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)))  AS roi " + // 实际roi=实际收入/实际消耗
		" FROM " + repo.ProjectReportTodayDataViewTableName() + " WHERE book_name != '' and date = " + "'" + todayStr + "'" + whereStr + " GROUP BY book_name,book_id "

	order := "ORDER BY cost desc limit 100"
	sqlStr := todaySql + order
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return data, err
	}
	return data, nil
}

func (d *ReportDataDao) TodayRegionRankingData(params *roidto.TodayRegionRankingReq) ([]repo.ProjectTodayRegionData, error) {
	now := time.Now()
	hour := now.Hour()
	if hour == 0 {
		midnight := time.Date(
			now.Year(),
			now.Month(),
			now.Day(),
			0, 0, 0, 0, // 0点0分0秒0纳秒
			now.Location(), // 关键：使用当前时区
		)
		now = midnight.Add(-1 * time.Second)
	}
	// 今天日期
	today := time.Date(now.Year(), now.Month(), now.Day(), 0, 0, 0, 0, time.Local)
	todayStr := today.Format("2006-01-02")
	whereStr := d.todayWhereStr(params.Params.AccountId, params.Params.BookName, params.Params.Media, params.Params.DeliveryProduct)
	var data []repo.ProjectTodayRegionData
	db := dorisdb.DorisClient()
	todaySql := "SELECT IF(region='','其他',region) AS region," + // 地区
		"((SUM(media_cost) - SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)) AS cost," + // 实际消耗
		"SUM(media_cost) AS total_cost," + // 消耗
		"(SUM(income)-((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02))) AS profit," + // 实际利润=实际收入-实际消耗  income-cost
		"(SUM(income)/((SUM(media_cost)- SUM(reward_cost)- SUM(shared_wallet_cost))/(1.0 + 0.02)))  AS roi " + // 实际roi=实际收入/实际消耗
		" FROM " + repo.ProjectReportTodayDataViewTableName() + " WHERE date = " + "'" + todayStr + "'" + whereStr + " GROUP BY region "

	order := "ORDER BY cost desc limit 100"
	sqlStr := todaySql + order
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return data, err
	}
	return data, nil
}

/******************************************      项目级数据更新        ******************************************/

// BuildAggHasCostAndIncomeProjectFinalEntityData 按时间刷新数据 有消耗有收入 按照账号ID和推广链接ID关联
func (d *ReportDataDao) BuildAggHasCostAndIncomeProjectFinalEntityData(queryDate string) error {
	var data []repo.ProjectReportDataViewEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	partition := "p" + strings.Replace(queryDate, "-", "", -1)
	ac := "SELECT pu.advertiser_id, project_id, n.advertiser_name, n.media, re.optimizer_city_name, app_name, promotion_id, promotion_url, optimizer_id, dpu.optimizer_name, book_id, book_name FROM ( SELECT advertiser_id, project_id, `code` FROM promotion_url_info GROUP BY advertiser_id, project_id, `code`) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url, app_name, promotion_name, optimizer_id, optimizer_name, book_id, book_name FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url LEFT JOIN ( SELECT advertiser_id, advertiser_name, media FROM oauth_account ) n ON pu.advertiser_id = n.advertiser_id LEFT JOIN ( SELECT optimizer_name, optimizer_city_name FROM ( SELECT optimizer_id, optimizer_name FROM optimizer ) op LEFT JOIN ( SELECT optimizer_id, optimizer_city_id FROM optimizer_city_relation ) re ON op.optimizer_id = re.optimizer_id LEFT JOIN ( SELECT optimizer_city_id, optimizer_city_name FROM optimizer_city ) c ON re.optimizer_city_id = c.optimizer_city_id ) re ON dpu.optimizer_name = re.optimizer_name"
	ad := "SELECT search_date, search_hour, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, referral_id, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM project_cost_income " + adWhere + " AND project_id != '' AND income != 0"
	projectInfo := "SELECT advertiser_id, project_id, delivery_product FROM project_info"
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, ac.media AS media, optimizer_city_name AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, ac.advertiser_name AS account_name, CASE WHEN t.project_id = '' THEN '0' ELSE t.project_id END AS project_id, project_name AS project_name, delivery_product AS delivery_product, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN (" + projectInfo + ") inf ON t.advertiser_id = inf.advertiser_id AND t.project_id = inf.project_id LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id AND t.project_id = ac.project_id AND t.referral_id = ac.promotion_id "
	db := dorisdb.DorisClient()
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	// 执行删除当日或历史数据
	deleteSql := "ALTER TABLE roi_project_hourly DROP PARTITION IF EXISTS " + partition
	_ = db.Exec(deleteSql).Error
	err = d.InsertBatchSizeProjectFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggHasCostNoIncomeProjectFinalEntityData 按时间刷新数据 有消耗有无收入 按账号ID关联
func (d *ReportDataDao) BuildAggHasCostNoIncomeProjectFinalEntityData(queryDate string) error {
	var data []repo.ProjectReportDataViewEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	ac := "SELECT pu.advertiser_id, min(project_id) as project_id, n.advertiser_name, min(n.media) as media, min(optimizer_id) as optimizer_id, min(re.optimizer_city_name) as optimizer_city_name, min(app_name) as app_name, min(dpu.optimizer_name) as optimizer_name, min(book_id) as book_id, min(book_name) as book_name FROM ( SELECT advertiser_id, project_id, `code` FROM promotion_url_info GROUP BY advertiser_id, project_id, `code`) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url, app_name, promotion_name, optimizer_id, optimizer_name, book_id, book_name FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url LEFT JOIN ( SELECT advertiser_id, advertiser_name, media FROM oauth_account ) n ON pu.advertiser_id = n.advertiser_id LEFT JOIN ( SELECT optimizer_name, optimizer_city_name FROM ( SELECT optimizer_id, optimizer_name FROM optimizer ) op LEFT JOIN ( SELECT optimizer_id, optimizer_city_id FROM optimizer_city_relation ) re ON op.optimizer_id = re.optimizer_id LEFT JOIN ( SELECT optimizer_city_id, optimizer_city_name FROM optimizer_city ) c ON re.optimizer_city_id = c.optimizer_city_id ) re ON dpu.optimizer_name = re.optimizer_name GROUP BY pu.advertiser_id, n.advertiser_name"
	ad := "SELECT search_date, search_hour, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt, new_income, income, new_pay_user, pay_user, referral_id, new_user, acc_income, acc_2day_income, acc_3day_income, acc_4day_income, acc_5day_income, acc_6day_income, acc_7day_income FROM project_cost_income " + adWhere + " AND project_id != '' AND income = 0 "
	projectInfo := "SELECT advertiser_id, project_id, delivery_product FROM project_info"
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, ac.media AS media, optimizer_city_name AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, ac.advertiser_name AS account_name, CASE WHEN t.project_id = '' THEN '0' ELSE t.project_id END AS project_id, project_name AS project_name, delivery_product AS delivery_product, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN (" + projectInfo + ") inf ON t.advertiser_id = inf.advertiser_id AND t.project_id = inf.project_id LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id"
	db := dorisdb.DorisClient()
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeProjectFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggNoCostProjectFinalEntityData 保存无收入的实际数据 按账号ID关联
func (d *ReportDataDao) BuildAggNoCostProjectFinalEntityData(queryDate string) error {
	var data []repo.ProjectReportDataViewEntity
	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
	ac := "SELECT pu.advertiser_id, min(project_id) as project_id, n.advertiser_name, min(n.media) as media, min(optimizer_id) as optimizer_id, min(re.optimizer_city_name) as optimizer_city_name, min(app_name) as app_name, min(dpu.optimizer_name) as optimizer_name, min(book_id) as book_id, min(book_name) as book_name FROM ( SELECT advertiser_id, project_id, `code` FROM promotion_url_info GROUP BY advertiser_id, project_id, `code`) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url, app_name, promotion_name, optimizer_id, optimizer_name, book_id, book_name FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url LEFT JOIN ( SELECT advertiser_id, advertiser_name, media FROM oauth_account ) n ON pu.advertiser_id = n.advertiser_id LEFT JOIN ( SELECT optimizer_name, optimizer_city_name FROM ( SELECT optimizer_id, optimizer_name FROM optimizer ) op LEFT JOIN ( SELECT optimizer_id, optimizer_city_id FROM optimizer_city_relation ) re ON op.optimizer_id = re.optimizer_id LEFT JOIN ( SELECT optimizer_city_id, optimizer_city_name FROM optimizer_city ) c ON re.optimizer_city_id = c.optimizer_city_id ) re ON dpu.optimizer_name = re.optimizer_name GROUP BY pu.advertiser_id, n.advertiser_name"
	ad := "SELECT search_date, search_hour,  advertiser_id, '' as project_id, '' as project_name, sum(show_cnt) as show_cnt, sum(click) as click, sum(active) as active, sum(active_pay) as active_pay, sum(cost) as cost, sum(convert_cnt) as convert_cnt, sum(new_income) as new_income, sum(income) as income, max(new_pay_user) as new_pay_user, max(pay_user) as pay_user, '' as referral_id, max(new_user) as new_user, max(acc_income) as acc_income, max(acc_2day_income) as acc_2day_income, max(acc_3day_income) as acc_3day_income, max(acc_4day_income) as acc_4day_income, max(acc_5day_income) as acc_5day_income, max(acc_6day_income) as acc_6day_income, max(acc_7day_income) as acc_7day_income FROM project_cost_income " + adWhere + " AND project_id = '' GROUP BY search_date, search_hour, advertiser_id"
	projectInfo := "SELECT advertiser_id, project_id, delivery_product FROM project_info"
	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, ac.media AS media, optimizer_city_name AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, ac.advertiser_name AS account_name, CASE WHEN t.project_id = '' THEN '0' ELSE t.project_id END AS project_id, project_name AS project_name, delivery_product AS delivery_product, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN (" + projectInfo + ") inf ON t.advertiser_id = inf.advertiser_id AND t.project_id = inf.project_id LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id "
	db := dorisdb.DorisClient()
	err := db.Raw(sqlStr).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeProjectFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

/********************************        当日/历史 ROI 分离       ********************************/

// BuildAggHasCostAndIncomeProjectFinalEntityDataToday 按时间刷新数据 有消耗有收入 按照账号ID和推广链接ID关联
func (d *ReportDataDao) BuildAggHasCostAndIncomeProjectFinalEntityDataToday(queryDate string) error {
	var data []repo.ProjectReportDataViewEntity
	orderWhere := " WHERE date(event_date) = '" + queryDate + "' "
	reportWhere := " WHERE date(search_date) = '" + queryDate + "' "
	reportSql := "SELECT date(search_date) AS search_date, search_hour, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt, stat_micro_game_0d_amount FROM report_project_hour " + reportWhere
	promotionUrlSql := "SELECT pu.advertiser_id, project_id, re.region as optimizer_city_name, app_name, promotion_id, promotion_url, optimizer_id, dpu.optimizer_name, book_id, book_name FROM ( SELECT advertiser_id, t1.project_id, t1.`code` FROM ( SELECT project_id, max(`code`) as `code` FROM  promotion_url_info GROUP BY project_id ) t1 LEFT JOIN ( SELECT advertiser_id, project_id, `code` FROM promotion_url_info GROUP BY advertiser_id, project_id, `code` ) t2 ON t1.project_id = t2.project_id AND t1.`code` = t2.`code` ) pu LEFT JOIN ( SELECT promotion_id, promotion_url, app_name, promotion_name, optimizer_id, optimizer_name, book_id, book_name FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url LEFT JOIN ( SELECT nick_name, region FROM optimizer_info_view ) re ON dpu.optimizer_name = re.nick_name "
	accountFiled := "search_date, search_hour, re.advertiser_id, re.project_id, re.project_name, app_name, promotion_id, promotion_url, optimizer_id, optimizer_name, optimizer_city_name, book_id, book_name, show_cnt, click, active, active_pay, cost, convert_cnt, stat_micro_game_0d_amount "
	accountSql := "SELECT " + accountFiled + " FROM ( " + reportSql + " ) re LEFT JOIN ( " + promotionUrlSql + " ) pr ON re.advertiser_id = pr.advertiser_id AND re.project_id = pr.project_id "
	projectInfo := "SELECT pr.advertiser_id, pr.project_id, delivery_product, delivery_medium, `name`, copyright_owner, pr.product_id FROM ( SELECT advertiser_id, project_id, delivery_product, delivery_medium, CAST(related_product->'product_id' as CHAR) as product_id, CAST(related_product->'product_platform_id' as CHAR) as product_platform_id  FROM project_info ) pr LEFT JOIN ( SELECT advertiser_id, product_id, platform_id, `name`, copyright_owner FROM product_info ) pi ON pr.advertiser_id = pi.advertiser_id AND pr.product_id = pi.product_id AND pr.product_platform_id = pi.platform_id "
	rawInfo := "SELECT advertiser_id, project_id, book_name, copyright_owner FROM ( SELECT advertiser_id, project_id, max(hash_res) as hash_res FROM promotion_url_info  WHERE hash_res != '' GROUP BY advertiser_id, project_id ) pui LEFT JOIN ( SELECT  hash_id, book_name, copyright_owner FROM raw_referral_config ) rrc ON pui.hash_res = rrc.hash_id"
	accountInfo := "SELECT advertiser_id, advertiser_name, nick_name, region, user_id FROM ( SELECT advertiser_id, advertiser_name, SUBSTRING_INDEX(advertiser_name, '-', 1) as sname, user_id FROM oauth_account ) oa LEFT JOIN ( SELECT nick_name, region FROM optimizer_info_view ) ov ON oa.sname = ov.nick_name"
	orderSql := "SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, SUM(CASE WHEN o.event_date = o.register_date THEN o.income END) AS new_income, SUM(o.income) AS income, COUNT(DISTINCT CASE WHEN o.event_date = o.register_date THEN o.device_id END) AS new_pay_user, COUNT(DISTINCT o.device_id) AS pay_user, u.project_id, o.referral_id as referral_id FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + orderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id, t2.referral_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(buying_timestamp) as buying_hour, promotion_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), promotion_id ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, buying_timestamp AS buying_hour, project_id, promotion_id AS referral_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), buying_timestamp, project_id, promotion_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date AND t1.buying_hour = t2.buying_hour and t1.promotion_id = t2.referral_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id GROUP BY o.event_date, o.event_hour, u.project_id, o.referral_id"
	userSql := "SELECT date(buying_date) AS buying_date, buying_hour, project_id, COUNT(DISTINCT device_id) AS new_user, promotion_id FROM tomato_iaa_buy GROUP BY date(buying_date), buying_hour, project_id, promotion_id "
	incomeSql := "SELECT pay_date, pay_hour, new_income, income, new_pay_user, new_user, pay_user, t1.project_id, t1.referral_id FROM ( " + orderSql + ") t1 LEFT JOIN (" + userSql + ") t2 ON t1.pay_date = t2.buying_date AND t1.pay_hour = t2.buying_hour AND t1.project_id = t2.project_id AND t1.referral_id = t2.promotion_id "
	queryFiled := "SUBSTR(search_date, 1, 10) AS date,  search_hour AS `hour`, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then '端原生' else '抖小' end as media, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then n.region else optimizer_city_name end AS region, '1' AS pay_type, '' AS app_id, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then '端原生' else app_name end  AS app_name, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME' ) OR delivery_product = 'AWEME' then 0 else book_id end  AS book_id, case when (delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then raw.book_name else ac.book_name end  AS book_name, case when delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME' then n.user_id else optimizer_id end AS optimizer_id, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME' ) or delivery_product = 'AWEME' then n.nick_name else optimizer_name end AS optimizer_nickname, ac.advertiser_id as account_id, advertiser_name as account_name, CASE WHEN ac.project_id = '' THEN '0' ELSE ac.project_id END AS project_id, project_name, delivery_product, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then stat_micro_game_0d_amount*0.98*0.9 when delivery_product = 'AWEME' AND raw.copyright_owner = '360' then  stat_micro_game_0d_amount else income end AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then stat_micro_game_0d_amount*0.98*0.9 when delivery_product = 'AWEME' AND raw.copyright_owner = '360' then  stat_micro_game_0d_amount else new_income end AS first_income, case when raw.copyright_owner != '' then raw.copyright_owner else '其他' end as copyright_owner, 0 AS new_sum_income, 0 AS income2, 0 AS income3, 0 AS income4, 0 AS income5, 0 AS income6, 0 AS income7 " // LOCATE('点众', inf.copyright_owner) > 0 then '点众' when LOCATE('掌阅', inf.copyright_owner) > 0 then '掌阅' when LOCATE('抖音视界', inf.copyright_owner) > 0 then '番茄' WHEN
	querySql := "SELECT " + queryFiled + " FROM ( " + accountSql + " ) ac LEFT JOIN ( " + projectInfo + " ) inf ON ac.advertiser_id = inf.advertiser_id AND ac.project_id = inf.project_id LEFT JOIN ( " + accountInfo + ") n ON ac.advertiser_id = n.advertiser_id LEFT JOIN ( " + rawInfo + " ) raw ON ac.advertiser_id = raw.advertiser_id AND ac.project_id = raw.project_id LEFT JOIN ( " + incomeSql + " ) inc ON ac.search_date = inc.pay_date AND ac.search_hour = inc.pay_hour AND ac.project_id = inc.project_id AND ac.promotion_id = inc.referral_id "
	db := dorisdb.DorisClient()
	err := db.Raw(querySql).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeProjectFinalTableToday(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggHasCostAndIncomeProjectFinalEntityDataToday1 test
func (d *ReportDataDao) BuildAggHasCostAndIncomeProjectFinalEntityDataToday1(queryDate string) error {
	var data []repo.ProjectReportDataViewEntity
	orderWhere := " WHERE date(event_date) = '" + queryDate + "' "
	reportWhere := " WHERE date(search_date) = '" + queryDate + "' "
	reportSql := "SELECT date(search_date) AS search_date, search_hour, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt FROM report_project_hour " + reportWhere
	promotionUrlSql := "SELECT pu.advertiser_id, project_id, n.advertiser_name, n.media, re.optimizer_city_name, app_name, promotion_id, promotion_url, optimizer_id, dpu.optimizer_name, book_id, book_name FROM ( SELECT advertiser_id, t1.project_id, t1.`code` FROM ( SELECT project_id, max(`code`) as `code` FROM  promotion_url_info GROUP BY project_id ) t1 LEFT JOIN ( SELECT advertiser_id, project_id, `code` FROM promotion_url_info GROUP BY advertiser_id, project_id, `code` ) t2 ON t1.project_id = t2.project_id AND t1.`code` = t2.`code` ) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url, app_name, promotion_name, optimizer_id, optimizer_name, book_id, book_name FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url LEFT JOIN ( SELECT advertiser_id, advertiser_name, media FROM oauth_account ) n ON pu.advertiser_id = n.advertiser_id LEFT JOIN ( SELECT optimizer_name, optimizer_city_name FROM ( SELECT optimizer_id, optimizer_name FROM optimizer ) op LEFT JOIN ( SELECT optimizer_id, optimizer_city_id FROM optimizer_city_relation ) re ON op.optimizer_id = re.optimizer_id LEFT JOIN ( SELECT optimizer_city_id, optimizer_city_name FROM optimizer_city ) c ON re.optimizer_city_id = c.optimizer_city_id ) re ON dpu.optimizer_name = re.optimizer_name "
	accountFiled := " search_date, search_hour, pr.media, re.advertiser_id, pr.advertiser_name, re.project_id, re.project_name, app_name, promotion_id, promotion_url, optimizer_id, optimizer_name, optimizer_city_name, book_id, book_name, show_cnt, click, active, active_pay, cost, convert_cnt "
	accountSql := "SELECT " + accountFiled + " FROM ( " + reportSql + " ) re LEFT JOIN ( " + promotionUrlSql + " ) pr ON re.advertiser_id = pr.advertiser_id AND re.project_id = pr.project_id "
	projectInfo := "SELECT advertiser_id, project_id, delivery_product FROM project_info"
	orderSql := "SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, SUM(CASE WHEN o.event_date = o.register_date THEN o.income END) AS new_income, SUM(o.income) AS income, COUNT(DISTINCT CASE WHEN o.event_date = o.register_date THEN o.device_id END) AS new_pay_user, COUNT(DISTINCT o.device_id) AS pay_user, u.project_id, o.referral_id as referral_id FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + orderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id, t2.referral_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(buying_timestamp) as buying_hour, promotion_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), promotion_id ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, buying_timestamp AS buying_hour, project_id, promotion_id AS referral_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), buying_timestamp, project_id, promotion_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date AND t1.buying_hour = t2.buying_hour and t1.promotion_id = t2.referral_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id GROUP BY o.event_date, o.event_hour, u.project_id, o.referral_id"
	userSql := "SELECT date(buying_date) AS buying_date, buying_hour, project_id, COUNT(DISTINCT device_id) AS new_user, promotion_id FROM tomato_iaa_buy GROUP BY date(buying_date), buying_hour, project_id, promotion_id "
	incomeSql := "SELECT pay_date, pay_hour, new_income, income, new_pay_user, new_user, pay_user, t1.project_id, t1.referral_id FROM ( " + orderSql + ") t1 LEFT JOIN (" + userSql + ") t2 ON t1.pay_date = t2.buying_date AND t1.pay_hour = t2.buying_hour AND t1.project_id = t2.project_id AND t1.referral_id = t2.promotion_id "
	queryFiled := "SUBSTR(search_date, 1, 10) AS date,  search_hour AS `hour`, media, optimizer_city_name AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' OR app_name = '白解星剧' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, ac.advertiser_id as account_id, advertiser_name as account_name, CASE WHEN ac.project_id = '' THEN '0' ELSE ac.project_id END AS project_id, project_name, delivery_product, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, 0 AS new_sum_income, 0 AS income2, 0 AS income3, 0 AS income4, 0 AS income5, 0 AS income6, 0 AS income7"
	querySql := "SELECT " + queryFiled + " FROM ( " + accountSql + " ) ac LEFT JOIN ( " + projectInfo + " ) inf ON ac.advertiser_id = inf.advertiser_id AND ac.project_id = inf.project_id LEFT JOIN ( " + incomeSql + " ) inc ON ac.search_date = inc.pay_date AND ac.search_hour = inc.pay_hour AND ac.project_id = inc.project_id AND ac.promotion_id = inc.referral_id "
	db := dorisdb.DorisClient()
	err := db.Raw(querySql).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeProjectFinalTableToday(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

// BuildAggHasCostNoIncomeProjectFinalEntityDataToday 按时间刷新数据 有消耗有无收入 按账号ID关联
func (d *ReportDataDao) BuildAggHasCostNoIncomeProjectFinalEntityDataToday(queryDate string) error {
	var data []repo.ProjectReportDataViewEntity
	orderWhere := " WHERE date(event_date) = '" + queryDate + "' "
	reportWhere := " WHERE date(search_date) = '" + queryDate + "' "
	orderSql := "SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, SUM(CASE WHEN o.event_date = o.register_date THEN o.income END) AS new_income, SUM(o.income) AS income, COUNT(DISTINCT CASE WHEN o.event_date = o.register_date THEN o.device_id END) AS new_pay_user, COUNT(DISTINCT o.device_id) AS pay_user, u.project_id, o.referral_id as referral_id FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + orderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id, t2.referral_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(buying_timestamp) as buying_hour, promotion_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), promotion_id ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, buying_timestamp AS buying_hour, project_id, promotion_id AS referral_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), buying_timestamp, project_id, promotion_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date AND t1.buying_hour = t2.buying_hour and t1.promotion_id = t2.referral_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id GROUP BY o.event_date, o.event_hour, u.project_id, o.referral_id"
	userSql := "SELECT date(buying_date) AS buying_date, buying_hour, project_id, COUNT(DISTINCT device_id) AS new_user, promotion_id FROM tomato_iaa_buy GROUP BY date(buying_date), buying_hour, project_id, promotion_id "
	incomeSql := "SELECT pay_date, pay_hour, new_income, income, new_pay_user, new_user, pay_user, t1.project_id, t1.referral_id FROM ( " + orderSql + ") t1 LEFT JOIN (" + userSql + ") t2 ON t1.pay_date = t2.buying_date AND t1.pay_hour = t2.buying_hour AND t1.project_id = t2.project_id AND t1.referral_id = t2.promotion_id "
	reportSql := "SELECT search_date, search_hour, a.advertiser_id, a.project_id, promotion_id FROM ( SELECT date(search_date) AS search_date, search_hour, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt FROM report_project_hour " + reportWhere + " ) a LEFT JOIN ( SELECT advertiser_id, project_id, promotion_id FROM ( SELECT advertiser_id, t1.project_id, t1.`code` FROM ( SELECT project_id, max(`code`) as `code` FROM  promotion_url_info GROUP BY project_id ) t1 LEFT JOIN ( SELECT advertiser_id, project_id, `code` FROM promotion_url_info GROUP BY advertiser_id, project_id, `code` ) t2 ON t1.project_id = t2.project_id AND t1.`code` = t2.`code` ) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url ) pr ON a.advertiser_id = pr.advertiser_id AND a.project_id = pr.project_id "
	incField := "pay_date, pay_hour, new_income, income, new_pay_user, new_user, pay_user, inc.project_id, referral_id "
	noRelateSql := "SELECT " + incField + " FROM ( " + incomeSql + " ) inc LEFT JOIN ( " + reportSql + " ) ac ON inc.pay_date = ac.search_date AND inc.pay_hour = ac.search_hour AND inc.project_id = ac.project_id AND inc.referral_id = ac.promotion_id WHERE ac.project_id IS NULL"
	promotionUrlSql := "SELECT pu.advertiser_id, n.advertiser_name, n.media, re.optimizer_city_name, app_name, promotion_id, promotion_url, optimizer_id, dpu.optimizer_name, book_id, book_name FROM ( SELECT url.advertiser_id, c.`code` FROM ( SELECT `code`, max(promotion_modify_time) as date FROM promotion_url_info GROUP BY `code` ) c LEFT JOIN ( SELECT advertiser_id, `code`, promotion_modify_time FROM promotion_url_info GROUP BY advertiser_id, `code`, promotion_modify_time ) url ON c.`code` = url.`code` AND c.date = url.promotion_modify_time ) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url, app_name, promotion_name, optimizer_id, optimizer_name, book_id, book_name FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url LEFT JOIN ( SELECT advertiser_id, advertiser_name, media FROM oauth_account ) n ON pu.advertiser_id = n.advertiser_id LEFT JOIN ( SELECT optimizer_name, optimizer_city_name FROM ( SELECT optimizer_id, optimizer_name FROM optimizer ) op LEFT JOIN ( SELECT optimizer_id, optimizer_city_id FROM optimizer_city_relation ) re ON op.optimizer_id = re.optimizer_id LEFT JOIN ( SELECT optimizer_city_id, optimizer_city_name FROM optimizer_city ) c ON re.optimizer_city_id = c.optimizer_city_id ) re ON dpu.optimizer_name = re.optimizer_name "
	queryFiled := "SUBSTR(pay_date, 1, 10) AS date,  pay_hour AS `hour`, '抖小' as media, optimizer_city_name AS region, '1' AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, ac.advertiser_id as account_id, advertiser_name as account_name, '0' AS project_id, '' as project_name, '' as delivery_product, 1 AS data_type, 0 AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, 0 AS show_count, 0 AS click_count, 0 AS media_active_count, 0 AS media_convert_count,  0 AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, 0 AS new_sum_income, 0 AS income2, 0 AS income3, 0 AS income4, 0 AS income5, 0 AS income6, 0 AS income7, '' as copyright_owner "
	querySql := "SELECT " + queryFiled + " FROM ( " + noRelateSql + " ) inc LEFT JOIN ( " + promotionUrlSql + " ) ac ON inc.referral_id = ac.promotion_id "
	db := dorisdb.DorisClient()
	err := db.Raw(querySql).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeProjectFinalTableToday(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

//// BuildAggNoCostProjectFinalEntityDataToday 保存无收入的实际数据 按账号ID关联
//func (d *ReportDataDao) BuildAggNoCostProjectFinalEntityDataToday(queryDate string) error {
//	var data []repo.ProjectReportDataViewEntity
//	adWhere := " WHERE date(search_date) = '" + queryDate + "' "
//	ac := "SELECT pu.advertiser_id, min(project_id) as project_id, n.advertiser_name, min(n.media) as media, min(optimizer_id) as optimizer_id, min(re.optimizer_city_name) as optimizer_city_name, min(app_name) as app_name, min(dpu.optimizer_name) as optimizer_name, min(book_id) as book_id, min(book_name) as book_name FROM ( SELECT advertiser_id, project_id, `code` FROM promotion_url_info GROUP BY advertiser_id, project_id, `code`) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url, app_name, promotion_name, optimizer_id, optimizer_name, book_id, book_name FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url LEFT JOIN ( SELECT advertiser_id, advertiser_name, media FROM oauth_account ) n ON pu.advertiser_id = n.advertiser_id LEFT JOIN ( SELECT optimizer_name, optimizer_city_name FROM ( SELECT optimizer_id, optimizer_name FROM optimizer ) op LEFT JOIN ( SELECT optimizer_id, optimizer_city_id FROM optimizer_city_relation ) re ON op.optimizer_id = re.optimizer_id LEFT JOIN ( SELECT optimizer_city_id, optimizer_city_name FROM optimizer_city ) c ON re.optimizer_city_id = c.optimizer_city_id ) re ON dpu.optimizer_name = re.optimizer_name GROUP BY pu.advertiser_id, n.advertiser_name"
//	ad := "SELECT search_date, search_hour,  advertiser_id, '' as project_id, '' as project_name, sum(show_cnt) as show_cnt, sum(click) as click, sum(active) as active, sum(active_pay) as active_pay, sum(cost) as cost, sum(convert_cnt) as convert_cnt, sum(new_income) as new_income, sum(income) as income, max(new_pay_user) as new_pay_user, max(pay_user) as pay_user, '' as referral_id, max(new_user) as new_user, max(acc_income) as acc_income, max(acc_2day_income) as acc_2day_income, max(acc_3day_income) as acc_3day_income, max(acc_4day_income) as acc_4day_income, max(acc_5day_income) as acc_5day_income, max(acc_6day_income) as acc_6day_income, max(acc_7day_income) as acc_7day_income FROM project_cost_income " + adWhere + " AND project_id = '' GROUP BY search_date, search_hour, advertiser_id"
//	projectInfo := "SELECT advertiser_id, project_id, delivery_product FROM project_info"
//	queryFiled := "SUBSTR(search_date, 1, 10) AS date, search_hour AS `hour`, ac.media AS media, optimizer_city_name AS region, CASE WHEN ( app_name = '常读爽剧' OR app_name = '松茶剧屋' OR app_name = '白解星剧' ) THEN '1' ELSE '2'END AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, t.advertiser_id AS account_id, ac.advertiser_name AS account_name, CASE WHEN t.project_id = '' THEN '0' ELSE t.project_id END AS project_id, project_name AS project_name, delivery_product AS delivery_product, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, acc_income AS new_sum_income, acc_2day_income AS income2, acc_3day_income AS income3, acc_4day_income AS income4, acc_5day_income AS income5, acc_6day_income AS income6, acc_7day_income AS income7 "
//	sqlStr := "SELECT " + queryFiled + " FROM (" + ad + " ) t LEFT JOIN (" + projectInfo + ") inf ON t.advertiser_id = inf.advertiser_id AND t.project_id = inf.project_id LEFT JOIN ( " + ac + ") ac ON  t.advertiser_id = ac.advertiser_id "
//	db := dorisdb.DorisClient()
//	err := db.Raw(sqlStr).Scan(&data).Error
//	if err != nil {
//		return err
//	}
//	err = d.InsertBatchSizeProjectFinalTableToday(data, 5000)
//	if err != nil {
//		return err
//	}
//	return nil
//}

// SwapProjectTable 原子交换表数据
func (d *ReportDataDao) SwapProjectTable() error {
	db := dorisdb.DorisClient()
	swapSql := "ALTER TABLE `roi_project_hourly_today_temp` SWAP WITH `roi_project_hourly_today`"
	err := db.Exec(swapSql).Error
	if err != nil {
		return err
	}
	// 清空临时表
	truncateSql := "TRUNCATE TABLE `roi_project_hourly_today_temp`"
	err = db.Exec(truncateSql).Error
	if err != nil {
		return err
	}
	return nil
}

// ExecProjectTimetable 最终关联数据时间表
func (d *ReportDataDao) ExecProjectTimetable(execTime string) error {
	db := dorisdb.DorisClient()
	insertSql := "INSERT INTO project_merge_exec_time (`exec_time`) VALUES ('" + execTime + "')"
	err := db.Exec(insertSql).Error
	if err != nil {
		return err
	}
	return nil

}

/******************************************      项目级数据更新new        ******************************************/

/*
	有消耗 有收入
       ① report_project_hour 关联 promotion_url_info  获取 日期 小时 账号信息  投手信息 推广链接  剧目信息
       ② tomato_iaa_award 关联 tomato_iaa_buy 获取 订单时间 订单小时 project_id referral_id 收入
       ①关联② 按 日期 小时 项目ID 推广链接关联
*/

// BuildAggHasCostAndIncomeProjectFinalData 项目维度聚合
func (d *ReportDataDao) BuildAggHasCostAndIncomeProjectFinalData(queryDate string) error {
	var data []repo.ProjectReportDataViewEntity
	db := dorisdb.DorisClient()
	partition := "p" + strings.Replace(queryDate, "-", "", -1) // 时间分区
	orderWhere := " WHERE date(event_date) = '" + queryDate + "' "
	reportWhere := " WHERE date(search_date) = '" + queryDate + "' "
	reportSql := "SELECT date(search_date) AS search_date, search_hour, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt, stat_micro_game_0d_amount FROM report_project_hour " + reportWhere
	promotionUrlSql := "SELECT pu.advertiser_id, project_id, re.region as optimizer_city_name, app_name, promotion_id, promotion_url, optimizer_id, dpu.optimizer_name, book_id, book_name FROM ( SELECT advertiser_id, t1.project_id, t1.`code` FROM ( SELECT project_id, max(`code`) as `code` FROM  promotion_url_info GROUP BY project_id ) t1 LEFT JOIN ( SELECT advertiser_id, project_id, `code` FROM promotion_url_info GROUP BY advertiser_id, project_id, `code` ) t2 ON t1.project_id = t2.project_id AND t1.`code` = t2.`code` ) pu LEFT JOIN ( SELECT promotion_id, promotion_url, app_name, promotion_name, optimizer_id, optimizer_name, book_id, book_name FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url LEFT JOIN ( SELECT nick_name, region FROM optimizer_info_view ) re ON dpu.optimizer_name = re.nick_name "
	accountFiled := "search_date, search_hour, re.advertiser_id, re.project_id, re.project_name, app_name, promotion_id, promotion_url, optimizer_id, optimizer_name, optimizer_city_name, book_id, book_name, show_cnt, click, active, active_pay, cost, convert_cnt, stat_micro_game_0d_amount "
	accountSql := "SELECT " + accountFiled + " FROM ( " + reportSql + " ) re LEFT JOIN ( " + promotionUrlSql + " ) pr ON re.advertiser_id = pr.advertiser_id AND re.project_id = pr.project_id "
	projectInfo := "SELECT pr.advertiser_id, pr.project_id, delivery_product, delivery_medium, `name`, copyright_owner, pr.product_id FROM ( SELECT advertiser_id, project_id, delivery_product, delivery_medium, CAST(related_product->'product_id' as CHAR) as product_id, CAST(related_product->'product_platform_id' as CHAR) as product_platform_id  FROM project_info ) pr LEFT JOIN ( SELECT advertiser_id, product_id, platform_id, `name`, copyright_owner FROM product_info ) pi ON pr.advertiser_id = pi.advertiser_id AND pr.product_id = pi.product_id AND pr.product_platform_id = pi.platform_id "
	rawInfo := "SELECT advertiser_id, project_id, book_name, copyright_owner FROM ( SELECT advertiser_id, project_id, max(hash_res) as hash_res FROM promotion_url_info  WHERE hash_res != '' GROUP BY advertiser_id, project_id ) pui LEFT JOIN ( SELECT  hash_id, book_name, copyright_owner FROM raw_referral_config ) rrc ON pui.hash_res = rrc.hash_id"
	accountInfo := "SELECT advertiser_id, advertiser_name, nick_name, region, user_id FROM ( SELECT advertiser_id, advertiser_name, SUBSTRING_INDEX(advertiser_name, '-', 1) as sname, user_id FROM oauth_account ) oa LEFT JOIN ( SELECT nick_name, region FROM optimizer_info_view ) ov ON oa.sname = ov.nick_name"
	orderSql := "SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, SUM(CASE WHEN o.event_date = o.register_date THEN o.income END) AS new_income, SUM(o.income) AS income, COUNT(DISTINCT CASE WHEN o.event_date = o.register_date THEN o.device_id END) AS new_pay_user, COUNT(DISTINCT o.device_id) AS pay_user, u.project_id, o.referral_id as referral_id FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + orderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id, t2.referral_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(buying_timestamp) as buying_hour, promotion_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), promotion_id ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, buying_timestamp AS buying_hour, project_id, promotion_id AS referral_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), buying_timestamp, project_id, promotion_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date AND t1.buying_hour = t2.buying_hour and t1.promotion_id = t2.referral_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id GROUP BY o.event_date, o.event_hour, u.project_id, o.referral_id"
	userSql := "SELECT date(buying_date) AS buying_date, buying_hour, project_id, COUNT(DISTINCT device_id) AS new_user, promotion_id FROM tomato_iaa_buy GROUP BY date(buying_date), buying_hour, project_id, promotion_id "
	incomeSql := "SELECT pay_date, pay_hour, new_income, income, new_pay_user, new_user, pay_user, t1.project_id, t1.referral_id FROM ( " + orderSql + ") t1 LEFT JOIN (" + userSql + ") t2 ON t1.pay_date = t2.buying_date AND t1.pay_hour = t2.buying_hour AND t1.project_id = t2.project_id AND t1.referral_id = t2.promotion_id "
	queryFiled := "SUBSTR(search_date, 1, 10) AS date,  search_hour AS `hour`, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then '端原生' else '抖小' end as media, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then n.region else optimizer_city_name end AS region, '1' AS pay_type, '' AS app_id, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then '端原生' else app_name end  AS app_name, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME' ) OR delivery_product = 'AWEME' then 0 else book_id end  AS book_id, case when (delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then raw.book_name else ac.book_name end  AS book_name, case when delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME' then n.user_id else optimizer_id end AS optimizer_id, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME' ) or delivery_product = 'AWEME' then n.nick_name else optimizer_name end AS optimizer_nickname, ac.advertiser_id as account_id, advertiser_name as account_name, CASE WHEN ac.project_id = '' THEN '0' ELSE ac.project_id END AS project_id, project_name, delivery_product, 1 AS data_type, cost AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, show_cnt AS show_count, click AS click_count, active AS media_active_count, convert_cnt AS media_convert_count,  active_pay AS media_first_pay_count, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then stat_micro_game_0d_amount*0.98*0.9 when delivery_product = 'AWEME' AND raw.copyright_owner = '360' then  stat_micro_game_0d_amount else income end AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, case when ( delivery_product = 'PRODUCT' AND delivery_medium = 'AWEME') OR delivery_product = 'AWEME' then stat_micro_game_0d_amount*0.98*0.9 when delivery_product = 'AWEME' AND raw.copyright_owner = '360' then  stat_micro_game_0d_amount else new_income end AS first_income, case when raw.copyright_owner != '' then raw.copyright_owner else '其他' end as copyright_owner, 0 AS new_sum_income, 0 AS income2, 0 AS income3, 0 AS income4, 0 AS income5, 0 AS income6, 0 AS income7 " // LOCATE('点众', inf.copyright_owner) > 0 then '点众' when LOCATE('掌阅', inf.copyright_owner) > 0 then '掌阅' when LOCATE('抖音视界', inf.copyright_owner) > 0 then '番茄' WHEN
	querySql := "SELECT " + queryFiled + " FROM ( " + accountSql + " ) ac LEFT JOIN ( " + projectInfo + " ) inf ON ac.advertiser_id = inf.advertiser_id AND ac.project_id = inf.project_id LEFT JOIN ( " + accountInfo + ") n ON ac.advertiser_id = n.advertiser_id LEFT JOIN ( " + rawInfo + " ) raw ON ac.advertiser_id = raw.advertiser_id AND ac.project_id = raw.project_id LEFT JOIN ( " + incomeSql + " ) inc ON ac.search_date = inc.pay_date AND ac.search_hour = inc.pay_hour AND ac.project_id = inc.project_id AND ac.promotion_id = inc.referral_id "
	err := db.Raw(querySql).Scan(&data).Error
	if err != nil {
		return err
	}
	// 执行删除当日或历史数据
	deleteSql := "ALTER TABLE roi_project_hourly DROP PARTITION IF EXISTS " + partition
	_ = db.Exec(deleteSql).Error
	err = d.InsertBatchSizeProjectFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

/*
	情况3： 有收入 但小时不对应 或 收入的project_id = '' 或  project_id = '_PROJECT_ID_'
		使用推广链接 反推账号信息
*/

func (d *ReportDataDao) BuildAggNoCostProjectFinalData(queryDate string) error {
	var data []repo.ProjectReportDataViewEntity
	db := dorisdb.DorisClient()
	orderWhere := " WHERE date(event_date) = '" + queryDate + "' "
	reportWhere := " WHERE date(search_date) = '" + queryDate + "' "
	orderSql := "SELECT o.event_date AS pay_date, o.event_hour AS pay_hour, SUM(CASE WHEN o.event_date = o.register_date THEN o.income END) AS new_income, SUM(o.income) AS income, COUNT(DISTINCT CASE WHEN o.event_date = o.register_date THEN o.device_id END) AS new_pay_user, COUNT(DISTINCT o.device_id) AS pay_user, u.project_id, o.referral_id as referral_id FROM ( SELECT device_id, event_date, event_hour, register_date, referral_id, income * coe.coefficient as income FROM ( SELECT device_id, date(event_date) AS event_date, event_hour, date(register_date) AS register_date, promotion_id AS referral_id, SUM(ecpm_cost/100000) AS income FROM tomato_iaa_award " + orderWhere + " GROUP BY device_id, date(event_date), event_hour, date(register_date), referral_id ) ord LEFT JOIN ( SELECT date(search_date) as search_date, coefficient FROM tomato_iaa_coefficient ) coe ON ord.event_date = coe.search_date ) o LEFT JOIN ( SELECT t1.device_id, t1.buying_date, project_id, t2.referral_id FROM ( SELECT device_id, date(buying_date) as buying_date, min(buying_timestamp) as buying_hour, promotion_id FROM tomato_iaa_buy GROUP BY device_id, date(buying_date), promotion_id ) t1 LEFT JOIN ( SELECT device_id, date(buying_date) AS buying_date, buying_timestamp AS buying_hour, project_id, promotion_id AS referral_id FROM tomato_iaa_buy  GROUP BY device_id, date(buying_date), buying_timestamp, project_id, promotion_id ) t2 ON t1. device_id = t2.device_id AND t1.buying_date = t2.buying_date AND t1.buying_hour = t2.buying_hour and t1.promotion_id = t2.referral_id ) u ON o.device_id = u.device_id AND o.register_date = u.buying_date AND o.referral_id = u.referral_id GROUP BY o.event_date, o.event_hour, u.project_id, o.referral_id"
	userSql := "SELECT date(buying_date) AS buying_date, buying_hour, project_id, COUNT(DISTINCT device_id) AS new_user, promotion_id FROM tomato_iaa_buy GROUP BY date(buying_date), buying_hour, project_id, promotion_id "
	incomeSql := "SELECT pay_date, pay_hour, new_income, income, new_pay_user, new_user, pay_user, t1.project_id, t1.referral_id FROM ( " + orderSql + ") t1 LEFT JOIN (" + userSql + ") t2 ON t1.pay_date = t2.buying_date AND t1.pay_hour = t2.buying_hour AND t1.project_id = t2.project_id AND t1.referral_id = t2.promotion_id "
	reportSql := "SELECT search_date, search_hour, a.advertiser_id, a.project_id, promotion_id FROM ( SELECT date(search_date) AS search_date, search_hour, advertiser_id, project_id, project_name, show_cnt, click, active, active_pay, cost, convert_cnt FROM report_project_hour " + reportWhere + " ) a LEFT JOIN ( SELECT advertiser_id, project_id, promotion_id FROM ( SELECT advertiser_id, t1.project_id, t1.`code` FROM ( SELECT project_id, max(`code`) as `code` FROM  promotion_url_info GROUP BY project_id ) t1 LEFT JOIN ( SELECT advertiser_id, project_id, `code` FROM promotion_url_info GROUP BY advertiser_id, project_id, `code` ) t2 ON t1.project_id = t2.project_id AND t1.`code` = t2.`code` ) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url ) pr ON a.advertiser_id = pr.advertiser_id AND a.project_id = pr.project_id "
	incField := "pay_date, pay_hour, new_income, income, new_pay_user, new_user, pay_user, inc.project_id, referral_id "
	noRelateSql := "SELECT " + incField + " FROM ( " + incomeSql + " ) inc LEFT JOIN ( " + reportSql + " ) ac ON inc.pay_date = ac.search_date AND inc.pay_hour = ac.search_hour AND inc.project_id = ac.project_id AND inc.referral_id = ac.promotion_id WHERE ac.project_id IS NULL"
	promotionUrlSql := "SELECT pu.advertiser_id, n.advertiser_name, n.media, re.optimizer_city_name, app_name, promotion_id, promotion_url, optimizer_id, dpu.optimizer_name, book_id, book_name FROM ( SELECT url.advertiser_id, c.`code` FROM ( SELECT `code`, max(promotion_modify_time) as date FROM promotion_url_info GROUP BY `code` ) c LEFT JOIN ( SELECT advertiser_id, `code`, promotion_modify_time FROM promotion_url_info GROUP BY advertiser_id, `code`, promotion_modify_time ) url ON c.`code` = url.`code` AND c.date = url.promotion_modify_time ) pu LEFT JOIN ( SELECT promotion_id, case when app_type = 4 then SUBSTRING_INDEX(SUBSTRING_INDEX(promotion_url,'&',1),'=', -1) else promotion_url end as promotion_url, app_name, promotion_name, optimizer_id, optimizer_name, book_id, book_name FROM distributor_promotion_url WHERE app_type = 10 ) dpu ON pu.`code` = dpu.promotion_url LEFT JOIN ( SELECT advertiser_id, advertiser_name, media FROM oauth_account ) n ON pu.advertiser_id = n.advertiser_id LEFT JOIN ( SELECT optimizer_name, optimizer_city_name FROM ( SELECT optimizer_id, optimizer_name FROM optimizer ) op LEFT JOIN ( SELECT optimizer_id, optimizer_city_id FROM optimizer_city_relation ) re ON op.optimizer_id = re.optimizer_id LEFT JOIN ( SELECT optimizer_city_id, optimizer_city_name FROM optimizer_city ) c ON re.optimizer_city_id = c.optimizer_city_id ) re ON dpu.optimizer_name = re.optimizer_name "
	queryFiled := "SUBSTR(pay_date, 1, 10) AS date,  pay_hour AS `hour`, '抖小' as media, optimizer_city_name AS region, '1' AS pay_type, '' AS app_id, app_name AS app_name, book_id AS book_id, book_name AS book_name, optimizer_id AS optimizer_id, optimizer_name AS optimizer_nickname, ac.advertiser_id as account_id, advertiser_name as account_name, '0' AS project_id, '' as project_name, '' as delivery_product, 1 AS data_type, 0 AS media_cost,  0 AS reward_cost, 0 AS shared_wallet_cost, 0 AS media_rebate_rate, 0 AS show_count, 0 AS click_count, 0 AS media_active_count, 0 AS media_convert_count,  0 AS media_first_pay_count, income AS income, new_user AS active_count, new_pay_user AS new_pay_count, pay_user AS active_pay_count, new_income AS first_income, 0 AS new_sum_income, 0 AS income2, 0 AS income3, 0 AS income4, 0 AS income5, 0 AS income6, 0 AS income7 "
	querySql := "SELECT " + queryFiled + " FROM ( " + noRelateSql + " ) inc LEFT JOIN ( " + promotionUrlSql + " ) ac ON inc.referral_id = ac.promotion_id "
	err := db.Raw(querySql).Scan(&data).Error
	if err != nil {
		return err
	}
	err = d.InsertBatchSizeProjectFinalTable(data, 5000)
	if err != nil {
		return err
	}
	return nil
}

const (
	CurHour  = 1
	LastHour = 2
	Daily    = 3
)

// 商品库day, hour sql
func GetSqlStr() string {
	sql := "SELECT ROUND(SUM(media_cost / 1.02),2) AS hour_cost,ROUND(SUM(income)/SUM(media_cost / 1.02),2)*100 AS hour_roi,hour,date,ROUND(SUM(SUM(media_cost / 1.02)) OVER(PARTITION BY date ORDER BY hour),2) AS day_cost,ROUND((SUM(SUM(income)) OVER(PARTITION BY date ORDER BY hour) / SUM(SUM(media_cost / 1.02)) OVER(PARTITION BY date ORDER BY hour)) * 100,2) AS day_roi,COALESCE(ROUND((SUM(media_cost / 1.02) - LAG(SUM(media_cost / 1.02),1) OVER(PARTITION BY date ORDER BY hour))/NULLIF(LAG(SUM(media_cost / 1.02),1) OVER(PARTITION BY date ORDER BY hour),0)*100,2),0) AS cost_ratio,COALESCE(ROUND((ROUND(SUM(income)/SUM(media_cost / 1.02),2) - LAG(ROUND(SUM(income)/SUM(media_cost / 1.02),2),1) OVER(PARTITION BY date ORDER BY hour))/NULLIF(LAG(ROUND(SUM(income)/SUM(media_cost / 1.02),2),1) OVER(PARTITION BY date ORDER BY hour),0)*100,2),0) AS roi_ratio FROM roi_project_hourly_today WHERE delivery_product = 'PRODUCT' GROUP BY hour,date ORDER BY date,hour desc"
	return sql
}

// 剧目sql
func GetBookSql(typeInt int) string {
	var sql string
	switch typeInt {
	case CurHour:
		sql = "SELECT SUM(media_cost/1.02) as hour_cost,  SUM(income)/ SUM(media_cost/1.02) as hour_roi, book_name,book_id,`hour`  from roi_project_hourly_today where `hour` = HOUR(CURTIME()) and `delivery_product` = 'PRODUCT' group by `hour`, book_id, book_name"
	case LastHour:
		sql = "SELECT SUM(media_cost/1.02) as hour_cost,  SUM(income)/ SUM(media_cost/1.02) as hour_roi, book_name,book_id,`hour`  from roi_project_hourly_today where `hour` = HOUR(CURTIME()) -1 and `delivery_product` = 'PRODUCT' group by `hour`, book_id, book_name"
	case Daily:
		sql = "SELECT SUM(media_cost/1.02) as day_cost,  SUM(income)/ SUM(media_cost/1.02) as day_roi, book_name,book_id  from roi_project_hourly_today where `date` = CURDATE() and `delivery_product` = 'PRODUCT' group by book_id, book_name"
	}
	return sql
}

// 获取地区sql
func GetRegionSql(typeInt int) string {
	var sql string
	switch typeInt {
	case CurHour:
		sql = "SELECT SUM(media_cost/1.02) as hour_cost,  SUM(income)/ SUM(media_cost/1.02) as hour_roi, region,`hour`  from roi_project_hourly_today where `hour` = HOUR(CURTIME()) and `delivery_product` = 'PRODUCT' group by `hour`, region"
	case LastHour:
		sql = "SELECT SUM(media_cost/1.02) as hour_cost,  SUM(income)/ SUM(media_cost/1.02) as hour_roi, region,`hour`  from roi_project_hourly_today where `hour` = HOUR(CURTIME())-1 and `delivery_product` = 'PRODUCT' group by `hour`, region"
	case Daily:
		sql = "SELECT SUM(media_cost/1.02) as day_cost,  SUM(income)/ SUM(media_cost/1.02) as day_roi, region  from roi_project_hourly_today where `date` = CURDATE() and `delivery_product` = 'PRODUCT' group by region"
	}
	return sql
}

// 获取投手sql
func GetOptimizeSql(typeInt int, isProduct bool) string {
	var sql string
	switch typeInt {
	case CurHour:
		// 投手当前小时商品库
		sql = "SELECT SUM(media_cost/1.02) as hour_cost,  SUM(income)/ SUM(media_cost/1.02) as hour_roi,`hour`, optimizer_id,optimizer_nickname  from roi_project_hourly_today where `hour` = HOUR(CURTIME())  group by `hour`, optimizer_id,optimizer_nickname"
		if isProduct {
			sql = "SELECT SUM(media_cost/1.02) as hour_cost,  SUM(income)/ SUM(media_cost/1.02) as hour_roi,`hour`, optimizer_id,optimizer_nickname  from roi_project_hourly_today where `hour` = HOUR(CURTIME()) and `delivery_product` = 'PRODUCT' group by `hour`, optimizer_id,optimizer_nickname"
		}
	case LastHour:
		sql = "SELECT SUM(media_cost/1.02) as hour_cost,  SUM(income)/ SUM(media_cost/1.02) as hour_roi,`hour`, optimizer_id,optimizer_nickname  from roi_project_hourly_today where `hour` = HOUR(CURTIME())-1  group by `hour`, optimizer_id,optimizer_nickname"
		if isProduct {
			sql = "SELECT SUM(media_cost/1.02) as hour_cost,  SUM(income)/ SUM(media_cost/1.02) as hour_roi, `hour`, optimizer_id,optimizer_nickname  from roi_project_hourly_today where `hour` = HOUR(CURTIME())-1 and `delivery_product` = 'PRODUCT' group by `hour`, optimizer_id,optimizer_nickname"
		}
	case Daily:

		sql = "SELECT SUM(media_cost/1.02) as day_cost,  SUM(income)/ SUM(media_cost/1.02) as day_roi, optimizer_id,optimizer_nickname,`date`  from roi_project_hourly_today where `date` = CURDATE()  group by optimizer_id,optimizer_nickname,`date`"
		if isProduct {
			sql = "SELECT SUM(media_cost/1.02) as day_cost,  SUM(income)/ SUM(media_cost/1.02) as day_roi, optimizer_id,optimizer_nickname, `date`  from roi_project_hourly_today where `date` = CURDATE() and `delivery_product` = 'PRODUCT' group by  optimizer_id,optimizer_nickname,`date`"
		}
	}
	return sql
}

// 查找需要推推推送的数据
func (d *ReportDataDao) FindReportData() (res []ProductTodayReportData, err error) {
	sql := GetSqlStr()
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

// 查找剧目数据
func (d *ReportDataDao) FindBookReportData(typeInt int) (res []ProductBookData, err error) {
	sql := GetBookSql(typeInt)
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

// 查找商品库的确统计
func (d *ReportDataDao) FindProductReginData(typeInt int) (res []ProductReginData, err error) {
	sql := GetRegionSql(typeInt)
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

// 查找投手统计数据
func (d *ReportDataDao) FindOptimizeData(typeInt int, isProduct bool) (res []OptimizeData, err error) {
	sql := GetOptimizeSql(typeInt, isProduct)
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

// 账户维度
func (d *ReportDataDao) FindAccountDataInfo(userIDs string, typeInt int) (res []AccountDataInfo, err error) {
	var sql string
	switch typeInt {
	case Today:
		sql = "SELECT search_date, advertiser_id, advertiser_name, ROUND(SUM(cost/1.02),2) AS cost, ROUND(SUM(income*0.9*0.98),2) AS income, ROUND(SUM(income*0.9*0.98)/NULLIF(SUM(cost/1.02),0),2)*100 AS roi, sum(today_income) as today_income, sum(threeday_income) as threeday_income, round(sum(24_income)/sum(cost/1.02),2) as income_roi_24, round(sum(today_income)/sum(cost/1.02),2) as today_income_roi, round(sum(threeday_income)/sum(cost/1.02),2) as three_income_roi FROM (SELECT b.advertiser_id, a.advertiser_name, b.cost, b.income, b.search_date, b.today_income, b.threeday_income, b.24_income FROM (SELECT advertiser_id, DATE(search_date) AS search_date, SUM(cost) AS cost, SUM(stat_micro_game_0d_amount) AS income, SUM(attribution_micro_game_0d_ltv) as today_income, SUM(attribution_micro_game_3d_ltv) as threeday_income, SUM(stat_attribution_micro_game_24h_amount) as 24_income FROM report_project_hour WHERE DATE(search_date)=CURRENT_DATE GROUP BY advertiser_id, DATE(search_date)) b LEFT JOIN oauth_account a ON b.advertiser_id = a.advertiser_id WHERE a.user_id IN (" + userIDs + ") AND b.cost IS NOT NULL AND b.income IS NOT NULL) c GROUP BY advertiser_id, advertiser_name, search_date ORDER BY cost DESC;"
	case Yesterday:
		// 获取前三天的数据
		sql = "SELECT search_date, advertiser_id, advertiser_name, ROUND(SUM(cost/1.02),2) AS cost, ROUND(SUM(income*0.9*0.98),2) AS income, ROUND(SUM(income*0.9*0.98)/NULLIF(SUM(cost/1.02),0),2)*100 AS roi, sum(today_income) AS today_income, sum(threeday_income) AS threeday_income, round(sum(24_income)/sum(cost/1.02),2) AS income_roi_24, round(sum(today_income)/sum(cost/1.02),2) AS today_income_roi, round(sum(threeday_income)/sum(cost/1.02),2) AS three_income_roi FROM (SELECT b.advertiser_id, a.advertiser_name, b.cost, b.income, b.search_date, b.today_income, b.threeday_income, b.24_income FROM (SELECT advertiser_id, DATE(search_date) AS search_date, SUM(cost) AS cost, SUM(stat_micro_game_0d_amount) AS income, SUM(attribution_micro_game_0d_ltv) AS today_income, SUM(attribution_micro_game_3d_ltv) AS threeday_income, SUM(stat_attribution_micro_game_24h_amount) AS 24_income FROM report_project_hour WHERE DATE(search_date) IN (CURRENT_DATE-1, CURRENT_DATE-2, CURRENT_DATE-3) GROUP BY advertiser_id, DATE(search_date)) b LEFT JOIN oauth_account a ON b.advertiser_id=a.advertiser_id WHERE a.user_id IN (" + userIDs + ") AND b.cost IS NOT NULL AND b.income IS NOT NULL) c GROUP BY advertiser_id, advertiser_name, search_date ORDER BY search_date DESC, cost DESC;"
	}
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

func (d *ReportDataDao) FindAccountCount(userIDs string) (res AccountData, err error) {
	sql := "SELECT ROUND(SUM(cost/1.02),2) AS cost, ROUND(SUM(income * 0.9 * 0.98),2) AS income, HOUR(CURRENT_TIME()) AS hour, ROUND(SUM(income*0.9*0.98) / SUM(cost/1.02), 2)*100 AS roi FROM (SELECT advertiser_id, oauth_id FROM oauth_account WHERE user_id IN" + "(" + userIDs + "))" + "a LEFT JOIN (SELECT advertiser_id, SUM(cost) AS cost, SUM(stat_micro_game_0d_amount) AS income FROM report_project_hour WHERE DATE(search_date) = CURRENT_DATE GROUP BY advertiser_id) b ON a.advertiser_id = b.advertiser_id;"
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

// 查询sql
func (d *ReportDataDao) FindInfoData(userIDsStr string, typeInt int) (res []AccountDataInfo, err error) {
	var sql string
	switch typeInt {
	case Today:
		sql = "SELECT b.search_date,round(sum(b.cost/1.02),2) as cost,round(sum(b.income * 0.9 * 0.98),2) as income,a.user_id,ROUND( SUM( b.income * 0.9 * 0.98 )/ NULLIF( SUM( b.cost / 1.02 ), 0 ), 2 )* 100 AS roi,sum( b.today_income ) AS today_income,sum( b.threeday_income ) AS threeday_income,round( sum( b.24_income )/ sum( b.cost / 1.02 ), 2 ) AS income_roi_24,round( sum( b.today_income )/ sum( b.cost / 1.02 ), 2 ) AS today_income_roi,round( sum( b.threeday_income )/ sum( b.cost / 1.02 ), 2 ) AS three_income_roi FROM (SELECT advertiser_id,DATE ( search_date ) AS search_date,SUM( cost ) AS cost,SUM( stat_micro_game_0d_amount ) AS income,SUM( attribution_micro_game_0d_ltv ) AS today_income,SUM( attribution_micro_game_3d_ltv ) AS threeday_income,SUM( stat_attribution_micro_game_24h_amount ) AS 24_income FROM report_project_hour WHERE DATE ( search_date )= CURRENT_DATE GROUP BY advertiser_id,DATE ( search_date )) b LEFT JOIN oauth_account a ON b.advertiser_id = a.advertiser_id WHERE a.user_id IN (" + userIDsStr + ") AND b.cost IS NOT NULL AND b.income IS NOT NULL GROUP BY a.user_id,search_date ORDER BY cost DESC;"
	case Yesterday:
		sql = "SELECT b.search_date,a.user_id,ROUND(SUM(b.cost/1.02),2)cost,ROUND(SUM(b.income*0.9 * 0.98),2)income,ROUND(SUM(b.income*0.9 * 0.98)/NULLIF(SUM(b.cost/1.02),0),2)*100 roi,SUM(b.today_income)today_income,SUM(b.threeday_income)threeday_income,ROUND(SUM(b.24_income)/SUM(b.cost/1.02),2)income_roi_24,ROUND(SUM(b.today_income)/SUM(b.cost/1.02),2)today_income_roi,ROUND(SUM(b.threeday_income)/SUM(b.cost/1.02),2)three_income_roi FROM (SELECT advertiser_id,DATE(search_date)search_date,SUM(cost)cost,SUM(stat_micro_game_0d_amount)income,SUM(attribution_micro_game_0d_ltv)today_income,SUM(attribution_micro_game_3d_ltv)threeday_income,SUM(stat_attribution_micro_game_24h_amount)24_income  FROM report_project_hour WHERE DATE(search_date)IN(CURRENT_DATE-1,CURRENT_DATE-2,CURRENT_DATE-3) GROUP BY advertiser_id,DATE(search_date))b LEFT JOIN oauth_account a ON b.advertiser_id=a.advertiser_id WHERE a.user_id IN(" + userIDsStr + ") AND b.cost IS NOT NULL AND b.income IS NOT NULL GROUP BY a.user_id,b.search_date ORDER BY b.search_date DESC,cost DESC"
	}
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

func (d *ReportDataDao) GetAccountManage(userIDsStr string) (res []UserExt, err error) {
	sql := "select user_id, ext from oauth where user_id in (" + userIDsStr + ")"
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}

// 获取账管当天数据·
func (d *ReportDataDao) GetAccountManageToday(typeInt int) (res []AccountDataInfo, err error) {
	var sql string
	switch typeInt {
	case Today:
		sql = "SELECT b.search_date,ROUND(SUM(b.cost),2)AS cost,ROUND(SUM(b.income),2)AS income,a.user_id,ROUND(SUM(b.income)/NULLIF(SUM(b.cost),0),2)*100 AS roi,ROUND(SUM(b.income)-SUM(b.cost),2)AS profit FROM(SELECT advertiser_id,DATE(search_date)AS search_date,SUM(cost)AS cost,SUM(stat_micro_game_0d_amount)AS income,project_id FROM report_project_hour WHERE DATE(search_date)=CURRENT_DATE GROUP BY advertiser_id,project_id,DATE(search_date))b LEFT JOIN project_info pi ON b.project_id=pi.project_id LEFT JOIN oauth_account a ON b.advertiser_id=a.advertiser_id WHERE b.cost IS NOT NULL AND b.income IS NOT NULL AND((pi.delivery_product='PRODUCT'AND pi.delivery_medium='AWEME')OR pi.delivery_product='AWEME')AND pi.project_id IS NOT NULL GROUP BY a.user_id,b.search_date ORDER BY cost DESC;"
	}
	if sql == "" {
		return
	}
	fmt.Println(sql)
	db := dorisdb.DorisClient()
	err = db.Raw(sql).Scan(&res).Error
	if err != nil && !gorm.IsRecordNotFoundError(err) {
		return
	}
	return
}
