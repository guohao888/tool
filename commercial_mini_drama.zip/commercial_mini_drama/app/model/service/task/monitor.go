package task

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"
	"time"

	noticeCommon "goserver/app/library/utils/notice/common"

	"github.com/spf13/viper"
	"github.com/xxl-job/xxl-job-executor-go"
)

type BurrowResponse struct {
	Error   bool   `json:"error"`
	Message string `json:"message"`
	Status  struct {
		Status     string    `json:"status"`
		Timestamp  time.Time `json:"timestamp"`
		Partitions []struct {
			Topic     string `json:"topic"`
			Partition int    `json:"partition"`
			Status    string `json:"status"`
			Start     struct {
				Offset    int64 `json:"offset"`
				Timestamp int64 `json:"timestamp"`
			} `json:"start"`
			End struct {
				Offset    int64 `json:"offset"`
				Timestamp int64 `json:"timestamp"`
			} `json:"end"`
			CurrentLag int64 `json:"current_lag"`
		} `json:"partitions"`
	} `json:"status"`
}

type KafkaLagMonitor struct {
	burrowHost string
	cluster    string
	client     *http.Client
}

func NewKafkaLagMonitor(host, cluster string) *KafkaLagMonitor {
	return &KafkaLagMonitor{
		burrowHost: host,
		cluster:    cluster,
		client:     &http.Client{Timeout: 10 * time.Second},
	}
}

func (m *KafkaLagMonitor) GetConsumerGroupLag(group string) (*BurrowResponse, error) {
	// 构建 Burrow API URL
	url := fmt.Sprintf("%s/v3/kafka/%s/consumer/%s/lag", m.burrowHost, m.cluster, group)
	// 发送 GET 请求
	resp, err := m.client.Get(url)
	if err != nil {
		return nil, fmt.Errorf("failed to get consumer group lag: %v", err)
	}
	defer resp.Body.Close()

	// 读取响应内容
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, fmt.Errorf("failed to read response body: %v", err)
	}

	// 解析 JSON 响应
	var burrowResp BurrowResponse
	if err := json.Unmarshal(body, &burrowResp); err != nil {
		return nil, fmt.Errorf("failed to unmarshal response: %v", err)
	}

	return &burrowResp, nil
}

// MonitorKafkaLag 监控Kafka消费延迟
func MonitorKafkaLag(ctx context.Context, param *xxl.RunReq) (msg string) {
	var alerts []string

	burrowURL := viper.GetString("kafka.burrow.url")
	clusterName := viper.GetString("kafka.cluster.name")
	threshold := viper.GetInt64("kafka.lag.threshold")
	monitorGroups := viper.GetStringSlice("kafka.monitor.groups")

	monitor := NewKafkaLagMonitor(burrowURL, clusterName)

	for _, v := range monitorGroups {
		resp, err := monitor.GetConsumerGroupLag(v)
		if err != nil {
			//todo
		} else {
			for _, partition := range resp.Status.Partitions {
				if partition.CurrentLag > threshold || partition.Status != "OK" {
					alerts = append(alerts, fmt.Sprintf("Topic: %s, Partition: %d, Current Lag: %d, Status: %s\n",
						partition.Topic,
						partition.Partition,
						partition.CurrentLag,
						partition.Status))
				}
			}
		}
	}
	err := sendTuiTuiMessage(alerts)
	if err != nil {
		return err.Error()
	}
	return "成功"
}

func sendTuiTuiMessage(alerts []string) error {
	var resp *noticeCommon.SingleResponse
	var err error
	if len(alerts) > 0 {
		message := fmt.Sprintf("Kafka消费延迟告警:\n%s", strings.Join(alerts, ""))
		fmt.Println("message:", message)
		// 获取配置的通知接收人
		toUsers := viper.GetStringSlice("kafka.monitor.notify_users")
		if len(toUsers) > 0 {
			// 获取推推通知配置
			/*
				apiUrl := viper.GetString("tuitui_notice.url")
				accountId := viper.GetString("tuitui_notice.account_id")
				prefix := viper.GetString("tuitui_notice.prefix")

				// 添加环境前缀
				message = fmt.Sprintf("%s %s", prefix, message)
				result, err := notice.SendTuiTuiMessage(apiUrl, accountId, toUsers, message)
				if err != nil {
					log.Errorf("发送推推通知失败: %v", err)
				}
				fmt.Println("发送报警结果:", result)
			*/

			appID := viper.GetString("common_monitor.appid")
			secret := viper.GetString("common_monitor.secret")
			host := viper.GetString("common_monitor.host")
			client := noticeCommon.NewClient(appID, secret, host)

			text := &noticeCommon.Text{
				Content: message,
			}
			msg := &noticeCommon.SingleMessage{
				Tousers: toUsers,
				Msgtype: "text",
				Text:    text,
			}
			for i := 0; i < 3; i++ {
				resp, err = client.SendMessage(msg)
				// fmt.Println(resp)
				if err == nil && resp.Errcode != 0 {
					err = errors.New(resp.Errmsg)
				} else {
					break
				}
			}
			return err
		}
	}

	return nil
}
