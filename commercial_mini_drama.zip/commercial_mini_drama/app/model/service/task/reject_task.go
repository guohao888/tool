package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	report "goserver/app/common/dto/mediareport"
	mediaRepo "goserver/app/model/service/mediareport"
)

// SyncToutiaoRejectReason 拉取头条消耗数据 历史数据
func SyncToutiaoRejectReason(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.AccountReportSyncExecutorParams{}
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}
	//
	rejectService := mediaRepo.NewRejectService(ctx)
	err := rejectService.DistributeRejectAccounts(ctx)
	if err != nil {
		return fmt.Sprintf("同步拒审信息数据失败, err: %s", err)
	}
	return "同步拒审信息数据刷新成功"
}
