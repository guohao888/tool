package slice

func PluckUniqueBy[T any, V comparable](slice []T, iteratee func(item T) V) []V {
	result := []V{}
	exists := make(map[V]struct{})

	for _, v := range slice {
		val := iteratee(v)
		if _, ok := exists[val]; !ok {
			result = append(result, val)
			exists[val] = struct{}{}
		}
	}

	return result
}

func PluckToMap[T any, V comparable](slice []T, iteratee func(item T) V) map[V]struct{} {
	m := make(map[V]struct{})

	for _, v := range slice {
		val := iteratee(v)
		m[val] = struct{}{}
	}

	return m
}

func MaxField[T any, V comparable](slice []T, maxFunc func(curr T, max V) V) V {
	var maxVal V
	for i := 0; i < len(slice); i++ {
		maxVal = maxFunc(slice[i], maxVal)
	}
	return maxVal
}

func MaxField2[T any, V comparable](slice []T, iteratee func(item T) V, comparator func(v V, m V) bool) V {
	var max V
	for _, v := range slice {
		val := iteratee(v)
		if comparator(val, max) {
			max = val
		}
	}
	return max
}
