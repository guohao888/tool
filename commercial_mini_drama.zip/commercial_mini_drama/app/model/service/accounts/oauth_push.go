package accounts

import (
	"context"
	"github.com/oceanengine/ad_open_sdk_go/models"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	"goserver/app/library/log"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
	"strconv"
	"time"
)

type OauthPushService struct {
	Ctx context.Context
}

func NewOauthPushService(ctx context.Context) *OauthPushService {
	return &OauthPushService{Ctx: ctx}
}
func (s *OauthPushService) OauthPushRefresh(media string, params accountdto.OauthRefreshExecutorParams) error {
	oauthDao := accountdao.NewOauthDao(s.Ctx)
	list, err := oauthDao.ListOauthPushByMedia(media)
	if err != nil {
		return err
	}

	m := params.OauthIdsStruct.ToMap()

	for _, oauth := range list {
		if len(m) > 0 { // 制定oauth_id的话，就只更新指定的oauth授权
			if _, ok := m[oauth.OauthId]; !ok {
				continue
			}
		}

		var newOauth *accountrepo.OauthEntity
		var err error

		// 调用更新授权令牌接口
		switch {
		case media == repository.MediaToutiao:
			newOauth, err = s.oauthPushRefresh(oauth)
		case media == repository.MediaKuaishou:
			// todo 快手oauth授权刷新
		}

		if err != nil {
			log.Errorf("oauth授权刷新错误, err: %s", err)
			return err
		}

		if newOauth != nil {
			// 保存到数据库
			err := oauthDao.UpdatePushById(newOauth.Media, newOauth.OauthId, newOauth)
			if err != nil {
				log.Errorf("oauth授权刷新保存到数据库错误, err: %s", err)
				return err
			}
		}
	}

	return nil
}

func (s *OauthPushService) oauthPushRefresh(oauth accountrepo.OauthEntity) (oauthEntity *accountrepo.OauthEntity, err error) {
	appId, err := strconv.ParseInt(oauth.AppId, 10, 64)
	if err != nil {
		return nil, err
	}
	resp, err := toutiao.Oauth2RefreshToken(s.Ctx, models.Oauth2RefreshTokenRequest{
		AppId:        &appId,
		RefreshToken: oauth.RefreshToken,
		Secret:       oauth.AppSecret,
	})
	if err != nil {
		return nil, err
	}

	// 获取授权User信息

	now := time.Now()
	oauthEntity = &accountrepo.OauthEntity{
		Media:        oauth.Media,
		OauthId:      oauth.OauthId,
		AccessToken:  *resp.Data.AccessToken,
		RefreshToken: *resp.Data.RefreshToken,
		ExpireAt: func() time.Time {
			return now.Add(time.Duration(*resp.Data.ExpiresIn) * time.Second)
		}(),
		RefreshExpireAt: func() time.Time {
			return now.Add(time.Duration(*resp.Data.RefreshTokenExpiresIn) * time.Second)
		}(),
		ExpireTime:        *resp.Data.ExpiresIn,
		RefreshExpireTime: *resp.Data.RefreshTokenExpiresIn,
		AppId:             oauth.AppId,
		UserId:            oauth.UserId,
		AppSecret:         oauth.AppSecret,
		Ext:               oauth.Ext,
	}

	return oauthEntity, nil
}
