package task

import (
	"context"
	"errors"
	"fmt"
	repo "goserver/app/common/repository/kuaishou"
	"goserver/app/library/log"
	noticeCommon "goserver/app/library/utils/notice/common"
	ksdao "goserver/app/model/dao/kuaishou"
	"image"
	"image/color"
	"image/draw"
	"image/png"
	"io/ioutil"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"strconv"
	"time"

	"github.com/golang/freetype"
	"golang.org/x/image/font/gofont/goregular"

	"github.com/spf13/viper"

	"github.com/tealeg/xlsx"
	"github.com/xxl-job/xxl-job-executor-go"
)

var ksAdvertiserInfo = map[int64]string{
	4326751500: "咖啡短剧",
	4699626326: "66短剧 ",
	4694932260: "西红柿短剧 ",
}

// --------------快手新剧时速消耗明细-----------------

func SyncKuaishouNewSeriesCostPush(ctx context.Context, _ *xxl.RunReq) string {
	var (
		todayDate, yesterdayDate, tomorrowDate string
		hour                                   int
		todayTime                              time.Time
	)

	now := time.Now()
	curHour := now.Hour()
	if curHour == 0 {
		hour = 23
		todayTime = now.Add(-1 * time.Hour)
	} else {
		hour = curHour - 1
		todayTime = now
	}
	todayDate = todayTime.Format(time.DateOnly)
	yesterdayDate = todayTime.AddDate(0, 0, -1).Format(time.DateOnly)
	tomorrowDate = todayTime.AddDate(0, 0, 1).Format(time.DateOnly)

	costInfo, err := getKsCostInfo(ctx, todayDate, yesterdayDate, tomorrowDate, hour)
	if err != nil {
		log.Error("[SyncKuaishouCostPush] GetCostInfo error:" + err.Error())
		return "查询失败" + err.Error()
	}

	file, err := createKsROICostExcel(costInfo)
	if err != nil {
		log.Error("[SyncKuaishouCostPush] createROICostExcel error:" + err.Error())
		return "创建excel失败" + err.Error()
	}

	defer file.Close()

	err = sendKsROICostExcelToTuitui(file, todayDate, hour)
	if err != nil {
		log.Error("[SyncKuaishouCostPush] sendKsROICostExcelToTuitui error:" + err.Error())
		return "发送推推失败" + err.Error()
	}
	return "成功"
}

func getKsCostInfo(ctx context.Context, todayDate string, yesterdayDate string, tomorrowDate string, hour int) ([]repo.NewlySpentSeriesRoiInfo, error) {
	dataDao := ksdao.NewCoreDataDao(ctx)
	seriesInfo, err := dataDao.GetNewlySpentSeries(todayDate, yesterdayDate, tomorrowDate)
	if err != nil {
		return nil, err
	}
	var seriesIds []string
	for id, _ := range seriesInfo {
		seriesIds = append(seriesIds, strconv.FormatInt(id, 10))
	}

	roiInfo, err := dataDao.GetNewlySpentBooksRoiInfo(todayDate, int64(hour), seriesIds)

	if err != nil {
		return nil, err
	}
	costCoe := 1.072
	for k, v := range roiInfo {
		parsedTime, _ := time.Parse(time.DateTime, v.DateTime)
		roiInfo[k].Date = parsedTime.Format(time.DateOnly)
		roiInfo[k].Hour = parsedTime.Hour()

		roiInfo[k].SeriesName = seriesInfo[v.SeriesId]
		roiInfo[k].TotalCharge = v.TotalCharge / costCoe / 1000
		roiInfo[k].HbTotalCharge = v.HbTotalCharge / costCoe / 1000
		// 当期ROI
		roiInfo[k].ActualROI = 0.0
		if v.TotalCharge != 0 {
			roiInfo[k].ActualROI = v.PayAmt * 0.9 * 0.99 * 1000 / (v.TotalCharge / costCoe)
		}
		// 上期ROI
		roiInfo[k].HbActualROI = 0.0
		if v.HbTotalCharge != 0 {
			roiInfo[k].HbActualROI = v.HbPayAmt * 0.9 * 0.99 * 1000 / (v.HbTotalCharge / costCoe)
		}
		// 消耗环比
		roiInfo[k].TotalChargeHb = geThbValue(roiInfo[k].TotalCharge, roiInfo[k].HbTotalCharge)
		// ROI环比
		roiInfo[k].ActualROIHb = geThbValue(roiInfo[k].ActualROI, roiInfo[k].HbActualROI)
	}
	return roiInfo, nil
}

// 生成快手ROI 报表 Excel 文件
func createKsROICostExcel(costInfo []repo.NewlySpentSeriesRoiInfo) (*os.File, error) {
	// 1. 创建新 Excel 文件和工作表
	file := xlsx.NewFile()
	sheet, err := file.AddSheet("Sheet1")
	if err != nil {
		return nil, fmt.Errorf("创建工作表失败: %v", err)
	}
	// 标题行
	title := []string{"日期", "时间", "剧目ID", "剧目名称", "实际消耗", "实际IAA广告变现ROI", "实际消耗环比", "实际IAA广告变现ROI环比"}
	row := sheet.AddRow()
	for _, v := range title {
		row.AddCell().Value = v
	}
	// 数据行
	for _, v := range costInfo {
		row := sheet.AddRow()
		row.AddCell().SetString(v.Date)
		row.AddCell().SetString(fmt.Sprintf("%02d时", v.Hour))
		row.AddCell().SetString(strconv.FormatInt(v.SeriesId, 10))
		row.AddCell().SetString(v.SeriesName)
		row.AddCell().SetFloat(v.TotalCharge)
		row.AddCell().SetString(getPercentageRoi(v.ActualROI))
		if v.Hour == 0 {
			row.AddCell().SetString("-")
			row.AddCell().SetString("-")
		} else {
			row.AddCell().SetString(getPercentageRoi(v.TotalChargeHb))
			row.AddCell().SetString(getPercentageRoi(v.ActualROIHb))
		}
	}
	// 3. 创建临时文件
	tempFile, err := os.CreateTemp("", "xxxxxxxx_kuaishou_roi_cost_*.xlsx")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close()
	// 4. 写入 Excel
	if fileErr := file.Write(tempFile); fileErr != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("写入 Excel 失败: %v", fileErr)
	}
	// 5. 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}
	return outputFile, nil
}

// 发送 Excel 文件到推推
func sendKsROICostExcelToTuitui(file *os.File, date string, hour int) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	hourStr := strconv.Itoa(hour)

	filePath := "/drama/快手新剧消耗时速表" + date + "-" + hourStr + "点.xlsx"
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return err
	}
	msg := &noticeCommon.GroupMessage{
		Togroups:   []string{"7652669649044229"},
		Msgtype:    "attachment",
		Attachment: &noticeCommon.Attachment{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err != nil {
		return err
	}
	if resp.Errcode != 0 {
		return errors.New(resp.Errmsg)
	}
	return nil
}

//----------------分管家账户消耗时速明细--------------------

func SyncKuaishouManagerCostPush(ctx context.Context, _ *xxl.RunReq) string {
	var (
		todayDate, yesterdayDate string
		hour                     int
		todayTime                time.Time
	)

	now := time.Now()
	curHour := now.Hour()
	if curHour == 0 {
		hour = 23
		todayTime = now.Add(-1 * time.Hour)
	} else {
		hour = curHour - 1
		todayTime = now
	}
	todayDate = todayTime.Format(time.DateOnly)
	yesterdayDate = todayTime.AddDate(0, 0, -1).Format(time.DateOnly)

	costInfo, err := getKsManagerCostInfo(ctx, todayDate, yesterdayDate, hour)
	if err != nil {
		log.Error("[SyncKuaishouManagerCostPush] SyncKuaishouManagerCostPush error:" + err.Error())
		return "查询失败" + err.Error()
	}

	file, err := createKsManagerROICostExcel(todayDate, costInfo)
	if err != nil {
		log.Error("[SyncKuaishouManagerCostPush] createKsManagerROICostExcel error:" + err.Error())
		return "创建excel失败" + err.Error()
	}

	defer file.Close()

	err = sendKsManagerROICostExcelToTuitui(file, todayDate, hour)
	if err != nil {
		log.Error("[SyncKuaishouManagerCostPush] sendKsManagerROICostExcelToTuitui error:" + err.Error())
		return "发送推推失败" + err.Error()
	}
	return "成功"
}

func getKsManagerCostInfo(ctx context.Context, todayDate string, yesterdayDate string, hour int) ([]repo.ManagerRoiInfo, error) {
	dataDao := ksdao.NewCoreDataDao(ctx)
	roiInfo, err := dataDao.GetManagerRoiInfo(todayDate, yesterdayDate, int64(hour))
	if err != nil {
		return nil, err
	}

	for k, v := range roiInfo {
		parsedTime, _ := time.Parse(time.DateTime, v.DateTime)
		roiInfo[k].Date = parsedTime.Format(time.DateOnly)
		roiInfo[k].Hour = parsedTime.Hour()
		roiInfo[k].AdvertiserName = ksAdvertiserInfo[v.AdvertiserId]

		roiInfo[k].ActualChargeHb = geThbValue(v.ActualCharge, v.HbActualCharge)
		roiInfo[k].ActualPayAmtHb = geThbValue(v.ActualPayAmt, v.HbActualPayAmt)
		roiInfo[k].ActualEventPayROIHb = geThbValue(v.ActualEventPayROI, v.HbActualEventPayROI)
	}
	return roiInfo, nil
}

func createKsManagerROICostExcel(date string, costInfo []repo.ManagerRoiInfo) (*os.File, error) {
	// 1. 创建新 Excel 文件和工作表
	file := xlsx.NewFile()
	sheet, err := file.AddSheet("Sheet1")
	if err != nil {
		return nil, fmt.Errorf("创建工作表失败: %v", err)
	}
	// 标题行
	title := []string{date, "时间", "实际消耗", "昨日实际消耗", "消耗环比", "实际IAA广告变现LTV", "昨日实际IAA广告变现LTV", "实际IAA广告变现LTV环比", "实际IAA广告变现ROI", "昨日IAA广告变现ROI", "实际IAA广告变现ROI"}
	row := sheet.AddRow()
	for _, v := range title {
		row.AddCell().Value = v
	}
	// 数据行
	for _, v := range costInfo {
		row := sheet.AddRow()
		row.AddCell().SetString(v.AdvertiserName)
		row.AddCell().SetString(fmt.Sprintf("%02d时", v.Hour))
		// 消耗
		row.AddCell().SetFloat(v.ActualCharge)
		row.AddCell().SetFloat(v.HbActualCharge)
		row.AddCell().SetString(getPercentageRoi(v.ActualChargeHb))
		// IAA广告变现LTV
		row.AddCell().SetFloat(v.ActualPayAmt)
		row.AddCell().SetFloat(v.HbActualPayAmt)
		row.AddCell().SetString(getPercentageRoi(v.ActualPayAmtHb))
		// IAA广告变现ROI
		row.AddCell().SetFloat(v.ActualEventPayROI)
		row.AddCell().SetFloat(v.HbActualEventPayROI)
		row.AddCell().SetString(getPercentageRoi(v.ActualEventPayROIHb))
	}
	// 3. 创建临时文件
	tempFile, err := os.CreateTemp("", "xxxxxxxx_kuaishou_manager_roi_*.xlsx")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close()
	// 4. 写入 Excel
	if fileErr := file.Write(tempFile); fileErr != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("写入 Excel 失败: %v", fileErr)
	}
	// 5. 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}
	return outputFile, nil
}

func sendKsManagerROICostExcelToTuitui(file *os.File, date string, hour int) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	hourStr := strconv.Itoa(hour)

	filePath := "/drama/快手管家账户消耗时速表" + date + "-" + hourStr + "点.xlsx"
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return err
	}
	msg := &noticeCommon.GroupMessage{
		Togroups:   []string{"7652669649067199"},
		Msgtype:    "attachment",
		Attachment: &noticeCommon.Attachment{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err != nil {
		return err
	}
	if resp.Errcode != 0 {
		return errors.New(resp.Errmsg)
	}
	return nil
}

func geThbValue(cur, pre float64) float64 {
	if pre == 0 {
		return 0.0
	}
	return (cur - pre) / pre
}

//----------------今日累计消耗、收入、roi数据--------------------

type ttCostIncome struct {
	Date                            string  `gorm:"column:date"`
	Hour                            string  `gorm:"column:hour"`
	ActualCharge                    float64 `gorm:"column:actual_charge"`                        // 实际消耗
	ActualMiniGameIaaPurchaseAmount float64 `gorm:"column:actual_mini_game_iaa_purchase_amount"` // 实际IAA广告变现LTV
	ActualMiniGameIaaRoi            string  `gorm:"column:actual_mini_game_iaa_roi"`             // 实际IAA广告变现ROI
}
type ksCostIncome struct {
	Columns []string
	Rows    []ttCostIncome
}

func SyncKuaishouCostIncomePush(ctx context.Context, _ *xxl.RunReq) string {
	var (
		todayDate string
		hour      int
		todayTime time.Time
	)

	now := time.Now()
	curHour := now.Hour()
	if curHour == 0 {
		hour = 23
		todayTime = now.Add(-1 * time.Hour)
	} else {
		hour = curHour - 1
		todayTime = now
	}
	todayDate = todayTime.Format(time.DateOnly)

	ksCostIncomeInfo, err := getKsCostIncomeInfo(ctx, todayDate, hour)
	if err != nil {
		log.Error("[SyncKuaishouCostIncomePush] SyncKuaishouCostIncomePush error:" + err.Error())
		return "查询失败" + err.Error()
	}

	file, err := createKsCostIncomeImg(ksCostIncomeInfo)
	if err != nil {
		log.Error("[SyncKuaishouCostIncomePush] createKsCostIncomeImg error:" + err.Error())
		return "创建excel失败" + err.Error()
	}
	defer file.Close()

	err = sendKsCostInomeImgToTuitui(file)
	if err != nil {
		log.Error("[SyncKuaishouCostIncomePush] sendKsCostInomeImgToTuitui error:" + err.Error())
		return "发送推推失败" + err.Error()
	}
	return "成功"
}

func getKsCostIncomeInfo(ctx context.Context, todayDate string, hour int) (*ksCostIncome, error) {
	dataDao := ksdao.NewCoreDataDao(ctx)
	roiInfo, err := dataDao.GetLastCostIncomeInfo(todayDate, int64(hour))
	if err != nil {
		return nil, err
	}

	var costInfo []ttCostIncome
	for _, v := range roiInfo {
		cost := ttCostIncome{
			Date:                            v.Date,
			Hour:                            v.Hour,
			ActualCharge:                    math.Round(v.ActualCharge*100) / 100,
			ActualMiniGameIaaPurchaseAmount: math.Round(v.ActualMiniGameIaaPurchaseAmount*100) / 100,
			ActualMiniGameIaaRoi:            getPercentageRoi(v.ActualMiniGameIaaRoi),
		}
		costInfo = append(costInfo, cost)
	}
	return &ksCostIncome{
		Columns: []string{"日期", "时间", "实际消耗", "实际IAA广告变现LTV", "实际IAA广告变现ROI"},
		Rows:    costInfo,
	}, nil
}

func createKsCostIncomeImg(result *ksCostIncome) (*os.File, error) {
	// 图片配置
	config := ImageConfig{
		Width:           1200,
		Height:          500,
		BackgroundColor: color.RGBA{255, 255, 255, 255}, // 白色背景
		TextColor:       color.RGBA{0, 0, 0, 255},       // 黑色文字
		HeaderColor:     color.RGBA{200, 200, 200, 255}, // 灰色表头
		RowColor:        color.RGBA{255, 255, 255, 255}, // 白色行
		AlternateColor:  color.RGBA{240, 240, 240, 255}, // 浅灰色交替行
		FontSize:        12,
		HeaderFontSize:  14,
		Padding:         10,
		LineHeight:      30,
	}

	// 计算图片高度
	numRows := len(result.Rows)
	headerHeight := config.LineHeight
	rowHeight := config.LineHeight
	totalHeight := headerHeight + (numRows * rowHeight) + (config.Padding * 2)

	// 如果计算的高度小于配置的高度，使用配置的高度
	if totalHeight < config.Height {
		totalHeight = config.Height
	} else {
		totalHeight += 50 // 有差异
	}

	// 创建图片
	img := image.NewRGBA(image.Rect(0, 0, config.Width, totalHeight))

	// 填充背景色
	draw.Draw(img, img.Bounds(), &image.Uniform{config.BackgroundColor}, image.Point{}, draw.Src)

	// 创建绘图上下文
	c := freetype.NewContext()
	c.SetDPI(72)

	// 尝试加载支持中文的系统字体
	var fontBytes []byte
	var err error
	exPath, err := os.Getwd()
	if nil != err {
		panic(err)
	}
	path := filepath.Join(exPath, "conf", "fonts", "MSYH.TTC")
	// 检查文件存在性
	if _, err := os.Stat(path); os.IsNotExist(err) {
		return nil, fmt.Errorf("字体文件不存在: %s\n检查路径是否匹配您的操作系统", path)
	}
	fontBytes, err = ioutil.ReadFile(path)

	// 如果所有系统字体都失败，使用内置字体
	if err != nil {
		fontBytes = goregular.TTF
	}

	font, err := freetype.ParseFont(fontBytes)
	if err != nil {
		return nil, fmt.Errorf("解析字体失败: %v", err)
	}

	c.SetFont(font)
	c.SetClip(img.Bounds())
	c.SetDst(img)
	c.SetSrc(image.NewUniform(config.TextColor))

	// 绘制标题
	c.SetFontSize(10)
	title := "短剧ROI预警"
	titleWidth := int(c.PointToFixed(float64(len(title)) * 12))
	titleX := (config.Width - titleWidth) / 2
	c.DrawString(title, freetype.Pt(titleX, 40))

	// 绘制时间戳
	c.SetFontSize(10)
	timestamp := fmt.Sprintf("生成时间: %s", time.Now().Format(time.DateTime))
	c.DrawString(timestamp, freetype.Pt(config.Width-200, 40))

	// 计算列宽
	colWidth := (config.Width - (config.Padding * 2)) / len(result.Columns)

	// 绘制表头
	c.SetFontSize(config.HeaderFontSize)
	c.SetSrc(image.NewUniform(config.TextColor))

	// 绘制表头背景
	headerRect := image.Rect(config.Padding, 60, config.Width-config.Padding, 60+headerHeight)
	draw.Draw(img, headerRect, &image.Uniform{config.HeaderColor}, image.Point{}, draw.Src)

	// 绘制表头文字
	x := config.Padding
	for _, col := range result.Columns {
		c.DrawString(col, freetype.Pt(x+5, 80))
		x += colWidth
	}

	// 绘制表格内容
	c.SetFontSize(config.FontSize)
	y := 60 + headerHeight

	// 使用反射获取结构体字段值
	dataValue := reflect.ValueOf(result.Rows)
	if dataValue.Kind() != reflect.Slice {
		return nil, fmt.Errorf("数据必须是切片类型")
	}

	for i := 0; i < dataValue.Len(); i++ {
		// 交替行颜色
		rowBgColor := config.RowColor
		if i%2 == 1 {
			rowBgColor = config.AlternateColor
		}

		// 绘制行背景
		rowRect := image.Rect(config.Padding, y, config.Width-config.Padding, y+rowHeight)
		draw.Draw(img, rowRect, &image.Uniform{rowBgColor}, image.Point{}, draw.Src)

		// 获取当前行的结构体
		rowStruct := dataValue.Index(i)
		if rowStruct.Kind() != reflect.Struct {
			return nil, fmt.Errorf("切片元素必须是结构体类型")
		}

		// 绘制单元格内容
		x := config.Padding
		for j := 0; j < rowStruct.NumField(); j++ {
			field := rowStruct.Field(j)
			cellStr := fmt.Sprintf("%v", field.Interface())
			c.DrawString(cellStr, freetype.Pt(x+5, y+20))
			x += colWidth
		}
		y += rowHeight
	}

	// 创建临时文件
	tempFile, err := os.CreateTemp("", "temp*.png")
	if err != nil {
		return nil, fmt.Errorf("创建临时文件失败: %v", err)
	}
	defer tempFile.Close() // 立即关闭以便后续操作

	// 4. 将 Excel 写入临时文件
	if fileErr := png.Encode(tempFile, img); fileErr != nil {
		_ = os.Remove(tempFile.Name()) // 写入失败时清理文件
		return nil, fmt.Errorf("写入 PNG 失败: %v", fileErr)
	}

	// 重新打开文件获取可读句柄
	outputFile, err := os.Open(tempFile.Name())
	if err != nil {
		_ = os.Remove(tempFile.Name())
		return nil, fmt.Errorf("重新打开文件失败: %v", err)
	}

	return outputFile, nil
}

func sendKsCostInomeImgToTuitui(file *os.File) error {
	appID := viper.GetString("common_monitor.appid")
	secret := viper.GetString("common_monitor.secret")
	host := viper.GetString("common_monitor.host")
	client := noticeCommon.NewClient(appID, secret, host)
	filePath := "/drama/短剧ROI预警"
	res, err := client.UploadMediaFile(file, &noticeCommon.MediaUploadRequest{
		Type:     "file",
		FilePath: filePath,
	})
	if err != nil {
		return err
	}
	msg := &noticeCommon.GroupMessage{
		Togroups: []string{"7652669649044229"},
		Msgtype:  "image",
		Image:    &noticeCommon.Image{MediaID: res.MediaID},
	}
	resp, err := client.SendGroupMessage(msg)
	if err != nil {
		return err
	}
	if resp.Errcode != 0 {
		return errors.New(resp.Errmsg)
	}
	return nil
}
