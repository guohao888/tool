package task

import (
	"context"
	"encoding/json"
	"fmt"
	"github.com/xxl-job/xxl-job-executor-go"
	"goserver/app/common/dto/mediareport"
	report "goserver/app/common/dto/widthtable"
	"goserver/app/model/service/synctable"
	"time"
)

func SyncProjectIncomeHistory(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewProjectCostService(ctx)
	// 最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfos(params.IsHistory)
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	return "最终关联数据刷新成功"
}

/********************************        当日/历史 ROI 分离  start     ********************************/

func SyncProjectIncomeToday(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := report.SyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewProjectCostService(ctx)
	//最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfos(params.IsHistory)
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	// swap
	err := syncService.SwapProjectTable()
	if err != nil {
		return err.Error()
	}
	// 写入最终关联数据时间表
	err = syncService.InsertProjectExecTime(time.Now().Format(time.DateTime))
	if err != nil {
		return err.Error()
	}
	return "最终关联数据刷新成功"
}

/********************************        当日/历史 ROI 分离   end    ********************************/

func SyncProjectIncomeHistoryReplenish(ctx context.Context, param *xxl.RunReq) (msg string) {
	params := mediareport.AccountReportSyncExecutorParams{}
	var errMsg string
	if param.ExecutorParams != "" {
		err := json.Unmarshal([]byte(param.ExecutorParams), &params)
		if err != nil {
			return fmt.Sprintf("参数解析错误, err: %s", err)
		}
	}

	syncService := synctable.NewProjectCostService(ctx)
	// 中间表数据查询
	startDate, _ := time.ParseInLocation(time.DateOnly, params.Start, time.Local)
	endDate, _ := time.ParseInLocation(time.DateOnly, params.End, time.Local)
	//midErrMap := syncService.QueryAndSaveCostInfosReplenish(startDate, endDate)
	//for date, errMessage := range midErrMap {
	//	if errMessage != "" {
	//		errMsg += fmt.Sprintf("补充消耗收入关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
	//	}
	//}
	// 最终数据查询
	finalErrList := syncService.QueryAndSaveFinalInfosReplenish(startDate, endDate)
	for date, errMessage := range finalErrList {
		if errMessage != "" {
			errMsg += fmt.Sprintf("补充最终关联数据刷新失败, date: %s, err: %s \n", date, errMessage)
		}
	}
	if errMsg != "" {
		return errMsg
	}
	return "补充最终关联数据刷新成功"
}
