package mediareport

import (
	"context"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"github.com/panjf2000/ants/v2"
	repo "goserver/app/common/repository"
	accountrepo "goserver/app/common/repository/accounts"
	mediaRepo "goserver/app/common/repository/mediareport"
	"goserver/app/library/playlet/toutiao"
	accountdao "goserver/app/model/dao/accounts"
	mediadao "goserver/app/model/dao/mediareport"
	"goserver/app/model/dao/subscribe"
	"strconv"
	"sync"
	"time"
)

type ReportProjectHourService struct {
	Ctx context.Context
}

func NewReportProjectHourService(ctx context.Context) *ReportProjectHourService {
	return &ReportProjectHourService{Ctx: ctx}
}

/***********************         新授权逻辑 令牌桶方式获取消耗  start       ***********************/
/*
	1. 查询所有活跃账号
	2. 根据应用ID数,平分账号
	3. 执行查询(令牌桶), params 应用执行账号数, token, appID
	4. 错误日志推推报警形式
*/

func (r *ReportProjectHourService) DistributeReportAccounts(crontabTime time.Time, ctx context.Context, isFast int) error {
	// 获取执行时间
	startDate, endDate := GetExecTime(crontabTime)
	// 按快慢队列查询出所有活跃账号
	activeList, err := GetActiveListBySubscribe(ctx, isFast, startDate)
	if err != nil {
		return fmt.Errorf("查询活跃账号失败, err: %v", err)
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return fmt.Errorf("查询活跃账号为空")
	}

	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncReportProjectHourLimit(startDate, endDate, activeList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

// SyncReportProjectHourLimit  令牌桶请求头条数据
func SyncReportProjectHourLimit(start, end string, activeList []accountrepo.OauthAccountEntity, oauth map[string]string, appId string) {

	resChan := make(chan *mediaRepo.ReportProjectHourEntity) // 结果缓存通道
	errChan := make(chan error, len(activeList))             // 缓冲通道避免阻塞

	// 开辟10个协程池
	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	// DB 只执行一次
	once.Do(func() {
		go func() {
			dbErr := execProjectDB(context.Background(), resChan)
			if dbErr != nil {
				errChan <- dbErr
			}
		}()
	})
	// 获取所有活跃账号及token 请求接口数据
	for _, v := range activeList {
		// copy变量 防止闭包重复执行数据
		currentItem := v
		wg.Add(1)

		task := func() {
			defer wg.Done()
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("panic recovered: %v", x)
				}
			}()
			advertiserId, _ := strconv.Atoi(currentItem.AdvertiserId)
			advertiserIdStr := currentItem.AdvertiserId
			userId := currentItem.UserId
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}
			// 按账号获取消耗报表
			allReport, execErr := execQueryProjectDataBase(context.Background(), oauth[userId], int64(advertiserId), start, end, appId)
			if execErr != nil {
				errChan <- fmt.Errorf("执行查询失败 advertiser_id: %s, token: %s, appId: %s, error: %s", advertiserIdStr, oauth[userId], appId, execErr.Error())
				return
			}
			// 查询无数据直接返回
			if allReport == nil {
				return
			}
			for _, row := range allReport.DataRows2InnerTransformMaterial() {
				pointTimeStr := row.StatTimeDay[0:16] + ":00"
				pointTime, _ := time.ParseInLocation(time.DateTime, pointTimeStr, time.Local)
				// 小时级 消耗
				info := trans2ProjectHourEntity(row, advertiserIdStr, pointTime)
				resChan <- info
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done() // 提交失败，减少计数器
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待所有任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan) // 确保所有任务完成后关闭通道
	}()
	// 收集所有错误
	var errs []error
	for errL := range errChan {
		errs = append(errs, errL)
	}

	if len(errs) > 0 {
		_ = sendMsg(errs, "同步消耗报表\n")
	}
	return
}

/***********************         新授权逻辑 令牌桶方式获取消耗  end       ***********************/

// trans2ProjectHourEntity 小时级数据转换
func trans2ProjectHourEntity(row toutiao.BaseMaterial, advertiserIdStr string, pointTime time.Time) *mediaRepo.ReportProjectHourEntity {
	return &mediaRepo.ReportProjectHourEntity{
		SearchDate:                        pointTime,
		SearchHour:                        row.StatTimeDay[11:13],
		AdvertiserId:                      advertiserIdStr,
		ProjectId:                         row.CdpProjectId,
		ProjectName:                       row.CdpProjectName,
		ShowCnt:                           row.ShowCnt,
		Click:                             row.ClickCnt,
		Active:                            row.Active,
		ActivePay:                         row.ActivePay,
		Cost:                              row.StatCost,
		ConvertCnt:                        row.ConvertCnt,
		CreatedTime:                       time.Now(),
		UpdatedTime:                       time.Now(),
		StatAttributionMicroGame24HAmount: row.StatAttributionMicroGame24HAmount,
		AttributionMicroGame24HRoi:        row.AttributionMicroGame24HRoi,
		StatMicroGame0DAmount:             row.StatMicroGame0DAmount,
		AttributionMicroGame0DLtv:         row.AttributionMicroGame0DTtv,
		AttributionMicroGame3DLtv:         row.AttributionMicroGame3DTtv,
		AttributionMicroGame7DLtv:         row.AttributionMicroGame7DTtv,
	}
}

// execProjectDB 小时级数据保存
func execProjectDB(ctx context.Context, resChan <-chan *mediaRepo.ReportProjectHourEntity) (err error) {
	reportProjectHourDao := mediadao.NewReportProjectHourDao(ctx)
	// 将数据写入 report_hour
	var data = make([]*mediaRepo.ReportProjectHourEntity, 0, 5000)
	var errs []error

	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			if dbErr := reportProjectHourDao.InsertBatchSize(data, 5000); dbErr != nil {
				errs = append(errs, dbErr) // 收集错误，不退出
			}
			data = data[:0]
		}

	}
	if len(data) > 0 {
		dbErr := reportProjectHourDao.InsertBatchSize(data, 5000)
		if dbErr != nil {
			errs = append(errs, dbErr)
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execProjectDB errors: %v", errs)
	}
	return nil
}

// execQueryProjectDataBase 执行database数据查询
func execQueryProjectDataBase(ctx context.Context, accessToken string, advertiserId int64,
	startDate, endDate string, appId string) (allReport toutiao.Rows, err error) {
	statTimeHourSort := models.ASC_ReportCustomGetV30OrderByType
	// BASE_DATE
	dataTopic := models.BASIC_DATA_ReportCustomGetV30DataTopic
	// 获取BASE_DATE数据
	allReport, err = toutiao.AllReportCustomGetV30(ctx, toutiao.AllReportCustomGetV30Req{
		AccessToken: accessToken,
		Dimensions: []string{
			"stat_time_hour",   // 按小时获取数据
			"cdp_project_id",   // 项目ID，对应推广计划id
			"cdp_project_name", // 项目的名称，对应推广计划名称
		},
		AdvertiserId: advertiserId,
		Metrics: []string{
			"stat_cost",                              // 花费
			"show_cnt",                               // 曝光
			"click_cnt",                              // 点击
			"active",                                 // 媒体激活
			"active_pay",                             // 媒体付费认量
			"convert_cnt",                            // 转化数
			"stat_attribution_micro_game_24h_amount", // 24小时变现金额（激活时间）
			"attribution_micro_game_24h_roi",         // 激活后24小时变现ROI
			"stat_micro_game_0d_amount",              // 原生短剧当日变现（结算）
			"attribution_micro_game_0d_ltv",          // 小程序/小游戏当日LTV
			"attribution_micro_game_3d_ltv",          // 小程序/小游戏激活后三日LTV
			"attribution_micro_game_7d_ltv",          // 小程序/小游戏激活后七日LTV
		},
		Filters: []*models.ReportCustomGetV30FiltersInner{},
		OrderBy: []*models.ReportCustomGetV30OrderByInner{
			{Field: "stat_time_hour", Type: &statTimeHourSort},
		},
		StartTime: startDate,
		EndTime:   endDate,
		DataTopic: dataTopic, // 基础数据
	}, appId)
	if err != nil {
		return
	}
	return
}

// DistributeReportAccountsReplenish 项目维度数据补充拉取
func (r *ReportProjectHourService) DistributeReportAccountsReplenish(crontabTime time.Time, ctx context.Context) error {
	// 获取执行时间
	startDate, endDate := GetExecTime(crontabTime)

	//activeDao := accountdao.NewOauthActiveAccountDao(ctx)
	// 按快慢队列查询出所有活跃账号
	//activeList, err := activeDao.ListReplenishQueen(startDate)
	beforeDao := subscribe.NewBeforeSubscribeDao(ctx)
	activeList, err := beforeDao.ReplenishManager(startDate)
	if err != nil {
		return fmt.Errorf("查询活跃账号失败, err: %v", err)
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return fmt.Errorf("查询活跃账号为空")
	}

	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, appIds)
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	oauthMap := make(map[string]map[string]string)
	for _, v := range appIds {
		oauthMap[v] = make(map[string]string)
	}
	for _, v := range oauthList {
		appId := v.AppId
		userId := v.UserId
		oauthMap[appId][userId] = v.AccessToken
	}
	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncReportProjectHourLimit(startDate, endDate, activeList[start:end], oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}
