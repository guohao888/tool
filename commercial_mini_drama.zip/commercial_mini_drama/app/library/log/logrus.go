package log

import (
	"github.com/lestrrat-go/file-rotatelogs"
	"time"
)

func getLogWriter(filename string) (*rotatelogs.RotateLogs, error) {
	return rotatelogs.New(
		// 分割后的文件名称
		filename+"_%Y%m%d.log",
		// 设置最大保存时间(4天)
		rotatelogs.WithMaxAge(4*24*time.Hour),
		// 设置日志切割时间间隔(1天)
		rotatelogs.WithRotationTime(24*time.Hour),
	)
}
