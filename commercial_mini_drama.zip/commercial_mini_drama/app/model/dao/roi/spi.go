package roi

import (
	"context"
	"encoding/json"
	"fmt"
	"goserver/app/common/repository/roi"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"

	"strings"

	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
)

// SpiRequestsDao 处理SPI请求的数据库操作
type SpiRequestsDao struct {
	Ctx context.Context
}

// NewSpiRequestsDao 创建SpiRequestsDao的新实例
func NewSpiRequestsDao(ctx context.Context) *SpiRequestsDao {
	return &SpiRequestsDao{Ctx: ctx}
}

// AddOSpiRequests 批量入库
func (m *SpiRequestsDao) AddSpiTasks(data []*roi.SpiRequestsDataEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = m.batchInsert(tx, data[start:end])
			if e == nil {
				logDatas := getLogDatas(data[start:end])
				e = m.batchInsertLog(tx, logDatas)
			}
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}
	tx.Commit()
	return nil
}

func getLogDatas(data []*roi.SpiRequestsDataEntity) []*roi.MaterialModificationLog {
	if len(data) == 0 {
		return nil
	}

	var logDatas []*roi.MaterialModificationLog

	for _, v := range data {
		// 解析Data字段
		var dataContent struct {
			AppID       int64   `json:"app_id"`
			CoreUserID  int64   `json:"core_user_id"`
			MaterialIDs []int64 `json:"material_ids"`
		}
		if err := json.Unmarshal([]byte(v.Data), &dataContent); err != nil {
			fmt.Printf("解析Data字段失败: %v\n", err)
			continue
		}

		// 解析AdvertiserIDs字段
		var advertiserIDs []int64
		if err := json.Unmarshal([]byte(v.AdvertiserIDs), &advertiserIDs); err != nil {
			fmt.Printf("解析AdvertiserIDs字段失败: %v\n", err)
			continue
		}

		// 为每个MaterialID创建一条记录
		for _, materialID := range dataContent.MaterialIDs {
			logData := &roi.MaterialModificationLog{
				TaskID:          v.TaskID,
				MaterialID:      materialID,
				SubscribeTaskID: v.SubscribeTaskID,
				AdvertiserID:    advertiserIDs[0], // 取第一个广告主ID
				CoreUserID:      dataContent.CoreUserID,
				PublishTime:     v.PublishTime,
				Timestamp:       v.Timestamp,
			}
			logDatas = append(logDatas, logData)
		}
	}

	return logDatas
}

func (m *SpiRequestsDao) batchInsert(tx *gorm.DB, data []*roi.SpiRequestsDataEntity) error {
	if len(data) == 0 {
		return nil
	}

	columns := "task_id, message_id, subscribe_task_id, advertiser_ids, account_relation, service_label, publish_time, timestamp, nonce, data, is_updated"
	values := ""
	for i, entity := range data {
		if i > 0 {
			values += ", "
		}
		// 对字符串类型的字段进行转义处理
		messageID := strings.ReplaceAll(entity.MessageID, "'", "''")
		advertiserIDs := strings.ReplaceAll(entity.AdvertiserIDs, "'", "''")
		accountRelation := strings.ReplaceAll(entity.AccountRelation, "'", "''")
		serviceLabel := strings.ReplaceAll(entity.ServiceLabel, "'", "''")
		dataStr := strings.ReplaceAll(entity.Data, "'", "''")

		values += fmt.Sprintf("(%d, '%s', %d, '%s', '%s', '%s', %d, %d, %d, '%s', %d)",
			entity.TaskID,
			messageID,
			entity.SubscribeTaskID,
			advertiserIDs,
			accountRelation,
			serviceLabel,
			entity.PublishTime,
			entity.Timestamp,
			entity.Nonce,
			dataStr,
			entity.IsUpdated)
	}

	sql := fmt.Sprintf("INSERT INTO %s (%s) VALUES %s", roi.SpiRequestsDataTableName(), columns, values)

	// 执行 SQL 语句
	result := tx.Exec(sql)
	return result.Error
}

func (m *SpiRequestsDao) batchInsertLog(tx *gorm.DB, data []*roi.MaterialModificationLog) error {
	if len(data) == 0 {
		return nil
	}

	columns := "task_id, material_id, subscribe_task_id, advertiser_id, core_user_id, publish_time, timestamp"
	values := ""
	for i, entity := range data {
		if i > 0 {
			values += ", "
		}
		values += fmt.Sprintf("(%d, %d, %d, %d, %d, %d, %d)",
			entity.TaskID,
			entity.MaterialID,
			entity.SubscribeTaskID,
			entity.AdvertiserID,
			entity.CoreUserID,
			entity.PublishTime,
			entity.Timestamp)
	}

	sql := fmt.Sprintf("INSERT INTO %s (%s) VALUES %s", roi.MaterialModificationLogTableNAME(), columns, values)

	// 执行 SQL 语句
	result := tx.Exec(sql)
	return result.Error
}

// AddMaterialModificationLogs 批量添加素材修改日志
//func (m *SpiRequestsDao) AddMaterialModificationLogs(logs []*roi.MaterialModificationLog) error {
//	if len(logs) == 0 {
//		return nil
//	}
//
//	db := dorisdb.DorisClient()
//	// 开始事务
//	tx := db.Begin()
//
//	// 批量插入数据
//	eg := new(errgroup.Group)
//
//	count := len(logs)
//	batchSize := 5000
//	batchPage := dao.BatchPage(count, batchSize)
//	for i := 0; i < batchPage; i++ {
//		start := i * batchSize
//		end := (i + 1) * batchSize
//		if end > count {
//			end = count
//		}
//
//		eg.Go(func() (e error) {
//			defer func() {
//				if x := recover(); x != nil {
//					e = fmt.Errorf("recover %s", x)
//				}
//			}()
//
//			e = m.batchInsertLog(tx, logs[start:end])
//			return e
//		})
//	}
//
//	err := eg.Wait()
//	if err != nil {
//		tx.Rollback()
//		return err
//	}
//	tx.Commit()
//	return nil
//}
