package utils

import (
	"encoding/json"
	"errors"
	"fmt"
	"github.com/satori/go.uuid"
	"github.com/shopspring/decimal"
	"goserver/app/library/constants"
	"goserver/app/library/log"
	utilsmd5 "goserver/app/library/utils/md5"
	"net"
	"net/http"
	"os"
	"path"
	"reflect"
	"sort"
	"strconv"
	"strings"
	"text/template"
	"time"
)

func GetUUID() string {
	bulkuuid := uuid.NewV4()
	struuid := fmt.Sprintf("%s", bulkuuid)

	return struuid
}

// 获取传入的时间所在月份的第一天，即某月第一天的0点。如传入time.Now(), 返回当前月份的第一天0点时间。
func GetFirstDateOfMonth(d time.Time) time.Time {
	d = d.AddDate(0, 0, -d.Day()+1)
	return GetZeroTime(d)
}

// 获取传入的时间所在月份的最后一天，即某月最后一天的0点。如传入time.Now(), 返回当前月份的最后一天0点时间。
func GetLastDateOfMonth(d time.Time) time.Time {
	return GetFirstDateOfMonth(d).AddDate(0, 1, -1)
}

// 获取某一天的0点时间
func GetZeroTime(d time.Time) time.Time {
	return time.Date(d.Year(), d.Month(), d.Day(), 0, 0, 0, 0, d.Location())
}

// 获取某一天的24点时间
func GetDayEndTime(d time.Time) time.Time {
	return time.Date(d.Year(), d.Month(), d.Day(), 23, 59, 59, 0, d.Location())
}

// ClientPublicIP 尽最大努力实现获取客户端公网 IP 的算法。
// 解析 X-Real-IP 和 X-Forwarded-For 以便于反向代理（nginx 或 haproxy）可以正常工作。
func ClientPublicIP(r *http.Request) string {
	var ip string
	for _, ip = range strings.Split(r.Header.Get("X-Forwarded-For"), ",") {
		ip = strings.TrimSpace(ip)
		if ip != "" {
			return ip
		}
	}

	ip = strings.TrimSpace(r.Header.Get("X-Real-Ip"))
	if ip != "" {
		return ip
	}

	if ip, _, err := net.SplitHostPort(strings.TrimSpace(r.RemoteAddr)); err == nil {
		if ip != "" {
			return ip
		}
	}

	return ""
}

// GetIntranetIp 本机IP地址，包含回环地址
func GetIntranetIp() (ips []string, err error) {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return
	}

	for _, address := range addrs {
		// 检查ip地址判断是否回环地址
		//if ipNet, ok := address.(*net.IPNet); ok && !ipNet.IP.IsLoopback() {
		if ipNet, ok := address.(*net.IPNet); ok {
			if ipNet.IP.To4() != nil {
				ips = append(ips, ipNet.IP.To4().String())
			}
		}
	}

	return
}

func StrToUInt(str string) uint {
	i, e := strconv.Atoi(str)
	if e != nil {
		return 0
	}
	return uint(i)
}

func GetFileExt(filename string) (string, error) {
	filename = path.Base(filename)
	extName := path.Ext(filename)
	if len(extName) == 0 {
		return "", nil
	}

	return extName[1:], nil
}

/*
*
是否包含全部的options
*/
func InclueWholeOption(options []string) bool {
	opMap := map[string]bool{}
	for _, op := range options {
		opMap[op] = true
	}

	if _, ok := opMap[constants.FILTER_ALL]; ok {
		return true
	}

	return false
}

/*
*
@desc 计算填充率
*/
func ComputeAvg(total float64, dayNum float64) float64 {
	if total == 0 {
		return 0
	}
	if dayNum == 0 {
		return 0
	}
	avg := fmt.Sprintf("%.2f", (float64(total))/float64(dayNum))
	v, err := strconv.ParseFloat(avg, 64)
	if err != nil {
		log.Errorf("[ComputeAvg] compute year avg failed, avg: %s", avg)
		return 0
	}
	return v
}

/*
*
@desc 计算当前日期是第几周
*/
func ComputeWeekNum(t time.Time) int {
	_, w := t.ISOWeek()
	return int(w)
}

func ComputeWeekBegin(t time.Time) time.Time {
	i := int(t.Weekday())
	if i == 0 {
		i = 7
	}
	i = i - 1
	b := t.AddDate(0, 0, -i)
	bb := time.Date(b.Year(), b.Month(), b.Day(), 0, 0, 0, 0, time.Local)
	return bb
}

func ComputeWeekEnd(t time.Time) time.Time {
	i := int(t.Weekday())
	if i == 0 {
		i = 7
	}
	e := t.AddDate(0, 0, 7-i)
	ee := time.Date(e.Year(), e.Month(), e.Day(), 23, 59, 59, 0, time.Local)
	return ee
}

func ComputeMonthBegin(t time.Time) time.Time {
	ee := time.Date(t.Year(), t.Month(), 1, 0, 0, 0, 0, time.Local)
	return ee
}

func ComputeMonthEnd(t time.Time) time.Time {
	e := time.Date(t.Year(), t.Month()+1, 1, 23, 59, 59, 0, time.Local)
	ee := e.AddDate(0, 0, -1)
	return ee
}

// 获取当天是本月的第几天
func ComputeMonthDay(t time.Time) int {
	b := ComputeMonthBegin(t)
	v := t.YearDay() - b.YearDay()
	return v
}

// 获取本月总天数
func ComputeMonthDayCount(t time.Time) int {
	b := ComputeMonthBegin(t)
	e := ComputeMonthEnd(t)
	v := e.YearDay() - b.YearDay() + 1
	return v
}

func ComputeLastMonthBegin(t time.Time) time.Time {
	ee := time.Date(t.Year(), t.Month()-1, 1, 0, 0, 0, 0, time.Local)
	return ee
}

func ComputeLastMonthEnd(t time.Time) time.Time {
	e := time.Date(t.Year(), t.Month(), 1, 23, 59, 59, 0, time.Local)
	ee := e.AddDate(0, 0, -1)
	return ee
}

func ComputeQuarterBegin(t time.Time) time.Time {
	m := int(t.Month())
	q := 1
	if m >= 1 && m <= 3 {
		q = 1
	}
	if m >= 4 && m <= 6 {
		q = 4
	}
	if m >= 7 && m <= 9 {
		q = 7
	}
	if m >= 10 && m <= 12 {
		q = 10
	}
	b := time.Date(t.Year(), time.Month(q), 1, 0, 0, 0, 0, time.Local)
	return b
}

func ComputeQuarterEnd(t time.Time) time.Time {
	m := int(t.Month())
	q := 1
	if m >= 1 && m <= 3 {
		q = 3
	}
	if m >= 4 && m <= 6 {
		q = 6
	}
	if m >= 7 && m <= 9 {
		q = 9
	}
	if m >= 10 && m <= 12 {
		q = 12
	}
	e := time.Date(t.Year(), time.Month(q)+1, 1, 23, 59, 59, 0, time.Local)
	ee := e.AddDate(0, 0, -1)
	return ee
}

func ComputeDateQuarter(t time.Time) int {
	m := int(t.Month())
	q := 1
	if m >= 1 && m <= 3 {
		q = 1
	}
	if m >= 4 && m <= 6 {
		q = 2
	}
	if m >= 7 && m <= 9 {
		q = 3
	}
	if m >= 10 && m <= 12 {
		q = 4
	}

	return q
}

// 当天是本季度的哪一天
func ComputeQuarterDay(t time.Time) int {
	b := ComputeQuarterBegin(t)
	v := t.YearDay() - b.YearDay()
	return v
}

// 获取本季度总天数
func ComputeQuarterDayCount(t time.Time) int {
	b := ComputeQuarterBegin(t)
	e := ComputeQuarterEnd(t)
	v := e.YearDay() - b.YearDay() + 1
	return v
}

func ComputeYearBegin(t time.Time) time.Time {
	e := time.Date(t.Year(), 1, 1, 0, 0, 0, 0, time.Local)
	return e
}

func ComputeYearEnd(t time.Time) time.Time {
	e := time.Date(t.Year()+1, 1, 1, 23, 59, 59, 0, time.Local)
	ee := e.AddDate(0, 0, -1)
	return ee
}

// 获取本年度总天数
func ComputeYearDayCount(t time.Time) int {
	b := ComputeYearBegin(t)
	e := ComputeYearEnd(t)
	v := e.YearDay() - b.YearDay() + 1
	return v
}

// 当天是本年的第几天
func ComputeYearDay(t time.Time) int {
	return t.YearDay()
}

// 本月进度
func ComputeMonthProcess(t time.Time) string {
	monthProcessDayNum := ComputeMonthDay(t)
	monthDayTotal := ComputeMonthDayCount(t)
	return fmt.Sprintf("%.2f", float64(monthProcessDayNum)/float64(monthDayTotal))
}

// 本季度进度
func ComputeQuarterProcess(t time.Time) string {
	quarterProcessDayNum := ComputeQuarterDay(t)
	quarterDayTotal := ComputeQuarterDayCount(t)
	return fmt.Sprintf("%.2f", float64(quarterProcessDayNum)/float64(quarterDayTotal))
}

// 本年进度
func ComputeYearProcess(t time.Time) string {
	yearProcessDayNum := ComputeYearDay(t)
	yearDayTotal := ComputeYearDayCount(t)
	return fmt.Sprintf("%.2f", float64(yearProcessDayNum)/float64(yearDayTotal))
}

// 本月剩余天数
func ComputeMonthSurplus(t time.Time) int {
	monthProcessDayNum := ComputeMonthDay(t)
	monthDayTotal := ComputeMonthDayCount(t)
	return monthDayTotal - monthProcessDayNum - 1
}

// 本季度剩余天数
func ComputeQuarterSurplus(t time.Time) int {
	quarterProcessDayNum := ComputeQuarterDay(t)
	quarterDayTotal := ComputeQuarterDayCount(t)
	return quarterDayTotal - quarterProcessDayNum - 1
}

// 本年剩余天数
func ComputeYearSurplus(t time.Time) int {
	yearProcessDayNum := ComputeYearDay(t)
	yearDayTotal := ComputeYearDayCount(t)
	return yearDayTotal - yearProcessDayNum - 1
}

// IsInnerIP
// tcp/ip协议中，专门保留了三个IP地址区域作为私有地址，其地址范围如下：
// 10.0.0.0/8：10.0.0.0～10.255.255.255
// 172.16.0.0/12：172.16.0.0～172.31.255.255
// 192.168.0.0/16：192.168.0.0～192.168.255.255
func IsInnerIP(IP net.IP) bool {

	if ip4 := IP.To4(); ip4 != nil {
		switch true {
		case ip4[0] == 10:
			return true
		case ip4[0] == 172 && ip4[1] >= 16 && ip4[1] <= 31:
			return true
		case ip4[0] == 192 && ip4[1] == 168:
			return true
		default:
			return false
		}
	}

	return false
}

func ComputeFloatRatio5(v1 float64, v2 float64) float64 {
	if v1 <= 0.0000001 && v1 >= -0.0000001 {
		return 0
	}
	if v2 <= 0.0000001 && v2 >= -0.0000001 {
		return 0
	}
	avg := fmt.Sprintf("%.5f", v1/v2)
	v, err := strconv.ParseFloat(avg, 64)
	if err != nil {
		return 0
	}
	return v
}

func ComputeFloatRatio2(v1 float64, v2 float64) float64 {
	if v1 <= 0.0000001 && v1 >= -0.0000001 {
		return 0
	}
	if v2 <= 0.0000001 && v2 >= -0.0000001 {
		return 0
	}
	avg := fmt.Sprintf("%.2f", v1/v2)
	v, err := strconv.ParseFloat(avg, 64)
	if err != nil {
		return 0
	}
	return v
}

func ComputeFloatRatioPercent(v1 float64, v2 float64) float64 {
	if v1 <= 0.0000001 && v1 >= -0.0000001 {
		return 0
	}
	if v2 <= 0.0000001 && v2 >= -0.0000001 {
		return 0
	}
	avg := fmt.Sprintf("%.2f", v1/v2*100.0)
	v, err := strconv.ParseFloat(avg, 64)
	if err != nil {
		return 0
	}
	return v
}

func ComputeFloatDiffPercent(now, before float64) float64 {
	diff := now - before
	if diff <= 0.0000001 && diff >= -0.0000001 {
		return 0
	}
	if before <= 0.0000001 && before >= -0.0000001 {
		return 0
	}
	avg := fmt.Sprintf("%.2f", diff/before*100.0)
	v, err := strconv.ParseFloat(avg, 64)
	if err != nil {
		return 0
	}
	return v
}

func ComputeFloatDiffPercentStrWithSigned(now, before float64) string {
	diff := now - before
	if diff <= 0.0000001 && diff >= -0.0000001 {
		return "0"
	}
	if before <= 0.0000001 && before >= -0.0000001 {
		return "0"
	}
	s := fmt.Sprintf("%.2f", diff/before*100.0)
	if diff > 0 {
		s = "+" + s
	}
	return s
}

func DecimalDiv(v1, v2 decimal.Decimal) decimal.Decimal {
	if v2.IsZero() {
		return decimal.Zero
	} else {
		return v1.Div(v2)
	}
}

func Float64Div(v1, v2 float64) float64 {
	if v2 == 0.0 {
		return 0.0
	} else {
		return v1 / v2
	}
}

func Decimal2Float64(v decimal.Decimal) float64 {
	f, _ := v.Float64()
	return f
}

func DecimalDiv2Float64(v1, v2 decimal.Decimal) float64 {
	if v2.IsZero() {
		return 0.0
	} else {
		f, _ := v1.Div(v2).Float64()
		return f
	}
}

type Cascade struct {
	Key      string    `json:"key"`
	Value    string    `json:"value"`
	Level    string    `json:"level,omitempty"`
	Children []Cascade `json:"children,omitempty"`
}

// FindOrCreateChild 查找或创建子节点 sunguangzong add
func FindOrCreateChild(children *[]Cascade, key string, level string, isUnKey bool) *Cascade {
	k := key
	if isUnKey {
		k = utilsmd5.GetStringMd5(fmt.Sprintf("%s_%s", level, k))
	}
	for i := range *children {
		if (*children)[i].Key == k {
			return &(*children)[i]
		}
	}
	newNode := Cascade{Key: k, Value: key, Level: level}
	*children = append(*children, newNode)
	return &(*children)[len(*children)-1]
}

func IntersectionStringSlicesWithSort(slice1, slice2 []string) []string {
	var result []string
	sort.Strings(slice1)
	sort.Strings(slice2)
	i, j := 0, 0
	for i < len(slice1) && j < len(slice2) {
		if slice1[i] == slice2[j] {
			if len(result) == 0 || slice1[i] != result[len(result)-1] {
				result = append(result, slice1[i])
			}
			i++
			j++
		} else if slice1[i] < slice2[j] {
			i++
		} else {
			j++
		}
	}
	return result
}

func GetIDC() (string, bool) {
	//新版容器云的机房环境变量拥有新的名字
	key := "QIHOO_IDC"
	idc, ok := os.LookupEnv(key)
	if ok {
		return idc, ok
	}
	//老容器云机房环境变量
	key = "SYS_IDC_NAME"
	idc, ok = os.LookupEnv(key)
	if ok {
		return idc, ok
	}
	//如果系统没有以上环境变量，则可能是虚拟机
	hostname, err := os.Hostname()
	if err != nil {
		return "", false
	}
	hostnameSplit := strings.Split(hostname, ".")
	if len(hostnameSplit) == 5 {
		return hostnameSplit[2], true
	}

	return "", false
}

func ExternalIP() (net.IP, error) {
	ifaces, err := net.Interfaces()
	if err != nil {
		return nil, err
	}
	for _, iface := range ifaces {
		if iface.Flags&net.FlagUp == 0 {
			continue // interface down
		}
		if iface.Flags&net.FlagLoopback != 0 {
			continue // loopback interface
		}
		addrs, err := iface.Addrs()
		if err != nil {
			return nil, err
		}
		for _, addr := range addrs {
			ip := getIpFromAddr(addr)
			if ip == nil {
				continue
			}
			return ip, nil
		}
	}
	return nil, errors.New("connected to the network?")
}

func getIpFromAddr(addr net.Addr) net.IP {
	var ip net.IP
	switch v := addr.(type) {
	case *net.IPNet:
		ip = v.IP
	case *net.IPAddr:
		ip = v.IP
	}
	if ip == nil || ip.IsLoopback() {
		return nil
	}
	ip = ip.To4()
	if ip == nil {
		return nil // not an ipv4 address
	}

	return ip
}

func HtmlEncode(html string) string {
	html = strings.Replace(html, "\\", "", -1) //先手工过滤掉反斜线sql注入
	return template.HTMLEscapeString(html)
}

func InArray(need string, needArr []string) bool {
	for _, v := range needArr {
		if need == v {
			return true
		}
	}
	return false
}

func IntInArray(need int, needArr []int) bool {
	for _, v := range needArr {
		if need == v {
			return true
		}
	}
	return false
}

func Contains[T comparable](input []T, elem T) bool {
	for _, t := range input {
		if t == elem {
			return true
		}
	}
	return false
}

// 去除切片中重复的值
func ArrayUnique[T comparable](input []T) []T {
	var res []T
	for _, v := range input {
		if !Contains(res, v) {
			res = append(res, v)
		}
	}
	return res
}

func Join[T any](elements []T, separator string) string {
	var strElements []string
	for _, element := range elements {
		strElements = append(strElements, fmt.Sprintf("%v", element))
	}
	return strings.Join(strElements, separator)
}

func Convert2Int64(data interface{}) int64 {
	switch data.(type) {
	case string:
		v, _ := strconv.ParseInt(data.(string), 10, 64)
		return v
	case json.Number:
		v, _ := strconv.ParseInt(data.(json.Number).String(), 10, 64)
		return v
	case float32, float64:
		return int64(reflect.ValueOf(data).Float())
	case int, int8, int16, int32, int64:
		return reflect.ValueOf(data).Int()
	case uint, uint8, uint16, uint32, uint64:
		return reflect.ValueOf(data).Int()
	}
	return 0
}

func Convert2Float64(data interface{}) float64 {
	switch data.(type) {
	case string:
		v, _ := strconv.ParseFloat(data.(string), 64)
		return v
	case json.Number:
		v, _ := strconv.ParseFloat(data.(json.Number).String(), 64)
		return v
	case float32, float64:
		return float64(reflect.ValueOf(data).Float())
	case int, int8, int16, int32, int64:
		return float64(reflect.ValueOf(data).Int())
	case uint, uint8, uint16, uint32, uint64:
		return float64(reflect.ValueOf(data).Int())
	}
	return 0
}

func Convert2String(data interface{}) string {
	switch data.(type) {
	case string:
		return data.(string)
	case json.Number:
		return data.(json.Number).String()
	case float32, float64:
		v := float64(reflect.ValueOf(data).Float())
		return fmt.Sprintf("%.2f", v)
	case int, int8, int16, int32, int64:
		v := reflect.ValueOf(data).Int()
		return fmt.Sprintf("%d", v)
	case uint, uint8, uint16, uint32, uint64:
		v := reflect.ValueOf(data).Int()
		return fmt.Sprintf("%d", v)
	}
	return ""
}

func SliceUniqStr(s []string) []string {
	if len(s) == 0 {
		return s
	}
	seen := make(map[string]struct{}, len(s))
	j := 0
	for _, v := range s {
		if _, ok := seen[v]; ok {
			continue
		}
		seen[v] = struct{}{}
		s[j] = v
		j++
	}
	return s[:j]
}

// 检查字符串是否在切片中
func ContainsString(slice []string, str string) bool {
	for _, s := range slice {
		if strings.Contains(s, str) {
			return true
		}
	}
	return false
}
