package warning

import (
	"goserver/app/common/repository"
)

const TaskInfoEntityTable = "task_info"

type TaskInfoEntity struct {
	PrimaryKey string `gorm:"column:primary_key"` // 主键
	Content    string `gorm:"column:content"`     // 内容
}

func (*TaskInfoEntity) TableName() string {
	return TaskInfoEntityTable
}

func TaskInfoEntityTableName() string {
	if repository.IsDebugTable(TaskInfoEntityTable) {
		return TaskInfoEntityTable + "_dev"
	} else {
		return TaskInfoEntityTable
	}
}
