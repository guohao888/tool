package accounts

import "context"

type DistributorConfigService struct {
	Ctx context.Context
}

func NewDistributorConfigService(ctx context.Context) *DistributorConfigService {
	return &DistributorConfigService{Ctx: ctx}
}
