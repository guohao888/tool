package accounts

import (
	"context"
	"github.com/jinzhu/gorm"
	accountdto "goserver/app/common/dto/accounts"
	"goserver/app/common/repository/accounts"
	"goserver/app/library/driver/dorisdb"
)

type OptimizerInfoDao struct {
	Ctx context.Context
}

func NewOptimizerInfoDao(ctx context.Context) *OptimizerInfoDao {
	return &OptimizerInfoDao{Ctx: ctx}
}

func (d *OptimizerInfoDao) OptimizerInfoList() (res []accounts.OptimizerInfoEntity, err error) {
	table := accounts.OptimizerInfoTableName()
	db := dorisdb.DorisClient()
	err = db.Table(table).Select("nick_name, region").
		Where("status=?", 0).
		Order("nick_name asc").
		Find(&res).Error
	return
}

func (d *OptimizerInfoDao) OptimizerInfoListByName(names string) (res []accounts.OptimizerInfoEntity, err error) {
	table := accounts.OptimizerInfoTableName()
	db := dorisdb.DorisClient()
	err = db.Table(table).Select("nick_name, region").
		Where("status=? and nick_name in (?)", 0, names).
		Order("nick_name asc").
		Find(&res).Error
	return
}

func (d *OptimizerInfoDao) OptimizerInfoListByNamePhone(names []string) (res []accounts.OptimizerInfoEntity, err error) {
	table := accounts.OptimizerInfoTableName()
	db := dorisdb.DorisClient()
	err = db.Table(table).Select("nick_name, phone, region").
		Where("status=? and nick_name in (?)", 0, names).
		Order("nick_name asc").
		Find(&res).Error
	return
}

func (d *OptimizerInfoDao) MergeQuery(params accountdto.PromotionUrlMergeExecutorParams) *gorm.SqlExpr {
	db := dorisdb.DorisClient()

	q := db.Table(accounts.OptimizerInfoTableName())
	return q.QueryExpr()
}
