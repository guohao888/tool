package spi

import (
	"context"
	"encoding/json"
	"errors"
	"goserver/app/common/dto/spidto"
	"goserver/app/common/repository/roi"
	"goserver/app/library/log"
	daoroi "goserver/app/model/dao/roi"
	"time"
)

// SpiMaterialService 番茄IAP订单Service
type SpiMaterialService struct {
	Ctx context.Context
}

// NewSpiMaterialService 创建上下文IAP订单Service
func NewSpiMaterialService(ctx context.Context) *SpiMaterialService {
	return &SpiMaterialService{Ctx: ctx}
}

// SaveSpiMaterialInfos 保存IAP订单数据
func (s *SpiMaterialService) SaveSpiMaterialInfos(reqs []spidto.SpiMaterialRequest) error {
	var res []*roi.SPIMaterialModificationLog
	for _, req := range reqs {
		logs, err := s.ConvertToMaterialLog(req)
		if err != nil {
			continue
		}
		res = append(res, logs...)
	}

	if len(res) > 0 {
		dao := daoroi.NewSpiMaterialDao(s.Ctx)
		return dao.InsertBatchSize(res, 5000)
	}
	return nil
}

// ConvertToMaterialLog 将 SpiMaterialRequest 转换为 SPIMaterialModificationLog
func (s *SpiMaterialService) ConvertToMaterialLog(entity spidto.SpiMaterialRequest) ([]*roi.SPIMaterialModificationLog, error) {
	// 解析 Data 字段
	data, err := entity.ParseData()
	if err != nil {
		entityByte, _ := json.Marshal(entity)
		log.Errorf("oceanengine spi ConvertToMaterialLog error: %s,  request: %s", err.Error(), string(entityByte))
		return nil, errors.New("解析错误")
	}

	// 为每个 MaterialID 创建一条记录
	var logs []*roi.SPIMaterialModificationLog
	for _, materialID := range data.MaterialIDs {
		clog := &roi.SPIMaterialModificationLog{
			MessageID:       entity.MessageID,
			AdvertiserID:    entity.AdvertiserIDs[0], // 取第一个广告主ID
			MaterialID:      materialID,
			ServiceLabel:    entity.ServiceLabel,
			SubscribeTaskID: entity.SubscribeTaskID,
			CoreUserID:      data.CoreUserID,
			AppID:           data.AppID,
			PublishTime:     entity.PublishTime,
			Timestamp:       entity.Timestamp,
			Nonce:           entity.Nonce,
			CreatedAt:       time.Now(),
			UpdatedAt:       time.Now(),
		}
		logs = append(logs, clog)
	}

	return logs, nil
}
