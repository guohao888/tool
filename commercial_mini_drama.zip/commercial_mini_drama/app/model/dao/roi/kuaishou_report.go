package roi

import (
	"context"
	"goserver/app/common/dto/roidto"
	repo "goserver/app/common/repository/roi"
	"goserver/app/library/driver/dorisdb"
	"strconv"
)

type KsReportDataDao struct {
	Ctx context.Context
}

func NewKsReportDataDao(ctx context.Context) *KsReportDataDao {
	return &KsReportDataDao{Ctx: ctx}
}

func (d *KsReportDataDao) BookAry(keywords string, limit int) (result []roidto.IDLabel, err error) {
	db := dorisdb.DorisClient()
	tableToday := repo.ProjectReportTodayDataViewTableName()
	tableHis := repo.ProjectReportDataViewTableName()

	innerSql := "(SELECT book_name FROM " + tableToday + " UNION ALL SELECT book_name FROM " + tableHis + ") t"
	sql := "SELECT DISTINCT book_name FROM " + innerSql + " WHERE book_name!='' "
	if keywords != "" {
		sql += " AND book_name LIKE '%" + keywords + "%'"
	}
	sql += "  ORDER BY book_name ASC"
	if limit > 0 {
		sql += " LIMIT " + strconv.FormatInt(int64(limit), 10)
	}

	type Row struct {
		Name string `gorm:"column:book_name"`
	}
	var res []Row
	err = db.Raw(sql).Scan(&res).Error
	if err != nil {
		return
	}
	for _, row := range res {
		result = append(result, roidto.IDLabel{
			ID:    row.Name, // 特殊处理
			Label: row.Name,
		})
	}
	return
}
