package kuaishou

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/kuaishou"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// AdDataDao 短剧广告报表
type AdDataDao struct {
	Ctx context.Context
}

func NewAdDataDao(ctx context.Context) *AdDataDao {
	return &AdDataDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (a *AdDataDao) InsertBatchSize(data []*kuaishou.AdDataEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 5000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = a.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (r *AdDataDao) buildInsertSentence(tx *gorm.DB, data []*kuaishou.AdDataEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + kuaishou.AdDataTableName() + " ( advertiser_id, date, series_type, likes, share, photo_click, impression, event_pay, t0_direct_paid_cnt, event_pay_purchase_amount, t0_direct_paid_amt, ad_show, total_charge, event_app_invoked, event_pay_purchase_amount_first_day, event_pay_purchase_amount_one_day_by_conversion, event_pay_purchase_amount_week_by_conversion, event_pay_purchase_amount_three_day_by_conversion, conversion, t0_direct_conversion_cnt, negative, report, block, comment, event_pay_first_day, played_num, played_three_seconds, ad_photo_played75percent, played_end, follow, event_new_user_pay, ad_item_click, t7_paid_cnt, t7_paid_amt, conversion_num_by_impression7d, deep_conversion_num_by_impression7d, conversion_num, deep_conversion_num, t0_paid_cnt, t0_paid_amt, play3s_ratio, ad_photo_played_75percent_ratio, t7_paid_roi, t0_paid_roi, photo_click_ratio, event_pay_cost, event_pay_roi, event_app_invoked_cost, event_app_invoked_ratio, conversion_cost, event_pay_first_day_roi, event_pay_purchase_amount_one_day_by_conversion_roi, event_pay_purchase_amount_three_day_by_conversion_roi, event_pay_purchase_amount_week_by_conversion_roi, photo_click_cost, impression1k_cost, click1k_cost, action_cost, deep_conversion_cost_by_impression7d, deep_conversion_ratio_by_impression7d, event_pay_first_day_cost, action_ratio, play_end_ratio, event_new_user_pay_cost, event_new_user_pay_ratio, action_new_ratio, conversion_cost_by_impression7d, conversion_ratio_by_impression7d, key_action, ad_photo_played75percent_ratio, mini_game_iaa_roi, mini_game_iaa_purchase_amount ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.Date,
			v.SeriesType,
			v.Likes,
			v.Share,
			v.PhotoClick,
			v.Impression,
			v.EventPay,
			v.T0DirectPaidCnt,
			v.EventPayPurchaseAmount,
			v.T0DirectPaidAmt,
			v.AdShow,
			v.TotalCharge,
			v.EventAppInvoked,
			v.EventPayPurchaseAmountFirstDay,
			v.EventPayPurchaseAmountOneDayByConversion,
			v.EventPayPurchaseAmountWeekByConversion,
			v.EventPayPurchaseAmountThreeDayByConversion,
			v.Conversion,
			v.T0DirectConversionCnt,
			v.Negative,
			v.Report,
			v.Block,
			v.Comment,
			v.EventPayFirstDay,
			v.PlayedNum,
			v.PlayedThreeSeconds,
			v.AdPhotoPlayed75percent,
			v.PlayedEnd,
			v.Follow,
			v.EventNewUserPay,
			v.AdItemClick,
			v.T7PaidCnt,
			v.T7PaidAmt,
			v.ConversionNumByImpression7d,
			v.DeepConversionNumByImpression7d,
			v.ConversionNum,
			v.DeepConversionNum,
			v.T0PaidCnt,
			v.T0PaidAmt,
			v.Play3sRatio,
			v.AdPhotoPlayed75PercentRatio,
			v.T7PaidRoi,
			v.T0PaidRoi,
			v.PhotoClickRatio,
			v.EventPayCost,
			v.EventPayRoi,
			v.EventAppInvokedCost,
			v.EventAppInvokedRatio,
			v.ConversionCost,
			v.EventPayFirstDayRoi,
			v.EventPayPurchaseAmountOneDayByConversionRoi,
			v.EventPayPurchaseAmountThreeDayByConversionRoi,
			v.EventPayPurchaseAmountWeekByConversionRoi,
			v.PhotoClickCost,
			v.Impression1kCost,
			v.Click1kCost,
			v.ActionCost,
			v.DeepConversionCostByImpression7d,
			v.DeepConversionRatioByImpression7d,
			v.EventPayFirstDayCost,
			v.ActionRatio,
			v.PlayEndRatio,
			v.EventNewUserPayCost,
			v.EventNewUserPayRatio,
			v.ActionNewRatio,
			v.ConversionCostByImpression7d,
			v.ConversionRatioByImpression7d,
			v.KeyAction,
			v.AdPhotoPlayed75percentRatio,
			v.MiniGameIaaRoi,
			v.MiniGameIaaPurchaseAmount,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")

	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
