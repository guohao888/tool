package kafka

import (
	"context"
	"encoding/json"
	"fmt"
	"goserver/app/common/dto"
	fanqie2 "goserver/app/common/dto/fanqie"
	"goserver/app/common/dto/spidto"
	"goserver/app/common/dto/subscribedto"
	glog "goserver/app/library/log"
	"log"
	"time"

	"github.com/IBM/sarama"
)

/****************************   IAA orders   ****************************/

type ConsumerIOrder struct {
	consumerGroup sarama.ConsumerGroup
	topic         string
	orderHandler  func(orders []fanqie2.TomatoIAAOrderReq)
}

func NewIOrderConsumer(brokers []string, groupID string, topic string, oHandler func([]fanqie2.TomatoIAAOrderReq)) (*ConsumerIOrder, error) {

	config := sarama.NewConfig()
	config.Version = sarama.V1_1_1_0
	config.Consumer.Offsets.Initial = sarama.OffsetOldest

	consumerGroup, err := sarama.NewConsumerGroup(brokers, groupID, config)
	if err != nil {
		return nil, fmt.Errorf("failed to create consumer: %w", err)
	}

	return &ConsumerIOrder{
		consumerGroup: consumerGroup,
		topic:         topic,
		orderHandler:  oHandler,
	}, nil
}

func (c *ConsumerIOrder) Consume(ctx context.Context) {
	consumerHandler := &consumerGroupHandler{
		msgHandler: c.processMessages,
	}

	for {
		err := c.consumerGroup.Consume(ctx, []string{c.topic}, consumerHandler)
		if err != nil {
			log.Printf("consume error: %v", err)
		}
		if ctx.Err() != nil {
			return
		}
	}
}

func (c *ConsumerIOrder) processMessages(messages []*sarama.ConsumerMessage) {
	var orders []fanqie2.TomatoIAAOrderReq
	for _, msg := range messages {
		var order fanqie2.TomatoIAAOrderReq
		if err := json.Unmarshal(msg.Value, &order); err != nil {
			log.Printf("unmarshal error: %v", err)
			continue
		}
		orders = append(orders, order)
	}
	if len(orders) > 0 {
		c.orderHandler(orders)
	}
}

/****************************   IAP orders   ****************************/

type ConsumerPOrder struct {
	consumerGroup   sarama.ConsumerGroup
	topic           string
	iapOrderHandler func(iapOrders []fanqie2.TomatoIAPOrderReq)
}

func NewPOrderConsumer(brokers []string, groupID string, topic string, pHandler func([]fanqie2.TomatoIAPOrderReq)) (*ConsumerPOrder, error) {

	config := sarama.NewConfig()
	config.Version = sarama.V1_1_1_0
	config.Consumer.Offsets.Initial = sarama.OffsetOldest

	consumerGroup, err := sarama.NewConsumerGroup(brokers, groupID, config)
	if err != nil {
		return nil, fmt.Errorf("failed to create consumer: %w", err)
	}

	return &ConsumerPOrder{
		consumerGroup:   consumerGroup,
		topic:           topic,
		iapOrderHandler: pHandler,
	}, nil
}

func (c *ConsumerPOrder) Consume(ctx context.Context) {
	consumerHandler := &consumerGroupHandler{
		msgHandler: c.processMessages,
	}

	for {
		err := c.consumerGroup.Consume(ctx, []string{c.topic}, consumerHandler)
		if err != nil {
			log.Printf("consume error: %v", err)
		}
		if ctx.Err() != nil {
			return
		}
	}
}

func (c *ConsumerPOrder) processMessages(messages []*sarama.ConsumerMessage) {
	var iapOrders []fanqie2.TomatoIAPOrderReq
	for _, msg := range messages {
		var iapOrder fanqie2.TomatoIAPOrderReq
		if err := json.Unmarshal(msg.Value, &iapOrder); err != nil {
			log.Printf("unmarshal error: %v", err)
			continue
		}
		iapOrders = append(iapOrders, iapOrder)
	}
	if len(iapOrders) > 0 {
		c.iapOrderHandler(iapOrders)
	}
}

/****************************   users   ****************************/

type ConsumerUser struct {
	consumerGroup sarama.ConsumerGroup
	topic         string
	userHandler   func(users []fanqie2.TomatoUserReq)
}

func NewUserConsumer(brokers []string, groupID string, topic string, uHandler func([]fanqie2.TomatoUserReq)) (*ConsumerUser, error) {

	config := sarama.NewConfig()
	config.Version = sarama.V1_1_1_0
	config.Consumer.Offsets.Initial = sarama.OffsetOldest

	consumerGroup, err := sarama.NewConsumerGroup(brokers, groupID, config)
	if err != nil {
		return nil, fmt.Errorf("failed to create consumer: %w", err)
	}

	return &ConsumerUser{
		consumerGroup: consumerGroup,
		topic:         topic,
		userHandler:   uHandler,
	}, nil
}

func (c *ConsumerUser) Consume(ctx context.Context) {
	consumerHandler := &consumerGroupHandler{
		msgHandler: c.processMessages,
	}

	for {
		err := c.consumerGroup.Consume(ctx, []string{c.topic}, consumerHandler)
		if err != nil {
			log.Printf("consume error: %v", err)
		}
		if ctx.Err() != nil {
			return
		}
	}
}

func (c *ConsumerUser) processMessages(messages []*sarama.ConsumerMessage) {

	var users []fanqie2.TomatoUserReq
	for _, msg := range messages {
		var user fanqie2.TomatoUserReq
		if err := json.Unmarshal(msg.Value, &user); err != nil {
			log.Printf("unmarshal error: %v", err)
			continue
		}
		users = append(users, user)
	}
	if len(users) > 0 {
		c.userHandler(users)

	}
}

/****************************   kafka_spi_material   ****************************/

type ConsumerSpiMaterial struct {
	consumerGroup sarama.ConsumerGroup
	topic         string
	userHandler   func(reqs []spidto.SpiMaterialRequest)
}

func NewConsumerSpiMaterial(brokers []string, groupID string, topic string, uHandler func([]spidto.SpiMaterialRequest)) (*ConsumerSpiMaterial, error) {

	config := sarama.NewConfig()
	config.Version = sarama.V1_1_1_0
	config.Consumer.Offsets.Initial = sarama.OffsetOldest

	consumerGroup, err := sarama.NewConsumerGroup(brokers, groupID, config)
	if err != nil {
		return nil, fmt.Errorf("failed to create consumer: %w", err)
	}

	return &ConsumerSpiMaterial{
		consumerGroup: consumerGroup,
		topic:         topic,
		userHandler:   uHandler,
	}, nil
}

func (c *ConsumerSpiMaterial) Consume(ctx context.Context) {
	consumerHandler := &consumerGroupHandler{
		msgHandler: c.processMessages,
	}

	for {
		err := c.consumerGroup.Consume(ctx, []string{c.topic}, consumerHandler)
		if err != nil {
			log.Printf("consume error: %v", err)
		}
		if ctx.Err() != nil {
			return
		}
	}
}

func (c *ConsumerSpiMaterial) processMessages(messages []*sarama.ConsumerMessage) {
	var reqs []spidto.SpiMaterialRequest
	for _, msg := range messages {
		var info dto.KafkaMessage
		if err := json.Unmarshal(msg.Value, &info); err != nil {
			glog.Errorf("oceanengine spi 解析 Kafka 消息失败: err=%s, value=%s", err.Error(), string(msg.Value))
			continue
		}

		// 只处理素材相关的推送
		if info.Type != dto.KafkaMessageSpiMaterial {
			continue
		}

		var req spidto.SpiMaterialRequest
		if err := json.Unmarshal(info.Payload, &req); err != nil {
			glog.Errorf("oceanengine spi 解析 SPI 素材请求失败: err=%s, payload=%s", err.Error(), string(info.Payload))
			continue
		}
		reqs = append(reqs, req)
	}
	if len(reqs) > 0 {
		c.userHandler(reqs)
	}
}

/****************************   公共方法   ****************************/

type consumerGroupHandler struct {
	msgHandler func([]*sarama.ConsumerMessage)
}

func (h *consumerGroupHandler) Setup(_ sarama.ConsumerGroupSession) error   { return nil }
func (h *consumerGroupHandler) Cleanup(_ sarama.ConsumerGroupSession) error { return nil }
func (h *consumerGroupHandler) ConsumeClaim(sess sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	const (
		batchSize    = 2000
		batchTimeout = 60 * time.Second
	)

	batch := make([]*sarama.ConsumerMessage, 0, batchSize)
	timer := time.NewTimer(batchTimeout)
	defer timer.Stop()

	for {
		select {
		case msg, ok := <-claim.Messages():
			if !ok {
				if len(batch) > 0 {
					h.msgHandler(batch)
					sess.MarkMessage(batch[len(batch)-1], "")
				}
				batch = nil
			}
			batch = append(batch, msg)
			if len(batch) >= batchSize {
				h.msgHandler(batch)
				sess.MarkMessage(batch[len(batch)-1], "")
				batch = batch[:0]
				timer.Reset(batchTimeout)
			}
		case <-timer.C:
			if len(batch) > 0 {
				h.msgHandler(batch)
				sess.MarkMessage(batch[len(batch)-1], "")
				batch = batch[:0]
			}
			timer.Reset(batchTimeout)
		case <-sess.Context().Done():
			return nil
		}
	}
}

/****************************   subscribe advertiser   ****************************/

type ConsumerPostInfo struct {
	consumerGroup          sarama.ConsumerGroup
	topic                  string
	subscribeBeforeHandler func(subscribe []subscribedto.PostInfoReq)
	subscribeTodayHandler  func(subscribe []subscribedto.PostInfoReq)
}

func NewSubscribeConsumer(brokers []string, groupID string, topic string, handlerBefore func([]subscribedto.PostInfoReq), handlerToday func([]subscribedto.PostInfoReq)) (*ConsumerPostInfo, error) {

	config := sarama.NewConfig()
	config.Version = sarama.V1_1_1_0
	config.Consumer.Offsets.Initial = sarama.OffsetOldest

	consumerGroup, err := sarama.NewConsumerGroup(brokers, groupID, config)
	if err != nil {
		return nil, fmt.Errorf("failed to create consumer: %w", err)
	}

	return &ConsumerPostInfo{
		consumerGroup:          consumerGroup,
		topic:                  topic,
		subscribeBeforeHandler: handlerBefore,
		subscribeTodayHandler:  handlerToday,
	}, nil
}

func (c *ConsumerPostInfo) Consume(ctx context.Context) {
	consumerHandler := &consumerGroupHandler{
		msgHandler: c.processMessages,
	}

	for {
		err := c.consumerGroup.Consume(ctx, []string{c.topic}, consumerHandler)
		if err != nil {
			log.Printf("consume error: %v", err)
		}
		if ctx.Err() != nil {
			return
		}
	}
}

func (c *ConsumerPostInfo) processMessages(messages []*sarama.ConsumerMessage) {

	var subscribeBefore, subscribeToday []subscribedto.PostInfoReq
	for _, msg := range messages {
		var subscribe subscribedto.PostInfoReq
		if err := json.Unmarshal(msg.Value, &subscribe); err != nil {
			log.Printf("unmarshal error: %v", err)
			continue
		}
		if subscribe.ServiceLabel == "report.advertiser.beforeday" {
			subscribeBefore = append(subscribeBefore, subscribe)
		} else if subscribe.ServiceLabel == "report.advertiser.activeprogram" {
			subscribeToday = append(subscribeToday, subscribe)
		}
	}
	if len(subscribeBefore) > 0 {
		c.subscribeBeforeHandler(subscribeBefore)
	}
	if len(subscribeToday) > 0 {
		c.subscribeTodayHandler(subscribeToday)
	}
}

//for msg := range claim.Messages() {
//	batch = append(batch, msg)
//	// 批量处理：每 300 条或缓冲区有数据时处理
//	if len(batch) >= 300 {
//		h.msgHandler(batch)
//		sess.MarkMessage(batch[len(batch)-1], "")
//		batch = nil
//	}
//}
//
//// 处理剩余消息
//if len(batch) > 0 {
//	h.msgHandler(batch)
//	sess.MarkMessage(batch[len(batch)-1], "")
//}
//return nil
//}
