package pprof

import (
	"context"
	"errors"
	"fmt"
	"net"
	"net/http"
	"net/http/pprof"
	"strings"
	"time"
)

var (
	errType = errors.New("params type error must be []string or []net.listener")
	ss      []*http.Server
)

// Init StartPprof start http pprof.
func Init(pprofBind interface{}) error {
	pprofServeMux := http.NewServeMux()
	pprofServeMux.HandleFunc("/debug/pprof/", pprof.Index)
	pprofServeMux.HandleFunc("/debug/pprof/cmdline", pprof.Cmdline)
	pprofServeMux.HandleFunc("/debug/pprof/profile", pprof.Profile)
	pprofServeMux.HandleFunc("/debug/pprof/symbol", pprof.Symbol)

	pprofAddrs, ok := pprofBind.([]string)
	if ok {
		for _, addr := range pprofAddrs {
			var (
				l   net.Listener
				err error
			)
			if strings.Index(addr, ":") == -1 {
				l, err = net.Listen("unix", addr)
			} else {
				l, err = net.Listen("tcp", addr)
			}
			if err != nil {
				fmt.Printf("net.Listen(%v) error(%v)", addr, err.Error())
				return err
			}

			s := &http.Server{
				Handler:        pprofServeMux,
				ReadTimeout:    15 * time.Second,
				MaxHeaderBytes: 1 << 20,
			}
			ss = append(ss, s)
			go func(s *http.Server, l net.Listener) {
				if err := s.Serve(l); err != nil {
					if err == http.ErrServerClosed {
						return
					}
					fmt.Printf("s.ListenAndServe() error(%v)", err.Error())
				}
			}(s, l)
		}
		return nil
	}

	pprofSockets, ok := pprofBind.([]net.Listener)
	if ok {
		for _, socket := range pprofSockets {
			s := &http.Server{
				Handler:        pprofServeMux,
				ReadTimeout:    15 * time.Second,
				MaxHeaderBytes: 1 << 20,
			}
			ss = append(ss, s)
			go func(s *http.Server, l net.Listener) {
				if err := s.Serve(l); err != nil {
					if err == http.ErrServerClosed {
						return
					}
					fmt.Printf("s.ListenAndServe() error(%v)", err.Error())
				}
			}(s, socket)
		}
		return nil
	}
	return errType
}

// Close close the resource.
func Close() {
	for _, s := range ss {
		ctx, _ := context.WithTimeout(context.Background(), 30*time.Second)
		if err := s.Shutdown(ctx); err != nil {
			fmt.Printf("s.Shutdown(ctx) error(%v)", err.Error())
		}
	}
	ss = []*http.Server{}
}
