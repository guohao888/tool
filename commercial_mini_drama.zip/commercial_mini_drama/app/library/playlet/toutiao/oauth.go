package toutiao

import (
	"context"
	"fmt"
	"github.com/avast/retry-go"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"goserver/app/library/playlet/cache"
	"time"
)

const (
	CodeSuccess             = 0
	CodeErrorOnManyRequests = 40110 // by this developer. Please retry in some time.
	CodeErrorAccessToken    = 40105 // access_token无效，请传入最新的access_token
	CodeError40000          = 40000 // 传参有误
	CodeError40002          = 40002 // 鉴权失败，请检查参数传入是否正确 (这种由于用户删除了), 还有 No permission to operate account 广告主id
)

func Oauth2AccessToken(ctx context.Context, request models.Oauth2AccessTokenRequest) (*models.Oauth2AccessTokenResponse, error) {
	var resp *models.Oauth2AccessTokenResponse
	err := retry.Do(func() error {
		var e error
		resp, _, e = apiClient.Oauth2AccessTokenApi().
			Post(ctx).
			Oauth2AccessTokenRequest(request).
			Execute()
		if e != nil {
			return e
		}
		if resp == nil {
			return fmt.Errorf("获取Access Token, %w", RespStructError)
		}
		if *resp.Code != CodeSuccess {
			return fmt.Errorf("获取Access Token, %w", RespCodeError)
		}
		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))

	return resp, err
}

func Oauth2RefreshToken(ctx context.Context, request models.Oauth2RefreshTokenRequest) (*models.Oauth2RefreshTokenResponse, error) {
	var resp *models.Oauth2RefreshTokenResponse
	err := retry.Do(func() error {
		var e error
		resp, _, e = apiClient.Oauth2RefreshTokenApi().
			Post(ctx).
			Oauth2RefreshTokenRequest(request).
			Execute()
		if e != nil {
			return e
		}
		if resp == nil {
			return fmt.Errorf("刷新Refresh Token失败, %w", RespStructError)
		}
		if *resp.Code != CodeSuccess {
			return fmt.Errorf("刷新Refresh Token失败, %w, code: %d, message: %s", RespCodeError, *resp.Code, *resp.Message)
		}
		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))

	return resp, err
}

func Oauth2AdvertiserGetByAdvertiserRole(ctx context.Context, accessToken string, advertiserRoles ...int64) ([]*models.Oauth2AdvertiserGetResponseDataListInner, error) {
	resp, err := Oauth2AdvertiserGet(ctx, accessToken)
	if err != nil {
		return nil, err
	}
	if resp.Data == nil || len(resp.Data.List) == 0 {
		return nil, nil
	}
	if len(advertiserRoles) == 0 {
		return resp.Data.List, nil
	}

	m := make(map[int64]struct{}, len(advertiserRoles))
	for _, r := range advertiserRoles {
		m[r] = struct{}{}
	}

	var res []*models.Oauth2AdvertiserGetResponseDataListInner
	for _, v := range resp.Data.List {
		if _, ok := m[*v.AdvertiserRole]; ok {
			res = append(res, v)
		}
	}
	return res, nil
}

func Oauth2AdvertiserGetByAdvertiserRoleAssist(ctx context.Context, accessToken string, advertiserRoles ...int64) ([]*models.Oauth2AdvertiserGetResponseDataListInner, error) {
	resp, err := Oauth2AdvertiserGetAssist(ctx, accessToken)
	if err != nil {
		return nil, err
	}
	if resp.Data == nil || len(resp.Data.List) == 0 {
		return nil, nil
	}
	if len(advertiserRoles) == 0 {
		return resp.Data.List, nil
	}

	m := make(map[int64]struct{}, len(advertiserRoles))
	for _, r := range advertiserRoles {
		m[r] = struct{}{}
	}

	var res []*models.Oauth2AdvertiserGetResponseDataListInner
	for _, v := range resp.Data.List {
		if _, ok := m[*v.AdvertiserRole]; ok {
			res = append(res, v)
		}
	}
	return res, nil
}

// Oauth2AdvertiserGetAssist 获取已授权账户
// https://open.oceanengine.com/labels/7/docs/1696710506574848
func Oauth2AdvertiserGetAssist(ctx context.Context, accessToken string) (*models.Oauth2AdvertiserGetResponse, error) {
	resp, _, err := apiClient.Oauth2AdvertiserGetApi().
		Get(ctx).
		AccessToken(accessToken).
		Execute()
	if err != nil {
		return resp, err
	}

	if resp == nil {
		return resp, fmt.Errorf("获取已授权账户失败, %w", RespStructError)
	}
	if *resp.Code != CodeSuccess {
		return resp, fmt.Errorf("获取已授权账户失败, %w", RespCodeError)
	}

	return resp, nil
}

// Oauth2AdvertiserGet 获取已授权账户
// https://open.oceanengine.com/labels/7/docs/1696710506574848
func Oauth2AdvertiserGet(ctx context.Context, accessToken string) (*models.Oauth2AdvertiserGetResponse, error) {
	latestAccessToken, err := cache.GetLatestAccessToken(accessToken)
	if err != nil {
		return nil, err
	}

	resp, _, err := apiClient.Oauth2AdvertiserGetApi().
		Get(ctx).
		AccessToken(latestAccessToken).
		Execute()
	if err != nil {
		return resp, err
	}

	if resp == nil {
		return resp, fmt.Errorf("获取已授权账户失败, %w", RespStructError)
	}
	if *resp.Code != CodeSuccess {
		return resp, fmt.Errorf("获取已授权账户失败, %w", RespCodeError)
	}

	return resp, nil
}

func UserInfoV2(ctx context.Context, accessToken string) (*models.UserInfoV2Response, error) {
	var resp *models.UserInfoV2Response

	err := retry.Do(func() error {
		var e error
		resp, _, e = apiClient.UserInfoV2Api().
			Get(ctx).
			AccessToken(accessToken).
			Execute()
		if e != nil {
			return e
		}
		if resp == nil {
			return fmt.Errorf("获取授权User信息失败, %w", RespStructError)
		}
		if *resp.Code != CodeSuccess {
			return fmt.Errorf("获取授权User信息失败, %w", RespCodeError)
		}
		return nil
	}, retry.Delay(time.Millisecond*300), retry.Attempts(3))

	return resp, err
}
