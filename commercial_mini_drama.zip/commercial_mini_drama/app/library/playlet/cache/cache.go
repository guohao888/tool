package cache

import (
	"errors"
	"fmt"
	"github.com/gomodule/redigo/redis"
	"github.com/muesli/cache2go"
	"github.com/spf13/viper"
	"golang.org/x/sync/singleflight"
	"goserver/app/library/driver/redisdb"
	"time"
)

var (
	oauthCache        *cache2go.CacheTable
	sfg               singleflight.Group
	accessTokenScript *redis.Script
)

var (
	cacheDuration = time.Hour * 24 * 2 // 两天
)

func init() {
	oauthCache = cache2go.Cache("toutiao_oauth_cache")
	script := fmt.Sprintf(`
	-- 定义一个Lua脚本
	local key = KEYS[1]
	local value = redis.call('GET', '%s' .. key)

	if value ~= nil and value ~= '' and value ~= false then
		local newValue = redis.call('GET', '%s' .. value)
		return newValue
	else
		return nil
	end
`, accessTokenCacheKey, oauthIdCacheKey)
	accessTokenScript = redis.NewScript(1, script)
}

var (
	accessTokenCacheKey = "access_token:"
	oauthIdCacheKey     = "oauth_id:"
)

func updateOauthCache(oauthId string, accessToken string, d time.Duration) error {
	c := redisdb.RedisPool.Get()
	defer c.Close()

	i := int64(d.Seconds())
	// access_token 和 oauth_id 的缓存，三天
	accessTokenKey := fmt.Sprintf("%s%s", accessTokenCacheKey, accessToken)
	err := c.Send("SET", accessTokenKey, oauthId, "EX", i)
	if err != nil {
		return err
	}
	// oauth_id 和 access_token 的缓存，两天
	oauthIdKey := fmt.Sprintf("%s%s", oauthIdCacheKey, oauthId)
	err = c.Send("SET", oauthIdKey, accessToken, "EX", i)
	if err != nil {
		return err
	}

	err = c.Flush()
	if err != nil {
		return err
	}

	_, err = c.Receive()
	if err != nil {
		return err
	}

	return nil
}

func updateOauthLocalCache(oauthId string, accessToken string, d time.Duration) error {
	accessTokenKey := fmt.Sprintf("%s%s", accessTokenCacheKey, accessToken)
	_ = oauthCache.Add(accessTokenKey, d, oauthId)

	oauthIdKey := fmt.Sprintf("%s%s", oauthIdCacheKey, oauthId)
	_ = oauthCache.Add(oauthIdKey, d, accessToken)
	return nil
}

func SetOauthCache(oauthId string, accessToken string) error {

	err := updateOauthCache(oauthId, accessToken, cacheDuration)
	if err != nil {
		return err
	}

	m := viper.GetBool("cron")
	if m { // 在任务机上设置本地缓存
		err = updateOauthLocalCache(oauthId, accessToken, cacheDuration)
		if err != nil {
			return err
		}
	}
	return nil
}

func GetAccessTokenByOauthId(oauthId string) (string, error) {
	m := viper.GetBool("cron")
	if m { // 在任务机上从本地获取缓存
		v, err, _ := sfg.Do(oauthId, func() (interface{}, error) {
			return getAccessTokenByOauthIdLocalCache(oauthId)
		})
		if err == nil {
			return v.(string), nil
		}
	}

	return getAccessTokenByOauthIdCache(oauthId)
}

func GetLatestAccessToken(accessToken string) (string, error) {
	m := viper.GetBool("cron")
	if m { // 在任务机上从本地获取缓存
		v, err, _ := sfg.Do(accessToken, func() (interface{}, error) {
			return getLatestAccessTokenFromLocalCache(accessToken)
		})
		if err == nil {
			return v.(string), nil
		}
	}

	return getLatestAccessTokenFromCache(accessToken)
}

func getAccessTokenByOauthIdCache(oauthId string) (string, error) {
	c := redisdb.RedisPool.Get()
	defer c.Close()

	return redis.String(accessTokenScript.Do(c, oauthId))
}

func getLatestAccessTokenFromCache(accessToken string) (string, error) {
	c := redisdb.RedisPool.Get()
	defer c.Close()

	return redis.String(accessTokenScript.Do(c, accessToken))
}

func getAccessTokenByOauthIdLocalCache(oauthId string) (string, error) {
	oauthIdKey := fmt.Sprintf("%s%s", oauthIdCacheKey, oauthId)
	latestAccessToken, err := getLocalCache(oauthIdKey)
	if err != nil {
		return "", err
	}
	return latestAccessToken, nil
}

func getLatestAccessTokenFromLocalCache(accessToken string) (string, error) {
	accessTokenKey := fmt.Sprintf("%s%s", accessTokenCacheKey, accessToken)
	oauthId, err := getLocalCache(accessTokenKey)
	if err != nil {
		return "", err
	}
	return getAccessTokenByOauthIdLocalCache(oauthId)
}

func getLocalCache(key string) (string, error) {
	cacheItem, err := oauthCache.Value(key)

	if errors.Is(err, cache2go.ErrKeyNotFound) { // 没有获取到本地缓存，查询并设置本地缓存
		cache, err := getCache(key)
		if err != nil {
			return "", err
		}
		cacheItem = oauthCache.Add(key, cacheDuration, cache)
	}

	if cacheItem != nil {
		// 获取到了本地缓存
		data := cacheItem.Data()
		if data != nil {
			if v, ok := data.(string); ok {
				return v, nil
			}
		}
	}

	return "", nil
}

func getCache(key string) (string, error) {
	c := redisdb.RedisPool.Get()
	defer c.Close()

	return redis.String(c.Do("GET", key))
}
