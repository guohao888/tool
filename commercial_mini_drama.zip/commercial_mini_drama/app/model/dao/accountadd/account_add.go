package accountadd

import (
	"context"
	"fmt"
	"github.com/jinzhu/gorm"
	"golang.org/x/sync/errgroup"
	"goserver/app/common/repository/accountadd"
	"goserver/app/library/driver/dorisdb"
	"goserver/app/model/dao"
	"strings"
)

// AddAccountDao 推送数据
type AddAccountDao struct {
	Ctx context.Context
}

func NewAddAccountDao(ctx context.Context) *AddAccountDao {
	return &AddAccountDao{Ctx: ctx}
}

// InsertBatchSize 插入更新数据
func (a *AddAccountDao) InsertBatchSize(data []*accountadd.AddAccountEntity, batchSize int) error {
	if len(data) == 0 {
		return nil
	}
	if batchSize <= 0 {
		batchSize = 2000
	}

	db := dorisdb.DorisClient()
	// 开始事务
	tx := db.Begin()

	// 2. 在批量插入数据
	eg := new(errgroup.Group)

	count := len(data)
	batchPage := dao.BatchPage(count, batchSize)
	for i := 0; i < batchPage; i++ {
		start := i * batchSize

		end := (i + 1) * batchSize
		if end > count {
			end = count
		}

		eg.Go(func() (e error) {
			defer func() {
				if x := recover(); x != nil {
					e = fmt.Errorf("recover %s", x)
				}
			}()

			e = a.buildInsertSentence(tx, data[start:end])
			return e
		})
	}

	err := eg.Wait()
	if err != nil {
		tx.Rollback()
		return err
	}

	tx.Commit()
	return nil
}

// 组装插入数据语句
func (a *AddAccountDao) buildInsertSentence(tx *gorm.DB, data []*accountadd.AddAccountEntity) error {
	if len(data) == 0 {
		return nil
	}
	sqlStr := "INSERT INTO " + accountadd.AddAccountTableName() + " ( advertiser_id, created_time, status ) VALUES "
	var vals []interface{}
	for _, v := range data {
		sqlStr += "(?,?,?),"
		vals = append(vals,
			v.AdvertiserId,
			v.CreatedTime,
			v.Status,
		)
	}
	sqlStr = strings.TrimSuffix(sqlStr, ",")
	// 执行 SQL 语句
	err := tx.Exec(sqlStr, vals...).Error
	return err
}
