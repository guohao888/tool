package kuaishou

import (
	"context"
	"errors"
	"goserver/app/library/playlet/kuaishou/middleware"
	"math"
	"strconv"
)

const (
	restOpenapiGwDspSeriesReportQueryAccountInfo     = "/rest/openapi/gw/dsp/series/report/queryAccountInfo" // 短剧查询账户信息接口
	restOpenapiGwDspSeriesReportQuerySeriesInfo      = "/rest/openapi/gw/dsp/series/report/querySeriesInfo"  // 短剧信息列表
	restOpenapiGwDspSeriesReportQueryQueryCoreData   = "/rest/openapi/gw/dsp/series/report/queryCoreData"    // 短剧核心总览数据报表
	restOpenapiGwDspSeriesReportQueryQueryDetailData = "/rest/openapi/gw/dsp/series/report/queryAdDetail"    // 短剧广告报表明细查询接口
	restOpenapiGwDspUnitList                         = "/rest/openapi/gw/dsp/unit/list"                      // 查询广告组
	restOpenapiGwDspUnitUpdate                       = "/rest/openapi/gw/dsp/unit/update"                    // 修改广告组
)

type ReportQueryAccountInfoReq struct {
	OauthId      string
	AppId        string
	AccessToken  string
	AdvertiserId int64
}

type Account struct {
	AccountId   string `json:"account_id"`
	AccountName string `json:"account_name"`
}

type ReportQueryAccountInfoResp struct {
	CommonRespField
	Data struct {
		AccountList []Account `json:"account_list"`
	} `json:"data"`
}

func getHeaders(accessToken string, oauthId string) map[string]string {
	return map[string]string{
		middleware.HeaderAccessToken: accessToken,
		middleware.HeaderOauthId:     oauthId,
	}
}

func ReportQueryAccountInfo(ctx context.Context, req ReportQueryAccountInfoReq) (resp *ReportQueryAccountInfoResp, err error) {
	ctx = middleware.WithValue(ctx,
		middleware.CtxAppIdKey, req.AppId,
		middleware.CtxPathKey, restOpenapiGwDspSeriesReportQueryAccountInfo,
		middleware.CtxAdvertiserId, strconv.FormatInt(req.AdvertiserId, 10),
	)

	response, err := client.R().
		SetContext(ctx).
		SetHeaders(getHeaders(req.AccessToken, req.OauthId)).
		SetQueryParam("advertiser_id", strconv.FormatInt(req.AdvertiserId, 10)).
		SetResult(&ReportQueryAccountInfoResp{}).
		Get(restOpenapiGwDspSeriesReportQueryAccountInfo)
	if err != nil {
		return
	}
	resp, ok := response.Result().(*ReportQueryAccountInfoResp)
	if !ok {
		err = errors.New("result type conversion failed")
		return
	}
	return
}

/*****************************  request  *****************************/

func getPostHeaders(accessToken string) map[string]string {
	return map[string]string{
		"Access-Token": accessToken,
		"Content-Type": "application/json",
	}
}

type ReportQueryReq struct {
	AdvertiserId   int64    `json:"advertiser_id"`
	AccessToken    string   `json:"access_token,omitempty"`
	PageNo         int64    `json:"page_no"`
	PageSize       int64    `json:"page_size"`
	StartTime      int64    `json:"start_time"`
	EndTime        int64    `json:"end_time"`
	ExtraDimension []string `json:"extra_dimension"`
	SeriesType     int      `json:"series_type,omitempty"`
	SeriesIds      []int64  `json:"series_ids,omitempty"`
	ResourceType   int      `json:"resource_type,omitempty"`
	Source         int64    `json:"source,omitempty"`
}

type ReportQueryCoreReq struct {
	AdvertiserId int64   `json:"advertiser_id"`
	AccessToken  string  `json:"access_token,omitempty"`
	PageNo       int64   `json:"page_no"`
	PageSize     int64   `json:"page_size"`
	StartTime    int64   `json:"start_time"`
	EndTime      int64   `json:"end_time"`
	SeriesType   int     `json:"series_type,omitempty"`
	SeriesIds    []int64 `json:"series_ids,omitempty"`
	ResourceType int     `json:"resource_type,omitempty"`
	Source       int64   `json:"source"`
}

/*********************************** 短剧核心总览数据报表 ***********************************/

type CoreDataResp struct {
	CommonRespField
	Data DateCore `json:"data"`
}

type DateCore struct {
	TotalCount int64      `json:"total_count"`
	DataList   []CoreData `json:"data_list"`
}

type CoreData struct {
	Date                            string  `json:"date"`                                 // 日期（yyyy-MM-dd hh:mm:ss）
	TotalCharge                     int64   `json:"total_charge"`                         // 消耗
	AccuFansUserNum                 int64   `json:"accu_fans_user_num"`                   // 粉丝峰值量
	FansUserNum                     int64   `json:"fans_user_num"`                        // 粉丝净增量
	EventPayRoi                     float64 `json:"event_pay_roi"`                        // 商业化ROI
	EventPayRoiAll                  float64 `json:"event_pay_roi_all"`                    // 全域ROI
	PayUserCount                    int64   `json:"pay_user_count"`                       // 付费人数
	PayCount                        int64   `json:"pay_count"`                            // 付费订单数
	PayAmt                          float64 `json:"pay_amt"`                              // 付费金额
	IsFansUser                      bool    `json:"is_fans_user"`                         // 是否粉丝
	DisplayPlayCnt                  int64   `json:"display_play_cnt"`                     // 播放数
	DisplayLikeCnt                  int64   `json:"display_like_cnt"`                     // 点赞数
	DisplayCommentCnt               int64   `json:"display_comment_cnt"`                  // 评论数
	DisplayCollectCnt               int64   `json:"display_collect_cnt"`                  // 收藏数
	MiniGameIaaRoi                  float64 `json:"mini_game_iaa_roi"`                    // IAA广告变现ROI（含返货）
	MiniGameIaaPurchaseAmount       float64 `json:"mini_game_iaa_purchase_amount"`        // IAA广告变现LTV（含返货，元）
	MiniGameIaaPurchaseAmountDivide float64 `json:"mini_game_iaa_purchase_amount_divide"` // IAA广告变现LTV（不含返货，元）
	MiniGameIaaDividedRoi           float64 `json:"mini_game_iaa_divided_roi"`            // IAA广告变现ROI（不含返货）
}

func AllCoreDate(ctx context.Context, req ReportQueryCoreReq) ([]CoreData, error) {
	page := int64(1)
	pageSizeMax := int64(100)
	var res []CoreData
	for {
		response, err := ReportQueryCoreData(ctx, ReportQueryCoreReq{
			AdvertiserId: req.AdvertiserId,
			PageNo:       page,
			PageSize:     pageSizeMax,
			StartTime:    req.StartTime,
			EndTime:      req.EndTime,
			SeriesIds:    req.SeriesIds,
			SeriesType:   req.SeriesType,
			ResourceType: req.ResourceType,
			Source:       req.Source,
		}, req.AccessToken)
		if err != nil {
			return res, err
		}
		if response.Code != CodeSuccess {
			return res, nil
		}
		res = append(res, response.Data.DataList...)
		if int64(math.Ceil(float64(response.Data.TotalCount)/100)) <= page {
			break
		}
		page++
	}

	return res, nil
}

func ReportQueryCoreData(ctx context.Context, req ReportQueryCoreReq, accessToken string) (resp *CoreDataResp, err error) {
	response, err := client.R().
		SetContext(ctx).
		SetHeaders(getPostHeaders(accessToken)).
		SetBody(ReportQueryCoreReq{
			AdvertiserId: req.AdvertiserId,
			PageNo:       req.PageNo,
			PageSize:     req.PageSize,
			StartTime:    req.StartTime,
			EndTime:      req.EndTime,
			SeriesIds:    req.SeriesIds,
			SeriesType:   req.SeriesType,
			ResourceType: req.ResourceType,
			Source:       req.Source,
		}).
		SetResult(&CoreDataResp{}).
		Post(restOpenapiGwDspSeriesReportQueryQueryCoreData)
	if err != nil {
		return
	}
	resp, ok := response.Result().(*CoreDataResp)
	if !ok {
		err = errors.New("result type conversion failed")
		return
	}
	return
}

/***********************************短剧广告报表明细查询接口 ***********************************/

type AdDataDetailResp struct {
	CommonRespField
	Data DateDetail `json:"data"`
}

type DateDetail struct {
	TotalCount int64      `json:"total_count"`
	DataList   []AdDetail `json:"data_list"`
}

type AdDetail struct {
	Date                                       string  `json:"date"`                                              // 日期（yyyy-MM-dd hh:mm:ss）
	Likes                                      int64   `json:"likes"`                                             // 点赞数
	Share                                      int64   `json:"share"`                                             // 分享数
	PhotoClick                                 int64   `json:"photo_click"`                                       // 封面点击数
	Impression                                 int64   `json:"impression"`                                        // 封面曝光数
	EventPay                                   int64   `json:"event_pay"`                                         // 付费次数
	T0DirectPaidCnt                            float64 `json:"t_0_direct_paied_cnt"`                              // 付费次数(计费时间)
	EventPayPurchaseAmount                     float64 `json:"event_pay_purchase_amount"`                         // 付费金额
	T0DirectPaidAmt                            float64 `json:"t_0_direct_paied_amt"`                              // 付费金额(计费时间)
	AdShow                                     int64   `json:"ad_show"`                                           // 广告曝光
	TotalCharge                                float64 `json:"total_charge"`                                      // 消耗
	EventAppInvoked                            int64   `json:"event_app_invoked"`                                 // 唤起应用数
	EventPayPurchaseAmountFirstDay             float64 `json:"event_pay_purchase_amount_first_day"`               // 激活当日付费金额
	EventPayPurchaseAmountOneDayByConversion   float64 `json:"event_pay_purchase_amount_one_day_by_conversion"`   // 激活后24h付费金额(激活时间)
	EventPayPurchaseAmountWeekByConversion     float64 `json:"event_pay_purchase_amount_week_by_conversion"`      // 激活后七日付费金额
	EventPayPurchaseAmountThreeDayByConversion float64 `json:"event_pay_purchase_amount_three_day_by_conversion"` // 激活后三日付费金额
	Conversion                                 int64   `json:"conversion"`                                        // 激活数
	T0DirectConversionCnt                      int64   `json:"t_0_direct_conversion_cnt"`                         // 激活数(计费时间)
	//Negative                                      int64   `json:"negative"`                                              // 减少此类作品数
	Report                                        int64   `json:"report"`                                                // 举报数
	Block                                         int64   `json:"block"`                                                 // 拉黑数
	Comment                                       int64   `json:"comment"`                                               // 评论数
	EventPayFirstDay                              int64   `json:"event_pay_first_day"`                                   // 首日付费次数
	PlayedNum                                     int64   `json:"played_num"`                                            // 素材曝光数
	PlayedThreeSeconds                            int64   `json:"played_three_seconds"`                                  // 3s播放数
	AdPhotoPlayed75percent                        int64   `json:"ad_photo_played_75_percent"`                            // 75%播放进度数
	PlayedEnd                                     int64   `json:"played_end"`                                            // 完播数
	Follow                                        int64   `json:"follow"`                                                // 新增粉丝数
	EventNewUserPay                               int64   `json:"event_new_user_pay"`                                    //新增付费人数
	AdItemClick                                   int64   `json:"ad_item_click"`                                         //行为数
	T7PaidCnt                                     int64   `json:"t7_paied_cnt"`                                          //7日累计付费次数
	T7PaidAmt                                     float64 `json:"t7_paied_amt"`                                          //7日累计付费金额
	ConversionNumByImpression7d                   int64   `json:"conversion_num_by_impression7d"`                        //转化数(计费时间)
	DeepConversionNumByImpression7d               int64   `json:"deep_conversion_num_by_impression7d"`                   //深度转化数(计费时间)
	ConversionNum                                 int64   `json:"conversion_num"`                                        //转化数(回传时间)
	DeepConversionNum                             int64   `json:"deep_conversion_num"`                                   //深度转化数
	T0PaidCnt                                     int64   `json:"t0_paied_cnt"`                                          //当日累计付费次数
	T0PaidAmt                                     float64 `json:"t0_paied_amt"`                                          //当日累计付费金额
	Play3sRatio                                   float64 `json:"play_3_s_ratio"`                                        //3s播放率
	AdPhotoPlayed75PercentRatio                   float64 `json:"ad_photo_played_75percent_ratio"`                       //75%进度播放率
	T7PaidRoi                                     float64 `json:"t7_paied_roi"`                                          //7日累计ROI
	T0PaidRoi                                     float64 `json:"t0_paied_roi"`                                          //当日累计ROI
	PhotoClickRatio                               float64 `json:"photo_click_ratio"`                                     //封面点击率
	EventPayCost                                  float64 `json:"event_pay_cost"`                                        //付费次数成本
	EventPayRoi                                   float64 `json:"event_pay_roi"`                                         //付费ROI
	EventAppInvokedCost                           float64 `json:"event_app_invoked_cost"`                                //唤起应用成本
	EventAppInvokedRatio                          float64 `json:"event_app_invoked_ratio"`                               //唤起应用率
	ConversionCost                                float64 `json:"conversion_cost"`                                       //激活单价
	EventPayFirstDayRoi                           float64 `json:"event_pay_first_day_roi"`                               //激活当日ROI
	EventPayPurchaseAmountOneDayByConversionRoi   float64 `json:"event_pay_purchase_amount_one_day_by_conversion_roi"`   //激活后24h-ROI(激活时间)
	EventPayPurchaseAmountThreeDayByConversionRoi float64 `json:"event_pay_purchase_amount_three_day_by_conversion_roi"` //激活后3日ROI
	EventPayPurchaseAmountWeekByConversionRoi     float64 `json:"event_pay_purchase_amount_week_by_conversion_roi"`      //激活后7日ROI
	PhotoClickCost                                float64 `json:"photo_click_cost"`                                      //平均封面点击单价（元）
	Impression1kCost                              float64 `json:"impression1k_cost"`                                     //平均千次封面曝光花费（元）
	Click1kCost                                   float64 `json:"click1k_cost"`                                          //平均千次素材曝光花费（元）
	ActionCost                                    float64 `json:"action_cost"`                                           //平均行为单价（元）
	DeepConversionCostByImpression7d              float64 `json:"deep_conversion_cost_by_impression7d"`                  //深度转化成本(计费时间)，单位元
	DeepConversionRatioByImpression7d             float64 `json:"deep_conversion_ratio_by_impression7d"`                 //深度转化率(计费时间)
	EventPayFirstDayCost                          float64 `json:"event_pay_first_day_cost"`                              //首日付费次数成本，单位元
	ActionRatio                                   float64 `json:"action_ratio"`                                          //素材点击率
	PlayEndRatio                                  float64 `json:"play_end_ratio"`                                        //完播率
	EventNewUserPayCost                           float64 `json:"event_new_user_pay_cost"`                               //新增付费人数成本，单位元
	EventNewUserPayRatio                          float64 `json:"event_new_user_pay_ratio"`                              //新增付费人数率
	ActionNewRatio                                float64 `json:"action_new_ratio"`                                      //行为率
	ConversionCostByImpression7d                  float64 `json:"conversion_cost_by_impression7d"`                       //转化成本(计费时间)，单位元
	ConversionRatioByImpression7d                 float64 `json:"conversion_ratio_by_impression7d"`                      //转化率(计费时间)
	KeyAction                                     int64   `json:"key_action"`                                            //关键行为数
	AdPhotoPlayed75percentRatio                   float64 `json:"ad_photo_played75percent_ratio"`                        //75%进度播放数
	MiniGameIaaRoi                                float64 `json:"mini_game_iaa_roi"`                                     //IAA广告变现ROI
	MiniGameIaaPurchaseAmount                     float64 `json:"mini_game_iaa_purchase_amount"`
	AccountId                                     int64   `json:"account_id"`    // 账号ID
	SeriesId                                      int64   `json:"series_id"`     // 短剧ID
	RechargeRate                                  float64 `json:"recharge_rate"` // 充值几率
}

func AllDetailData(ctx context.Context, req ReportQueryReq) ([]AdDetail, error) {
	page := int64(1)
	pageSizeMax := int64(100)
	var res []AdDetail
	for {
		response, err := ReportQueryDetailData(ctx, ReportQueryReq{
			AdvertiserId:   req.AdvertiserId,
			PageNo:         page,
			PageSize:       pageSizeMax,
			StartTime:      req.StartTime,
			EndTime:        req.EndTime,
			ExtraDimension: []string{"seriesId", "accountId"},
			SeriesType:     req.SeriesType,
		}, req.AccessToken)
		if err != nil {
			return res, err
		}
		if response.Code != CodeSuccess {
			return res, nil
		}
		res = append(res, response.Data.DataList...)
		if int64(math.Ceil(float64(response.Data.TotalCount)/100)) <= page {
			break
		}
		page++
	}

	return res, nil
}

func ReportQueryDetailData(ctx context.Context, req ReportQueryReq, accessToken string) (resp *AdDataDetailResp, err error) {
	response, err := client.R().
		SetContext(ctx).
		SetHeaders(getPostHeaders(accessToken)).
		SetBody(ReportQueryReq{
			AdvertiserId:   req.AdvertiserId,
			PageNo:         req.PageNo,
			PageSize:       req.PageSize,
			StartTime:      req.StartTime,
			EndTime:        req.EndTime,
			ExtraDimension: req.ExtraDimension,
			SeriesType:     req.SeriesType,
		}).
		SetResult(&AdDataDetailResp{}).
		Post(restOpenapiGwDspSeriesReportQueryQueryDetailData)
	if err != nil {
		return
	}
	resp, ok := response.Result().(*AdDataDetailResp)
	if !ok {
		err = errors.New("result type conversion failed")
		return
	}
	return
}

/*********************************** 短剧查询账户信息接口 ***********************************/

type SeriesInfoResp struct {
	CommonRespField
	Data []SeriesInfo `json:"data"`
}

type SeriesInfo struct {
	SeriesId    string `json:"series_id"`    // 短剧id
	SeriesName  string `json:"series_name"`  // 短剧名称
	AuditStatus int    `json:"audit_status"` // 审核状态
	SellStatus  int    `json:"sell_status"`  // 售卖状态
}

func ReportQuerySeriesInfo(ctx context.Context, req ReportQueryAccountInfoReq) (resp *SeriesInfoResp, err error) {
	response, err := client.R().
		SetContext(ctx).
		SetHeaders(getHeaders(req.AccessToken, req.OauthId)).
		SetQueryParam("advertiser_id", strconv.FormatInt(req.AdvertiserId, 10)).
		SetResult(&SeriesInfoResp{}).
		Get(restOpenapiGwDspSeriesReportQuerySeriesInfo)
	if err != nil {
		return
	}
	resp, ok := response.Result().(*SeriesInfoResp)
	if !ok {
		err = errors.New("result type conversion failed")
		return
	}
	return
}

type UnitReq struct {
	AdvertiserId int64  `json:"advertiser_id"`
	AccessToken  string `json:"access_token,omitempty"`
	PageNo       int64  `json:"page_no"`
	PageSize     int64  `json:"page_size"`
}
type UnitResp struct {
	CommonRespField
	Data UnitRespData
}

type UnitRespData struct {
	TotalCount int64       `json:"total_count"`
	Details    []UnitInfos `json:"details"`
}

type UnitInfos struct {
	BidType  int64  `json:"bid_type"`
	UnitId   int64  `json:"unit_id"`
	UnitName string `json:"unit_name"`
}

func AllUnitList(ctx context.Context, req UnitReq) ([]UnitInfos, error) {
	page := int64(1)
	pageSizeMax := int64(100)
	var res []UnitInfos
	for {
		response, err := ReportQueryUnitList(ctx, UnitReq{
			AdvertiserId: req.AdvertiserId,
			PageNo:       page,
			PageSize:     pageSizeMax,
		}, req.AccessToken)
		if err != nil {
			return res, err
		}
		if response.Code != CodeSuccess {
			return res, nil
		}
		res = append(res, response.Data.Details...)
		if int64(math.Ceil(float64(response.Data.TotalCount)/100)) <= page {
			break
		}
		page++
	}

	return res, nil
}

func ReportQueryUnitList(ctx context.Context, req UnitReq, accessToken string) (resp *UnitResp, err error) {
	response, err := client.R().
		SetContext(ctx).
		SetHeaders(getPostHeaders(accessToken)).
		SetBody(ReportQueryReq{
			AdvertiserId: req.AdvertiserId,
			PageNo:       req.PageNo,
			PageSize:     req.PageSize,
		}).
		SetResult(&UnitResp{}).
		Post(restOpenapiGwDspUnitList)
	if err != nil {
		return
	}
	resp, ok := response.Result().(*UnitResp)
	if !ok {
		err = errors.New("result type conversion failed")
		return
	}
	return
}

type UpdateUnitReq struct {
	AdvertiserId int64  `json:"advertiser_id"`
	AccessToken  string `json:"access_token,omitempty"`
	BidType      int64  `json:"bid_type"`
	UnitId       int64  `json:"unit_id"`
	UnitName     string `json:"unit_name"`
	ScheduleTime string `json:"schedule_time"`
}

type UpdateUnitResp struct {
	Code    int64          `json:"code"`
	Message string         `json:"message"`
	Data    UpdateUnitInfo `json:"data"`
}

type UpdateUnitInfo struct {
	UnitId int64 `json:"unit_id"`
}

func UpdateUnit(ctx context.Context, req UpdateUnitReq, accessToken string) (resp *UpdateUnitResp, err error) {
	response, err := client.R().
		SetContext(ctx).
		SetHeaders(getPostHeaders(accessToken)).
		SetBody(UpdateUnitReq{
			AdvertiserId: req.AdvertiserId,
			BidType:      req.BidType,
			UnitId:       req.UnitId,
			UnitName:     req.UnitName,
			ScheduleTime: req.ScheduleTime,
		}).
		SetResult(&UpdateUnitResp{}).
		Post(restOpenapiGwDspUnitList)
	if err != nil {
		return
	}
	resp, ok := response.Result().(*UpdateUnitResp)
	if !ok {
		err = errors.New("result type conversion failed")
		return
	}
	return
}
