package roi

import (
	"encoding/json"
	"goserver/app/common/dto/roidto"
	repo "goserver/app/common/repository/roi"
	"goserver/app/library/myerror"
	"goserver/app/library/utils"
	"goserver/app/library/utils/response"
	"goserver/app/model/service/roi"
	"net/http"
	"net/url"
	"strings"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/tealeg/xlsx"
)

func LastExecTime(c *gin.Context) {
	r := response.Gin{Ctx: c}
	reportService := roi.NewReportService(c, true)
	lastTime := reportService.GetLastExecTime()
	r.Response(myerror.OK.Code, myerror.OK.Message, roidto.MergeExecTime{
		ExecTime: lastTime,
	})
}

func ProjectLastExecTime(c *gin.Context) {
	r := response.Gin{Ctx: c}
	reportService := roi.NewReportService(c, false)
	lastTime := reportService.ProjectGetLastExecTime()
	r.Response(myerror.OK.Code, myerror.OK.Message, roidto.MergeExecTime{
		ExecTime: lastTime,
	})
}

func BoardTopData(c *gin.Context) {
	r := response.Gin{Ctx: c}
	reportService := roi.NewReportService(c, false)
	result := reportService.BoardTopData()
	r.Response(myerror.OK.Code, myerror.OK.Message, roidto.BoardTopDataResp{
		CountTime: result.CountTime,
		StartHour: result.StartHour,
		EndHour:   result.EndHour,
	})
}

func Options(c *gin.Context) {
	r := response.Gin{Ctx: c}
	reportService := roi.NewReportService(c, true)
	mediaSlice, err := reportService.MediaOptionsAry()
	if err != nil {
		r.Response(myerror.MiniAppFilterOptionsError.Code, myerror.MiniAppFilterOptionsError.Message, nil)
		return
	}
	DeliveryProductSlice, err := reportService.DeliveryProductOptionsAry()
	if err != nil {
		r.Response(myerror.MiniAppFilterOptionsError.Code, myerror.MiniAppFilterOptionsError.Message, nil)
		return
	}
	r.Response(myerror.OK.Code, myerror.OK.Message, roidto.OptionsResp{Media: mediaSlice, DeliveryProduct: DeliveryProductSlice})
}

func Params(c *gin.Context) {
	r := response.Gin{Ctx: c}

	reportService := roi.NewReportService(c, true)
	params, err := reportService.ReportParams()
	if err != nil { //查询失败，返回数据库查询错误
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, params)
}

func ProjectParams(c *gin.Context) {
	r := response.Gin{Ctx: c}

	reportService := roi.NewReportService(c, false)
	params, err := reportService.ReportParams()
	if err != nil { //查询失败，返回数据库查询错误
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, params)
}

func OptionSearch(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := roidto.NewReportOptionSearchReq(c)

	reportService := roi.NewReportService(c, true)
	options, err := reportService.ReportOptionSearch(req.Keywords, req.SearchType)
	if err != nil {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, options)
}

func ReportData(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := roidto.NewReportDataReq(c, "view", true)

	reportService := roi.NewReportService(c, true)
	paginator, err := reportService.ReportData(req)
	if err != nil {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, paginator)
}

func ProjectReportData(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := roidto.NewReportDataReq(c, "view", false)

	reportService := roi.NewReportService(c, false)
	paginator, err := reportService.ProjectReportDataNew(req)
	if err != nil {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, paginator)
}

// TodayMarketData 推推大盘数据（今日）
func TodayMarketData(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := roidto.NewTodayMarketDataReq(c)

	reportService := roi.NewReportService(c, false)
	data, err := reportService.TodayMarketData(req)
	if err != nil {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, data)
}

// TodayTimeData 推推分时数据（今日）
func TodayTimeData(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := roidto.NewTodayTimeDataReq(c)

	reportService := roi.NewReportService(c, false)
	data, err := reportService.TodayTimeData(req)
	if err != nil {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, data)
}

// TodayBookRanking 推推今日短剧排名
func TodayBookRanking(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := roidto.NewTodayBookRankingReq(c)

	reportService := roi.NewReportService(c, false)
	data, err := reportService.TodayBookRankingData(req)
	if err != nil {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, data)
}

// TodayRegionRanking 推推今日地区排名
func TodayRegionRanking(c *gin.Context) {
	r := response.Gin{Ctx: c}
	req := roidto.NewTodayRegionRankingReq(c)

	reportService := roi.NewReportService(c, false)
	data, err := reportService.TodayRegionRankingData(req)
	if err != nil {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	r.Response(myerror.OK.Code, myerror.OK.Message, data)
}

func Export(c *gin.Context) {
	r := response.Gin{Ctx: c}
	proGroup := true
	req := roidto.NewReportDataReq(c, "export", proGroup)

	reportService := roi.NewReportService(c, true)
	exportData, err := reportService.Export(req)
	if err != nil && err.Error() != "record not found" {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	//excel导出
	file := xlsx.NewFile()
	sheet, _ := file.AddSheet("sheet1")
	var row *xlsx.Row
	var cell *xlsx.Cell
	var style *xlsx.Style
	var col *xlsx.Col

	//标题行
	var title []string
	var keys []string //导出的字段名列表
	title = append(title, "日期")
	keys = append(keys, "date")
	groupMap := roidto.GetGroupByMapping(proGroup)
	for _, key := range req.GroupBy {
		if val, ok := groupMap[key]; ok {
			title = append(title, val)
			keys = append(keys, key)
			// 如果聚合维度包含了 account_name, 则自动把 account_id 加进去
			if key == "account_name" {
				title = append(title, "账户ID")
				keys = append(keys, "account_id")
			}
		}
	}
	kpiMap := roidto.GetKpiMapping(proGroup)
	for _, key := range req.Kpi {
		if val, ok := kpiMap[key]; ok {
			title = append(title, val)
			keys = append(keys, key)
		}
	}
	row = sheet.AddRow()
	for _, v := range title {
		cell = row.AddCell()
		// 设置单元格样式
		style = cell.GetStyle()
		style.Alignment = xlsx.Alignment{
			Horizontal: "center", // 水平居中
			Vertical:   "center", // 垂直居中
		}
		// 设置字体加粗
		style.Font = xlsx.Font{
			Bold: true,
		}
		cell.Value = v
	}
	for idx, v := range keys {
		col = sheet.Col(idx)
		if v == "date" && req.GroupType == "h" {
			col.Width = 20
		} else {
			col.Width = 15
		}
	}

	//内容行
	zhTZ, _ := time.LoadLocation("Asia/Shanghai")
	for _, v := range *exportData {
		row = sheet.AddRow()
		data, _ := json.Marshal(v)
		var m = make(map[string]interface{})
		_ = json.Unmarshal(data, &m)
		for _, key := range keys {
			cell = row.AddCell()
			if val, ok := m[key]; ok {
				if utils.InArray(key, repo.ExcelNumColumn) {
					v := utils.Convert2Int64(val)
					cell.SetInt64(v)
					cell.SetFormat("#,##0")
				} else if utils.InArray(key, repo.ExcelStringColumn) {
					v := utils.Convert2String(val)
					if (key == "pay_type" || key == "mid_id") && v == "0" {
						v = ""
					}
					cell.SetString(v)
				} else if key == "date" {
					t := val.(string)
					if req.GroupType == "h" && t != "汇总" {
						td, _ := time.ParseInLocation(time.DateTime, t, time.Local)
						cell.SetDateWithOptions(td, xlsx.DateTimeOptions{
							ExcelTimeFormat: "yyyy-mm-dd hh:mm:ss",
							Location:        zhTZ,
						})
					} else if req.GroupType == "d" && t != "汇总" {
						td, _ := time.ParseInLocation(time.DateOnly, t, time.Local)
						cell.SetDateWithOptions(td, xlsx.DateTimeOptions{
							ExcelTimeFormat: "yyyy-mm-dd",
							Location:        zhTZ,
						})
					} else {
						cell.SetString(t)
					}
					// 设置单元格样式
					style = cell.GetStyle()
					style.Alignment = xlsx.Alignment{
						Horizontal: "center", // 水平居中
						Vertical:   "center", // 垂直居中
					}
				} else {
					v := utils.Convert2Float64(val)
					cell.SetFloat(v)
					cell.SetFormat("#,##0.00")
				}
			} else {
				cell.SetValue("")
			}
		}
	}

	//导出文件
	ua := c.Request.UserAgent()
	fileName := "投放ROI数据报表_" + req.StartDate + "~" + req.EndDate + ".xlsx"
	encodedFileName := strings.Replace(url.QueryEscape(fileName), "+", "20%", -1)
	if strings.Contains(ua, "MSIE") || strings.Contains(ua, "Trident") { // for IE
		c.Header("Content-Disposition", "attachment; filename=\""+url.PathEscape(fileName)+"\"")
	} else if strings.Contains(ua, "Firefox") { // for Firefox
		c.Header("Content-Disposition", "attachment; filename*=UTF-8''"+encodedFileName)
	} else if strings.Contains(ua, "Chrome") || strings.Contains(ua, "Safari") { // for Chrome and Safari
		c.Header("Content-Disposition", "attachment; filename=\""+fileName+"\"; filename*=UTF-8''"+encodedFileName)
	} else { // for other browsers
		c.Header("Content-Disposition", "attachment; filename=\""+fileName+"\"")
	}
	c.Header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Header("Content-Transfer-Encoding", "binary")
	c.Header("Cache-Control", "max-age=0")
	c.Header("Pragma", "no-cache")
	//文件内容写入返回体
	if err := file.Write(c.Writer); err != nil {
		r.Response(myerror.ExportExcelError.Code, err.Error(), nil)
		return
	}
	c.Status(http.StatusOK)
	c.Abort()
	r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}

func ProjectExport(c *gin.Context) {
	r := response.Gin{Ctx: c}
	proGroup := false
	req := roidto.NewReportDataReq(c, "export", proGroup)

	reportService := roi.NewReportService(c, false)
	exportData, err := reportService.ProjectExportNew(req)
	if err != nil && err.Error() != "record not found" {
		r.Response(myerror.DBQueryDataError.Code, err.Error(), nil)
		return
	}

	//excel导出
	file := xlsx.NewFile()
	sheet, _ := file.AddSheet("sheet1")
	var row *xlsx.Row
	var cell *xlsx.Cell
	var style *xlsx.Style
	var col *xlsx.Col

	//标题行
	var title []string
	var keys []string //导出的字段名列表
	title = append(title, "日期")
	keys = append(keys, "date")

	groupMap := roidto.GetGroupByMapping(proGroup)
	for _, key := range req.GroupBy {
		if val, ok := groupMap[key]; ok {
			title = append(title, val)
			keys = append(keys, key)
			// 如果聚合维度包含了 account_name, 则自动把 account_id 加进去
			if key == "account_name" {
				title = append(title, "账户ID")
				keys = append(keys, "account_id")
			}
			if key == "user_id" {
				title = append(title, "账管")
				keys = append(keys, "user_name")
			}
		}
	}
	kpiMap := roidto.GetKpiMapping(proGroup)
	for _, key := range req.Kpi {
		if val, ok := kpiMap[key]; ok {
			title = append(title, val)
			keys = append(keys, key)
		}
	}
	row = sheet.AddRow()
	for _, v := range title {
		cell = row.AddCell()
		// 设置单元格样式
		style = cell.GetStyle()
		style.Alignment = xlsx.Alignment{
			Horizontal: "center", // 水平居中
			Vertical:   "center", // 垂直居中
		}
		// 设置字体加粗
		style.Font = xlsx.Font{
			Bold: true,
		}
		cell.Value = v
	}
	for idx, v := range keys {
		col = sheet.Col(idx)
		if v == "date" && req.GroupType == "h" {
			col.Width = 20
		} else {
			col.Width = 15
		}
	}

	//内容行
	zhTZ, _ := time.LoadLocation("Asia/Shanghai")
	for _, v := range exportData {
		row = sheet.AddRow()
		data, _ := json.Marshal(v)
		var m = make(map[string]interface{})
		_ = json.Unmarshal(data, &m)
		for _, key := range keys {
			cell = row.AddCell()
			if val, ok := m[key]; ok {
				if utils.InArray(key, repo.ProjectExcelNumColumn) {
					v := utils.Convert2Int64(val)
					cell.SetInt64(v)
					cell.SetFormat("#,##0")
				} else if utils.InArray(key, repo.ProjectExcelStringColumn) {
					v := utils.Convert2String(val)
					if (key == "pay_type" || key == "mid_id") && v == "0" {
						v = ""
					}
					cell.SetString(v)
				} else if key == "date" {
					t := val.(string)
					if req.GroupType == "h" && t != "汇总" {
						td, _ := time.ParseInLocation(time.DateTime, t, time.Local)
						cell.SetDateWithOptions(td, xlsx.DateTimeOptions{
							ExcelTimeFormat: "yyyy-mm-dd hh:mm:ss",
							Location:        zhTZ,
						})
					} else if req.GroupType == "d" && t != "汇总" {
						td, _ := time.ParseInLocation(time.DateOnly, t, time.Local)
						cell.SetDateWithOptions(td, xlsx.DateTimeOptions{
							ExcelTimeFormat: "yyyy-mm-dd",
							Location:        zhTZ,
						})
					} else {
						cell.SetString(t)
					}
					// 设置单元格样式
					style = cell.GetStyle()
					style.Alignment = xlsx.Alignment{
						Horizontal: "center", // 水平居中
						Vertical:   "center", // 垂直居中
					}
				} else {
					v := utils.Convert2Float64(val)
					cell.SetFloat(v)
					cell.SetFormat("#,##0.00")
				}
			} else {
				cell.SetValue("")
			}
		}
	}

	//导出文件
	ua := c.Request.UserAgent()
	fileName := "投放ROI数据报表_" + req.StartDate + "~" + req.EndDate + ".xlsx"
	encodedFileName := strings.Replace(url.QueryEscape(fileName), "+", "20%", -1)
	if strings.Contains(ua, "MSIE") || strings.Contains(ua, "Trident") { // for IE
		c.Header("Content-Disposition", "attachment; filename=\""+url.PathEscape(fileName)+"\"")
	} else if strings.Contains(ua, "Firefox") { // for Firefox
		c.Header("Content-Disposition", "attachment; filename*=UTF-8''"+encodedFileName)
	} else if strings.Contains(ua, "Chrome") || strings.Contains(ua, "Safari") { // for Chrome and Safari
		c.Header("Content-Disposition", "attachment; filename=\""+fileName+"\"; filename*=UTF-8''"+encodedFileName)
	} else { // for other browsers
		c.Header("Content-Disposition", "attachment; filename=\""+fileName+"\"")
	}
	c.Header("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	c.Header("Content-Transfer-Encoding", "binary")
	c.Header("Cache-Control", "max-age=0")
	c.Header("Pragma", "no-cache")
	//文件内容写入返回体
	if err := file.Write(c.Writer); err != nil {
		r.Response(myerror.ExportExcelError.Code, err.Error(), nil)
		return
	}
	c.Status(http.StatusOK)
	c.Abort()
	//r.Response(myerror.OK.Code, myerror.OK.Message, nil)
}
