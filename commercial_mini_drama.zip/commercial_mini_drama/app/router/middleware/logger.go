package middleware

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/sirupsen/logrus"
	"goserver/app/library/log"
	"goserver/app/library/utils/time"
	"io/ioutil"
)

type bodyLogWriter struct {
	gin.ResponseWriter
	body *bytes.Buffer
}

func (w bodyLogWriter) Write(b []byte) (int, error) {
	w.body.Write(b)
	return w.ResponseWriter.Write(b)
}

func (w bodyLogWriter) WriteString(s string) (int, error) {
	w.body.WriteString(s)
	return w.ResponseWriter.WriteString(s)
}

// 日志记录到文件
func LoggerMiddleware() gin.HandlerFunc {
	return func(c *gin.Context) {
		//hack gin writer, record return data
		bodyLogWriter := &bodyLogWriter{body: bytes.NewBufferString(""), ResponseWriter: c.Writer}
		c.Writer = bodyLogWriter

		reqBody := []byte{}
		if c.Request.Method == "POST" {
			reqBody, _ = ioutil.ReadAll(c.Request.Body)
			c.Request.Body = ioutil.NopCloser(bytes.NewBuffer(reqBody))
		}
		if c.Request.Method == "GET" {
			reqBody = []byte(c.Request.URL.Query().Encode())
		}

		req := logrus.Fields{}
		json.Unmarshal([]byte(reqBody), &req)

		// 开始时间
		startTime := time.NowInMillSecond()
		// 处理请求
		c.Next()
		// 结束时间
		endTime := time.NowInMillSecond()
		responseBody := bodyLogWriter.body.String()
		res := logrus.Fields{}
		json.Unmarshal([]byte(responseBody), &res)

		// 执行时间
		latencyTime := endTime - startTime
		cost := fmt.Sprintf("%dms", latencyTime)
		// 请求方式
		reqMethod := c.Request.Method
		// 请求路由
		reqUri := c.Request.RequestURI
		// 状态码
		statusCode := c.Writer.Status()
		// 请求IP
		clientIP := c.ClientIP()

		// 日志格式
		log.LogrusEventLog.WithFields(logrus.Fields{
			"client_ip":    clientIP,
			"req_method":   reqMethod,
			"req_uri":      reqUri,
			"status_code":  statusCode,
			"latency_time": cost,
			"request":      req,
			"response":     res,
		}).Info()
	}
}
