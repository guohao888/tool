package fanqie

import (
	"github.com/gin-gonic/gin"
	"goserver/app/common"
	"goserver/app/library/myerror"
)

// IAACoefficientReq 新增
type IAACoefficientReq struct {
	common.CommonParams
	SearchDate  string  `json:"search_date" form:"search_date"` // 日期
	Coefficient float64 `json:"coefficient" form:"coefficient"` // 系数
}

// IAACoefficientFilter 查询
type IAACoefficientFilter struct {
	common.CommonParams
	common.Pagination        // 分页
	StartDate         string `json:"start_date" form:"start_date"`
	EndDate           string `json:"end_date" form:"end_date"`
}

// IAACoefficientResp 查询返回
type IAACoefficientResp struct {
	SearchDate        string  `json:"search_date" form:"search_date"` // 日期
	Coefficient       float64 `json:"coefficient" form:"coefficient"` // 系数
	common.Pagination         // 分页
}

func NewIAACoefficientQuery(c *gin.Context) *IAACoefficientFilter {
	req := &IAACoefficientFilter{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	return req
}

// NewIAACoefficientReq 解析绑定IAA系数参数
func NewIAACoefficientReq(c *gin.Context) *IAACoefficientReq {
	req := &IAACoefficientReq{}
	if err := c.ShouldBindJSON(req); err != nil {
		panic(myerror.ParamsError)
	}
	req.UserInfo = common.GetUserInfo(c)
	return req
}
