package mediareport

import (
	"context"
	"fmt"
	"github.com/oceanengine/ad_open_sdk_go/models"
	"github.com/panjf2000/ants/v2"
	repo "goserver/app/common/repository"
	mediaRepo "goserver/app/common/repository/mediareport"
	"goserver/app/library/playlet/toutiao"
	"goserver/app/model/dao"
	accountdao "goserver/app/model/dao/accounts"
	mediadao "goserver/app/model/dao/mediareport"
	"strconv"
	"strings"
	"sync"
	"time"
)

type VideoFileService struct {
	Ctx context.Context
}

func NewVideoFileService(ctx context.Context) *VideoFileService {
	return &VideoFileService{Ctx: ctx}
}

/***********************         新授权逻辑 令牌桶方式获取素材  start       ***********************/

func (v *VideoFileService) DistributeVideoAccounts(crontabTime time.Time, ctx context.Context) error {
	// 获取执行时间
	startDate, _ := GetExecTime(crontabTime)
	videoDao := mediadao.NewVideoFileDao(v.Ctx)
	// 获取有消耗账号
	activeList, acErr := videoDao.GetAccountAndUser(startDate)
	if acErr != nil {
		return acErr
	}
	// 列表为空 直接返回
	if len(activeList) == 0 {
		return fmt.Errorf("查询活跃账号为空")
	}
	materialList, err := videoDao.GetAccountAndMaterialIds(startDate)
	if err != nil {
		return err
	}
	oauthDao := accountdao.NewOauthDao(ctx)
	// 获取所有应用ID
	appIds, appErr := oauthDao.DistinctAppIds(repo.MediaToutiao)
	if appErr != nil {
		return fmt.Errorf("查询AppId 列表失败, err: %v", appErr)
	}
	// 获取所有token
	oauthList, oauthErr := oauthDao.ListOauthByMediaAppIds(repo.MediaToutiao, []string{})
	if oauthErr != nil {
		return fmt.Errorf("查询token 列表失败, err: %v", oauthErr)
	}
	// 列表为空 直接返回
	if len(oauthList) == 0 {
		return fmt.Errorf("查询token 列表为空")
	}
	// token映射
	oauthMap := make(map[string]map[string]string)
	for _, vv := range appIds {
		oauthMap[vv] = make(map[string]string)
	}
	for _, vv := range oauthList {
		oauthMap[vv.AppId][vv.UserId] = vv.AccessToken
	}

	m := make(map[string][]int64)
	for _, vv := range materialList {
		m[vv.AdvertiserId] = append(m[vv.AdvertiserId], vv.MaterialId)
	}

	var wg sync.WaitGroup

	// 分片算法
	perAppCount := len(activeList) / len(appIds)
	remainder := len(activeList) % len(appIds)

	currentIndex := 0
	for _, appId := range appIds {
		wg.Add(1)
		// 为每个goroutine创建局部变量
		currentAppId := appId
		sliceSize := perAppCount

		if remainder > 0 {
			sliceSize++
			remainder--
		}

		go func(start, end int) {
			defer wg.Done()
			// 验证token存在性
			oauth, exists := oauthMap[currentAppId]
			if !exists {
				return
			}
			SyncVideoFile(activeList[start:end], m, oauth, currentAppId)
		}(currentIndex, currentIndex+sliceSize)
		currentIndex += sliceSize
	}
	wg.Wait()
	return nil
}

// SyncVideoFile 同步拉取头条视频素材数据
func SyncVideoFile(activeList []mediaRepo.AdvertiserIdsAndMaterialIdsNew, m map[string][]int64, oauth map[string]string, appId string) {

	resChan := make(chan *mediaRepo.VideoFileEntity)
	errChan := make(chan error, len(activeList)) // 缓冲通道避免阻塞

	p, _ := ants.NewPool(10)
	defer p.Release()
	var once sync.Once
	wg := new(sync.WaitGroup)

	once.Do(func() {
		go func() {
			// 保存数据到SR
			insertErr := execVideoDB(context.Background(), resChan)
			if insertErr != nil {
				errChan <- insertErr
			}
		}()
	})
	// 获取所有活跃账号及token 请求接口数据
	for _, active := range activeList {
		wg.Add(1)
		currentAccount := active
		task := func() {
			advertiserId, _ := strconv.Atoi(currentAccount.AdvertiserId)
			advertiserIdStr := currentAccount.AdvertiserId
			userId := currentAccount.UserId
			defer func() {
				if x := recover(); x != nil {
					errChan <- fmt.Errorf("recover %s", x)
				}
				defer wg.Done()
			}()

			materialIds, mok := m[advertiserIdStr]
			if !mok {
				errChan <- fmt.Errorf("没有获取到对应的materialIds信息, %s", advertiserIdStr)
				return
			}
			// 验证token存在性
			_, exists := oauth[userId]
			if !exists {
				return
			}

			// 如果materialIds 长度超过100  分批执行
			batchPage := dao.BatchPage(len(materialIds), 99)
			for i := 0; i < batchPage; i++ {
				start := i * 99
				end := (i + 1) * 99
				if end > len(materialIds) {
					end = len(materialIds)
				}

				// 获取账号下 startDate ~ endDate 所有视频素材
				allVideos, getErr := execQueryVideo(context.Background(), oauth[userId], int64(advertiserId), materialIds[start:end], appId)
				if getErr != nil {
					errChan <- fmt.Errorf("视频素材请求失败, advertiserId: %d, token: %s, appId: %s, err: %s", advertiserId, oauth[userId], appId, getErr.Error())
					return
				}
				// 查询无数据直接返回
				if allVideos == nil {
					return
				}
				for _, row := range allVideos {
					fileCutter := strings.Split(*row.Filename, "_")[0]
					creatTime, _ := time.ParseInLocation(time.DateTime, *row.CreateTime, time.Local)
					info := &mediaRepo.VideoFileEntity{
						AdvertiserId: advertiserIdStr,
						MaterialId:   *row.MaterialId,
						VideoId:      *row.Id,
						CreateTime:   creatTime,
						Filename:     *row.Filename,
						Width:        *row.Width,
						Size:         *row.Size,
						Duration:     *row.Duration,
						Format:       *row.Format,
						BitRate:      *row.BitRate,
						Height:       *row.Height,
						Url:          *row.Url,
						PosterUrl:    *row.PosterUrl,
						Signature:    *row.Signature,
						Source:       *row.Source,
						FileCutter:   fileCutter,
					}
					resChan <- info
				}
			}
		}
		if submitErr := p.Submit(task); submitErr != nil {
			wg.Done() // 提交失败，减少计数器
			errChan <- fmt.Errorf("submit task failed: %w", submitErr)
		}
	}
	// 等待任务完成并关闭通道
	go func() {
		wg.Wait()
		close(resChan)
		close(errChan)
	}()

	// 收集所有错误
	var errs []error
	for errL := range errChan {
		errs = append(errs, errL)
	}

	if len(errs) > 0 {
		_ = sendMsg(errs, "同步视频信息\n")
	}
	return
}

/***********************         新授权逻辑 令牌桶方式获取素材  end       ***********************/

// execQueryVideo 请求巨量接口 获取账号下所有素材数据
func execQueryVideo(ctx context.Context, accessToken string, advertiserId int64, materialIds []int64, appId string) (allVideos toutiao.VideoRows, err error) {
	allVideos, err = toutiao.AllFileVideoGetV2(ctx, toutiao.FileVideoGetReq{
		AccessToken:  accessToken,
		AdvertiserId: advertiserId,
		Filtering: models.FileVideoGetV2Filtering{
			MaterialIds: materialIds,
		},
	}, appId)
	if err != nil {
		return
	}
	return
}

// execVideoDB 保存数据到SR
func execVideoDB(cxt context.Context, resChan <-chan *mediaRepo.VideoFileEntity) (err error) {
	videoFileDao := mediadao.NewVideoFileDao(cxt)
	// 2.3 将数据写入 report_hour
	var data = make([]*mediaRepo.VideoFileEntity, 0, 5000)
	var errs []error
	for row := range resChan {
		data = append(data, row)
		if len(data) >= 5000 {
			err = videoFileDao.InsertBatchSize(data, 5000)
			if err != nil {
				errs = append(errs, err)
			}
			data = data[:0]
		}
	}
	if len(data) > 0 {
		err = videoFileDao.InsertBatchSize(data, 5000)
		if err != nil {
			errs = append(errs, err)
		}
	}
	if len(errs) > 0 {
		return fmt.Errorf("execVideoDB errors: %v", errs)
	}
	return nil
}
