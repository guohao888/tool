package utils

func GetTotalPage[T int | int64](totalCount T, pageSize T) T {
	if totalCount == 0 || pageSize == 0 {
		return 0
	}

	if totalCount%pageSize == 0 {
		return totalCount / pageSize
	} else {
		return totalCount/pageSize + 1
	}
}
