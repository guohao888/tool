package toutiao

import (
	"context"
	"errors"
	"fmt"
	"goserver/app/library/log"
	"goserver/app/library/playlet/cache"
	"time"

	"github.com/avast/retry-go"
	"github.com/oceanengine/ad_open_sdk_go/models"
)

const (
	OpenApiV30ToolsWechatAppletList = "/open_api/v3.0/tools/wechat_applet/list/" // 获取微信小程序列表
	OpenApiV30ToolsMicroAppList     = "/open_api/v3.0/tools/micro_app/list/"     // 获取字节小程序
	OpenApiV30ToolsAssetLinkList    = "/open_api/v3.0/tools/asset_link/list/"    // 获取字节小程序/小游戏详情内容
	OpenApiV30ToolsMicroAppUpdate   = "/open_api/v3.0/tools/micro_app/update/"   // 更新字节小程序
	CreatePromotionCase             = "CreatePromotionCase"                      // 创建推广场景
)

type ToolsWechatAppletListReq struct {
	AccessToken  string
	AdvertiserId int64
	Filtering    *models.ToolsWechatAppletListV30Filtering
	Page         int32
	PageSize     int32
}

type ToolsMicroAppUpdateReq struct {
	AdvertiserId      int64
	AccessToken       string
	InstanceId        int64
	TagInfo           string
	AppPageLink       string
	AppPageRemark     string
	AppPageStartPage  string
	AppPageStartParam string
}

func backOff(n uint) time.Duration {
	// 基础退避时间（例如1毫秒）
	delay := 1 * time.Second
	return delay
}

// ToolsMicroAppUpdate 更新字节小程序
func ToolsMicroAppUpdate(ctx context.Context, req ToolsMicroAppUpdateReq) error {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiV30ToolsMicroAppUpdate)
	appPage := &models.ToolsMicroAppUpdateV30RequestAppPageInner{
		Link:        req.AppPageLink,
		Remark:      req.AppPageRemark,
		StartPage:   &req.AppPageStartPage,
		StartParam:  &req.AppPageStartParam,
		OperateType: "NEW",
	}

	request := models.ToolsMicroAppUpdateV30Request{
		AdvertiserId: req.AdvertiserId,
		InstanceId:   req.InstanceId,
		TagInfo:      req.TagInfo,
		AppPage:      []*models.ToolsMicroAppUpdateV30RequestAppPageInner{appPage},
	}
	err := retry.Do(func() error {
		resp, _, e := apiClient.ToolsMicroAppUpdateV30Api().
			Post(ctx).
			AccessToken(req.AccessToken).
			ToolsMicroAppUpdateV30Request(request).
			Execute()
		if e != nil {
			log.Errorf("ToolsMicroAppUpdate 更新字节小程序失败 %s, AdvertiserId:%d, InstanceId:%d", e.Error(), req.AdvertiserId, req.InstanceId)
			return e
		}
		if *resp.Code == CodeError40000 {
			log.Errorf("ToolsMicroAppUpdate 更新字节小程序失败 %s, AdvertiserId:%d, InstanceId:%d", *resp.Message, req.AdvertiserId, req.InstanceId)
			return nil
		}
		if *resp.Code == CodeError40002 {
			return nil
		}
		if *resp.Code == CodeErrorOnManyRequests {
			return fmt.Errorf("ToolsMicroAppUpdate 更新字节小程序失败, %w, code: %d, message: %s", RespCodeErrorToManyRequests, *resp.Code, *resp.Message)
		}
		if *resp.Code == CodeErrorAccessToken {
			return fmt.Errorf("ToolsMicroAppUpdate 更新字节小程序失败, %w, code: %d, message: %s", RespCodeErrorAccessToken, *resp.Code, *resp.Message)
		}
		if *resp.Code != CodeSuccess {
			return fmt.Errorf("ToolsMicroAppUpdate 更新字节小程序失败, %w, code: %d, message: %s", RespCodeError, *resp.Code, *resp.Message)
		}
		return nil
	},
		retry.Attempts(5),
		retry.DelayType(func(n uint, err error, config *retry.Config) time.Duration {
			if errors.Is(err, RespCodeErrorToManyRequests) {
				return backOff(n)
			}

			return time.Second * 3
		}),
		retry.RetryIf(func(err error) bool {
			if errors.Is(err, RespCodeErrorAccessToken) {
				return false
			}
			return true
		}),
	)

	return err
}

// ToolsWechatAppletList
// 获取微信小程序列表
// https://open.oceanengine.com/labels/7/docs/1771203622020111?origin=left_nav
func ToolsWechatAppletList(ctx context.Context, req ToolsWechatAppletListReq) (*models.ToolsWechatAppletListV30Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiV30ToolsWechatAppletList)

	var resp *models.ToolsWechatAppletListV30Response
	err := retry.Do(func() error {
		latestAccessToken, e := cache.GetLatestAccessToken(req.AccessToken)
		if e != nil {
			return e
		}

		request := apiClient.ToolsWechatAppletListV30Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(req.AdvertiserId)

		if req.Filtering != nil {
			request = request.Filtering(*req.Filtering)
		}
		if req.Page > 0 {
			request = request.Page(req.Page)
		}
		if req.PageSize > 0 {
			request = request.PageSize(req.PageSize)
		}

		resp, _, e = request.Execute()
		if e != nil {
			return e
		}
		if resp == nil {
			return fmt.Errorf("获取微信小程序列表失败, %w", RespStructError)
		}
		// 这个接口也有广告主账户删除的情况，错误会有
		// 1. code: 40002, message: 鉴权失败，请检查参数传入是否正确。
		// 2. code: 40002, message: Account 1828983243159619 doesn't exist or the role is wrong
		if *resp.Code == CodeError40002 {
			return nil
		}
		if *resp.Code == CodeErrorOnManyRequests {
			return fmt.Errorf("获取微信小程序列表错误, %w, code: %d, message: %s", RespCodeErrorToManyRequests, *resp.Code, *resp.Message)
		}
		if *resp.Code == CodeErrorAccessToken {
			return fmt.Errorf("获取微信小程序列表错误, %w, code: %d, message: %s", RespCodeErrorAccessToken, *resp.Code, *resp.Message)
		}
		if *resp.Code != CodeSuccess {
			return fmt.Errorf("获取微信小程序列表错误, %w, code: %d, message: %s", RespCodeError, *resp.Code, *resp.Message)
		}
		return nil
	},
		retry.Attempts(5),
		retry.DelayType(func(n uint, err error, config *retry.Config) time.Duration {
			if errors.Is(err, RespCodeErrorToManyRequests) {
				return backOff(n)
			}

			return time.Second * 3
		}),
		retry.RetryIf(func(err error) bool {
			if errors.Is(err, RespCodeErrorAccessToken) {
				return false
			}
			return true
		}),
	)

	return resp, err
}

type AllToolsWechatAppletListReq struct {
	AccessToken  string
	AdvertiserId int64
	Filtering    *models.ToolsWechatAppletListV30Filtering
}

func AllToolsWechatAppletList(ctx context.Context, req AllToolsWechatAppletListReq) ([]*models.ToolsWechatAppletListV30ResponseDataListInner, error) {
	var list []*models.ToolsWechatAppletListV30ResponseDataListInner

	page := int32(1)
	pageSizeMax := int32(100)

	for {
		resp, err := ToolsWechatAppletList(ctx, ToolsWechatAppletListReq{
			AccessToken:  req.AccessToken,
			AdvertiserId: req.AdvertiserId,
			Filtering:    req.Filtering,
			Page:         page,
			PageSize:     pageSizeMax,
		})
		if err != nil {
			return nil, err
		}
		if resp.Data == nil || resp.Data.List == nil || resp.Data.PageInfo == nil || resp.Data.PageInfo.TotalPage == nil {
			return nil, nil
		}

		list = append(list, resp.Data.List...)

		if int32(len(resp.Data.List)) < pageSizeMax || int32(len(resp.Data.List)) == *resp.Data.PageInfo.TotalPage {
			break
		}

		page++
	}

	return list, nil
}

type ToolsAssetLinkListReq struct {
	AccessToken  string
	AdvertiserId int64
	Filtering    *models.ToolsAssetLinkListV30Filtering
	Page         int32
	PageSize     int32
}

// ToolsAssetLinkList
// 获取字节小程序/小游戏详情内容
// https://open.oceanengine.com/labels/7/docs/1778265753535620
func ToolsAssetLinkList(ctx context.Context, req ToolsAssetLinkListReq) (*models.ToolsAssetLinkListV30Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiV30ToolsAssetLinkList)

	var resp *models.ToolsAssetLinkListV30Response
	err := retry.Do(func() error {
		latestAccessToken, e := cache.GetLatestAccessToken(req.AccessToken)
		if e != nil {
			return e
		}

		request := apiClient.ToolsAssetLinkListV30Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(req.AdvertiserId)

		if req.Filtering != nil {
			request = request.Filtering(*req.Filtering)
		}
		if req.Page > 0 {
			request = request.Page(req.Page)
		}
		if req.PageSize > 0 {
			request = request.PageSize(req.PageSize)
		}

		resp, _, e = request.Execute()
		if e != nil {
			return e
		}
		if resp == nil {
			return fmt.Errorf("获取字节小程序/小游戏详情内容失败, %w", RespStructError)
		}
		if *resp.Code == CodeError40002 {
			return nil
		}
		if *resp.Code == CodeErrorOnManyRequests {
			return fmt.Errorf("获取字节小程序/小游戏详情内容错误, %w, code: %d, message: %s", RespCodeErrorToManyRequests, *resp.Code, *resp.Message)
		}
		if *resp.Code == CodeErrorAccessToken {
			return fmt.Errorf("获取字节小程序/小游戏详情内容错误, %w, code: %d, message: %s", RespCodeErrorAccessToken, *resp.Code, *resp.Message)
		}
		if *resp.Code != CodeSuccess {
			return fmt.Errorf("获取字节小程序/小游戏详情内容错误, %w, code: %d, message: %s", RespCodeError, *resp.Code, *resp.Message)
		}
		return nil
	},
		retry.Attempts(5),
		retry.DelayType(func(n uint, err error, config *retry.Config) time.Duration {
			if errors.Is(err, RespCodeErrorToManyRequests) {
				return backOff(n)
			}

			return time.Second * 3
		}),
		retry.RetryIf(func(err error) bool {
			if errors.Is(err, RespCodeErrorAccessToken) {
				return false
			}
			return true
		}),
	)

	return resp, err
}

type AllToolsAssetLinkListInstanceIdsReq struct {
	AccessToken  string
	AdvertiserId int64
	Filtering    *models.ToolsAssetLinkListV30Filtering
	InstanceIds  []int64
}

func AllToolsAssetLinkListByInstanceIds(ctx context.Context, req AllToolsAssetLinkListInstanceIdsReq) ([]*models.ToolsAssetLinkListV30ResponseDataListInner, error) {
	var list []*models.ToolsAssetLinkListV30ResponseDataListInner

	for _, instanceId := range req.InstanceIds {
		page := int32(1)
		pageSizeMax := int32(100)

		for {
			resp, err := ToolsAssetLinkList(ctx, ToolsAssetLinkListReq{
				AccessToken:  req.AccessToken,
				AdvertiserId: req.AdvertiserId,
				Filtering: &models.ToolsAssetLinkListV30Filtering{
					InstanceId: instanceId,
				},
				Page:     page,
				PageSize: pageSizeMax,
			})
			if err != nil {
				return nil, err
			}
			if resp.Data == nil || resp.Data.List == nil || resp.Data.PageInfo == nil || resp.Data.PageInfo.TotalPage == nil {
				return nil, nil
			}

			list = append(list, resp.Data.List...)

			if int32(len(resp.Data.List)) < pageSizeMax || int32(len(resp.Data.List)) == *resp.Data.PageInfo.TotalPage {
				break
			}

			page++
		}
	}

	return list, nil
}

type ToolsMicroAppListReq struct {
	AccessToken  string
	AdvertiserId int64
	Filtering    *models.ToolsMicroAppListV30Filtering
	Page         int32
	PageSize     int32
}

// ToolsMicroAppList
// 获取字节小程序
// https://open.oceanengine.com/labels/7/docs/1778249831680135?origin=left_nav
func ToolsMicroAppList(ctx context.Context, req ToolsMicroAppListReq) (*models.ToolsMicroAppListV30Response, error) {
	ctx = context.WithValue(ctx, CtxPathKey, OpenApiV30ToolsMicroAppList)

	var resp *models.ToolsMicroAppListV30Response
	err := retry.Do(func() error {
		var latestAccessToken string
		var e error
		if ctx.Value(CreatePromotionCase) != nil {
			latestAccessToken = req.AccessToken
		} else {
			latestAccessToken, e = cache.GetLatestAccessToken(req.AccessToken)
			if e != nil {
				return e
			}
		}

		request := apiClient.ToolsMicroAppListV30Api().
			Get(ctx).
			AccessToken(latestAccessToken).
			AdvertiserId(req.AdvertiserId)

		if req.Filtering != nil {
			request = request.Filtering(*req.Filtering)
		}
		if req.Page > 0 {
			request = request.Page(req.Page)
		}
		if req.PageSize > 0 {
			request = request.PageSize(req.PageSize)
		}

		resp, _, e = request.Execute()
		if e != nil {
			return e
		}
		if resp == nil {
			return fmt.Errorf("获取字节小程序失败, %w", RespStructError)
		}
		if *resp.Code == CodeError40002 {
			return nil
		}
		if *resp.Code == CodeErrorOnManyRequests {
			return fmt.Errorf("获取字节小程序错误, %w, code: %d, message: %s", RespCodeErrorToManyRequests, *resp.Code, *resp.Message)
		}
		if *resp.Code == CodeErrorAccessToken {
			return fmt.Errorf("获取字节小程序错误, %w, code: %d, message: %s", RespCodeErrorAccessToken, *resp.Code, *resp.Message)
		}
		if *resp.Code != CodeSuccess {
			return fmt.Errorf("获取字节小程序错误, %w, code: %d, message: %s", RespCodeError, *resp.Code, *resp.Message)
		}
		return nil
	},
		retry.Attempts(5),
		retry.DelayType(func(n uint, err error, config *retry.Config) time.Duration {
			if errors.Is(err, RespCodeErrorToManyRequests) {
				return backOff(n)
			}

			return time.Second * 3
		}),
		retry.RetryIf(func(err error) bool {
			if errors.Is(err, RespCodeErrorAccessToken) {
				return false
			}
			return true
		}),
	)

	return resp, err
}

type AllToolsMicroAppListReq struct {
	AccessToken  string
	AdvertiserId int64
	Filtering    *models.ToolsMicroAppListV30Filtering
}

type ToolsMicroAppListV30ResponseDataListInnerList []*models.ToolsMicroAppListV30ResponseDataListInner

func (l ToolsMicroAppListV30ResponseDataListInnerList) GetInstanceIds() []int64 {
	m := make(map[int64]struct{})
	var instanceIds []int64
	for _, v := range l {
		if _, ok := m[*v.InstanceId]; !ok {
			instanceIds = append(instanceIds, *v.InstanceId)
			m[*v.InstanceId] = struct{}{}
		}
	}
	return instanceIds
}

func AllToolsMicroAppList(ctx context.Context, req AllToolsMicroAppListReq) (ToolsMicroAppListV30ResponseDataListInnerList, error) {
	var list ToolsMicroAppListV30ResponseDataListInnerList

	page := int32(1)
	pageSizeMax := int32(100)

	for {
		resp, err := ToolsMicroAppList(ctx, ToolsMicroAppListReq{
			AccessToken:  req.AccessToken,
			AdvertiserId: req.AdvertiserId,
			Filtering:    req.Filtering,
			Page:         page,
			PageSize:     pageSizeMax,
		})
		if err != nil {
			return nil, err
		}
		if resp.Data == nil || resp.Data.List == nil || resp.Data.PageInfo == nil || resp.Data.PageInfo.TotalPage == nil {
			return nil, nil
		}

		list = append(list, resp.Data.List...)

		if int32(len(resp.Data.List)) < pageSizeMax || int32(len(resp.Data.List)) == *resp.Data.PageInfo.TotalPage {
			break
		}

		page++
	}

	return list, nil
}
