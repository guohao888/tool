package kuaishou

import (
	"goserver/app/common/repository"
	"time"
)

const AccountInfo = "kuaishou_account_info"

type AccountInfoEntity struct {
	AdvertiserId int64     `gorm:"column:advertiser_id"` // 用户快手号id
	AccountId    int64     `gorm:"column:account_id"`    // 账户id
	AccountName  string    `gorm:"column:account_name"`  // 账户名称
	CreatedAt    time.Time `gorm:"column:created_at"`    // 创建时间
	UpdatedAt    time.Time `gorm:"column:updated_at"`    // 更新时间
}

func (*AccountInfoEntity) TableName() string {
	return AccountInfo
}

func AccountInfoTableName() string {
	if repository.IsDebugTable(AccountInfo) {
		return AccountInfo // + "_dev"
	} else {
		return AccountInfo
	}
}
