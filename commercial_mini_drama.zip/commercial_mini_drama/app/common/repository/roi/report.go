package roi

import (
	"github.com/shopspring/decimal"
	"goserver/app/common/repository"
	"time"
)

const ReportDataTable = "roi_report"

type ReportDataEntity struct {
	PointTime        time.Time       `gorm:"column:point_time"`         // 时间点
	Media            string          `gorm:"column:media"`              // 媒体
	CampaignId       int64           `gorm:"column:campaign_id"`        // 推广计划id
	GroupId          int64           `gorm:"column:group_id"`           // 推广组id
	AdCreativeId     int64           `gorm:"column:adcreative_id"`      // 创意id
	AccountId        string          `gorm:"column:account_id"`         // 账户id
	Cost             decimal.Decimal `gorm:"column:cost"`               // 花费
	ShowCount        int             `gorm:"column:show_count"`         // 曝光数量
	ClickCount       int             `gorm:"column:click_count"`        // 点击数量
	DownloadCount    int             `gorm:"column:download_count"`     // 下载数量
	ActiveCount      int             `gorm:"column:active_count"`       // 媒体激活数量
	PayCount         int             `gorm:"column:pay_count"`          // 媒体付费认数量
	KeyBehaviorCount int             `gorm:"column:key_behavior_count"` // 媒体关键行为数量
	CampaignName     string          `gorm:"column:campaign_name"`      // 推广计划
	GroupName        string          `gorm:"column:group_name"`         // 推广组
	AdCreativeName   string          `gorm:"column:adcreative_name"`    // 创意
	Source           int             `gorm:"column:source"`             // 数据来源 1:api
	PointDate        time.Time       `gorm:"column:point_date"`         // 日期
	Platform         string          `gorm:"column:platform"`           // 平台
}

func (*ReportDataEntity) TableName() string {
	return ReportDataTableName()
}

func ReportDataTableName() string {
	if repository.IsDebugTable(ReportDataTable) {
		return ReportDataTable + "_dev"
	} else {
		return ReportDataTable
	}
}
